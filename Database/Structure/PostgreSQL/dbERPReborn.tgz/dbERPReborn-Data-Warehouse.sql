--
-- PostgreSQL database dump
--

\restrict nhzu5sLfJv6wCYclQ6WF2esp88qqNo9kjXx36BIG5j6IouzbKRZJnTLmqPApT2v

-- Dumped from database version 18.7 (Debian 18.7-1.pgdg13+2)
-- Dumped by pg_dump version 18.7 (Debian 18.7-1.pgdg13+2)

-- Started on 2026-11-26 18:47:28 WIB

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 9 (class 2615 OID 6653616)
-- Name: SchAcquisition; Type: SCHEMA; Schema: -; Owner: SysEngine
--

CREATE SCHEMA "SchAcquisition";


ALTER SCHEMA "SchAcquisition" OWNER TO "SysEngine";

--
-- TOC entry 10 (class 2615 OID 6653617)
-- Name: SchCache; Type: SCHEMA; Schema: -; Owner: SysAdmin
--

CREATE SCHEMA "SchCache";


ALTER SCHEMA "SchCache" OWNER TO "SysAdmin";

--
-- TOC entry 11 (class 2615 OID 6653618)
-- Name: SchLock; Type: SCHEMA; Schema: -; Owner: SysAdmin
--

CREATE SCHEMA "SchLock";


ALTER SCHEMA "SchLock" OWNER TO "SysAdmin";

--
-- TOC entry 12 (class 2615 OID 6653619)
-- Name: SchLog; Type: SCHEMA; Schema: -; Owner: SysEngine
--

CREATE SCHEMA "SchLog";


ALTER SCHEMA "SchLog" OWNER TO "SysEngine";

--
-- TOC entry 13 (class 2615 OID 6653620)
-- Name: SchRecovery; Type: SCHEMA; Schema: -; Owner: SysAdmin
--

CREATE SCHEMA "SchRecovery";


ALTER SCHEMA "SchRecovery" OWNER TO "SysAdmin";

--
-- TOC entry 14 (class 2615 OID 6653621)
-- Name: SchSystem; Type: SCHEMA; Schema: -; Owner: SysEngine
--

CREATE SCHEMA "SchSystem";


ALTER SCHEMA "SchSystem" OWNER TO "SysEngine";

--
-- TOC entry 2 (class 3079 OID 6653622)
-- Name: dblink; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS dblink WITH SCHEMA public;


--
-- TOC entry 3766 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION dblink; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION dblink IS 'connect to other PostgreSQL databases from within a database';


--
-- TOC entry 3 (class 3079 OID 6653668)
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA public;


--
-- TOC entry 3767 (class 0 OID 0)
-- Dependencies: 3
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- TOC entry 4 (class 3079 OID 6653712)
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- TOC entry 3768 (class 0 OID 0)
-- Dependencies: 4
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- TOC entry 1044 (class 1247 OID 6653752)
-- Name: HoldFuncSys_General_FeedBackQuery; Type: TYPE; Schema: SchSystem; Owner: SysEngine
--

CREATE TYPE "SchSystem"."HoldFuncSys_General_FeedBackQuery" AS (
	"SignSuccess" smallint,
	"SignRecordType" character varying,
	"SignRecordID" bigint,
	"SignMessage" character varying,
	"AdditionalData" json
);


ALTER TYPE "SchSystem"."HoldFuncSys_General_FeedBackQuery" OWNER TO "SysEngine";

--
-- TOC entry 1047 (class 1247 OID 6653755)
-- Name: HoldFuncSys_General_GetDataPickSet; Type: TYPE; Schema: SchSystem; Owner: SysEngine
--

CREATE TYPE "SchSystem"."HoldFuncSys_General_GetDataPickSet" AS (
	"Sys_ID" bigint,
	"ProcessedData_FlatText" character varying,
	"ProcessedData_TextArray" character varying[],
	"ProcessedData_JSON" json,
	"RawData_JSON" json
);


ALTER TYPE "SchSystem"."HoldFuncSys_General_GetDataPickSet" OWNER TO "SysEngine";

--
-- TOC entry 1050 (class 1247 OID 6653758)
-- Name: HoldFuncSys_General_GetEnvironmentParameterExtraction; Type: TYPE; Schema: SchSystem; Owner: SysAdmin
--

CREATE TYPE "SchSystem"."HoldFuncSys_General_GetEnvironmentParameterExtraction" AS (
	"Env_Session" json,
	"DBLinkConnectionString_FE" character varying,
	"DBLinkConnectionString_BE_DataOLAP" character varying,
	"DBLinkConnectionString_BE_DataOLTP" character varying,
	"DBLinkConnectionString_BE_DataWarehouse" character varying,
	"DBLinkConnectionString_BE_SysConfig" character varying,
	"Pagination_PageSize" bigint,
	"Pagination_PageShow" bigint,
	"DataCustomize_Filter_JSON" json,
	"DataCustomize_Filter" character varying,
	"DataCustomize_Sort_JSON" json,
	"DataCustomize_Sort" character varying,
	"DataCustomize_Filter_CoreFields_JSON" json,
	"DataCustomize_Filter_CoreFields" character varying,
	"DataCustomize_Sort_CoreFields_JSON" json,
	"DataCustomize_Sort_CoreFields" character varying,
	"DataCustomize_Filter_NonCoreFields_JSON" json,
	"DataCustomize_Filter_NonCoreFields" character varying,
	"DataCustomize_Sort_NonCoreFields_JSON" json,
	"DataCustomize_Sort_NonCoreFields" character varying,
	"Array_SysBranch_RefID" bigint[],
	"Array_SysBaseBranch_RefID" bigint[],
	"Array_Currency_RefID" bigint[],
	"Array_CurrencyISOCode" character varying(3)[],
	"Array_CurrencySymbol" character varying(4)[]
);


ALTER TYPE "SchSystem"."HoldFuncSys_General_GetEnvironmentParameterExtraction" OWNER TO "SysAdmin";

--
-- TOC entry 320 (class 1255 OID 6653759)
-- Name: Func_SQLGenerator_DataList_FileUploads(bigint, bigint, bigint[], json); Type: FUNCTION; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE FUNCTION "SchAcquisition"."Func_SQLGenerator_DataList_FileUploads"(bigint, bigint, bigint[] DEFAULT NULL::bigint[], json DEFAULT NULL::json) RETURNS character varying
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchAcquisition"."Func_SQLGenerator_DataList_FileUploads"
▪ Versi               :	1.01.0000
▪ Tanggal
     ► Pemutakhiran   :	2026-07-07
     ► Pembuatan      :	2025-11-14
▪ Input               :	• varSysDataReadLoginSession_RefID (bigint - Mandatory)
						• varSysBranch_RefID (bigint - Mandatory)
						------------------------------
						------------------------------
						• varArrayID (bigint[] - Optional)
						• varEnvironmentParameter (json - Optional)
						------------------------------
▪ Output              :	varReturn (varchar)
▪ Keterkaitan Fungsi  :	• "SchMaster"."Func_SQLGenerator_DataList_BusinessDocumentVersion"(bigint, bigint[], json)
▪ Deskripsi           :	• Mendapatkan SQL Generator untuk Daftar Unggahan File-File berdasarkan ID
						  Branch (varSysBranch_RefID) dan ID Data (varArrayID).
						• ID yang dapat diterima oleh varArrayID adalah :
							- ID Log File Upload Pointer							(91..., x0091...)
						• Ketentuan mekanisme dasar parameter :
							- varArrayID diset '{}'::bigint[]						-> Tidak memunculkan data apapun
							- varSysBranch_RefID diset dengan ID Branch dan varArrayID diset array ID data tertentu
																					-> Memunculkan data tertentu yang terkait Branch ID dan Array ID
							- varSysBranch_RefID diset dengan ID Branch dan varArrayID diset NULL
																					-> Memunculkan seluruh data yang terkait Branch ID tersebut
					  	• Parameter (diperbolehkan parsial) pada varEnvironmentParameter yang dapat
						  digunakan adalah :
						  	- DBLink Connection String :
						 		- "DBLink.ConnectionString.FrontEnd"				-> (varchar) DBLink Connection String untuk Database FrontEnd
								- "DBLink.ConnectionString.BackEnd.DataOLAP"		-> (varchar) DBLink Connection String untuk Database BackEnd OLAP
								- "DBLink.ConnectionString.BackEnd.DataOLTP"		-> (varchar) DBLink Connection String untuk Database BackEnd OLTP
								- "DBLink.ConnectionString.BackEnd.DataWarehouse"	-> (varchar) DBLink Connection String untuk Database BackEnd Data Warehouse
								- "DBLink.ConnectionString.BackEnd.SysConfig"		-> (varchar) DBLink Connection String untuk Database BackEnd SysConfig
						  	- Pagination :
								- "Pagination.PageSize"								-> (bigint) Pagination Page Size (Items Per Page)
								- "Pagination.PageShow"								-> (bigint) Pagination Page Show (Page Cursor)
						  	- Data Customize :
								- "DataCustomize.Filter"							-> (json) Data Filtering (Format JSON Array : Field Name, Field Data Type, Operator, Value)
								- "DataCustomize.Sort"								-> (json) Data Sorting (Format JSON Array : Field Name, Mode)
						  	- Data Reference :
								- "DataReference.Array.BaseBranch"					-> (json) Data Reference - Array - Base Branch (Format JSON Object : ID, Value_BaseBranchID)
								- "DataReference.Array.Currency"					-> (json) Data Reference - Array - Currency (Format JSON Object : ID, Value_ISOCode, Value_Symbol)
						• Apabila pada Data Customize diaktifkan pada varEnvironmentParameter, maka
						  akan berpotensi memperlambat proses eksekusi.
						  Hal ini terjadi disebabkan oleh adanya DATA PREPROCESSING terlebih dahulu
						  untuk merepresentasikan data secara lengkap dan utuh sebelum dilakukan
						  proses FILTERING dan SORTING.
						• Jika varArrayID hanya terdiri dari 1 (satu) ID saja, maka secara otomatis
						  field "JSONDataDetail" akan diinisialisasi dengan DATA DETAIL untuk 
						  mengantisipasi adanya kemungkinan pengolahan DOCUMENT FORM.
						  Sedangkan apabila varArrayID lebih dari 1 ID, maka field "JSONDataDetail"
						  tidak akan diinisialisasi sama sekali (diisi nilai NULL).
▪ Copyright           :	Zheta © 2025 - 2026

----[ Related Database Object(s) ]------------------------------------------------------------------

▪ Tabel               :	• [BE] "SchAcquisition"."TblLog_FileUpload_Object"
						• [BE] "SchAcquisition"."TblLog_FileUpload_ObjectDetail"
						• [BE] "SchAcquisition"."TblLog_FileUpload_Pointer"
						• [BE] "SchAcquisition"."TblLog_FileUpload_PointerHistory"
						• [BE] "SchAcquisition"."TblLog_FileUpload_PointerHistoryDetail"

▪ Fungsi              :	• [BE] "SchSystem"."FuncSys_General_GetEnvironmentParameterExtraction"(bigint, bigint, json, varchar, json, json)
						------------------------------

----[ SQL Example(s) ]------------------------------------------------------------------------------

▪ ---> With Login Session ID and Branch ID
	SELECT 
		"SchAcquisition"."Func_SQLGenerator_DataList_FileUploads"(
			6000000000001::bigint,
			11000000000004::bigint
			------------------------------
			------------------------------
			);

▪ ---> With Login Session ID, Branch ID, and Array ID
	SELECT 
		"SchAcquisition"."Func_SQLGenerator_DataList_FileUploads"(
			6000000000001::bigint,
			11000000000004::bigint,
			------------------------------
			------------------------------
			'{91000000000001, 91000000000002, 91000000000003}'::bigint[]
			------------------------------
			);

▪ ---> With Login Session ID, Branch ID, Array ID, and Environment Parameter (varEnvironmentParameter : DBLink Connection String)
	SELECT 
		"SchAcquisition"."Func_SQLGenerator_DataList_FileUploads"(
			6000000000001::bigint,
			11000000000004::bigint,
			------------------------------
			------------------------------
			'{91000000000001, 91000000000002, 91000000000003}'::bigint[],
			------------------------------
			JSON_BUILD_OBJECT (
				'DBLink.ConnectionString.FrontEnd', 'dbname=''dbERPReborn'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263''',
				'DBLink.ConnectionString.BackEnd.DataOLAP', 'dbname=''dbERPReborn-Data-OLAP'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263''',
				'DBLink.ConnectionString.BackEnd.DataOLTP', 'dbname=''dbERPReborn-Data-OLTP'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263''',
				'DBLink.ConnectionString.BackEnd.DataWarehouse', 'dbname=''dbERPReborn-Data-Warehouse'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263''',
				'DBLink.ConnectionString.BackEnd.SysConfig', 'dbname=''dbERPReborn-SysConfig'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263'''
				------------------------------
				------------------------------
				)
			);

▪ ---> With Login Session ID, Branch ID, Array ID, and Environment Parameter (varEnvironmentParameter : DBLink Connection String, Pagination, and Data Customize)
	SELECT 
		"SchAcquisition"."Func_SQLGenerator_DataList_FileUploads"(
			6000000000001::bigint,
			11000000000004::bigint,
			------------------------------
			------------------------------
			'{91000000000001, 91000000000002, 91000000000003}'::bigint[],
			------------------------------
			JSON_BUILD_OBJECT (
				'DBLink.ConnectionString.FrontEnd', 'dbname=''dbERPReborn'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263''',
				'DBLink.ConnectionString.BackEnd.DataOLAP', 'dbname=''dbERPReborn-Data-OLAP'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263''',
				'DBLink.ConnectionString.BackEnd.DataOLTP', 'dbname=''dbERPReborn-Data-OLTP'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263''',
				'DBLink.ConnectionString.BackEnd.DataWarehouse', 'dbname=''dbERPReborn-Data-Warehouse'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263''',
				'DBLink.ConnectionString.BackEnd.SysConfig', 'dbname=''dbERPReborn-SysConfig'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263''',
				------------------------------
				'Pagination.PageSize', 10,
				'Pagination.PageShow', 1,
				------------------------------
				'DataCustomize.Filter', JSON_BUILD_ARRAY (
					JSON_BUILD_ARRAY (
						'DocumentNumber', 'varchar', 'ILIKE', 'Adv'
						)
					),
				'DataCustomize.Sort', JSON_BUILD_ARRAY (
					JSON_BUILD_ARRAY (
						'DocumentNumber', 'ASC'
						)
					),
				------------------------------
				'DataReference.Array.BaseBranch', JSON_BUILD_OBJECT (
					'ID', '{11000000000001,10011000000000001,11000000000002,10011000000000002,11000000000003,10011000000000003,11000000000004,10011000000000004}'::bigint[]::varchar,
					'Value_BaseBranchID', '{11000000000004,11000000000004,11000000000004,11000000000004,11000000000004,11000000000004,11000000000004,11000000000004}'::bigint[]::varchar
					),
				'DataReference.Array.Currency', JSON_BUILD_OBJECT (
					'ID', '{62000000000001,10062000000000001,62000000000002,10062000000000002,62000000000003,10062000000000003,62000000000004,10062000000000004,62000000000005,10062000000000005,62000000000006,10062000000000006,62000000000007,10062000000000007,62000000000008,10062000000000008,62000000000009,10062000000000009,62000000000010,10062000000000010,62000000000011,10062000000000011,62000000000012,10062000000000012,62000000000013,10062000000000013,62000000000014,10062000000000014,62000000000015,10062000000000015,62000000000016,10062000000000016,62000000000017,10062000000000017,62000000000018,10062000000000018,62000000000019,10062000000000019,62000000000020,10062000000000020,62000000000021,10062000000000021,62000000000022,10062000000000022,62000000000023,10062000000000023,62000000000024,10062000000000024,62000000000025,10062000000000025,62000000000026,10062000000000026,62000000000027,10062000000000027,62000000000028,10062000000000028,62000000000029,10062000000000029,62000000000030,10062000000000030,62000000000031,10062000000000031,62000000000032,10062000000000032,62000000000033,10062000000000033,62000000000034,10062000000000034,62000000000035,10062000000000035,62000000000036,10062000000000036,62000000000037,10062000000000037,62000000000038,10062000000000038,62000000000039,10062000000000039,62000000000040,10062000000000040,62000000000041,10062000000000041,62000000000042,10062000000000042,62000000000043,10062000000000043,62000000000044,10062000000000044,62000000000045,10062000000000045,62000000000046,10062000000000046,62000000000047,10062000000000047,62000000000048,10062000000000048,62000000000049,10062000000000049,62000000000050,10062000000000050,62000000000051,10062000000000051,62000000000052,10062000000000052,62000000000053,10062000000000053,62000000000054,10062000000000054,62000000000055,10062000000000055,62000000000056,10062000000000056,62000000000057,10062000000000057,62000000000058,10062000000000058,62000000000059,10062000000000059,62000000000060,10062000000000060,62000000000061,10062000000000061,62000000000062,10062000000000062,62000000000063,10062000000000063,62000000000064,10062000000000064,62000000000065,10062000000000065,62000000000066,10062000000000066,62000000000067,10062000000000067,62000000000068,10062000000000068,62000000000069,10062000000000069,62000000000070,10062000000000070,62000000000071,10062000000000071,62000000000072,10062000000000072,62000000000073,10062000000000073,62000000000074,10062000000000074,62000000000075,10062000000000075,62000000000076,10062000000000076,62000000000077,10062000000000077,62000000000078,10062000000000078,62000000000079,10062000000000079,62000000000080,10062000000000080,62000000000081,10062000000000081,62000000000082,10062000000000082,62000000000083,10062000000000083,62000000000084,10062000000000084,62000000000085,10062000000000085,62000000000086,10062000000000086,62000000000087,10062000000000087,62000000000088,10062000000000088,62000000000089,10062000000000089,62000000000090,10062000000000090,62000000000091,10062000000000091,62000000000092,10062000000000092,62000000000093,10062000000000093,62000000000094,10062000000000094,62000000000095,10062000000000095,62000000000096,10062000000000096,62000000000097,10062000000000097,62000000000098,10062000000000098,62000000000099,10062000000000099,62000000000100,10062000000000100,62000000000101,10062000000000101,62000000000102,10062000000000102,62000000000103,10062000000000103,62000000000104,10062000000000104,62000000000105,10062000000000105,62000000000106,10062000000000106,62000000000107,10062000000000107,62000000000108,10062000000000108,62000000000109,10062000000000109,62000000000110,10062000000000110,62000000000111,10062000000000111,62000000000112,10062000000000112,62000000000113,10062000000000113,62000000000114,10062000000000114,62000000000115,10062000000000115,62000000000116,10062000000000116,62000000000117,10062000000000117,62000000000118,10062000000000118,62000000000119,10062000000000119,62000000000120,10062000000000120}'::bigint[]::varchar,
					'Value_ISOCode', '{IDR,IDR,USD,USD,AUD,AUD,CAD,CAD,DKK,DKK,HKD,HKD,MYR,MYR,NZD,NZD,NOK,NOK,GBP,GBP,SGD,SGD,SEK,SEK,CHF,CHF,JPY,JPY,MMK,MMK,INR,INR,KWD,KWD,PKR,PKR,PHP,PHP,SAR,SAR,LKR,LKR,THB,THB,BND,BND,EUR,EUR,CNY,CNY,KRW,KRW,CNH,CNH,LAK,LAK,PGK,PGK,VND,VND,ID2,ID2,ALL,ALL,AFN,AFN,ARS,ARS,AWG,AWG,AZN,AZN,BSD,BSD,BBD,BBD,BYR,BYR,BZD,BZD,BMD,BMD,BOB,BOB,BAM,BAM,BWP,BWP,BGN,BGN,BRL,BRL,KHR,KHR,KYD,KYD,CLP,CLP,COP,COP,CRC,CRC,HRK,HRK,CUP,CUP,CZK,CZK,DOP,DOP,XCD,XCD,EGP,EGP,SVC,SVC,EEK,EEK,FKP,FKP,FJD,FJD,GHC,GHC,GIP,GIP,GTQ,GTQ,GGP,GGP,GYD,GYD,HNL,HNL,HUF,HUF,ISK,ISK,IRR,IRR,IMP,IMP,ILS,ILS,JMD,JMD,JEP,JEP,KZT,KZT,KPW,KPW,KGS,KGS,LVL,LVL,LBP,LBP,LRD,LRD,LTL,LTL,MKD,MKD,MUR,MUR,MXN,MXN,MNT,MNT,MZN,MZN,NAD,NAD,NPR,NPR,ANG,ANG,NIO,NIO,NGN,NGN,KPW,KPW,OMR,OMR,PAB,PAB,PYG,PYG,PEN,PEN,PLN,PLN,QAR,QAR,RON,RON,RUB,RUB,SHP,SHP,RSD,RSD,SCR,SCR,SBD,SBD,SOS,SOS,ZAR,ZAR,KRW,KRW,SRD,SRD,SYP,SYP,TWD,TWD,TTD,TTD,TRY,TRY,TRL,TRL,TVD,TVD,UAH,UAH,UYU,UYU,UZS,UZS,VEF,VEF,YER,YER,ZWD,ZWD}'::varchar[]::varchar,
					'Value_Symbol', '{Rp,Rp,$,$,$,$,$,$,kr,kr,$,$,RM,RM,$,$,kr,kr,£,£,$,$,kr,kr,₣,₣,¥,¥,K,K,NULL,NULL,NULL,NULL,₨,₨,₱,₱,﷼,﷼,රු,රු,฿,฿,$,$,€,€,¥,¥,₩,₩,¥,¥,₭,₭,K,K,₫,₫,Rp,Rp,Lek,Lek,؋,؋,$,$,ƒ,ƒ,ман,ман,$,$,$,$,p.,p.,BZ$,BZ$,$,$,$b,$b,KM,KM,P,P,лв,лв,R$,R$,៛,៛,$,$,$,$,$,$,₡,₡,kn,kn,₱,₱,Kč,Kč,RD$,RD$,$,$,£,£,$,$,kr,kr,£,£,$,$,¢,¢,£,£,Q,Q,£,£,$,$,L,L,Ft,Ft,kr,kr,﷼,﷼,£,£,₪,₪,J$,J$,£,£,лв,лв,₩,₩,лв,лв,Ls,Ls,£,£,$,$,Lt,Lt,ден,ден,₨,₨,$,$,₮,₮,MT,MT,$,$,₨,₨,ƒ,ƒ,C$,C$,₦,₦,₩,₩,﷼,﷼,B/.,B/.,Gs,Gs,S/.,S/.,zł,zł,﷼,﷼,lei,lei,руб,руб,£,£,Дин.,Дин.,₨,₨,$,$,S,S,R,R,₩,₩,$,$,£,£,NT$,NT$,TT$,TT$,TL,TL,₤,₤,$,$,₴,₴,$U,$U,лв,лв,Bs,Bs,﷼,﷼,Z$,Z$}'::varchar[]::varchar
					)
				)
			);

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varSysDataReadLoginSession_RefID						ALIAS FOR $1;
			varSysBranch_RefID										ALIAS FOR $2;
			------------------------------

		---{ Optional }-------------------
			varArrayID												ALIAS FOR $3;
			varEnvironmentParameter									ALIAS FOR $4;

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----
			varReturn												varchar;

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

			varObjectIdentity										varchar;
			varJSONData_EnvSession									json;

			varDBLinkConnectionString_FE							varchar;
			varDBLinkConnectionString_BE_DataOLAP					varchar;
			varDBLinkConnectionString_BE_DataOLTP					varchar;
			varDBLinkConnectionString_BE_DataWarehouse				varchar;
			varDBLinkConnectionString_BE_SysConfig					varchar;

			varPagination_PageSize									bigint;
			varPagination_PageShow									bigint;

			varDataCustomize_Filter									varchar;
			varDataCustomize_Sort									varchar;
			varDataCustomize_Filter_CoreFields						varchar;
			varDataCustomize_Sort_CoreFields						varchar;
			varDataCustomize_Filter_NonCoreFields					varchar;
			varDataCustomize_Sort_NonCoreFields						varchar;

			varArraySysBranch_RefID									bigint[];
			varArraySysBaseBranch_RefID								bigint[];

			varArrayCurrency_RefID									bigint[];
			varArrayCurrencyISOCode									varchar(3)[];
			varArrayCurrencySymbol									varchar(4)[];

			varMainTable											varchar;

			varSQL													varchar;
			varSQLDefault											varchar;

		---{ Additional }-----------------

BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		---> Initializing : varObjectIdentity
			varObjectIdentity :=
				'SchAcquisition.Func_SQLGenerator_DataList_FileUploads';

		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------( START )-----
			IF (varSignEligibleToProcess IS FALSE) THEN
				varSignEligibleToProcess := TRUE;

				/*
				---> Reinitializing : varArrayID
					IF (varArrayID::bigint[] IS NULL) THEN
						varArrayID := '{}'::bigint[];
					END IF;
				*/

				IF (CARDINALITY(varArrayID::bigint[]) = 0) THEN
					varSignEligibleToProcess := FALSE;
				END IF;
			END IF;
		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------(  END  )-----

		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------( START )-----
			IF (varSignEligibleToProcess IS TRUE) THEN
				---> Initializing : Environment Parameter
					SELECT
						"Env_Session",
						------------------------------
						"DBLinkConnectionString_FE",
						"DBLinkConnectionString_BE_DataOLAP",
						"DBLinkConnectionString_BE_DataOLTP",
						"DBLinkConnectionString_BE_DataWarehouse",
						"DBLinkConnectionString_BE_SysConfig",
						------------------------------
						"Pagination_PageSize",
						"Pagination_PageShow",
						------------------------------
						"DataCustomize_Filter", 
						"DataCustomize_Sort",
						"DataCustomize_Filter_CoreFields",
						"DataCustomize_Sort_CoreFields",
						"DataCustomize_Filter_NonCoreFields", 
						"DataCustomize_Sort_NonCoreFields",
						------------------------------
						"Array_SysBranch_RefID",
						"Array_SysBaseBranch_RefID",
						------------------------------
						"Array_Currency_RefID",
						"Array_CurrencyISOCode",
						"Array_CurrencySymbol"
					INTO
						varJSONData_EnvSession,
						------------------------------
						varDBLinkConnectionString_FE,
						varDBLinkConnectionString_BE_DataOLAP,
						varDBLinkConnectionString_BE_DataOLTP,
						varDBLinkConnectionString_BE_DataWarehouse,
						varDBLinkConnectionString_BE_SysConfig,
						------------------------------
						varPagination_PageSize,
						varPagination_PageShow,
						------------------------------
						varDataCustomize_Filter,
						varDataCustomize_Sort,
						varDataCustomize_Filter_CoreFields,
						varDataCustomize_Sort_CoreFields,
						varDataCustomize_Filter_NonCoreFields,
						varDataCustomize_Sort_NonCoreFields,
						------------------------------
						varArraySysBranch_RefID,
						varArraySysBaseBranch_RefID,
						------------------------------
						varArrayCurrency_RefID,
						varArrayCurrencyISOCode,
						varArrayCurrencySymbol
					FROM
						"SchSystem"."FuncSys_General_GetEnvironmentParameterExtraction"(
							varSysDataReadLoginSession_RefID::bigint,
							varSysBranch_RefID::bigint,
							------------------------------
							varEnvironmentParameter::json,
							varObjectIdentity::varchar,
							------------------------------
							JSON_BUILD_ARRAY (
								'Sys_ID',
								'Sys_PID',
								'Sys_SID',
								'Sys_RPK',
								'Sys_Branch_RefID',
								'Sys_BaseBranch_RefID',
								'Sys_BaseCurrency_RefID',
								'Sys_BaseCurrencyISOCode',
								'Sys_BaseCurrencySymbol',
								------------------------------
								'Log_FileUpload_PointerHistory_RefID',
								------------------------------
								'Log_FileUpload_PointerHistoryDetail_RefID',
								------------------------------
								'Log_FileUpload_Object_RefID',
								------------------------------
								'JSONData'
								),
							JSON_BUILD_ARRAY (
								'Sys_ID',
								'Sys_PID',
								'Sys_SID',
								'Sys_RPK',
								'Sys_Branch_RefID',
								'Sys_BaseBranch_RefID',
								'Sys_BaseCurrency_RefID',
								'Sys_BaseCurrencyISOCode',
								'Sys_BaseCurrencySymbol',
								------------------------------
								'Log_FileUpload_PointerHistory_RefID',
								------------------------------
								'Log_FileUpload_PointerHistoryDetail_RefID',
								------------------------------
								'Log_FileUpload_Object_RefID',
								------------------------------
								'JSONData',
								------------------------------
								'OrderSequence',
								------------------------------
								'Env_Pagination_ItemSequence',
								'Env_Information'
								)
							);

				---> Initializing : varMainTable
					varMainTable := '"SchAcquisition"."TblLog_FileUpload_Pointer"';

				---> Reinitializing : varArrayID
					IF (varArrayID::varchar = '{}') THEN
						varArrayID := NULL::bigint[];
					END IF;

				---> Initializing : varSQL ► Build Source Data Link
					IF (varArrayID IS NOT NULL) THEN
						varSQL := '
							SELECT
								"Sys_PID",
								"Sys_SID",
								"Sys_RPK"
							FROM
								' || varMainTable || '
							WHERE
								"Sys_PID" IN (
									SELECT DISTINCT
										UNNEST ((''' || COALESCE(varArrayID::varchar, '') || ''')::bigint[])
									)
								AND
								"Sys_Data_Delete_DateTimeTZ" IS NULL
								AND
								"Sys_Data_Hidden_DateTimeTZ" IS NULL
								AND
								CASE
									WHEN (' || COALESCE(varSysBranch_RefID::varchar, 'NULL') || '::bigint IS NOT NULL) THEN
										"Sys_Branch_RefID" IN (' || ('SELECT UNNEST(''' || varArraySysBranch_RefID::varchar || '''::bigint[])::bigint')::varchar || ')
									ELSE
										TRUE
								END
							UNION
							SELECT
								"Sys_PID",
								"Sys_SID",
								"Sys_RPK"
							FROM
								' || varMainTable || '
							WHERE
								"Sys_SID" IN (
									SELECT DISTINCT
										UNNEST ((''' || COALESCE(varArrayID::varchar, '') || ''')::bigint[])
									)
								AND
								"Sys_Data_Delete_DateTimeTZ" IS NULL
								AND
								"Sys_Data_Hidden_DateTimeTZ" IS NULL
								AND
								CASE
									WHEN (' || COALESCE(varSysBranch_RefID::varchar, 'NULL') || '::bigint IS NOT NULL) THEN
										"Sys_Branch_RefID" IN (' || ('SELECT UNNEST(''' || varArraySysBranch_RefID::varchar || '''::bigint[])::bigint')::varchar || ')
									ELSE
										TRUE
								END
						';
					ELSE
						varSQL := '
							SELECT
								"Sys_PID",
								"Sys_SID",
								"Sys_RPK"
							FROM
								' || varMainTable || '
							WHERE
								"Sys_Data_Delete_DateTimeTZ" IS NULL
								AND
								"Sys_Data_Hidden_DateTimeTZ" IS NULL
								AND
								CASE
									WHEN (' || COALESCE(varSysBranch_RefID::varchar, 'NULL') || '::bigint IS NOT NULL) THEN
										"Sys_Branch_RefID" IN (' || ('SELECT UNNEST(''' || varArraySysBranch_RefID::varchar || '''::bigint[])::bigint')::varchar || ')
									ELSE
										TRUE
								END
							';
					END IF;				
					--RAISE NOTICE '%', varSQL;

				---> Initializing : varSQL ► Rearrange Sequence
					IF (varArrayID IS NOT NULL) THEN
						varSQL := '
							SELECT
								"SubSQL"."Sys_ID",
								"SubSQL"."Sys_RPK",
								------------------------------
								"SubSQL"."OrderSequence"
							FROM
								(
								SELECT
									COALESCE (
										"SubSQL2"."Sys_PID",
										"SubSQL2"."Sys_SID"
										) AS "Sys_ID",
									"SubSQL2"."Sys_RPK",
									------------------------------
									"SubSQL1"."OrderSequence"
								FROM
									(
									SELECT
										"SubSQL"."Sys_IDLink",
										------------------------------
										ROW_NUMBER () OVER () AS "OrderSequence"
									FROM
										(
										SELECT
											UNNEST (' || (COALESCE(('''' || varArrayID::varchar || ''''), 'NULL'::varchar)) || '::bigint[]) AS "Sys_IDLink"
										) AS "SubSQL"
									) AS "SubSQL1"
										LEFT JOIN
											(' || varSQL || ') AS "SubSQL2"
												ON
													"SubSQL1"."Sys_IDLink" = "SubSQL2"."Sys_PID"
													OR
													"SubSQL1"."Sys_IDLink" = "SubSQL2"."Sys_SID"
								ORDER BY
									"SubSQL1"."OrderSequence" ASC
								) AS "SubSQL"
							';
					ELSE
						varSQL := '
							SELECT
								"SubSQL"."Sys_ID",
								"SubSQL"."Sys_RPK",
								------------------------------
								"SubSQL"."OrderSequence"
							FROM
								(
								SELECT
									COALESCE (
										"SubSQL"."Sys_PID",
										"SubSQL"."Sys_SID"
										) AS "Sys_ID",
									"SubSQL"."Sys_RPK",
									------------------------------
									ROW_NUMBER () OVER () AS "OrderSequence"
								FROM
									(' || varSQL || ') AS "SubSQL"
								) AS "SubSQL"
							';
					END IF;
					--RAISE NOTICE '%', varSQL;

			ELSE
				---> Initializing : varSQLDefault
					varSQLDefault := '
						SELECT
							*
						FROM
							(
							SELECT
								NULL::bigint AS "Sys_ID",
								NULL::bigint AS "Sys_PID",
								NULL::bigint AS "Sys_SID",
								NULL::bigint AS "Sys_RPK",
								NULL::bigint AS "Sys_Branch_RefID",
								NULL::bigint AS "Sys_BaseBranch_RefID",
								NULL::bigint AS "Sys_BaseCurrency_RefID",
								NULL::varchar(3) AS "Sys_BaseCurrencyISOCode",
								NULL::varchar(4) AS "Sys_BaseCurrencySymbol",
								-----------------------------
								NULL::bigint AS "Log_FileUpload_PointerHistory_RefID",
								------------------------------
								NULL::bigint AS "Log_FileUpload_PointerHistoryDetail_RefID",
								------------------------------
								NULL::bigint AS "Log_FileUpload_Object_RefID",
								------------------------------
								NULL::json AS "JSONData",
								------------------------------
								NULL::bigint AS "OrderSequence",
								------------------------------
								NULL::bigint AS "Env_Pagination_ItemSequence",
								NULL::json AS "Env_Information"
							WHERE
								FALSE IS TRUE
							) AS "SubSQL"
						';
			END IF;
		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------(  END  )-----

	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			-----[ MAIN DATA PROCESSING ]---------------------------------------------( START )-----
				---> Initializing : varSQL
					varSQL := '
						SELECT
							*
						FROM
							(
							SELECT
								"SubSQL"."Sys_ID",
								"SubSQL"."Sys_PID",
								"SubSQL"."Sys_SID",
								"SubSQL"."Sys_RPK",
								"SubSQL"."Sys_Branch_RefID",
								"SubSQL"."Sys_BaseBranch_RefID",
								"SubSQL"."Sys_BaseCurrency_RefID",
								------------------------------
								"SubSQL"."Log_FileUpload_PointerHistory_RefID",
								------------------------------
								"SubSQL"."Log_FileUpload_PointerHistoryDetail_RefID",
								------------------------------
								"SubSQL"."Log_FileUpload_Object_RefID",
								------------------------------
								"SubSQL"."JSONData",
								------------------------------
								"SubSQL"."OrderSequence"
							FROM
								(
								SELECT
									"SubSQL"."Sys_ID",
									"SubSQL"."Sys_PID",
									"SubSQL"."Sys_SID",
									"SubSQL"."Sys_RPK",
									"SubSQL"."Sys_Branch_RefID",
									"SubSQL"."Sys_BaseBranch_RefID",
									"SubSQL"."Sys_BaseCurrency_RefID",
									------------------------------
									"SubSQL"."Log_FileUpload_PointerHistory_RefID",
									------------------------------
									"SubSQL"."Log_FileUpload_PointerHistoryDetail_RefID",
									------------------------------
									"SubSQL"."Log_FileUpload_Object_RefID",
									------------------------------
									(
									''['' ||
									STRING_AGG (
										(
										CASE
											WHEN ("SubSQL"."Log_FileUpload_ObjectDetail_RefID" IS NOT NULL) THEN 
												JSON_BUILD_OBJECT (
													''index'', "SubSQL"."IndexSequence",
													''recordID'', "SubSQL"."Log_FileUpload_ObjectDetail_RefID",
													''dataSource'', ''SchAcquisition.TblLog_FileUpload_ObjectDetail'',
													''entities'',
														JSON_BUILD_OBJECT (
															''log_FileUpload_PointerHistory_RefID'', "SubSQL"."Log_FileUpload_PointerHistory_RefID",
															''log_FileUpload_PointerHistoryDetail_RefID'', "SubSQL"."Log_FileUpload_PointerHistoryDetail_RefID",
															''log_FileUpload_Object_RefID'', "SubSQL"."Log_FileUpload_Object_RefID",
															''uploadDateTimeTZ'', "SubSQL"."UploadDateTimeTZ",
															''name'', "SubSQL"."Name",
															''size'', "SubSQL"."Size",
															''extension'', "SubSQL"."Extension"
															)
													)::varchar
											ELSE
												NULL
										END
										),
										'', ''
									) OVER (
										PARTITION BY
											"SubSQL"."OrderSequence"
										) ||
									'']''
									)::json AS "JSONData",
									------------------------------
									"SubSQL"."OrderSequence",
									ROW_NUMBER () OVER (
										PARTITION BY
											"SubSQL"."OrderSequence"
										) AS "FilterSequence",
									"SubSQL"."OrderSequenceExpansion"
								FROM
									(
									SELECT
										"SubSQL"."Sys_ID",
										"SubSQL"."Sys_PID",
										"SubSQL"."Sys_SID",
										"SubSQL"."Sys_RPK",
										"SubSQL"."Sys_Branch_RefID",
										"SubSQL"."Sys_BaseBranch_RefID",
										"SubSQL"."Sys_BaseCurrency_RefID",
										------------------------------
										"SubSQL"."UploadDateTimeTZ",
										------------------------------
										"SubSQL"."Log_FileUpload_PointerHistory_RefID",
										------------------------------
										"SubSQL"."Log_FileUpload_PointerHistoryDetail_RefID",
										------------------------------
										"SubSQL"."Log_FileUpload_Object_RefID",
										------------------------------
										"SubSQL"."Log_FileUpload_ObjectDetail_RefID",
										------------------------------
										"SubSQL"."Sequence",
										"SubSQL"."Name",
										"SubSQL"."Size",
										"SubSQL"."Extension",
										------------------------------
										"SubSQL"."OrderSequence",
										ROW_NUMBER () OVER (
											PARTITION BY
												"SubSQL"."OrderSequence"
											ORDER BY
												"SubSQL"."OrderSequenceExpansion" ASC
											) AS "IndexSequence",
										"SubSQL"."OrderSequenceExpansion"
									FROM
										(
										SELECT
											"SubSQL"."Sys_ID",
											"SubSQL"."Sys_PID",
											"SubSQL"."Sys_SID",
											"SubSQL"."Sys_RPK",
											"SubSQL"."Sys_Branch_RefID",
											"SubSQL"."Sys_BaseBranch_RefID",
											"SubSQL"."Sys_BaseCurrency_RefID",
											------------------------------
											"SubSQL"."UploadDateTimeTZ",
											------------------------------
											"SubSQL"."Log_FileUpload_PointerHistory_RefID",
											------------------------------
											"SubSQL"."Log_FileUpload_PointerHistoryDetail_RefID",
											------------------------------
											"SubSQL"."Log_FileUpload_Object_RefID",
											------------------------------
											"SubSQL"."Log_FileUpload_ObjectDetail_RefID",
											------------------------------
											"SubSQL"."Sequence",
											"SubSQL"."Name",
											"SubSQL"."Size",
											"SubSQL"."Extension",
											------------------------------
											"SubSQL"."OrderSequence",
											ROW_NUMBER () OVER (
												ORDER BY
													"SubSQL"."OrderSequenceExpansion" ASC,
													"SubSQL"."Sequence" ASC
												) AS "OrderSequenceExpansion"
										FROM
											(
											SELECT
												"SubSQL"."Sys_ID",
												"SubSQL"."Sys_PID",
												"SubSQL"."Sys_SID",
												"SubSQL"."Sys_RPK",
												"SubSQL"."Sys_Branch_RefID",
												"SubSQL"."Sys_BaseBranch_RefID",
												"SubSQL"."Sys_BaseCurrency_RefID",
												------------------------------
												"SubSQL"."UploadDateTimeTZ",
												------------------------------
												"SubSQL"."Log_FileUpload_PointerHistory_RefID",
												------------------------------
												"SubSQL"."Log_FileUpload_PointerHistoryDetail_RefID",
												------------------------------
												"SubSQL"."Log_FileUpload_Object_RefID",
												------------------------------
												COALESCE (
													"VirtTblLog_FileUpload_ObjectDetail_PID"."Sys_PID",
													"VirtTblLog_FileUpload_ObjectDetail_SID"."Sys_PID",
													"VirtTblLog_FileUpload_ObjectDetail_PID"."Sys_SID",
													"VirtTblLog_FileUpload_ObjectDetail_SID"."Sys_SID"
													) AS "Log_FileUpload_ObjectDetail_RefID",
												------------------------------
												COALESCE (
													"VirtTblLog_FileUpload_ObjectDetail_PID"."Sequence",
													"VirtTblLog_FileUpload_ObjectDetail_SID"."Sequence"
													) AS "Sequence",
												COALESCE (
													"VirtTblLog_FileUpload_ObjectDetail_PID"."Name",
													"VirtTblLog_FileUpload_ObjectDetail_SID"."Name"
													) AS "Name",
												COALESCE (
													"VirtTblLog_FileUpload_ObjectDetail_PID"."Size",
													"VirtTblLog_FileUpload_ObjectDetail_SID"."Size"
													) AS "Size",
												COALESCE (
													"VirtTblLog_FileUpload_ObjectDetail_PID"."Extension",
													"VirtTblLog_FileUpload_ObjectDetail_SID"."Extension"
													) AS "Extension",
												------------------------------
												"SubSQL"."OrderSequence",
												ROW_NUMBER () OVER (
													ORDER BY
														"SubSQL"."OrderSequenceExpansion" ASC,
														COALESCE (
															"VirtTblLog_FileUpload_ObjectDetail_PID"."Sys_Data_Edit_DateTimeTZ",
															"VirtTblLog_FileUpload_ObjectDetail_SID"."Sys_Data_Edit_DateTimeTZ",
															"VirtTblLog_FileUpload_ObjectDetail_PID"."Sys_Data_Entry_DateTimeTZ",
															"VirtTblLog_FileUpload_ObjectDetail_SID"."Sys_Data_Entry_DateTimeTZ"
															) ASC
													) AS "OrderSequenceExpansion"
											FROM
												(
												SELECT
													"SubSQL"."Sys_ID",
													"SubSQL"."Sys_PID",
													"SubSQL"."Sys_SID",
													"SubSQL"."Sys_RPK",
													"SubSQL"."Sys_Branch_RefID",
													"SubSQL"."Sys_BaseBranch_RefID",
													"SubSQL"."Sys_BaseCurrency_RefID",
													------------------------------
													"SubSQL"."UploadDateTimeTZ",
													------------------------------
													"SubSQL"."Log_FileUpload_PointerHistory_RefID",
													------------------------------
													"SubSQL"."Log_FileUpload_PointerHistoryDetail_RefID",
													------------------------------
													COALESCE (
														"VirtTblLog_FileUpload_Object_PID"."Sys_PID",
														"VirtTblLog_FileUpload_Object_SID"."Sys_PID",
														"VirtTblLog_FileUpload_Object_PID"."Sys_SID",
														"VirtTblLog_FileUpload_Object_SID"."Sys_SID"
														) AS "Log_FileUpload_Object_RefID",
													COALESCE (
														"VirtTblLog_FileUpload_Object_PID"."Sys_PID",
														"VirtTblLog_FileUpload_Object_SID"."Sys_PID"
														) AS "Log_FileUpload_Object_RefPIDLink",
													COALESCE (
														"VirtTblLog_FileUpload_Object_PID"."Sys_SID",
														"VirtTblLog_FileUpload_Object_SID"."Sys_SID"
														) AS "Log_FileUpload_Object_RefSIDLink",
													------------------------------
													"SubSQL"."OrderSequence",
													ROW_NUMBER () OVER (
														ORDER BY
															"SubSQL"."OrderSequenceExpansion" ASC,
															COALESCE (
																"VirtTblLog_FileUpload_Object_PID"."Sys_Data_Edit_DateTimeTZ",
																"VirtTblLog_FileUpload_Object_SID"."Sys_Data_Edit_DateTimeTZ",
																"VirtTblLog_FileUpload_Object_PID"."Sys_Data_Entry_DateTimeTZ",
																"VirtTblLog_FileUpload_Object_SID"."Sys_Data_Entry_DateTimeTZ"
																) ASC
														) AS "OrderSequenceExpansion"
												FROM
													(
													SELECT
														"SubSQL"."Sys_ID",
														"SubSQL"."Sys_PID",
														"SubSQL"."Sys_SID",
														"SubSQL"."Sys_RPK",
														"SubSQL"."Sys_Branch_RefID",
														"SubSQL"."Sys_BaseBranch_RefID",
														"SubSQL"."Sys_BaseCurrency_RefID",
														------------------------------
														"SubSQL"."UploadDateTimeTZ",
														------------------------------
														"SubSQL"."Log_FileUpload_PointerHistory_RefID",
														------------------------------
														COALESCE (
															"VirtTblLog_FileUpload_PointerHistoryDetail_PID". "Sys_PID",
															"VirtTblLog_FileUpload_PointerHistoryDetail_PID". "Sys_PID",
															"VirtTblLog_FileUpload_PointerHistoryDetail_SID". "Sys_SID",
															"VirtTblLog_FileUpload_PointerHistoryDetail_SID". "Sys_SID"
															) AS "Log_FileUpload_PointerHistoryDetail_RefID",
														------------------------------
														COALESCE (
															"VirtTblLog_FileUpload_PointerHistoryDetail_PID". "Log_FileUpload_Object_RefID",
															"VirtTblLog_FileUpload_PointerHistoryDetail_SID". "Log_FileUpload_Object_RefID"
															) AS "Log_FileUpload_Object_RefIDLink",
														------------------------------
														"SubSQL"."OrderSequence",
														ROW_NUMBER () OVER (
															ORDER BY
																"SubSQL"."OrderSequenceExpansion" ASC,
																COALESCE (
																	"VirtTblLog_FileUpload_PointerHistoryDetail_PID"."Sys_Data_Edit_DateTimeTZ",
																	"VirtTblLog_FileUpload_PointerHistoryDetail_SID"."Sys_Data_Edit_DateTimeTZ",
																	"VirtTblLog_FileUpload_PointerHistoryDetail_PID"."Sys_Data_Entry_DateTimeTZ",
																	"VirtTblLog_FileUpload_PointerHistoryDetail_SID"."Sys_Data_Entry_DateTimeTZ"
																	) ASC
															) AS "OrderSequenceExpansion"
													FROM
														(
														SELECT
															"SubSQL"."Sys_ID",
															"SubSQL"."Sys_PID",
															"SubSQL"."Sys_SID",
															"SubSQL"."Sys_RPK",
															"SubSQL"."Sys_Branch_RefID",
															"SubSQL"."Sys_BaseBranch_RefID",
															"SubSQL"."Sys_BaseCurrency_RefID",
															------------------------------
															COALESCE (
																"VirtTblLog_FileUpload_PointerHistory_PID"."Sys_PID",
																"VirtTblLog_FileUpload_PointerHistory_SID"."Sys_PID",
																"VirtTblLog_FileUpload_PointerHistory_PID"."Sys_SID",
																"VirtTblLog_FileUpload_PointerHistory_SID"."Sys_SID"
																) AS "Log_FileUpload_PointerHistory_RefID",
															COALESCE (
																"VirtTblLog_FileUpload_PointerHistory_PID"."Sys_PID",
																"VirtTblLog_FileUpload_PointerHistory_SID"."Sys_PID"
																) AS "Log_FileUpload_PointerHistory_RefPIDLink",
															COALESCE (
																"VirtTblLog_FileUpload_PointerHistory_PID"."Sys_SID",
																"VirtTblLog_FileUpload_PointerHistory_SID"."Sys_SID"
																) AS "Log_FileUpload_PointerHistory_RefSIDLink",
															------------------------------
															COALESCE (
																"VirtTblLog_FileUpload_PointerHistory_PID"."Sys_Data_Edit_DateTimeTZ",
																"VirtTblLog_FileUpload_PointerHistory_SID"."Sys_Data_Edit_DateTimeTZ",
																"VirtTblLog_FileUpload_PointerHistory_PID"."Sys_Data_Entry_DateTimeTZ",
																"VirtTblLog_FileUpload_PointerHistory_SID"."Sys_Data_Entry_DateTimeTZ"
																) AS "UploadDateTimeTZ",
															------------------------------
															"SubSQL"."OrderSequence",
															ROW_NUMBER () OVER (
																ORDER BY
																	"SubSQL"."OrderSequence" ASC,
																	COALESCE (
																		"VirtTblLog_FileUpload_PointerHistory_PID"."Sys_Data_Edit_DateTimeTZ",
																		"VirtTblLog_FileUpload_PointerHistory_SID"."Sys_Data_Edit_DateTimeTZ",
																		"VirtTblLog_FileUpload_PointerHistory_PID"."Sys_Data_Entry_DateTimeTZ",
																		"VirtTblLog_FileUpload_PointerHistory_SID"."Sys_Data_Entry_DateTimeTZ"
																		) ASC
																) AS "OrderSequenceExpansion"
														FROM
															(
															----[ MAIN CORE DATA ]-----( START )-----
															SELECT
																"SubSQL"."Sys_ID",
																"SubSQL"."Sys_PID",
																"SubSQL"."Sys_SID",
																"SubSQL"."Sys_RPK",
																"SubSQL"."Sys_Branch_RefID",
																"SubSQL"."Sys_BaseBranch_RefID",
																"SubSQL"."Sys_BaseCurrency_RefID",
																------------------------------
																"SubSQL"."OrderSequence"
															FROM
																(
																SELECT
																	COALESCE (
																		"VirtTblMainData"."Sys_PID",
																		"VirtTblMainData"."Sys_SID"
																		) AS "Sys_ID",
																	"VirtTblMainData"."Sys_PID",
																	"VirtTblMainData"."Sys_SID",
																	"VirtTblMainData"."Sys_RPK",
																	"VirtTblMainData"."Sys_Branch_RefID",
																	"SubSQLBaseBranch"."BaseInstitutionBranch_RefID" AS "Sys_BaseBranch_RefID",
																	"VirtTblMainData"."Sys_BaseCurrency_RefID",
																	------------------------------
																	ROW_NUMBER () OVER (
																		ORDER BY
																			"SubSQL"."OrderSequence" ASC
																	) AS "OrderSequence"
																FROM
																	(' || varSQL || ') AS "SubSQL"
																		LEFT JOIN
																			' || varMainTable || ' AS "VirtTblMainData"
																				ON
																					"SubSQL"."Sys_RPK" = "VirtTblMainData"."Sys_RPK"
																		LEFT JOIN
																			(
																			SELECT
																				UNNEST(''' || varArraySysBranch_RefID::varchar || '''::bigint[])::bigint AS "InstitutionBranch_RefID",
																				UNNEST(''' || varArraySysBaseBranch_RefID::varchar || '''::bigint[])::bigint AS "BaseInstitutionBranch_RefID"
																			) AS "SubSQLBaseBranch"
																				ON
																					"VirtTblMainData"."Sys_Branch_RefID" = "SubSQLBaseBranch"."InstitutionBranch_RefID"
																) AS "SubSQL"
															----[ MAIN CORE DATA ]-----(  END  )-----
															) AS "SubSQL"
																LEFT JOIN
																	"SchAcquisition"."TblLog_FileUpload_PointerHistory" AS "VirtTblLog_FileUpload_PointerHistory_PID"
																		ON
																			"SubSQL"."Sys_PID" = "VirtTblLog_FileUpload_PointerHistory_PID". "Log_FileUpload_Pointer_RefID"
																			AND
																			"VirtTblLog_FileUpload_PointerHistory_PID". "Sys_Data_Delete_DateTimeTZ" IS NULL
																			AND
																			"VirtTblLog_FileUpload_PointerHistory_PID". "Sys_Data_Hidden_DateTimeTZ" IS NULL
																LEFT JOIN
																	"SchAcquisition"."TblLog_FileUpload_PointerHistory" AS "VirtTblLog_FileUpload_PointerHistory_SID"
																		ON
																			"SubSQL"."Sys_SID" = "VirtTblLog_FileUpload_PointerHistory_SID". "Log_FileUpload_Pointer_RefID"
																			AND
																			"VirtTblLog_FileUpload_PointerHistory_SID". "Sys_Data_Delete_DateTimeTZ" IS NULL
																			AND
																			"VirtTblLog_FileUpload_PointerHistory_SID". "Sys_Data_Hidden_DateTimeTZ" IS NULL
														) AS "SubSQL"
															LEFT JOIN
																"SchAcquisition"."TblLog_FileUpload_PointerHistoryDetail" AS "VirtTblLog_FileUpload_PointerHistoryDetail_PID"
																	ON
																		"SubSQL"."Log_FileUpload_PointerHistory_RefPIDLink" = "VirtTblLog_FileUpload_PointerHistoryDetail_PID". "Log_FileUpload_PointerHistory_RefID"
																		AND
																		"VirtTblLog_FileUpload_PointerHistoryDetail_PID". "Sys_Data_Delete_DateTimeTZ" IS NULL
																		AND
																		"VirtTblLog_FileUpload_PointerHistoryDetail_PID". "Sys_Data_Hidden_DateTimeTZ" IS NULL
															LEFT JOIN
																"SchAcquisition"."TblLog_FileUpload_PointerHistoryDetail" AS "VirtTblLog_FileUpload_PointerHistoryDetail_SID"
																	ON
																		"SubSQL"."Log_FileUpload_PointerHistory_RefSIDLink" = "VirtTblLog_FileUpload_PointerHistoryDetail_SID". "Log_FileUpload_PointerHistory_RefID"
																		AND
																		"VirtTblLog_FileUpload_PointerHistoryDetail_SID". "Sys_Data_Delete_DateTimeTZ" IS NULL
																		AND
																		"VirtTblLog_FileUpload_PointerHistoryDetail_SID". "Sys_Data_Hidden_DateTimeTZ" IS NULL
													) AS "SubSQL"
														LEFT JOIN
															"SchAcquisition"."TblLog_FileUpload_Object" AS "VirtTblLog_FileUpload_Object_PID"
																ON
																	"SubSQL"."Log_FileUpload_Object_RefIDLink" = "VirtTblLog_FileUpload_Object_PID"."Sys_PID"
																	AND
																	"VirtTblLog_FileUpload_Object_PID". "Sys_Data_Delete_DateTimeTZ" IS NULL
																	AND
																	"VirtTblLog_FileUpload_Object_PID". "Sys_Data_Hidden_DateTimeTZ" IS NULL
														LEFT JOIN
															"SchAcquisition"."TblLog_FileUpload_Object" AS "VirtTblLog_FileUpload_Object_SID"
																ON
																	"SubSQL"."Log_FileUpload_Object_RefIDLink" = "VirtTblLog_FileUpload_Object_SID"."Sys_SID"
																	AND
																	"VirtTblLog_FileUpload_Object_SID". "Sys_Data_Delete_DateTimeTZ" IS NULL
																	AND
																	"VirtTblLog_FileUpload_Object_SID". "Sys_Data_Hidden_DateTimeTZ" IS NULL
												) AS "SubSQL"
													LEFT JOIN
														"SchAcquisition"."TblLog_FileUpload_ObjectDetail" AS "VirtTblLog_FileUpload_ObjectDetail_PID"
															ON
																"SubSQL"."Log_FileUpload_Object_RefPIDLink" = "VirtTblLog_FileUpload_ObjectDetail_PID"."Log_FileUpload_Object_RefID"
																AND
																"VirtTblLog_FileUpload_ObjectDetail_PID". "Sys_Data_Delete_DateTimeTZ" IS NULL
																AND
																"VirtTblLog_FileUpload_ObjectDetail_PID". "Sys_Data_Hidden_DateTimeTZ" IS NULL
													LEFT JOIN
														"SchAcquisition"."TblLog_FileUpload_ObjectDetail" AS "VirtTblLog_FileUpload_ObjectDetail_SID"
															ON
																"SubSQL"."Log_FileUpload_Object_RefSIDLink" = "VirtTblLog_FileUpload_ObjectDetail_SID"."Log_FileUpload_Object_RefID"
																AND
																"VirtTblLog_FileUpload_ObjectDetail_SID". "Sys_Data_Delete_DateTimeTZ" IS NULL
																AND
																"VirtTblLog_FileUpload_ObjectDetail_SID". "Sys_Data_Hidden_DateTimeTZ" IS NULL
											) AS "SubSQL"
										--WHERE
										--	"SubSQL"."Log_FileUpload_ObjectDetail_RefID" IS NOT NULL
										) AS "SubSQL"
									) AS "SubSQL"
								) AS "SubSQL"
							WHERE
								"SubSQL"."FilterSequence" = 1
							) AS "SubSQL"
						';

					varSQL := '
						SELECT
							*
						FROM
							(
							SELECT
								"SubSQL"."Sys_ID",
								"SubSQL"."Sys_PID",
								"SubSQL"."Sys_SID",
								"SubSQL"."Sys_RPK",
								"SubSQL"."Sys_Branch_RefID",
								"SubSQL"."Sys_BaseBranch_RefID",
								"SubSQL"."Sys_BaseCurrency_RefID",
								"SubSQL"."Sys_BaseCurrencyISOCode",
								"SubSQL"."Sys_BaseCurrencySymbol",
								------------------------------
								"SubSQL"."Log_FileUpload_PointerHistory_RefID",
								------------------------------
								"SubSQL"."Log_FileUpload_PointerHistoryDetail_RefID",
								------------------------------
								"SubSQL"."Log_FileUpload_Object_RefID",
								------------------------------
								"SubSQL"."JSONData",
								------------------------------
								ROW_NUMBER () OVER (
									ORDER BY
										"SubSQL"."OrderSequence" ASC
									) AS "OrderSequence",
								------------------------------
								"SubSQL"."Env_Pagination_ItemSequence",
								"SubSQL"."Env_Information"
							FROM
								(
								SELECT
									"SubSQL"."Env_Information",
									"SubSQL"."Env_Pagination_ItemSequence",
									------------------------------
									"SubSQL"."Sys_ID",
									"SubSQL"."Sys_PID",
									"SubSQL"."Sys_SID",
									"SubSQL"."Sys_RPK",
									"SubSQL"."Sys_Branch_RefID",
									"SubSQL"."Sys_BaseBranch_RefID",
									"SubSQLBaseCurrency"."Sys_ID" AS "Sys_BaseCurrency_RefID",
									"SubSQLBaseCurrency"."ISOCode" AS "Sys_BaseCurrencyISOCode",
									"SubSQLBaseCurrency"."Symbol" AS "Sys_BaseCurrencySymbol",
									------------------------------
									"SubSQL"."Log_FileUpload_PointerHistory_RefID",
									------------------------------
									"SubSQL"."Log_FileUpload_PointerHistoryDetail_RefID",
									------------------------------
									"SubSQL"."Log_FileUpload_Object_RefID",
									------------------------------
									"SubSQL"."JSONData",
									------------------------------
									"SubSQL"."OrderSequence"
								FROM
									(
									----[ MAIN CORE DATA + PAGINATION ]-----( START )-----
									SELECT
										"SubSQL"."Env_Information",
										"SubSQL"."Env_Pagination_ItemSequence",
										------------------------------
										"SubSQL"."Sys_ID",
										"SubSQL"."Sys_PID",
										"SubSQL"."Sys_SID",
										"SubSQL"."Sys_RPK",
										"SubSQL"."Sys_Branch_RefID",
										"SubSQL"."Sys_BaseBranch_RefID",
										"SubSQL"."Sys_BaseCurrency_RefID",
										------------------------------
										"SubSQL"."Log_FileUpload_PointerHistory_RefID",
										------------------------------
										"SubSQL"."Log_FileUpload_PointerHistoryDetail_RefID",
										------------------------------
										"SubSQL"."Log_FileUpload_Object_RefID",
										------------------------------
										"SubSQL"."JSONData",
										------------------------------
										"SubSQL"."OrderSequence"
									FROM
										(
										SELECT
											(
											CASE
												WHEN ("SubSQL"."OrderSequence" = 1) THEN
													JSON_BUILD_OBJECT (
														''general'',
															JSON_BUILD_OBJECT (
																''dataCount'', "SubSQL"."Env_DataCount",
																''pagination'',
																	JSON_BUILD_OBJECT (
																		''pageSize'', "SubSQL"."Env_Pagination_PageSize",
																		''pageCount'', "SubSQL"."Env_Pagination_PageCount",
																		''pageShow'', "SubSQL"."Env_Pagination_PageShow"																
																		),
																''dataCustomize'',
																	JSON_BUILD_OBJECT (
																		''filterString'', ' || COALESCE(('''' || REPLACE (varDataCustomize_Filter, '''', '''''') || ''''), 'NULL') || ',
																		''sortString'', ' || COALESCE(('''' || REPLACE (varDataCustomize_Sort, '''', '''''') || ''''), 'NULL') || '
																		)
																)
														)
												ELSE
													NULL
											END
											) AS "Env_Information",
											"SubSQL"."Env_Pagination_ItemSequence",
											------------------------------
											"SubSQL"."Sys_ID",
											"SubSQL"."Sys_PID",
											"SubSQL"."Sys_SID",
											"SubSQL"."Sys_RPK",
											"SubSQL"."Sys_Branch_RefID",
											"SubSQL"."Sys_BaseBranch_RefID",
											"SubSQL"."Sys_BaseCurrency_RefID",
											------------------------------
											"SubSQL"."Log_FileUpload_PointerHistory_RefID",
											------------------------------
											"SubSQL"."Log_FileUpload_PointerHistoryDetail_RefID",
											------------------------------
											"SubSQL"."Log_FileUpload_Object_RefID",
											------------------------------
											"SubSQL"."JSONData",
											------------------------------
											"SubSQL"."OrderSequence"
										FROM
											(
											SELECT
												"SubSQL"."Env_DataCount",
												"SubSQL"."Env_Pagination_PageSize",
												"SubSQL"."Env_Pagination_PageCount",
												"SubSQL"."Env_Pagination_PageShow",
												"SubSQL"."Env_Pagination_ItemSequence",
												------------------------------
												"SubSQL"."Sys_ID",
												"SubSQL"."Sys_PID",
												"SubSQL"."Sys_SID",
												"SubSQL"."Sys_RPK",
												"SubSQL"."Sys_Branch_RefID",
												"SubSQL"."Sys_BaseBranch_RefID",
												"SubSQL"."Sys_BaseCurrency_RefID",
												------------------------------
												"SubSQL"."Log_FileUpload_PointerHistory_RefID",
												------------------------------
												"SubSQL"."Log_FileUpload_PointerHistoryDetail_RefID",
												------------------------------
												"SubSQL"."Log_FileUpload_Object_RefID",
												------------------------------
												"SubSQL"."JSONData",
												------------------------------
												"SubSQL"."OrderSequence"
											FROM
												(
												SELECT
													"SubSQL"."Env_DataCount",
													"SubSQL"."Env_Pagination_PageSize",
													"SubSQL"."Env_Pagination_PageCount",
													COALESCE (
														CASE
															WHEN ("SubSQL"."Env_Pagination_PageShow" > "SubSQL"."Env_Pagination_PageCount") THEN
																"SubSQL"."Env_Pagination_PageCount"
															WHEN ("SubSQL"."Env_Pagination_PageShow" > 0) THEN
																"SubSQL"."Env_Pagination_PageShow"
															ELSE
																NULL
														END,
														1
														) AS "Env_Pagination_PageShow",
													"SubSQL"."Env_Pagination_ItemSequence",
													------------------------------
													"SubSQL"."Sys_ID",
													"SubSQL"."Sys_PID",
													"SubSQL"."Sys_SID",
													"SubSQL"."Sys_RPK",
													"SubSQL"."Sys_Branch_RefID",
													"SubSQL"."Sys_BaseBranch_RefID",
													"SubSQL"."Sys_BaseCurrency_RefID",
													------------------------------
													"SubSQL"."Log_FileUpload_PointerHistory_RefID",
													------------------------------
													"SubSQL"."Log_FileUpload_PointerHistoryDetail_RefID",
													------------------------------
													"SubSQL"."Log_FileUpload_Object_RefID",
													------------------------------
													"SubSQL"."JSONData",
													------------------------------
													"SubSQL"."OrderSequence"
												FROM
													(
													SELECT
														"SubSQL"."Env_DataCount",
														"SubSQL"."Env_Pagination_PageSize",
														(
															("SubSQL"."Env_DataCount" / "SubSQL"."Env_Pagination_PageSize") + 
															CASE
																WHEN (("SubSQL"."Env_DataCount" % "SubSQL"."Env_Pagination_PageSize") = 0) THEN
																	0
																ELSE
																	1
															END
														) AS "Env_Pagination_PageCount",
														"SubSQL"."Env_Pagination_PageShow",
														"SubSQL"."Env_Pagination_ItemSequence",
														------------------------------
														"SubSQL"."Sys_ID",
														"SubSQL"."Sys_PID",
														"SubSQL"."Sys_SID",
														"SubSQL"."Sys_RPK",
														"SubSQL"."Sys_Branch_RefID",
														"SubSQL"."Sys_BaseBranch_RefID",
														"SubSQL"."Sys_BaseCurrency_RefID",
														------------------------------
														"SubSQL"."Log_FileUpload_PointerHistory_RefID",
														------------------------------
														"SubSQL"."Log_FileUpload_PointerHistoryDetail_RefID",
														------------------------------
														"SubSQL"."Log_FileUpload_Object_RefID",
														------------------------------
														"SubSQL"."JSONData",
														------------------------------
														"SubSQL"."OrderSequence"
													FROM
														(
														SELECT
															"SubSQL"."Env_DataCount",
															COALESCE (
																CASE
																	WHEN ("SubSQL"."Env_Pagination_PageSize" > "SubSQL"."Env_DataCount") THEN
																		NULL
																	WHEN ("SubSQL"."Env_Pagination_PageSize" > 0) THEN
																		"SubSQL"."Env_Pagination_PageSize"
																	ELSE
																		NULL
																END,
																"SubSQL"."Env_DataCount"
																) AS "Env_Pagination_PageSize",
															"SubSQL"."Env_Pagination_PageShow",
															"SubSQL"."Env_Pagination_ItemSequence",
															------------------------------
															"SubSQL"."Sys_ID",
															"SubSQL"."Sys_PID",
															"SubSQL"."Sys_SID",
															"SubSQL"."Sys_RPK",
															"SubSQL"."Sys_Branch_RefID",
															"SubSQL"."Sys_BaseBranch_RefID",
															"SubSQL"."Sys_BaseCurrency_RefID",
															------------------------------
															"SubSQL"."Log_FileUpload_PointerHistory_RefID",
															------------------------------
															"SubSQL"."Log_FileUpload_PointerHistoryDetail_RefID",
															------------------------------
															"SubSQL"."Log_FileUpload_Object_RefID",
															------------------------------
															"SubSQL"."JSONData",
															------------------------------
															"SubSQL"."OrderSequence"
														FROM
															(
															SELECT
																MAX ("SubSQL"."OrderSequence") OVER () AS "Env_DataCount",
																' || COALESCE (varPagination_PageSize::varchar, 'NULL'::varchar) || '::bigint AS "Env_Pagination_PageSize",
																' || COALESCE (varPagination_PageShow::varchar, 'NULL'::varchar) || '::bigint AS "Env_Pagination_PageShow",
																"SubSQL"."OrderSequence" AS "Env_Pagination_ItemSequence",
																------------------------------
																"SubSQL"."Sys_ID",
																"SubSQL"."Sys_PID",
																"SubSQL"."Sys_SID",
																"SubSQL"."Sys_RPK",
																"SubSQL"."Sys_Branch_RefID",
																"SubSQL"."Sys_BaseBranch_RefID",
																"SubSQL"."Sys_BaseCurrency_RefID",
																------------------------------
																"SubSQL"."Log_FileUpload_PointerHistory_RefID",
																------------------------------
																"SubSQL"."Log_FileUpload_PointerHistoryDetail_RefID",
																------------------------------
																"SubSQL"."Log_FileUpload_Object_RefID",
																------------------------------
																"SubSQL"."JSONData",
																------------------------------
																"SubSQL"."OrderSequence"
															FROM
																(
																----[ MAIN CORE DATA ]-----( START )-----
																SELECT
																	"SubSQL"."Sys_ID",
																	"SubSQL"."Sys_PID",
																	"SubSQL"."Sys_SID",
																	"SubSQL"."Sys_RPK",
																	"SubSQL"."Sys_Branch_RefID",
																	"SubSQL"."Sys_BaseBranch_RefID",
																	"SubSQL"."Sys_BaseCurrency_RefID",
																	------------------------------
																	"SubSQL"."Log_FileUpload_PointerHistory_RefID",
																	------------------------------
																	"SubSQL"."Log_FileUpload_PointerHistoryDetail_RefID",
																	------------------------------
																	"SubSQL"."Log_FileUpload_Object_RefID",
																	------------------------------
																	"SubSQL"."JSONData",
																	------------------------------
																	"SubSQL"."OrderSequence"
																FROM
																	(
																	SELECT
																		"SubSQL"."Sys_ID",
																		"SubSQL"."Sys_PID",
																		"SubSQL"."Sys_SID",
																		"SubSQL"."Sys_RPK",
																		"SubSQL"."Sys_Branch_RefID",
																		"SubSQL"."Sys_BaseBranch_RefID",
																		"SubSQL"."Sys_BaseCurrency_RefID",
																		------------------------------
																		"SubSQL"."Log_FileUpload_PointerHistory_RefID",
																		------------------------------
																		"SubSQL"."Log_FileUpload_PointerHistoryDetail_RefID",
																		------------------------------
																		"SubSQL"."Log_FileUpload_Object_RefID",
																		------------------------------
																		"SubSQL"."JSONData",
																		------------------------------
																		"SubSQL"."OrderSequence"
																	FROM
																		(
																		SELECT
																			COALESCE (
																				"VirtTblMainData"."Sys_PID",
																				"VirtTblMainData"."Sys_SID"
																				) AS "Sys_ID",
																			"VirtTblMainData"."Sys_PID",
																			"VirtTblMainData"."Sys_SID",
																			"VirtTblMainData"."Sys_RPK",
																			"VirtTblMainData"."Sys_Branch_RefID",
																			"SubSQLBaseBranch"."BaseInstitutionBranch_RefID" AS "Sys_BaseBranch_RefID",
																			"VirtTblMainData"."Sys_BaseCurrency_RefID",
																			------------------------------
																			"VirtTblMainData"."Log_FileUpload_PointerHistory_RefID",
																			------------------------------
																			"VirtTblMainData"."Log_FileUpload_PointerHistoryDetail_RefID",
																			------------------------------
																			"VirtTblMainData"."Log_FileUpload_Object_RefID",
																			------------------------------
																			"VirtTblMainData"."JSONData",
																			------------------------------
																			"VirtTblMainData"."OrderSequence"
																		FROM
																			(
																			' || varSQL || '
																			) AS "VirtTblMainData"
																				LEFT JOIN
																					(
																					SELECT
																						UNNEST(''' || varArraySysBranch_RefID::varchar || '''::bigint[])::bigint AS "InstitutionBranch_RefID",
																						UNNEST(''' || varArraySysBaseBranch_RefID::varchar || '''::bigint[])::bigint AS "BaseInstitutionBranch_RefID"
																					) AS "SubSQLBaseBranch"
																						ON
																							"VirtTblMainData"."Sys_Branch_RefID" = "SubSQLBaseBranch"."InstitutionBranch_RefID"
																		) AS "SubSQL"
																	) AS "SubSQL"
																----[ MAIN CORE DATA ]-----(  END  )-----
																) AS "SubSQL"
															) AS "SubSQL"
														) AS "SubSQL"
													) AS "SubSQL"
												) AS "SubSQL"
											WHERE
												CASE
													WHEN (' || (CASE WHEN ((varDataCustomize_Filter IS NULL) AND (varDataCustomize_Sort IS NULL)) THEN 'TRUE' ELSE 'FALSE' END) || ' IS TRUE) THEN
														("SubSQL"."OrderSequence" > (("SubSQL"."Env_Pagination_PageShow" - 1) * "SubSQL"."Env_Pagination_PageSize"))
														AND
														("SubSQL"."OrderSequence" <= ("SubSQL"."Env_Pagination_PageShow" * "SubSQL"."Env_Pagination_PageSize"))
													ELSE
														TRUE
												END
											) AS "SubSQL"
										) AS "SubSQL"
									----[ MAIN CORE DATA + PAGINATION ]-----(  END  )-----
									) AS "SubSQL"
										LEFT JOIN
											(
											SELECT
												UNNEST(('|| COALESCE ('''' || varArrayCurrency_RefID::varchar || '''', 'NULL'::varchar) || ')::bigint[]) AS "Sys_ID",
												UNNEST(('|| COALESCE ('''' || varArrayCurrencyISOCode::varchar || '''', 'NULL'::varchar) || ')::varchar[]) AS "ISOCode",
												UNNEST(('|| COALESCE ('''' || varArrayCurrencySymbol::varchar || '''', 'NULL'::varchar) || ')::varchar[]) AS "Symbol"
											) AS "SubSQLBaseCurrency"
												ON
													"SubSQL"."Sys_BaseCurrency_RefID" = "SubSQLBaseCurrency"."Sys_ID"
								) AS "SubSQL"
							) AS "SubSQL"
						';
			-----[ MAIN DATA PROCESSING ]---------------------------------------------(  END  )-----
		END IF;

		---> Initializing : varReturn
			varReturn := 
				(
				'
				-----[ SQL Syntax Generator : ' || varObjectIdentity || ' ]-----( START )-----
				SELECT
					*
				FROM
					(
					'
					||
					CASE
						WHEN (varSignEligibleToProcess IS TRUE) THEN
							varSQL
						ELSE
							varSQLDefault
					END 
					||
					'
					) AS "SubSQL"
				-----[ SQL Syntax Generator : ' || varObjectIdentity || ' ]-----(  END  )-----
				'
				);

	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----
		---> Send Data Output
		RETURN
			varReturn;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		EXCEPTION
			WHEN OTHERS THEN
				NULL;

END;
$_$;


ALTER FUNCTION "SchAcquisition"."Func_SQLGenerator_DataList_FileUploads"(bigint, bigint, bigint[], json) OWNER TO "SysAdmin";

--
-- TOC entry 359 (class 1255 OID 6653762)
-- Name: Func_TblLog_Device_PersonAccessFetch_INSERT(character varying, bigint, timestamp with time zone, bigint, bigint, bigint, bigint, timestamp with time zone); Type: FUNCTION; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE FUNCTION "SchAcquisition"."Func_TblLog_Device_PersonAccessFetch_INSERT"(character varying, bigint, timestamp with time zone, bigint, bigint, bigint, bigint, timestamp with time zone) RETURNS SETOF "SchSystem"."HoldFuncSys_General_FeedBackQuery"
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchAcquisition"."Func_TblLog_Device_PersonAccessFetch_INSERT"
▪ Versi               :	1.00.0002
▪ Tanggal
     ► Pemutakhiran   :	2024-10-04
     ► Pembuatan      :	2021-05-03
▪ Input               :	• varSysDataAnnotation (varchar - Mandatory)
						• varIDSession (bigint - Mandatory)
						• varEntryDateTimeTZ (timestamptz - Mandatory)
						• varSysPartitionRemovableRecordKeyRefID (bigint - Mandatory)
						• varBranch_RefID (bigint - Mandatory)
						• varBaseCurrency_RefID (bigint - Mandatory)
						------------------------------
						• varGoodsIdentity_RefID (bigint - Mandatory)
						• varFetchDateTimeTZ (timestamptz - Mandatory)
						------------------------------
▪ Output              :	varRecSetOutput ("SchSystem"."HoldFuncSys_General_FeedBackQuery")
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Memasukan data (INSERT) pada tabel TblLog_Device_PersonAccessFetch
▪ Copyright           :	Zheta © 2021 - 2024

----[ SQL Example(s) ]------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------*/

DECLARE
	---[ Input Variable(s) ]------------------------------------------------------------------------
		---{ Mandatory }------------------
			varSysDataAnnotation									ALIAS FOR $1;
			varIDSession											ALIAS FOR $2;
			varEntryDateTimeTZ										ALIAS FOR $3;
			varSysPartitionRemovableRecordKeyRefID					ALIAS FOR $4;
			varBranch_RefID											ALIAS FOR $5;
			varBaseCurrency_RefID									ALIAS FOR $6;
			------------------------------
			varGoodsIdentity_RefID									ALIAS FOR $7;
			varFetchDateTimeTZ										ALIAS FOR $8;

		---{ Optional }-------------------

		---{ Additional }-----------------

	---[ Output Variable(s) ]-----------------------------------------------------------------------
			varRecSetOutput											"SchSystem"."HoldFuncSys_General_FeedBackQuery"%rowtype;

	---[ Intermediate Variable(s) ]-----------------------------------------------------------------
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

		---{ Additional }-----------------

BEGIN
	---[ Data Initializing ]------------------------------------------------------------------------
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		IF (varSignEligibleToProcess IS FALSE) THEN
			varSignEligibleToProcess := TRUE;
		END IF;

		IF (varSignEligibleToProcess IS TRUE) THEN
		END IF;

	---[ Data Processing ]--------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			INSERT INTO 
				"SchAcquisition"."TblLog_Device_PersonAccessFetch"
					(
					"Sys_Data_Annotation",
					"Sys_Data_Entry_LoginSession_RefID",
					"Sys_Data_Entry_DateTimeTZ",
					"Sys_Partition_RemovableRecord_Key_RefID",
					"Sys_Branch_RefID",
					"Sys_BaseCurrency_RefID",
					------------------------------
					"GoodsIdentity_RefID",
					"FetchDateTimeTZ"
					)
				VALUES
					(
					varSysDataAnnotation,
					varIDSession,
					varEntryDateTimeTZ,
					varSysPartitionRemovableRecordKeyRefID,
					varBranch_RefID,
					varBaseCurrency_RefID,
					------------------------------
					varGoodsIdentity_RefID,
					varFetchDateTimeTZ
					);
		END IF;

	---[ Data Return ]-----------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			varRecSetOutput."SignSuccess" := 1;
			varRecSetOutput."SignRecordType" := 'Sys_RPK';
			varRecSetOutput."SignRecordID" := CURRVAL('"SchAcquisition"."TblLog_Device_PersonAccessFetch_Sys_RPK_seq"');
			varRecSetOutput."SignMessage" := null;
		
			RETURN NEXT varRecSetOutput;
		END IF;

	---[ Exception Handling ]-----------------------------------------------------------------------
		--EXCEPTION WHEN OTHERS THEN ...

END;
$_$;


ALTER FUNCTION "SchAcquisition"."Func_TblLog_Device_PersonAccessFetch_INSERT"(character varying, bigint, timestamp with time zone, bigint, bigint, bigint, bigint, timestamp with time zone) OWNER TO "SysAdmin";

--
-- TOC entry 360 (class 1255 OID 6653763)
-- Name: Func_TblLog_Device_PersonAccessFetch_UPDATE(bigint, bigint, timestamp with time zone, bigint, bigint, bigint, bigint, timestamp with time zone); Type: FUNCTION; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE FUNCTION "SchAcquisition"."Func_TblLog_Device_PersonAccessFetch_UPDATE"(bigint, bigint, timestamp with time zone, bigint, bigint, bigint, bigint, timestamp with time zone) RETURNS SETOF "SchSystem"."HoldFuncSys_General_FeedBackQuery"
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchAcquisition"."Func_TblLog_Device_PersonAccessFetch_UPDATE"
▪ Versi               :	1.00.0002
▪ Tanggal
     ► Pemutakhiran   :	2024-10-04
     ► Pembuatan      :	2021-05-03
▪ Input               :	• varID (bigint - Mandatory)
						• varIDSession (bigint - Mandatory)
						• varEditDateTimeTZ (timestamptz - Mandatory)
						• varSysPartitionRemovableRecordKeyRefID (bigint - Mandatory)
						• varBranch_RefID (bigint - Mandatory)
						• varBaseCurrency_RefID (bigint - Mandatory)
						------------------------------
						• varGoodsIdentity_RefID (bigint - Mandatory)
						• varFetchDateTimeTZ (timestamptz - Mandatory)
						------------------------------
▪ Output              :	varRecSetOutput ("SchSystem"."HoldFuncSys_General_FeedBackQuery")
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Memutakhirkan data (UPDATE) pada tabel TblLog_Device_PersonAccessFetch
▪ Copyright           :	Zheta © 2021 - 2024

----[ SQL Example(s) ]------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------*/

DECLARE
	---[ Input Variable(s) ]------------------------------------------------------------------------
		---{ Mandatory }------------------
			varID													ALIAS FOR $1;
			varIDSession											ALIAS FOR $2;
			varEditDateTimeTZ										ALIAS FOR $3;
			varSysPartitionRemovableRecordKeyRefID					ALIAS FOR $4;
			varBranch_RefID											ALIAS FOR $5;
			varBaseCurrency_RefID									ALIAS FOR $6;
			------------------------------
			varGoodsIdentity_RefID									ALIAS FOR $7;
			varFetchDateTimeTZ										ALIAS FOR $8;

		---{ Optional }-------------------

		---{ Additional }-----------------

	---[ Output Variable(s) ]-----------------------------------------------------------------------
			varRecSetOutput											"SchSystem"."HoldFuncSys_General_FeedBackQuery"%rowtype;

	---[ Intermediate Variable(s) ]-----------------------------------------------------------------
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

		---{ Additional }-----------------

BEGIN
	---[ Data Initializing ]------------------------------------------------------------------------
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		IF (varSignEligibleToProcess IS FALSE) THEN
			varSignEligibleToProcess := TRUE;
		END IF;

		IF (varSignEligibleToProcess IS TRUE) THEN
		END IF;

	---[ Data Processing ]--------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			UPDATE
				"SchAcquisition"."TblLog_Device_PersonAccessFetch"
			SET
				"Sys_Data_Edit_LoginSession_RefID" = varIDSession,
				"Sys_Data_Edit_DateTimeTZ" = varEditDateTimeTZ,
				"Sys_Partition_RemovableRecord_Key_RefID" = varSysPartitionRemovableRecordKeyRefID,
				"Sys_Branch_RefID" = varBranch_RefID,
				"Sys_BaseCurrency_RefID" = varBaseCurrency_RefID,
				------------------------------
				"GoodsIdentity_RefID" = varGoodsIdentity_RefID,
				"FetchDateTimeTZ" = varFetchDateTimeTZ
			WHERE
				"Sys_PID" = varID
				OR
				"Sys_SID" = varID;
		END IF;

	---[ Data Return ]-----------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			varRecSetOutput."SignSuccess" := 1;
			varRecSetOutput."SignRecordType" := 'Sys_RPK';
			varRecSetOutput."SignRecordID" := (SELECT "Sys_RPK" FROM "SchAcquisition"."TblLog_Device_PersonAccessFetch" WHERE "Sys_PID" = varID OR "Sys_SID" = varID LIMIT 1);
			varRecSetOutput."SignMessage" := null;
		
			RETURN NEXT varRecSetOutput;
		END IF;

	---[ Exception Handling ]-----------------------------------------------------------------------
		--EXCEPTION WHEN OTHERS THEN ...

END;
$_$;


ALTER FUNCTION "SchAcquisition"."Func_TblLog_Device_PersonAccessFetch_UPDATE"(bigint, bigint, timestamp with time zone, bigint, bigint, bigint, bigint, timestamp with time zone) OWNER TO "SysAdmin";

--
-- TOC entry 361 (class 1255 OID 6653764)
-- Name: Func_TblLog_Device_PersonAccess_INSERT(character varying, bigint, timestamp with time zone, bigint, bigint, bigint, bigint, timestamp with time zone, bigint, character varying); Type: FUNCTION; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE FUNCTION "SchAcquisition"."Func_TblLog_Device_PersonAccess_INSERT"(character varying, bigint, timestamp with time zone, bigint, bigint, bigint, bigint, timestamp with time zone, bigint, character varying) RETURNS SETOF "SchSystem"."HoldFuncSys_General_FeedBackQuery"
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchAcquisition"."Func_TblLog_Device_PersonAccess_INSERT"
▪ Versi               :	1.00.0002
▪ Tanggal
     ► Pemutakhiran   :	2024-10-04
     ► Pembuatan      :	2021-05-03
▪ Input               :	• varSysDataAnnotation (varchar - Mandatory)
						• varIDSession (bigint - Mandatory)
						• varEntryDateTimeTZ (timestamptz - Mandatory)
						• varSysPartitionRemovableRecordKeyRefID (bigint - Mandatory)
						• varBranch_RefID (bigint - Mandatory)
						• varBaseCurrency_RefID (bigint - Mandatory)
						------------------------------
						• varLog_Device_PersonAccessFetch_RefID (bigint - Mandatory)
						• varAttendanceDateTimeTZ (timestamptz - Mandatory)
						• varPersonID (bigint - Mandatory)
						• varPersonUserName (varchar - Mandatory)
						------------------------------
▪ Output              :	varRecSetOutput ("SchSystem"."HoldFuncSys_General_FeedBackQuery")
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Memasukan data (INSERT) pada tabel TblLog_Device_PersonAccess
▪ Copyright           :	Zheta © 2021 - 2024

----[ SQL Example(s) ]------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------*/

DECLARE
	---[ Input Variable(s) ]------------------------------------------------------------------------
		---{ Mandatory }------------------
			varSysDataAnnotation									ALIAS FOR $1;
			varIDSession											ALIAS FOR $2;
			varEntryDateTimeTZ										ALIAS FOR $3;
			varSysPartitionRemovableRecordKeyRefID					ALIAS FOR $4;
			varBranch_RefID											ALIAS FOR $5;
			varBaseCurrency_RefID									ALIAS FOR $6;
			------------------------------
			varLog_Device_PersonAccessFetch_RefID					ALIAS FOR $7;
			varAttendanceDateTimeTZ									ALIAS FOR $8;
			varPersonID												ALIAS FOR $9;
			varPersonUserName										ALIAS FOR $10;

		---{ Optional }-------------------

		---{ Additional }-----------------

	---[ Output Variable(s) ]-----------------------------------------------------------------------
			varRecSetOutput											"SchSystem"."HoldFuncSys_General_FeedBackQuery"%rowtype;

	---[ Intermediate Variable(s) ]-----------------------------------------------------------------
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

		---{ Additional }-----------------

BEGIN
	---[ Data Initializing ]------------------------------------------------------------------------
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		IF (varSignEligibleToProcess IS FALSE) THEN
			varSignEligibleToProcess := TRUE;
		END IF;

		IF (varSignEligibleToProcess IS TRUE) THEN
		END IF;

	---[ Data Processing ]--------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			INSERT INTO 
				"SchAcquisition"."TblLog_Device_PersonAccess"
					(
					"Sys_Data_Annotation",
					"Sys_Data_Entry_LoginSession_RefID",
					"Sys_Data_Entry_DateTimeTZ",
					"Sys_Partition_RemovableRecord_Key_RefID",
					"Sys_Branch_RefID",
					"Sys_BaseCurrency_RefID",
					------------------------------
					"Log_Device_PersonAccessFetch_RefID",
					"AttendanceDateTimeTZ",
					"PersonID",
					"PersonUserName"
					)
				VALUES
					(
					varSysDataAnnotation,
					varIDSession,
					varEntryDateTimeTZ,
					varSysPartitionRemovableRecordKeyRefID,
					varBranch_RefID,
					varBaseCurrency_RefID,
					------------------------------
					varLog_Device_PersonAccessFetch_RefID,
					varAttendanceDateTimeTZ,
					varPersonID,
					varPersonUserName
					);
		END IF;

	---[ Data Return ]-----------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			varRecSetOutput."SignSuccess" := 1;
			varRecSetOutput."SignRecordType" := 'Sys_RPK';
			varRecSetOutput."SignRecordID" := CURRVAL('"SchAcquisition"."TblLog_Device_PersonAccess_Sys_RPK_seq"');
			varRecSetOutput."SignMessage" := null;
		
			RETURN NEXT varRecSetOutput;
		END IF;

	---[ Exception Handling ]-----------------------------------------------------------------------
		--EXCEPTION WHEN OTHERS THEN ...

END;
$_$;


ALTER FUNCTION "SchAcquisition"."Func_TblLog_Device_PersonAccess_INSERT"(character varying, bigint, timestamp with time zone, bigint, bigint, bigint, bigint, timestamp with time zone, bigint, character varying) OWNER TO "SysAdmin";

--
-- TOC entry 362 (class 1255 OID 6653765)
-- Name: Func_TblLog_Device_PersonAccess_UPDATE(bigint, bigint, timestamp with time zone, bigint, bigint, bigint, bigint, timestamp with time zone, bigint, character varying); Type: FUNCTION; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE FUNCTION "SchAcquisition"."Func_TblLog_Device_PersonAccess_UPDATE"(bigint, bigint, timestamp with time zone, bigint, bigint, bigint, bigint, timestamp with time zone, bigint, character varying) RETURNS SETOF "SchSystem"."HoldFuncSys_General_FeedBackQuery"
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchAcquisition"."Func_TblLog_Device_PersonAccess_UPDATE"
▪ Versi               :	1.00.0002
▪ Tanggal
     ► Pemutakhiran   :	2024-10-04
     ► Pembuatan      :	2021-05-03
▪ Input               :	• varID (bigint)
						• varIDSession (bigint)
						• varEditDateTimeTZ (timestamptz)
						• varSysPartitionRemovableRecordKeyRefID (bigint)
						• varBranch_RefID (bigint)
						• varBaseCurrency_RefID (bigint - Mandatory)
						------------------------------
						• varLog_Device_PersonAccessFetch_RefID (bigint)
						• varAttendanceDateTimeTZ (timestamptz)
						• varPersonID (bigint)
						• varPersonUserName (varchar)
						------------------------------
▪ Output              :	varRecSetOutput ("SchSystem"."HoldFuncSys_General_FeedBackQuery")
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Memutakhirkan data (UPDATE) pada tabel TblLog_Device_PersonAccess
▪ Copyright           :	Zheta © 2021 - 2024

----[ SQL Example(s) ]------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------*/

DECLARE
	---[ Input Variable(s) ]------------------------------------------------------------------------
		---{ Mandatory }------------------
			varID													ALIAS FOR $1;
			varIDSession											ALIAS FOR $2;
			varEditDateTimeTZ										ALIAS FOR $3;
			varSysPartitionRemovableRecordKeyRefID					ALIAS FOR $4;
			varBranch_RefID											ALIAS FOR $5;
			varBaseCurrency_RefID									ALIAS FOR $6;
			------------------------------
			varLog_Device_PersonAccessFetch_RefID					ALIAS FOR $7;
			varAttendanceDateTimeTZ									ALIAS FOR $8;
			varPersonID												ALIAS FOR $9;
			varPersonUserName										ALIAS FOR $10;

		---{ Optional }-------------------

		---{ Additional }-----------------

	---[ Output Variable(s) ]-----------------------------------------------------------------------
			varRecSetOutput											"SchSystem"."HoldFuncSys_General_FeedBackQuery"%rowtype;

	---[ Intermediate Variable(s) ]-----------------------------------------------------------------
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

		---{ Additional }-----------------

BEGIN
	---[ Data Initializing ]------------------------------------------------------------------------
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		IF (varSignEligibleToProcess IS FALSE) THEN
			varSignEligibleToProcess := TRUE;
		END IF;

		IF (varSignEligibleToProcess IS TRUE) THEN
		END IF;

	---[ Data Processing ]--------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			UPDATE
				"SchAcquisition"."TblLog_Device_PersonAccess"
			SET
				"Sys_Data_Edit_LoginSession_RefID" = varIDSession,
				"Sys_Data_Edit_DateTimeTZ" = varEditDateTimeTZ,
				"Sys_Partition_RemovableRecord_Key_RefID" = varSysPartitionRemovableRecordKeyRefID,
				"Sys_Branch_RefID" = varBranch_RefID,
				"Sys_BaseCurrency_RefID" = varBaseCurrency_RefID,
				------------------------------
				"Log_Device_PersonAccessFetch_RefID" = varLog_Device_PersonAccessFetch_RefID,
				"AttendanceDateTimeTZ" = varAttendanceDateTimeTZ,
				"PersonID" = varPersonID,
				"PersonUserName" = varPersonUserName
			WHERE
				"Sys_PID" = varID
				OR
				"Sys_SID" = varID;
		END IF;

	---[ Data Return ]-----------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			varRecSetOutput."SignSuccess" := 1;
			varRecSetOutput."SignRecordType" := 'Sys_RPK';
			varRecSetOutput."SignRecordID" := (SELECT "Sys_RPK" FROM "SchAcquisition"."TblLog_Device_PersonAccess" WHERE "Sys_PID" = varID OR "Sys_SID" = varID LIMIT 1);
			varRecSetOutput."SignMessage" := null;
		
			RETURN NEXT varRecSetOutput;
		END IF;

	---[ Exception Handling ]-----------------------------------------------------------------------
		--EXCEPTION WHEN OTHERS THEN ...

END;
$_$;


ALTER FUNCTION "SchAcquisition"."Func_TblLog_Device_PersonAccess_UPDATE"(bigint, bigint, timestamp with time zone, bigint, bigint, bigint, bigint, timestamp with time zone, bigint, character varying) OWNER TO "SysAdmin";

--
-- TOC entry 363 (class 1255 OID 6653766)
-- Name: Func_TblLog_FileUpload_ObjectDetail_INSERT(character varying, bigint, timestamp with time zone, bigint, bigint, bigint, bigint, bigint, smallint, character varying, bigint, character varying, character varying, character varying, bigint, bigint, character varying, bigint, character varying); Type: FUNCTION; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE FUNCTION "SchAcquisition"."Func_TblLog_FileUpload_ObjectDetail_INSERT"(character varying, bigint, timestamp with time zone, bigint, bigint, bigint, bigint, bigint, smallint, character varying, bigint, character varying, character varying, character varying, bigint, bigint, character varying, bigint, character varying) RETURNS SETOF "SchSystem"."HoldFuncSys_General_FeedBackQuery"
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchAcquisition"."Func_TblLog_FileUpload_ObjectDetail_INSERT"
▪ Versi               :	1.00.0005
▪ Tanggal
     ► Pemutakhiran   :	2024-10-04
     ► Pembuatan      :	2021-07-26
▪ Input               :	• varSysDataAnnotation (varchar - Mandatory)
						• varIDSession (bigint - Mandatory)
						• varEntryDateTimeTZ (timestamptz - Mandatory)
						• varSysPartitionRemovableRecordKeyRefID (bigint - Mandatory)
						• varBranchRefID (bigint - Mandatory)
						• varBaseCurrency_RefID (bigint - Mandatory)
						------------------------------
						• varLog_FileUpload_Object_RefID (bigint - Mandatory)
						• varRotateLog_FileUploadStagingAreaDetail_RefRPK (bigint - Mandatory)
						• varSequence (smallint - Mandatory)
						• varName (varchar - Mandatory)
						• varSize (bigint - Mandatory)
						• varMIME (varchar - Mandatory)
						• varExtension (varchar - Mandatory)
						• varLastModifiedDateTimeTZ (varchar - Mandatory)
						• varLastModifiedUnixTimestamp (bigint - Mandatory)
						• varHashMethod_RefID (bigint - Mandatory)
						• varContentBase64Hash (varchar - Mandatory)
						• varDataCompression_RefID (bigint - Mandatory)
						• varStagingAreaFilePath (varchar - Mandatory)
▪ Output              :	varRecSetOutput ("SchSystem"."HoldFuncSys_General_FeedBackQuery")
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Memasukan data (INSERT) pada tabel TblLog_FileUpload_ObjectDetail
▪ Copyright           :	Zheta © 2021 - 2024

----[ SQL Example(s) ]------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------*/

DECLARE
	---[ Input Variable(s) ]------------------------------------------------------------------------
		---{ Mandatory }------------------
			varSysDataAnnotation									ALIAS FOR $1;
			varIDSession											ALIAS FOR $2;
			varEntryDateTimeTZ										ALIAS FOR $3;
			varSysPartitionRemovableRecordKeyRefID					ALIAS FOR $4;
			varBranchRefID											ALIAS FOR $5;
			varBaseCurrency_RefID									ALIAS FOR $6;
			------------------------------
			varLog_FileUpload_Object_RefID							ALIAS FOR $7;
			varRotateLog_FileUploadStagingAreaDetail_RefRPK		ALIAS FOR $8;
			varSequence												ALIAS FOR $9;
			varName													ALIAS FOR $10;	
			varSize													ALIAS FOR $11;
			varMIME													ALIAS FOR $12;
			varExtension											ALIAS FOR $13;
			varLastModifiedDateTimeTZ								ALIAS FOR $14;
			varLastModifiedUnixTimestamp							ALIAS FOR $15;
			varHashMethod_RefID										ALIAS FOR $16;
			varContentBase64Hash									ALIAS FOR $17;
			varDataCompression_RefID								ALIAS FOR $18;
			varStagingAreaFilePath									ALIAS FOR $19;

		---{ Optional }-------------------

		---{ Additional }-----------------

	---[ Output Variable(s) ]-----------------------------------------------------------------------
			varRecSetOutput											"SchSystem"."HoldFuncSys_General_FeedBackQuery"%rowtype;

	---[ Intermediate Variable(s) ]-----------------------------------------------------------------
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

		---{ Additional }-----------------

BEGIN
	---[ Data Initializing ]------------------------------------------------------------------------
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		IF (varSignEligibleToProcess IS FALSE) THEN
			varSignEligibleToProcess := TRUE;
		END IF;

		IF (varSignEligibleToProcess IS TRUE) THEN
		END IF;

	---[ Data Processing ]--------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			INSERT INTO 
				"SchAcquisition"."TblLog_FileUpload_ObjectDetail"
					(
					"Sys_Data_Annotation",
					"Sys_Data_Entry_LoginSession_RefID",
					"Sys_Data_Entry_DateTimeTZ",
					"Sys_Partition_RemovableRecord_Key_RefID",
					"Sys_Branch_RefID",
					"Sys_BaseCurrency_RefID",
					------------------------------
					"Log_FileUpload_Object_RefID",
					"RotateLog_FileUploadStagingAreaDetail_RefRPK",
					"Sequence",
					"Name",
					"Size",
					"MIME",
					"Extension",
					"LastModifiedDateTimeTZ",
					"LastModifiedUnixTimestamp",
					"HashMethod_RefID",
					"ContentBase64Hash",
					"DataCompression_RefID",
					"StagingAreaFilePath"
					)
				VALUES
					(
					varSysDataAnnotation,
					varIDSession,
					varEntryDateTimeTZ,
					varSysPartitionRemovableRecordKeyRefID,
					varBranchRefID,
					varBaseCurrency_RefID,
					------------------------------
					varLog_FileUpload_Object_RefID,
					varRotateLog_FileUploadStagingAreaDetail_RefRPK,
					varSequence,
					varName,
					varSize,
					varMIME,
					varExtension,
					varLastModifiedDateTimeTZ,
					varLastModifiedUnixTimestamp,
					varHashMethod_RefID,
					varContentBase64Hash,
					varDataCompression_RefID,
					varStagingAreaFilePath
					);
		END IF;

	---[ Data Return ]-----------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			varRecSetOutput."SignSuccess" := 1;
			varRecSetOutput."SignRecordType" := 'Sys_RPK';
			varRecSetOutput."SignRecordID" := CURRVAL('"SchAcquisition"."TblLog_FileUpload_ObjectDetail_Sys_RPK_seq"');
			varRecSetOutput."SignMessage" := null;

			RETURN NEXT varRecSetOutput;
		END IF;

	---[ Exception Handling ]-----------------------------------------------------------------------
		--EXCEPTION WHEN OTHERS THEN ...

END;
$_$;


ALTER FUNCTION "SchAcquisition"."Func_TblLog_FileUpload_ObjectDetail_INSERT"(character varying, bigint, timestamp with time zone, bigint, bigint, bigint, bigint, bigint, smallint, character varying, bigint, character varying, character varying, character varying, bigint, bigint, character varying, bigint, character varying) OWNER TO "SysAdmin";

--
-- TOC entry 364 (class 1255 OID 6653767)
-- Name: Func_TblLog_FileUpload_ObjectDetail_UPDATE(bigint, bigint, timestamp with time zone, bigint, bigint, bigint, bigint, bigint, smallint, character varying, bigint, character varying, character varying, character varying, bigint, bigint, character varying, bigint, character varying); Type: FUNCTION; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE FUNCTION "SchAcquisition"."Func_TblLog_FileUpload_ObjectDetail_UPDATE"(bigint, bigint, timestamp with time zone, bigint, bigint, bigint, bigint, bigint, smallint, character varying, bigint, character varying, character varying, character varying, bigint, bigint, character varying, bigint, character varying) RETURNS SETOF "SchSystem"."HoldFuncSys_General_FeedBackQuery"
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchAcquisition"."Func_TblLog_FileUpload_ObjectDetail_UPDATE"
▪ Versi               :	1.00.0005
▪ Tanggal
     ► Pemutakhiran   :	2024-10-04
     ► Pembuatan      :	2021-07-26
▪ Input               :	• varID (bigint - Mandatory)
						• varIDSession (bigint - Mandatory)
						• varEditDateTimeTZ (timestamptz - Mandatory)
						• varSysPartitionRemovableRecordKeyRefID (bigint - Mandatory)
						• varBranchRefID (bigint - Mandatory)
						• varBaseCurrency_RefID (bigint - Mandatory)
						------------------------------
						• varLog_FileUpload_Object_RefID (bigint - Mandatory)
						• varRotateLog_FileUploadStagingAreaDetail_RefRPK (bigint - Mandatory)
						• varSequence (smallint - Mandatory)
						• varName (varchar - Mandatory)
						• varSize (bigint - Mandatory)
						• varMIME (varchar - Mandatory)
						• varExtension (varchar - Mandatory)
						• varLastModifiedDateTimeTZ (varchar - Mandatory)
						• varLastModifiedUnixTimestamp (bigint - Mandatory)
						• varHashMethod_RefID (bigint - Mandatory)
						• varContentBase64Hash (varchar - Mandatory)
						• varDataCompression_RefID (bigint - Mandatory)
						• varStagingAreaFilePath (varchar - Mandatory)
▪ Output              :	varRecSetOutput ("SchSystem"."HoldFuncSys_General_FeedBackQuery")
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Memutakhirkan data (UPDATE) pada tabel TblLog_FileUpload_ObjectDetail
▪ Copyright           :	Zheta © 2021 - 2024

----[ SQL Example(s) ]------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------*/

DECLARE
	---[ Input Variable(s) ]------------------------------------------------------------------------
		---{ Mandatory }------------------
			varID													ALIAS FOR $1;
			varIDSession											ALIAS FOR $2;
			varEditDateTimeTZ										ALIAS FOR $3;
			varSysPartitionRemovableRecordKeyRefID					ALIAS FOR $4;
			varBranchRefID											ALIAS FOR $5;
			varBaseCurrency_RefID									ALIAS FOR $6;
			------------------------------
			varLog_FileUpload_Object_RefID							ALIAS FOR $7;
			varRotateLog_FileUploadStagingAreaDetail_RefRPK		ALIAS FOR $8;
			varSequence												ALIAS FOR $9;
			varName													ALIAS FOR $10;	
			varSize													ALIAS FOR $11;
			varMIME													ALIAS FOR $12;
			varExtension											ALIAS FOR $13;
			varLastModifiedDateTimeTZ								ALIAS FOR $14;
			varLastModifiedUnixTimestamp							ALIAS FOR $15;
			varHashMethod_RefID										ALIAS FOR $16;
			varContentBase64Hash									ALIAS FOR $17;
			varDataCompression_RefID								ALIAS FOR $18;
			varStagingAreaFilePath									ALIAS FOR $19;

		---{ Optional }-------------------

		---{ Additional }-----------------

	---[ Output Variable(s) ]-----------------------------------------------------------------------
			varRecSetOutput											"SchSystem"."HoldFuncSys_General_FeedBackQuery"%rowtype;

	---[ Intermediate Variable(s) ]-----------------------------------------------------------------
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

		---{ Additional }-----------------

BEGIN
	---[ Data Initializing ]------------------------------------------------------------------------
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		IF (varSignEligibleToProcess IS FALSE) THEN
			varSignEligibleToProcess := TRUE;
		END IF;

		IF (varSignEligibleToProcess IS TRUE) THEN
		END IF;

	---[ Data Processing ]--------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			UPDATE
				"SchAcquisition"."TblLog_FileUpload_ObjectDetail"
			SET
				"Sys_Data_Edit_LoginSession_RefID" = varIDSession,
				"Sys_Data_Edit_DateTimeTZ" = varEditDateTimeTZ,
				"Sys_Partition_RemovableRecord_Key_RefID" = varSysPartitionRemovableRecordKeyRefID,
				"Sys_Branch_RefID" = varBranchRefID,
				"Sys_BaseCurrency_RefID" = varBaseCurrency_RefID,
				------------------------------
				"Log_FileUpload_Object_RefID" = varLog_FileUpload_Object_RefID,
				"RotateLog_FileUploadStagingAreaDetail_RefRPK" = varRotateLog_FileUploadStagingAreaDetail_RefRPK,
				"Sequence" = varSequence,
				"Name" = varName,
				"Size" = varSize,
				"MIME" = varMIME,
				"Extension" = varExtension,
				"LastModifiedDateTimeTZ" = varLastModifiedDateTimeTZ,
				"LastModifiedUnixTimestamp" = varLastModifiedUnixTimestamp,
				"HashMethod_RefID" = varHashMethod_RefID,
				"ContentBase64Hash" = varContentBase64Hash,
				"DataCompression_RefID" = varDataCompression_RefID,
				"StagingAreaFilePath" = varStagingAreaFilePath
			WHERE
				"Sys_PID" = varID
				OR
				"Sys_SID" = varID;
		END IF;

	---[ Data Return ]-----------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			varRecSetOutput."SignSuccess" := 1;
			varRecSetOutput."SignRecordType" := 'Sys_RPK';
			varRecSetOutput."SignRecordID" := (SELECT "Sys_RPK" FROM "SchAcquisition"."TblLog_FileUpload_ObjectDetail" WHERE "Sys_PID" = varID OR "Sys_SID" = varID LIMIT 1);
			varRecSetOutput."SignMessage" := null;

			RETURN NEXT varRecSetOutput;
		END IF;

	---[ Exception Handling ]-----------------------------------------------------------------------
		--EXCEPTION WHEN OTHERS THEN ...

END;
$_$;


ALTER FUNCTION "SchAcquisition"."Func_TblLog_FileUpload_ObjectDetail_UPDATE"(bigint, bigint, timestamp with time zone, bigint, bigint, bigint, bigint, bigint, smallint, character varying, bigint, character varying, character varying, character varying, bigint, bigint, character varying, bigint, character varying) OWNER TO "SysAdmin";

--
-- TOC entry 365 (class 1255 OID 6653768)
-- Name: Func_TblLog_FileUpload_Object_INSERT(character varying, bigint, timestamp with time zone, bigint, bigint, bigint, bigint); Type: FUNCTION; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE FUNCTION "SchAcquisition"."Func_TblLog_FileUpload_Object_INSERT"(character varying, bigint, timestamp with time zone, bigint, bigint, bigint, bigint) RETURNS SETOF "SchSystem"."HoldFuncSys_General_FeedBackQuery"
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchAcquisition"."Func_TblLog_FileUpload_Object_INSERT"
▪ Versi               :	1.00.0002
▪ Tanggal
     ► Pemutakhiran   :	2024-10-04
     ► Pembuatan      :	2021-07-26
▪ Input               :	• varSysDataAnnotation (varchar - Mandatory)
						• varIDSession (bigint - Mandatory)
						• varEntryDateTimeTZ (timestamptz - Mandatory)
						• varSysPartitionRemovableRecordKeyRefID (bigint - Mandatory)
						• varBranchRefID (bigint - Mandatory)
						• varBaseCurrency_RefID (bigint - Mandatory)
						------------------------------
						• varRotateLog_FileUploadStagingArea_RefRPK (bigint - Mandatory)
						------------------------------
▪ Output              :	varRecSetOutput ("SchSystem"."HoldFuncSys_General_FeedBackQuery")
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Memasukan data (INSERT) pada tabel TblLog_FileUpload_Object
▪ Copyright           :	Zheta © 2021 - 2024

----[ SQL Example(s) ]------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------*/

DECLARE
	---[ Input Variable(s) ]------------------------------------------------------------------------
		---{ Mandatory }------------------
			varSysDataAnnotation									ALIAS FOR $1;
			varIDSession											ALIAS FOR $2;
			varEntryDateTimeTZ										ALIAS FOR $3;
			varSysPartitionRemovableRecordKeyRefID					ALIAS FOR $4;
			varBranchRefID											ALIAS FOR $5;
			varBaseCurrency_RefID									ALIAS FOR $6;
			------------------------------
			varRotateLog_FileUploadStagingArea_RefRPK				ALIAS FOR $7;

		---{ Optional }-------------------

		---{ Additional }-----------------

	---[ Output Variable(s) ]-----------------------------------------------------------------------
			varRecSetOutput											"SchSystem"."HoldFuncSys_General_FeedBackQuery"%rowtype;

	---[ Intermediate Variable(s) ]-----------------------------------------------------------------
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

		---{ Additional }-----------------

BEGIN
	---[ Data Initializing ]------------------------------------------------------------------------
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		IF (varSignEligibleToProcess IS FALSE) THEN
			varSignEligibleToProcess := TRUE;
		END IF;

		IF (varSignEligibleToProcess IS TRUE) THEN
		END IF;

	---[ Data Processing ]--------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			INSERT INTO 
				"SchAcquisition"."TblLog_FileUpload_Object"
					(
					"Sys_Data_Annotation",
					"Sys_Data_Entry_LoginSession_RefID",
					"Sys_Data_Entry_DateTimeTZ",
					"Sys_Partition_RemovableRecord_Key_RefID",
					"Sys_Branch_RefID",
					"Sys_BaseCurrency_RefID",
					------------------------------
					"RotateLog_FileUploadStagingArea_RefRPK"
					)
				VALUES
					(
					varSysDataAnnotation,
					varIDSession,
					varEntryDateTimeTZ,
					varSysPartitionRemovableRecordKeyRefID,
					varBranchRefID,
					varBaseCurrency_RefID,
					------------------------------
					varRotateLog_FileUploadStagingArea_RefRPK
					);
		END IF;

	---[ Data Return ]-----------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			varRecSetOutput."SignSuccess" := 1;
			varRecSetOutput."SignRecordType" := 'Sys_RPK';
			varRecSetOutput."SignRecordID" := CURRVAL('"SchAcquisition"."TblLog_FileUpload_Object_Sys_RPK_seq"');
			varRecSetOutput."SignMessage" := null;

			RETURN NEXT varRecSetOutput;
		END IF;

	---[ Exception Handling ]-----------------------------------------------------------------------
		--EXCEPTION WHEN OTHERS THEN ...

END;
$_$;


ALTER FUNCTION "SchAcquisition"."Func_TblLog_FileUpload_Object_INSERT"(character varying, bigint, timestamp with time zone, bigint, bigint, bigint, bigint) OWNER TO "SysAdmin";

--
-- TOC entry 366 (class 1255 OID 6653769)
-- Name: Func_TblLog_FileUpload_Object_UPDATE(bigint, bigint, timestamp with time zone, bigint, bigint, bigint, bigint); Type: FUNCTION; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE FUNCTION "SchAcquisition"."Func_TblLog_FileUpload_Object_UPDATE"(bigint, bigint, timestamp with time zone, bigint, bigint, bigint, bigint) RETURNS SETOF "SchSystem"."HoldFuncSys_General_FeedBackQuery"
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchAcquisition"."Func_TblLog_FileUpload_Object_UPDATE"
▪ Versi               :	1.00.0002
▪ Tanggal
     ► Pemutakhiran   :	2024-10-04
     ► Pembuatan      :	2021-07-26
▪ Input               :	• varID (bigint - Mandatory)
						• varIDSession (bigint - Mandatory)
						• varEditDateTimeTZ (timestamptz - Mandatory)
						• varSysPartitionRemovableRecordKeyRefID (bigint - Mandatory)
						• varBranchRefID (bigint - Mandatory)
						• varBaseCurrency_RefID (bigint - Mandatory)
						------------------------------
						• varRotateLog_FileUploadStagingArea_RefRPK (bigint - Mandatory)
						------------------------------
▪ Output              :	varRecSetOutput ("SchSystem"."HoldFuncSys_General_FeedBackQuery")
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Memutakhirkan data (UPDATE) pada tabel TblLog_FileUpload_Object
▪ Copyright           :	Zheta © 2021 - 2024

----[ SQL Example(s) ]------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------*/

DECLARE
	---[ Input Variable(s) ]------------------------------------------------------------------------
		---{ Mandatory }------------------
			varID													ALIAS FOR $1;
			varIDSession											ALIAS FOR $2;
			varEditDateTimeTZ										ALIAS FOR $3;
			varSysPartitionRemovableRecordKeyRefID					ALIAS FOR $4;
			varBranchRefID											ALIAS FOR $5;
			varBaseCurrency_RefID									ALIAS FOR $6;
			------------------------------
			varRotateLog_FileUploadStagingArea_RefRPK				ALIAS FOR $7;

		---{ Optional }-------------------

		---{ Additional }-----------------

	---[ Output Variable(s) ]-----------------------------------------------------------------------
			varRecSetOutput											"SchSystem"."HoldFuncSys_General_FeedBackQuery"%rowtype;

	---[ Intermediate Variable(s) ]-----------------------------------------------------------------
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

		---{ Additional }-----------------

BEGIN
	---[ Data Initializing ]------------------------------------------------------------------------
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		IF (varSignEligibleToProcess IS FALSE) THEN
			varSignEligibleToProcess := TRUE;
		END IF;

		IF (varSignEligibleToProcess IS TRUE) THEN
		END IF;

	---[ Data Processing ]--------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			UPDATE
				"SchAcquisition"."TblLog_FileUpload_Object"
			SET
				"Sys_Data_Edit_LoginSession_RefID" = varIDSession,
				"Sys_Data_Edit_DateTimeTZ" = varEditDateTimeTZ,
				"Sys_Partition_RemovableRecord_Key_RefID" = varSysPartitionRemovableRecordKeyRefID,
				"Sys_Branch_RefID" = varBranchRefID,
				"Sys_BaseCurrency_RefID" = varBaseCurrency_RefID,
				------------------------------
				"RotateLog_FileUploadStagingArea_RefRPK" = varRotateLog_FileUploadStagingArea_RefRPK
			WHERE
				"Sys_PID" = varID
				OR
				"Sys_SID" = varID;
		END IF;

	---[ Data Return ]-----------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			varRecSetOutput."SignSuccess" := 1;
			varRecSetOutput."SignRecordType" := 'Sys_RPK';
			varRecSetOutput."SignRecordID" := (SELECT "Sys_RPK" FROM "SchAcquisition"."TblLog_FileUpload_Object" WHERE "Sys_PID" = varID OR "Sys_SID" = varID LIMIT 1);
			varRecSetOutput."SignMessage" := null;

			RETURN NEXT varRecSetOutput;
		END IF;

	---[ Exception Handling ]-----------------------------------------------------------------------
		--EXCEPTION WHEN OTHERS THEN ...

END;
$_$;


ALTER FUNCTION "SchAcquisition"."Func_TblLog_FileUpload_Object_UPDATE"(bigint, bigint, timestamp with time zone, bigint, bigint, bigint, bigint) OWNER TO "SysAdmin";

--
-- TOC entry 367 (class 1255 OID 6653770)
-- Name: Func_TblLog_FileUpload_PointerHistoryDetail_INSERT(character varying, bigint, timestamp with time zone, bigint, bigint, bigint, bigint, bigint); Type: FUNCTION; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE FUNCTION "SchAcquisition"."Func_TblLog_FileUpload_PointerHistoryDetail_INSERT"(character varying, bigint, timestamp with time zone, bigint, bigint, bigint, bigint, bigint) RETURNS SETOF "SchSystem"."HoldFuncSys_General_FeedBackQuery"
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchAcquisition"."Func_TblLog_FileUpload_PointerHistoryDetail_INSERT"
▪ Versi               :	1.00.0002
▪ Tanggal
     ► Pemutakhiran   :	2024-10-04
     ► Pembuatan      :	2021-07-29
▪ Input               :	• varSysDataAnnotation (varchar - Mandatory)
						• varIDSession (bigint - Mandatory)
						• varEntryDateTimeTZ (timestamptz - Mandatory)
						• varSysPartitionRemovableRecordKeyRefID (bigint - Mandatory)
						• varBranchRefID (bigint - Mandatory)
						• varBaseCurrency_RefID (bigint - Mandatory)
						------------------------------
						• varLog_FileUpload_PointerHistory_RefID (bigint - Mandatory)
						• varLog_FileUpload_Object_RefID (bigint - Mandatory)
						------------------------------
▪ Output              :	varRecSetOutput ("SchSystem"."HoldFuncSys_General_FeedBackQuery")
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Memasukan data (INSERT) pada tabel TblLog_FileUpload_PointerHistoryDetail
▪ Copyright           :	Zheta © 2021 - 2022

----[ SQL Example(s) ]------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------*/

DECLARE
	---[ Input Variable(s) ]------------------------------------------------------------------------
		varSysDataAnnotation									ALIAS FOR $1;
		varIDSession											ALIAS FOR $2;
		varEntryDateTimeTZ										ALIAS FOR $3;
		varSysPartitionRemovableRecordKeyRefID					ALIAS FOR $4;
		varBranchRefID											ALIAS FOR $5;
		varBaseCurrency_RefID									ALIAS FOR $6;
		------------------------------
		varLog_FileUpload_PointerHistory_RefID					ALIAS FOR $7;
		varLog_FileUpload_Object_RefID							ALIAS FOR $8;

	---[ Output Variable(s) ]-----------------------------------------------------------------------
		varRecSetOutput											"SchSystem"."HoldFuncSys_General_FeedBackQuery"%rowtype;

	---[ Intermediate Variable(s) ]-----------------------------------------------------------------
		varSystemNoticeTag										varchar;
		varSignEligibleToProcess								boolean;

BEGIN
	---[ Data Initializing ]------------------------------------------------------------------------
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		IF (varSignEligibleToProcess IS FALSE) THEN
			varSignEligibleToProcess := TRUE;
		END IF;

		IF (varSignEligibleToProcess IS TRUE) THEN
		END IF;

	---[ Data Processing ]--------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			INSERT INTO 
				"SchAcquisition"."TblLog_FileUpload_PointerHistoryDetail"
					(
					"Sys_Data_Annotation",
					"Sys_Data_Entry_LoginSession_RefID",
					"Sys_Data_Entry_DateTimeTZ",
					"Sys_Partition_RemovableRecord_Key_RefID",
					"Sys_Branch_RefID",
					"Sys_BaseCurrency_RefID",
					------------------------------
					"Log_FileUpload_PointerHistory_RefID",
					"Log_FileUpload_Object_RefID"
					)
				VALUES
					(
					varSysDataAnnotation,
					varIDSession,
					varEntryDateTimeTZ,
					varSysPartitionRemovableRecordKeyRefID,
					varBranchRefID,
					varBaseCurrency_RefID,
					------------------------------
					varLog_FileUpload_PointerHistory_RefID,
					varLog_FileUpload_Object_RefID
					);
		END IF;

	---[ Data Return ]-----------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			varRecSetOutput."SignSuccess" := 1;
			varRecSetOutput."SignRecordType" := 'Sys_RPK';
			varRecSetOutput."SignRecordID" := CURRVAL('"SchAcquisition"."TblLog_FileUpload_PointerHistoryDetail_Sys_RPK_seq"');
			varRecSetOutput."SignMessage" := null;

			RETURN NEXT varRecSetOutput;
		END IF;

	---[ Exception Handling ]-----------------------------------------------------------------------
		--EXCEPTION WHEN OTHERS THEN ...

END;
$_$;


ALTER FUNCTION "SchAcquisition"."Func_TblLog_FileUpload_PointerHistoryDetail_INSERT"(character varying, bigint, timestamp with time zone, bigint, bigint, bigint, bigint, bigint) OWNER TO "SysAdmin";

--
-- TOC entry 368 (class 1255 OID 6653771)
-- Name: Func_TblLog_FileUpload_PointerHistoryDetail_UPDATE(bigint, bigint, timestamp with time zone, bigint, bigint, bigint, bigint, bigint); Type: FUNCTION; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE FUNCTION "SchAcquisition"."Func_TblLog_FileUpload_PointerHistoryDetail_UPDATE"(bigint, bigint, timestamp with time zone, bigint, bigint, bigint, bigint, bigint) RETURNS SETOF "SchSystem"."HoldFuncSys_General_FeedBackQuery"
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchAcquisition"."Func_TblLog_FileUpload_PointerHistoryDetail_UPDATE"
▪ Versi               :	1.00.0002
▪ Tanggal
     ► Pemutakhiran   :	2024-10-04
     ► Pembuatan      :	2021-07-29
▪ Input               :	• varID (bigint - Mandatory)
						• varIDSession (bigint - Mandatory)
						• varEditDateTimeTZ (timestamptz - Mandatory)
						• varSysPartitionRemovableRecordKeyRefID (bigint - Mandatory)
						• varBranchRefID (bigint - Mandatory)
						• varBaseCurrency_RefID (bigint - Mandatory)
						------------------------------
						• varLog_FileUpload_PointerHistory_RefID (bigint - Mandatory)
						• varLog_FileUpload_Object_RefID (bigint - Mandatory)
						------------------------------
▪ Output              :	varRecSetOutput ("SchSystem"."HoldFuncSys_General_FeedBackQuery")
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Memutakhirkan data (UPDATE) pada tabel
						  TblLog_FileUpload_PointerHistoryDetail
▪ Copyright           :	Zheta © 2021 - 2022

----[ SQL Example(s) ]------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------*/

DECLARE
	---[ Input Variable(s) ]------------------------------------------------------------------------
		varID													ALIAS FOR $1;
		varIDSession											ALIAS FOR $2;
		varEditDateTimeTZ										ALIAS FOR $3;
		varSysPartitionRemovableRecordKeyRefID					ALIAS FOR $4;
		varBranchRefID											ALIAS FOR $5;
		varBaseCurrency_RefID									ALIAS FOR $6;
		------------------------------
		varLog_FileUpload_PointerHistory_RefID					ALIAS FOR $7;
		varLog_FileUpload_Object_RefID							ALIAS FOR $8;

	---[ Output Variable(s) ]-----------------------------------------------------------------------
		varRecSetOutput											"SchSystem"."HoldFuncSys_General_FeedBackQuery"%rowtype;

	---[ Intermediate Variable(s) ]-----------------------------------------------------------------
		varSystemNoticeTag										varchar;
		varSignEligibleToProcess								boolean;

BEGIN
	---[ Data Initializing ]------------------------------------------------------------------------
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		IF (varSignEligibleToProcess IS FALSE) THEN
			varSignEligibleToProcess := TRUE;
		END IF;

		IF (varSignEligibleToProcess IS TRUE) THEN
		END IF;

	---[ Data Processing ]--------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			UPDATE
				"SchAcquisition"."TblLog_FileUpload_PointerHistoryDetail"
			SET
				"Sys_Data_Edit_LoginSession_RefID" = varIDSession,
				"Sys_Data_Edit_DateTimeTZ" = varEditDateTimeTZ,
				"Sys_Partition_RemovableRecord_Key_RefID" = varSysPartitionRemovableRecordKeyRefID,
				"Sys_Branch_RefID" = varBranchRefID,
				"Sys_BaseCurrency_RefID" = varBaseCurrency_RefID,
				------------------------------
				"Log_FileUpload_PointerHistory_RefID" = varLog_FileUpload_PointerHistory_RefID,
				"Log_FileUpload_Object_RefID" = varLog_FileUpload_Object_RefID
			WHERE
				"Sys_PID" = varID
				OR
				"Sys_SID" = varID;
		END IF;

	---[ Data Return ]-----------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			varRecSetOutput."SignSuccess" := 1;
			varRecSetOutput."SignRecordType" := 'Sys_RPK';
			varRecSetOutput."SignRecordID" := (SELECT "Sys_RPK" FROM "SchAcquisition"."TblLog_FileUpload_PointerHistoryDetail" WHERE "Sys_PID" = varID OR "Sys_SID" = varID LIMIT 1);
			varRecSetOutput."SignMessage" := null;
		END IF;

	---[ Exception Handling ]-----------------------------------------------------------------------
		--EXCEPTION WHEN OTHERS THEN ...

END;
$_$;


ALTER FUNCTION "SchAcquisition"."Func_TblLog_FileUpload_PointerHistoryDetail_UPDATE"(bigint, bigint, timestamp with time zone, bigint, bigint, bigint, bigint, bigint) OWNER TO "SysAdmin";

--
-- TOC entry 369 (class 1255 OID 6653772)
-- Name: Func_TblLog_FileUpload_PointerHistory_INSERT(character varying, bigint, timestamp with time zone, bigint, bigint, bigint, bigint); Type: FUNCTION; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE FUNCTION "SchAcquisition"."Func_TblLog_FileUpload_PointerHistory_INSERT"(character varying, bigint, timestamp with time zone, bigint, bigint, bigint, bigint) RETURNS SETOF "SchSystem"."HoldFuncSys_General_FeedBackQuery"
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchAcquisition"."Func_TblLog_FileUpload_PointerHistory_INSERT"
▪ Versi               :	1.00.0001
▪ Tanggal
     ► Pemutakhiran   :	2024-10-04
     ► Pembuatan      :	2022-08-08
▪ Input               :	• varSysDataAnnotation (varchar - Mandatory)
						• varIDSession (bigint - Mandatory)
						• varEntryDateTimeTZ (timestamptz - Mandatory)
						• varSysPartitionRemovableRecordKeyRefID (bigint - Mandatory)
						• varBranchRefID (bigint - Mandatory)
						• varBaseCurrency_RefID (bigint - Mandatory)
						------------------------------
						• varLog_FileUpload_Pointer_RefID (bigint - Mandatory)
▪ Output              :	varRecSetOutput ("SchSystem"."HoldFuncSys_General_FeedBackQuery")
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Memasukan data (INSERT) pada tabel TblLog_FileUpload_PointerHistory
▪ Copyright           :	Zheta © 2021 - 2024

----[ SQL Example(s) ]------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------*/

DECLARE
	---[ Input Variable(s) ]------------------------------------------------------------------------
		---{ Mandatory }------------------
			varSysDataAnnotation									ALIAS FOR $1;
			varIDSession											ALIAS FOR $2;
			varEntryDateTimeTZ										ALIAS FOR $3;
			varSysPartitionRemovableRecordKeyRefID					ALIAS FOR $4;
			varBranchRefID											ALIAS FOR $5;
			varBaseCurrency_RefID									ALIAS FOR $6;
			------------------------------
			varLog_FileUpload_Pointer_RefID						ALIAS FOR $7;

		---{ Optional }-------------------

		---{ Additional }-----------------

	---[ Output Variable(s) ]-----------------------------------------------------------------------
			varRecSetOutput											"SchSystem"."HoldFuncSys_General_FeedBackQuery"%rowtype;

	---[ Intermediate Variable(s) ]-----------------------------------------------------------------
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

		---{ Additional }-----------------


BEGIN
	---[ Data Initializing ]------------------------------------------------------------------------
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		IF (varSignEligibleToProcess IS FALSE) THEN
			varSignEligibleToProcess := TRUE;
		END IF;

		IF (varSignEligibleToProcess IS TRUE) THEN
		END IF;

	---[ Data Processing ]--------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			INSERT INTO 
				"SchAcquisition"."TblLog_FileUpload_PointerHistory"
					(
					"Sys_Data_Annotation",
					"Sys_Data_Entry_LoginSession_RefID",
					"Sys_Data_Entry_DateTimeTZ",
					"Sys_Partition_RemovableRecord_Key_RefID",
					"Sys_Branch_RefID",
					"Sys_BaseCurrency_RefID",
					------------------------------
					"Log_FileUpload_Pointer_RefID"
					)
				VALUES
					(
					varSysDataAnnotation,
					varIDSession,
					varEntryDateTimeTZ,
					varSysPartitionRemovableRecordKeyRefID,
					varBranchRefID,
					varBaseCurrency_RefID,
					------------------------------
					varLog_FileUpload_Pointer_RefID
					);
		END IF;

	---[ Data Return ]-----------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			varRecSetOutput."SignSuccess" := 1;
			varRecSetOutput."SignRecordType" := 'Sys_RPK';
			varRecSetOutput."SignRecordID" := CURRVAL('"SchAcquisition"."TblLog_FileUpload_PointerHistory_Sys_RPK_seq"');
			varRecSetOutput."SignMessage" := null;

			RETURN NEXT varRecSetOutput;
		END IF;

	---[ Exception Handling ]-----------------------------------------------------------------------
		--EXCEPTION WHEN OTHERS THEN ...

END;
$_$;


ALTER FUNCTION "SchAcquisition"."Func_TblLog_FileUpload_PointerHistory_INSERT"(character varying, bigint, timestamp with time zone, bigint, bigint, bigint, bigint) OWNER TO "SysAdmin";

--
-- TOC entry 370 (class 1255 OID 6653773)
-- Name: Func_TblLog_FileUpload_PointerHistory_UPDATE(bigint, bigint, timestamp with time zone, bigint, bigint, bigint, bigint); Type: FUNCTION; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE FUNCTION "SchAcquisition"."Func_TblLog_FileUpload_PointerHistory_UPDATE"(bigint, bigint, timestamp with time zone, bigint, bigint, bigint, bigint) RETURNS SETOF "SchSystem"."HoldFuncSys_General_FeedBackQuery"
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchAcquisition"."Func_TblLog_FileUpload_PointerHistory_UPDATE"
▪ Versi               :	1.00.0001
▪ Tanggal
     ► Pemutakhiran   :	2024-10-04
     ► Pembuatan      :	2022-08-08
▪ Input               :	• varID (bigint - Mandatory)
						• varIDSession (bigint - Mandatory)
						• varEditDateTimeTZ (timestamptz - Mandatory)
						• varSysPartitionRemovableRecordKeyRefID (bigint - Mandatory)
						• varBranchRefID (bigint - Mandatory)
						• varBaseCurrency_RefID (bigint - Mandatory)
						------------------------------
						• varLog_FileUpload_Pointer_RefID (bigint - Mandatory)
▪ Output              :	varRecSetOutput ("SchSystem"."HoldFuncSys_General_FeedBackQuery")
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Memutakhirkan data (UPDATE) pada tabel TblLog_FileUpload_PointerHistory
▪ Copyright           :	Zheta © 2021 - 2024

----[ SQL Example(s) ]------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------*/

DECLARE
	---[ Input Variable(s) ]------------------------------------------------------------------------
		---{ Mandatory }------------------
			varID													ALIAS FOR $1;
			varIDSession											ALIAS FOR $2;
			varEditDateTimeTZ										ALIAS FOR $3;
			varSysPartitionRemovableRecordKeyRefID					ALIAS FOR $4;
			varBranchRefID											ALIAS FOR $5;
			varBaseCurrency_RefID									ALIAS FOR $6;
			------------------------------
			varLog_FileUpload_Pointer_RefID						ALIAS FOR $7;

		---{ Optional }-------------------

		---{ Additional }-----------------

	---[ Output Variable(s) ]-----------------------------------------------------------------------
			varRecSetOutput											"SchSystem"."HoldFuncSys_General_FeedBackQuery"%rowtype;

	---[ Intermediate Variable(s) ]-----------------------------------------------------------------
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

		---{ Additional }-----------------


BEGIN
	---[ Data Initializing ]------------------------------------------------------------------------
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		IF (varSignEligibleToProcess IS FALSE) THEN
			varSignEligibleToProcess := TRUE;
		END IF;

		IF (varSignEligibleToProcess IS TRUE) THEN
		END IF;

	---[ Data Processing ]--------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			UPDATE
				"SchAcquisition"."TblLog_FileUpload_PointerHistory"
			SET
				"Sys_Data_Edit_LoginSession_RefID" = varIDSession,
				"Sys_Data_Edit_DateTimeTZ" = varEditDateTimeTZ,
				"Sys_Partition_RemovableRecord_Key_RefID" = varSysPartitionRemovableRecordKeyRefID,
				"Sys_Branch_RefID" = varBranchRefID,
				"Sys_BaseCurrency_RefID" = varBaseCurrency_RefID,
				------------------------------
				"Log_FileUpload_Pointer_RefID" = varLog_FileUpload_Pointer_RefID
			WHERE
				"Sys_PID" = varID
				OR
				"Sys_SID" = varID;
		END IF;

	---[ Data Return ]-----------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			varRecSetOutput."SignSuccess" := 1;
			varRecSetOutput."SignRecordType" := 'Sys_RPK';
			varRecSetOutput."SignRecordID" := (SELECT "Sys_RPK" FROM "SchAcquisition"."TblLog_FileUpload_PointerHistory" WHERE "Sys_PID" = varID OR "Sys_SID" = varID LIMIT 1);
			varRecSetOutput."SignMessage" := null;

			RETURN NEXT varRecSetOutput;
		END IF;

	---[ Exception Handling ]-----------------------------------------------------------------------
		--EXCEPTION WHEN OTHERS THEN ...

END;
$_$;


ALTER FUNCTION "SchAcquisition"."Func_TblLog_FileUpload_PointerHistory_UPDATE"(bigint, bigint, timestamp with time zone, bigint, bigint, bigint, bigint) OWNER TO "SysAdmin";

--
-- TOC entry 371 (class 1255 OID 6653774)
-- Name: Func_TblLog_FileUpload_Pointer_INSERT(character varying, bigint, timestamp with time zone, bigint, bigint, bigint); Type: FUNCTION; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE FUNCTION "SchAcquisition"."Func_TblLog_FileUpload_Pointer_INSERT"(character varying, bigint, timestamp with time zone, bigint, bigint, bigint) RETURNS SETOF "SchSystem"."HoldFuncSys_General_FeedBackQuery"
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchAcquisition"."Func_TblLog_FileUpload_Pointer_INSERT"
▪ Versi               :	1.00.0003
▪ Tanggal
     ► Pemutakhiran   :	2024-10-04
     ► Pembuatan      :	2021-07-26
▪ Input               :	• varSysDataAnnotation (varchar - Mandatory)
						• varIDSession (bigint - Mandatory)
						• varEntryDateTimeTZ (timestamptz - Mandatory)
						• varSysPartitionRemovableRecordKeyRefID (bigint - Mandatory)
						• varBranchRefID (bigint - Mandatory)
						• varBaseCurrency_RefID (bigint - Mandatory)
						------------------------------
						------------------------------
▪ Output              :	varRecSetOutput ("SchSystem"."HoldFuncSys_General_FeedBackQuery")
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Memasukan data (INSERT) pada tabel TblLog_FileUpload_Pointer
▪ Copyright           :	Zheta © 2021 - 2024

----[ SQL Example(s) ]------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------*/

DECLARE
	---[ Input Variable(s) ]------------------------------------------------------------------------
		---{ Mandatory }------------------
			varSysDataAnnotation									ALIAS FOR $1;
			varIDSession											ALIAS FOR $2;
			varEntryDateTimeTZ										ALIAS FOR $3;
			varSysPartitionRemovableRecordKeyRefID					ALIAS FOR $4;
			varBranchRefID											ALIAS FOR $5;
			varBaseCurrency_RefID									ALIAS FOR $6;
			------------------------------

		---{ Optional }-------------------

		---{ Additional }-----------------

	---[ Output Variable(s) ]-----------------------------------------------------------------------
			varRecSetOutput											"SchSystem"."HoldFuncSys_General_FeedBackQuery"%rowtype;

	---[ Intermediate Variable(s) ]-----------------------------------------------------------------
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

		---{ Additional }-----------------

BEGIN
	---[ Data Initializing ]------------------------------------------------------------------------
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		IF (varSignEligibleToProcess IS FALSE) THEN
			varSignEligibleToProcess := TRUE;
		END IF;

		IF (varSignEligibleToProcess IS TRUE) THEN
		END IF;

	---[ Data Processing ]--------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			INSERT INTO 
				"SchAcquisition"."TblLog_FileUpload_Pointer"
					(
					"Sys_Data_Annotation",
					"Sys_Data_Entry_LoginSession_RefID",
					"Sys_Data_Entry_DateTimeTZ",
					"Sys_Partition_RemovableRecord_Key_RefID",
					"Sys_Branch_RefID",
					"Sys_BaseCurrency_RefID"
					------------------------------
					)
				VALUES
					(
					varSysDataAnnotation,
					varIDSession,
					varEntryDateTimeTZ,
					varSysPartitionRemovableRecordKeyRefID,
					varBranchRefID,
					varBaseCurrency_RefID
					------------------------------
					);
		END IF;

	---[ Data Return ]-----------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			varRecSetOutput."SignSuccess" := 1;
			varRecSetOutput."SignRecordType" := 'Sys_RPK';
			varRecSetOutput."SignRecordID" := CURRVAL('"SchAcquisition"."TblLog_FileUpload_Pointer_Sys_RPK_seq"');
			varRecSetOutput."SignMessage" := null;
		
			RETURN NEXT varRecSetOutput;
		END IF;

	---[ Exception Handling ]-----------------------------------------------------------------------
		--EXCEPTION WHEN OTHERS THEN ...

END;
$_$;


ALTER FUNCTION "SchAcquisition"."Func_TblLog_FileUpload_Pointer_INSERT"(character varying, bigint, timestamp with time zone, bigint, bigint, bigint) OWNER TO "SysAdmin";

--
-- TOC entry 372 (class 1255 OID 6653775)
-- Name: Func_TblLog_FileUpload_Pointer_UPDATE(bigint, bigint, timestamp with time zone, bigint, bigint, bigint); Type: FUNCTION; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE FUNCTION "SchAcquisition"."Func_TblLog_FileUpload_Pointer_UPDATE"(bigint, bigint, timestamp with time zone, bigint, bigint, bigint) RETURNS SETOF "SchSystem"."HoldFuncSys_General_FeedBackQuery"
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchAcquisition"."Func_TblLog_FileUpload_Pointer_UPDATE"
▪ Versi               :	1.00.0003
▪ Tanggal
     ► Pemutakhiran   :	2024-10-04
     ► Pembuatan      :	2021-07-26
▪ Input               :	• varID (bigint - Mandatory)
						• varIDSession (bigint - Mandatory)
						• varEditDateTimeTZ (timestamptz - Mandatory)
						• varSysPartitionRemovableRecordKeyRefID (bigint - Mandatory)
						• varBranchRefID (bigint - Mandatory)
						• varBaseCurrency_RefID (bigint - Mandatory)
						------------------------------
						------------------------------
▪ Output              :	varRecSetOutput ("SchSystem"."HoldFuncSys_General_FeedBackQuery")
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Memutakhirkan data (UPDATE) pada tabel TblLog_FileUpload_Pointer
▪ Copyright           :	Zheta © 2021 - 2024

----[ SQL Example(s) ]------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------*/

DECLARE
	---[ Input Variable(s) ]------------------------------------------------------------------------
		---{ Mandatory }------------------
			varID													ALIAS FOR $1;
			varIDSession											ALIAS FOR $2;
			varEditDateTimeTZ										ALIAS FOR $3;
			varSysPartitionRemovableRecordKeyRefID					ALIAS FOR $4;
			varBranchRefID											ALIAS FOR $5;
			varBaseCurrency_RefID									ALIAS FOR $6;
			------------------------------

		---{ Optional }-------------------

		---{ Additional }-----------------

	---[ Output Variable(s) ]-----------------------------------------------------------------------
			varRecSetOutput											"SchSystem"."HoldFuncSys_General_FeedBackQuery"%rowtype;

	---[ Intermediate Variable(s) ]-----------------------------------------------------------------
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

		---{ Additional }-----------------
BEGIN
	---[ Data Initializing ]------------------------------------------------------------------------
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		IF (varSignEligibleToProcess IS FALSE) THEN
			varSignEligibleToProcess := TRUE;
		END IF;

		IF (varSignEligibleToProcess IS TRUE) THEN
		END IF;

	---[ Data Processing ]--------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			UPDATE
				"SchAcquisition"."TblLog_FileUpload_Pointer"
			SET
				"Sys_Data_Edit_LoginSession_RefID" = varIDSession,
				"Sys_Data_Edit_DateTimeTZ" = varEditDateTimeTZ,
				"Sys_Partition_RemovableRecord_Key_RefID" = varSysPartitionRemovableRecordKeyRefID,
				"Sys_Branch_RefID" = varBranchRefID,
				"Sys_BaseCurrency_RefID" = varBaseCurrency_RefID
				------------------------------
			WHERE
				"Sys_PID" = varID
				OR
				"Sys_SID" = varID;
		END IF;

	---[ Data Return ]-----------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			varRecSetOutput."SignSuccess" := 1;
			varRecSetOutput."SignRecordType" := 'Sys_RPK';
			varRecSetOutput."SignRecordID" := (SELECT "Sys_RPK" FROM "SchAcquisition"."TblLog_FileUpload_Pointer" WHERE "Sys_PID" = varID OR "Sys_SID" = varID LIMIT 1);
			varRecSetOutput."SignMessage" := null;
		
			RETURN NEXT varRecSetOutput;
		END IF;

	---[ Exception Handling ]-----------------------------------------------------------------------
		--EXCEPTION WHEN OTHERS THEN ...

END;
$_$;


ALTER FUNCTION "SchAcquisition"."Func_TblLog_FileUpload_Pointer_UPDATE"(bigint, bigint, timestamp with time zone, bigint, bigint, bigint) OWNER TO "SysAdmin";

--
-- TOC entry 373 (class 1255 OID 6653776)
-- Name: Func_TblRotateLog_FileUploadStagingAreaDetail_INSERT(character varying, bigint, timestamp with time zone, bigint, smallint, character varying, bigint, character varying, character varying, character varying, bigint, bigint, character varying, character varying); Type: FUNCTION; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE FUNCTION "SchAcquisition"."Func_TblRotateLog_FileUploadStagingAreaDetail_INSERT"(character varying, bigint, timestamp with time zone, bigint, smallint, character varying, bigint, character varying, character varying, character varying, bigint, bigint, character varying, character varying) RETURNS SETOF "SchSystem"."HoldFuncSys_General_FeedBackQuery"
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchAcquisition"."Func_TblRotateLog_FileUploadStagingAreaDetail_INSERT"
▪ Versi               :	1.00.0001
▪ Tanggal
     ► Pemutakhiran   :	2024-10-04
     ► Pembuatan      :	2024-08-19
▪ Input               :	• varSysDataAnnotation (varchar - Mandatory)
						• varIDSession (bigint - Mandatory)
						• varEntryDateTimeTZ (timestamptz - Mandatory)
						------------------------------
						• varRotateLog_FileUploadStagingArea_RefRPK (bigint - Mandatory)
						• varSequence (smallint - Mandatory)
						• varName	(varchar - Mandatory)
						• varSize (bigint - Mandatory)
						• varMIME (varchar - Mandatory)
						• varExtension (varchar - Mandatory)
						• varLastModifiedDateTimeTZ (varchar - Mandatory)
						• varLastModifiedUnixTimestamp (bigint - Mandatory)
						• varHashMethod_RefID (bigint - Mandatory)
						• varContentBase64Hash (varchar - Mandatory)
						• varURLDelete (varchar - Mandatory)
						------------------------------
▪ Output              :	varRecSetOutput ("SchSystem"."HoldFuncSys_General_FeedBackQuery")
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Memasukan data (INSERT) pada tabel TblRotateLog_FileUploadStagingAreaDetail
▪ Copyright           :	Zheta © 2024

----[ SQL Example(s) ]------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------*/

DECLARE
	---[ Input Variable(s) ]------------------------------------------------------------------------
		---{ Mandatory }------------------
			varSysDataAnnotation									ALIAS FOR $1;
			varIDSession											ALIAS FOR $2;
			varEntryDateTimeTZ										ALIAS FOR $3;
			------------------------------
			varRotateLog_FileUploadStagingArea_RefRPK				ALIAS FOR $4;
			varSequence												ALIAS FOR $5;
			varName													ALIAS FOR $6;	
			varSize													ALIAS FOR $7;
			varMIME													ALIAS FOR $8;
			varExtension											ALIAS FOR $9;
			varLastModifiedDateTimeTZ								ALIAS FOR $10;
			varLastModifiedUnixTimestamp							ALIAS FOR $11;
			varHashMethod_RefID										ALIAS FOR $12;
			varContentBase64Hash									ALIAS FOR $13;
			varURLDelete											ALIAS FOR $14;

		---{ Optional }-------------------

		---{ Additional }-----------------

	---[ Output Variable(s) ]-----------------------------------------------------------------------
			varRecSetOutput											"SchSystem"."HoldFuncSys_General_FeedBackQuery"%rowtype;
	
	---[ Intermediate Variable(s) ]-----------------------------------------------------------------
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;
	
			varPrimeNumber											bigint;
			varSys_RotateID											bigint;
			varSys_RPK												bigint;
		
		   	varSignExist											smallint;

		---{ Additional }-----------------

BEGIN
	---[ Data Initializing ]------------------------------------------------------------------------
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		IF (varSignEligibleToProcess IS FALSE) THEN
			varSignEligibleToProcess := TRUE;
		END IF;

		IF (varSignEligibleToProcess IS TRUE) THEN
			---> Reinitializing varPrimeNumber
			varPrimeNumber := 10007; --2; --10007;

			---> Reinitializing varSys_RPK
			varSys_RPK := nextval('"SchAcquisition"."TblRotateLog_FileUploadStagingAreaDetail_Sys_RPK_seq"'::regclass);
			--RAISE NOTICE '%', varSys_RPK;

			---> Reinitializing varSys_RotateID
			varSys_RotateID := (((varSys_RPK - 1) % varPrimeNumber) + 1);
			--RAISE NOTICE '%', varSys_RotateID;

			---> Reinitializing varSignExist
			SELECT 
				COUNT("Sys_RotateID")
					INTO
						varSignExist
			FROM 
				"SchAcquisition"."TblRotateLog_FileUploadStagingAreaDetail"
			WHERE
				"Sys_RotateID" = varSys_RotateID;			
			--RAISE NOTICE '%', varSignExist;
		END IF;

	---[ Data Processing ]--------------------------------------------------------------------------
		IF (varSignExist = 0) THEN
			INSERT INTO 
				"SchAcquisition"."TblRotateLog_FileUploadStagingAreaDetail"
					(
					"Sys_RotateID",
					"Sys_RPK",
					"Sys_Data_Annotation",
					"Sys_Data_Entry_LoginSession_RefID",
					"Sys_Data_Entry_DateTimeTZ",
					------------------------------
					"RotateLog_FileUploadStagingArea_RefRPK",
					"Sequence",
					"Name",
					"Size",
					"MIME",
					"Extension",
					"LastModifiedDateTimeTZ",
					"LastModifiedUnixTimestamp",
					"HashMethod_RefID",
					"ContentBase64Hash",
					"URLDelete"
					)
				VALUES
					(
					varSys_RotateID,
					varSys_RPK,
					varSysDataAnnotation,
					varIDSession,
					varEntryDateTimeTZ,
					------------------------------
					varRotateLog_FileUploadStagingArea_RefRPK,
					varSequence,
					varName,
					varSize,
					varMIME,
					varExtension,
					varLastModifiedDateTimeTZ,
					varLastModifiedUnixTimestamp,
					varHashMethod_RefID,
					varContentBase64Hash,
					varURLDelete
					);
		ELSE
			UPDATE 
				"SchAcquisition"."TblRotateLog_FileUploadStagingAreaDetail"
			SET
				"Sys_RPK" = varSys_RPK,
				"Sys_Data_Annotation" = varSysDataAnnotation,
				"Sys_Data_Entry_LoginSession_RefID" = varIDSession,
				"Sys_Data_Entry_DateTimeTZ" = varEntryDateTimeTZ,
				------------------------------
				"RotateLog_FileUploadStagingArea_RefRPK" = varRotateLog_FileUploadStagingArea_RefRPK,
				"Sequence" = varSequence,
				"Name" = varName,
				"Size" = varSize,
				"MIME" = varMIME,
				"Extension" = varExtension,
				"LastModifiedDateTimeTZ" = varLastModifiedDateTimeTZ,
				"LastModifiedUnixTimestamp" = varLastModifiedUnixTimestamp,
				"HashMethod_RefID" = varHashMethod_RefID,
				"ContentBase64Hash" = varContentBase64Hash,
				"URLDelete" = varURLDelete
			WHERE
				"Sys_RotateID" = varSys_RotateID;
		END IF;

	---[ Data Return ]-----------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			varRecSetOutput."SignSuccess" := 1;
			varRecSetOutput."SignRecordType" := 'Sys_RotateID';
			varRecSetOutput."SignRecordID" := CURRVAL('"SchAcquisition"."TblRotateLog_FileUploadStagingAreaDetail_Sys_RPK_seq"');
			varRecSetOutput."SignMessage" := null;
		
			RETURN NEXT varRecSetOutput;
		END IF;

	---[ Exception Handling ]-----------------------------------------------------------------------
		--EXCEPTION WHEN OTHERS THEN ...

END;
$_$;


ALTER FUNCTION "SchAcquisition"."Func_TblRotateLog_FileUploadStagingAreaDetail_INSERT"(character varying, bigint, timestamp with time zone, bigint, smallint, character varying, bigint, character varying, character varying, character varying, bigint, bigint, character varying, character varying) OWNER TO "SysAdmin";

--
-- TOC entry 374 (class 1255 OID 6653779)
-- Name: Func_TblRotateLog_FileUploadStagingArea_INSERT(character varying, bigint, timestamp with time zone, character varying); Type: FUNCTION; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE FUNCTION "SchAcquisition"."Func_TblRotateLog_FileUploadStagingArea_INSERT"(character varying, bigint, timestamp with time zone, character varying) RETURNS SETOF "SchSystem"."HoldFuncSys_General_FeedBackQuery"
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchAcquisition"."Func_TblRotateLog_FileUploadStagingArea_INSERT"
▪ Versi               :	1.00.0001
▪ Tanggal
     ► Pemutakhiran   :	2024-10-04
     ► Pembuatan      :	2024-08-19
▪ Input               :	• varSysDataAnnotation (varchar - Mandatory)
						• varIDSession (bigint - Mandatory)
						• varEntryDateTimeTZ (timestamptz - Mandatory)
						------------------------------
						• varApplicationKey (varchar - Mandatory)
						------------------------------
▪ Output              :	varRecSetOutput ("SchSystem"."HoldFuncSys_General_FeedBackQuery")
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Memasukan data (INSERT) pada tabel TblRotateLog_FileUploadStagingArea
▪ Copyright           :	Zheta © 2024

----[ SQL Example(s) ]------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------*/

DECLARE
	---[ Input Variable(s) ]------------------------------------------------------------------------
		---{ Mandatory }------------------
			varSysDataAnnotation									ALIAS FOR $1;
			varIDSession											ALIAS FOR $2;
			varEntryDateTimeTZ										ALIAS FOR $3;
			------------------------------
			varApplicationKey										ALIAS FOR $4;

		---{ Optional }-------------------

		---{ Additional }-----------------

	---[ Output Variable(s) ]-----------------------------------------------------------------------
			varRecSetOutput											"SchSystem"."HoldFuncSys_General_FeedBackQuery"%rowtype;
	
	---[ Intermediate Variable(s) ]-----------------------------------------------------------------
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;
	
			varPrimeNumber											bigint;
			varSys_RotateID											bigint;
			varSys_RPK												bigint;
		
		   	varSignExist											smallint;

		---{ Additional }-----------------

BEGIN
	---[ Data Initializing ]------------------------------------------------------------------------
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		IF (varSignEligibleToProcess IS FALSE) THEN
			varSignEligibleToProcess := TRUE;
		END IF;

		IF (varSignEligibleToProcess IS TRUE) THEN
			---> Reinitializing varPrimeNumber
			varPrimeNumber := 10007; --2; --10007;

			---> Reinitializing varSys_RPK
			varSys_RPK := nextval('"SchAcquisition"."TblRotateLog_FileUploadStagingArea_Sys_RPK_seq"'::regclass);
			--RAISE NOTICE '%', varSys_RPK;

			---> Reinitializing varSys_RotateID
			varSys_RotateID := (((varSys_RPK - 1) % varPrimeNumber) + 1);
			--RAISE NOTICE '%', varSys_RotateID;

			---> Reinitializing varSignExist
			SELECT
				COUNT("Sys_RotateID")
					INTO
						varSignExist
			FROM 
				"SchAcquisition"."TblRotateLog_FileUploadStagingArea"
			WHERE
				"Sys_RotateID" = varSys_RotateID;
			--RAISE NOTICE '%', varSignExist;
		END IF;

	---[ Data Processing ]--------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			IF (varSignExist = 0) THEN
				INSERT INTO 
					"SchAcquisition"."TblRotateLog_FileUploadStagingArea"
						(
						"Sys_RotateID",
						"Sys_RPK",
						"Sys_Data_Annotation",
						"Sys_Data_Entry_LoginSession_RefID",
						"Sys_Data_Entry_DateTimeTZ",
						------------------------------
						"ApplicationKey"
						)
					VALUES
						(
						varSys_RotateID,
						varSys_RPK,
						varSysDataAnnotation,
						varIDSession,
						varEntryDateTimeTZ,
						------------------------------
						varApplicationKey
						);
			ELSE
				UPDATE 
					"SchAcquisition"."TblRotateLog_FileUploadStagingArea"
				SET
					"Sys_RPK" = varSys_RPK,
					"Sys_Data_Annotation" = varSysDataAnnotation,
					"Sys_Data_Entry_LoginSession_RefID" = varIDSession,
					"Sys_Data_Entry_DateTimeTZ" = varEntryDateTimeTZ,
					------------------------------
					"ApplicationKey" = varApplicationKey
				WHERE
					"Sys_RotateID" = varSys_RotateID;
			END IF;
		END IF;

	---[ Data Return ]-----------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			varRecSetOutput."SignSuccess" := 1;
			varRecSetOutput."SignRecordType" := 'Sys_RotateID';
			varRecSetOutput."SignRecordID" := CURRVAL('"SchAcquisition"."TblRotateLog_FileUploadStagingArea_Sys_RPK_seq"');
			varRecSetOutput."SignMessage" := null;
		
			RETURN NEXT varRecSetOutput;
		END IF;

	---[ Exception Handling ]-----------------------------------------------------------------------
		--EXCEPTION WHEN OTHERS THEN ...

END;
$_$;


ALTER FUNCTION "SchAcquisition"."Func_TblRotateLog_FileUploadStagingArea_INSERT"(character varying, bigint, timestamp with time zone, character varying) OWNER TO "SysAdmin";

--
-- TOC entry 375 (class 1255 OID 6653780)
-- Name: Func_TblCache_FunctionResult_INSERT(character varying, bigint, timestamp with time zone, bigint, bigint, bigint, character varying, json, json, character varying, json, character varying, character varying, bigint, interval); Type: FUNCTION; Schema: SchCache; Owner: SysAdmin
--

CREATE FUNCTION "SchCache"."Func_TblCache_FunctionResult_INSERT"(character varying, bigint, timestamp with time zone, bigint, bigint, bigint, character varying, json, json, character varying, json, character varying, character varying, bigint, interval) RETURNS SETOF "SchSystem"."HoldFuncSys_General_FeedBackQuery"
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchCache"."Func_TblCache_FunctionResult_INSERT"
▪ Versi               :	1.03.0001
▪ Tanggal
     ► Pemutakhiran   :	2024-10-04
     ► Pembuatan      :	2024-07-03
▪ Input               :	• varSysDataAnnotation (varchar - Mandatory)
						• varIDSession (bigint - Mandatory)
						• varEntryDateTimeTZ (timestamptz - Mandatory)
						• varSysPartitionRemovableRecordKeyRefID (bigint - Mandatory)
						• varBranch_RefID (bigint - Mandatory)
						• varBaseCurrency_RefID (bigint - Mandatory)
						------------------------------
						• varSchemaFunctionName (varchar - Mandatory)
						• varParameter (json - Mandatory)
						• varObjectsSignatureReference (json - Mandatory)
						• varSQLRecallSyntax (varchar - Mandatory)
						• varResult (json - Mandatory)
						• varReturnDataType (varchar - Mandatory)
						• varReturnDataTypePlaceHolder (varchar - Mandatory)
						• varRecordCount (bigint - Mandatory)
						• varQueryExecutionInterval (interval - Mandatory)
						------------------------------
▪ Output              :	varRecSetOutput ("SchSystem"."HoldFuncSys_General_FeedBackQuery")
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Memasukan data (INSERT) pada tabel TblCache_FunctionResult
▪ Copyright           :	Zheta © 2024

----[ SQL Example(s) ]------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------*/

DECLARE
	---[ Input Variable(s) ]------------------------------------------------------------------------
		---{ Mandatory }------------------
			varSysDataAnnotation									ALIAS FOR $1;
			varIDSession											ALIAS FOR $2;
			varEntryDateTimeTZ										ALIAS FOR $3;
			varSysPartitionRemovableRecordKeyRefID					ALIAS FOR $4;
			varBranch_RefID											ALIAS FOR $5;
			varBaseCurrency_RefID									ALIAS FOR $6;
			------------------------------
			varSchemaFunctionName									ALIAS FOR $7;
			varParameter											ALIAS FOR $8;
			varObjectsSignatureReference							ALIAS FOR $9;
			varSQLRecallSyntax										ALIAS FOR $10;
			varResult												ALIAS FOR $11;
			varReturnDataType										ALIAS FOR $12;
			varReturnDataTypePlaceHolder							ALIAS FOR $13;
			varRecordCount											ALIAS FOR $14;
			varQueryExecutionInterval								ALIAS FOR $15;

		---{ Optional }-------------------

		---{ Additional }-----------------

	---[ Output Variable(s) ]-----------------------------------------------------------------------
			varRecSetOutput											"SchSystem"."HoldFuncSys_General_FeedBackQuery"%rowtype;

	---[ Intermediate Variable(s) ]-----------------------------------------------------------------
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

		---{ Additional }-----------------

BEGIN
	---[ Data Initializing ]------------------------------------------------------------------------
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		IF (varSignEligibleToProcess IS FALSE) THEN
			varSignEligibleToProcess := TRUE;
		END IF;

		IF (varSignEligibleToProcess IS TRUE) THEN
		END IF;

	---[ Data Processing ]--------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			INSERT INTO 
				"SchCache"."TblCache_FunctionResult"
					(
					"Sys_Data_Annotation",
					"Sys_Data_Entry_LoginSession_RefID",
					"Sys_Data_Entry_DateTimeTZ",
					"Sys_Partition_RemovableRecord_Key_RefID",
					"Sys_Branch_RefID",
					"Sys_BaseCurrency_RefID",
					------------------------------
					"SchemaFunctionName",
					"Parameter",
					"ObjectsSignatureReference",
					"SQLRecallSyntax",
					"Result",
					"ReturnDataType",
					"ReturnDataTypePlaceHolder",
					"RecordCount",
					"QueryExecutionInterval"
					)
				VALUES
					(
					varSysDataAnnotation,
					varIDSession,
					varEntryDateTimeTZ,
					varSysPartitionRemovableRecordKeyRefID,
					varBranch_RefID,
					varBaseCurrency_RefID,
					------------------------------
					varSchemaFunctionName,
					varParameter,
					varObjectsSignatureReference,
					varSQLRecallSyntax,
					varResult,
					varReturnDataType,
					varReturnDataTypePlaceHolder,
					varRecordCount,
					varQueryExecutionInterval
					);
		END IF;

	---[ Data Return ]-----------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			varRecSetOutput."SignSuccess" := 1;
			varRecSetOutput."SignRecordType" := 'Sys_RPK';
			varRecSetOutput."SignRecordID" := CURRVAL('"SchCache"."TblCache_FunctionResult_Sys_RPK_seq"');
			varRecSetOutput."SignMessage" := null;

			RETURN NEXT varRecSetOutput;
		END IF;

	---[ Exception Handling ]-----------------------------------------------------------------------
		--EXCEPTION WHEN OTHERS THEN ...

END;
$_$;


ALTER FUNCTION "SchCache"."Func_TblCache_FunctionResult_INSERT"(character varying, bigint, timestamp with time zone, bigint, bigint, bigint, character varying, json, json, character varying, json, character varying, character varying, bigint, interval) OWNER TO "SysAdmin";

--
-- TOC entry 379 (class 1255 OID 6653781)
-- Name: Func_TblCache_FunctionResult_UPDATE(bigint, bigint, timestamp with time zone, bigint, bigint, bigint, character varying, json, json, character varying, json, character varying, character varying, bigint, interval); Type: FUNCTION; Schema: SchCache; Owner: SysAdmin
--

CREATE FUNCTION "SchCache"."Func_TblCache_FunctionResult_UPDATE"(bigint, bigint, timestamp with time zone, bigint, bigint, bigint, character varying, json, json, character varying, json, character varying, character varying, bigint, interval) RETURNS SETOF "SchSystem"."HoldFuncSys_General_FeedBackQuery"
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchCache"."Func_TblCache_FunctionResult_UPDATE"
▪ Versi               :	1.03.0001
▪ Tanggal
     ► Pemutakhiran   :	2024-10-04
     ► Pembuatan      :	2024-07-03
▪ Input               :	• varID (bigint - Mandatory)
						• varIDSession (bigint - Mandatory)
						• varEditDateTimeTZ (timestamptz - Mandatory)
						• varSysPartitionRemovableRecordKeyRefID (bigint - Mandatory)
						• varBranch_RefID (bigint - Mandatory)
						• varBaseCurrency_RefID (bigint - Mandatory)
						------------------------------
						• varSchemaFunctionName (varchar - Mandatory)
						• varParameter (json - Mandatory)
						• varObjectsSignatureReference (json - Mandatory)
						• varSQLRecallSyntax (varchar - Mandatory)
						• varResult (json - Mandatory)
						• varReturnDataType (varchar - Mandatory)
						• varReturnDataTypePlaceHolder (varchar - Mandatory)
						• varRecordCount (bigint - Mandatory)
						• varQueryExecutionInterval (interval - Mandatory)
						------------------------------
▪ Output              :	varRecSetOutput ("SchSystem"."HoldFuncSys_General_FeedBackQuery")
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Memutakhirkan data (UPDATE) pada tabel TblCache_FunctionResult
▪ Copyright           :	Zheta © 2024

----[ SQL Example(s) ]------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------*/

DECLARE
	---[ Input Variable(s) ]------------------------------------------------------------------------
		---{ Mandatory }------------------
			varID													ALIAS FOR $1;
			varIDSession											ALIAS FOR $2;
			varEditDateTimeTZ										ALIAS FOR $3;
			varSysPartitionRemovableRecordKeyRefID					ALIAS FOR $4;
			varBranch_RefID											ALIAS FOR $5;
			varBaseCurrency_RefID									ALIAS FOR $6;
			------------------------------
			varSchemaFunctionName									ALIAS FOR $7;
			varParameter											ALIAS FOR $8;
			varObjectsSignatureReference							ALIAS FOR $9;
			varSQLRecallSyntax										ALIAS FOR $10;
			varResult												ALIAS FOR $11;
			varReturnDataType										ALIAS FOR $12;
			varReturnDataTypePlaceHolder							ALIAS FOR $13;
			varRecordCount											ALIAS FOR $14;
			varQueryExecutionInterval								ALIAS FOR $15;

		---{ Optional }-------------------

		---{ Additional }-----------------

	---[ Output Variable(s) ]-----------------------------------------------------------------------
			varRecSetOutput											"SchSystem"."HoldFuncSys_General_FeedBackQuery"%rowtype;

	---[ Intermediate Variable(s) ]-----------------------------------------------------------------
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

		---{ Additional }-----------------

BEGIN
	---[ Data Initializing ]------------------------------------------------------------------------
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		IF (varSignEligibleToProcess IS FALSE) THEN
			varSignEligibleToProcess := TRUE;
		END IF;

		IF (varSignEligibleToProcess IS TRUE) THEN
		END IF;

	---[ Data Processing ]--------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			UPDATE
				"SchCache"."TblCache_FunctionResult"
			SET
				"Sys_Data_Edit_LoginSession_RefID" = varIDSession,
				"Sys_Data_Edit_DateTimeTZ" = varEditDateTimeTZ,
				-- "Sys_Partition_RemovableRecord_Key_RefID" = varSysPartitionRemovableRecordKeyRefID,
				"Sys_Branch_RefID" = varBranch_RefID,
				"Sys_BaseCurrency_RefID" = varBaseCurrency_RefID,
				------------------------------
				"SchemaFunctionName" = varSchemaFunctionName,
				"Parameter" = varParameter,
				"ObjectsSignatureReference" = varObjectsSignatureReference,
				"SQLRecallSyntax" = varSQLRecallSyntax,
				"Result" = varResult,
				"ReturnDataType" = varReturnDataType,
				"ReturnDataTypePlaceHolder" = varReturnDataTypePlaceHolder,
				"RecordCount" = varRecordCount,
				"QueryExecutionInterval" = varQueryExecutionInterval
			WHERE
				"Sys_PID" = varID
				OR
				"Sys_SID" = varID;
		END IF;

	---[ Data Return ]-----------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			varRecSetOutput."SignSuccess" := 1;
			varRecSetOutput."SignRecordType" := 'Sys_RPK';
			varRecSetOutput."SignRecordID" := (SELECT "Sys_RPK" FROM "SchCache"."TblCache_FunctionResult" WHERE "Sys_PID" = varID OR "Sys_SID" = varID LIMIT 1);
			varRecSetOutput."SignMessage" := null;
		
			RETURN NEXT varRecSetOutput;
		END IF;

	---[ Exception Handling ]-----------------------------------------------------------------------
		--EXCEPTION WHEN OTHERS THEN ...

END;
$_$;


ALTER FUNCTION "SchCache"."Func_TblCache_FunctionResult_UPDATE"(bigint, bigint, timestamp with time zone, bigint, bigint, bigint, character varying, json, json, character varying, json, character varying, character varying, bigint, interval) OWNER TO "SysAdmin";

--
-- TOC entry 380 (class 1255 OID 6653782)
-- Name: Func_TblStatistic_CacheFunctionResultAccess_INSERT(character varying, bigint, timestamp with time zone, bigint, bigint, bigint, bigint, timestamp with time zone, bigint); Type: FUNCTION; Schema: SchCache; Owner: SysAdmin
--

CREATE FUNCTION "SchCache"."Func_TblStatistic_CacheFunctionResultAccess_INSERT"(character varying, bigint, timestamp with time zone, bigint, bigint, bigint, bigint, timestamp with time zone, bigint) RETURNS SETOF "SchSystem"."HoldFuncSys_General_FeedBackQuery"
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchCache"."Func_TblStatistic_CacheFunctionResultAccess_INSERT"
▪ Versi               :	1.00.0001
▪ Tanggal
     ► Pemutakhiran   :	2024-10-04
     ► Pembuatan      :	2024-07-08
▪ Input               :	• varSysDataAnnotation (varchar - Mandatory)
						• varIDSession (bigint - Mandatory)
						• varEntryDateTimeTZ (timestamptz - Mandatory)
						• varSysPartitionRemovableRecordKeyRefID (bigint - Mandatory)
						• varBranch_RefID (bigint - Mandatory)
						• varBaseCurrency_RefID (bigint - Mandatory)
						------------------------------
						• varCache_FunctionResult_RefID (bigint - Mandatory)
						• varLastReadDateTimeTZ (timestamptz - Mandatory)
						• varReadFrequencies (bigint - Mandatory)
						------------------------------
▪ Output              :	varRecSetOutput ("SchSystem"."HoldFuncSys_General_FeedBackQuery")
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Memasukan data (INSERT) pada tabel TblStatistic_CacheFunctionResultAccess
▪ Copyright           :	Zheta © 2024

----[ SQL Example(s) ]------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------*/

DECLARE
	---[ Input Variable(s) ]------------------------------------------------------------------------
		---{ Mandatory }------------------
			varSysDataAnnotation									ALIAS FOR $1;
			varIDSession											ALIAS FOR $2;
			varEntryDateTimeTZ										ALIAS FOR $3;
			varSysPartitionRemovableRecordKeyRefID					ALIAS FOR $4;
			varBranch_RefID											ALIAS FOR $5;
			varBaseCurrency_RefID									ALIAS FOR $6;
			------------------------------
			varCache_FunctionResult_RefID							ALIAS FOR $7;
			varLastReadDateTimeTZ									ALIAS FOR $8;
			varReadFrequencies										ALIAS FOR $9;

		---{ Optional }-------------------

		---{ Additional }-----------------

	---[ Output Variable(s) ]-----------------------------------------------------------------------
			varRecSetOutput											"SchSystem"."HoldFuncSys_General_FeedBackQuery"%rowtype;

	---[ Intermediate Variable(s) ]-----------------------------------------------------------------
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

		---{ Additional }-----------------

BEGIN
	---[ Data Initializing ]------------------------------------------------------------------------
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		IF (varSignEligibleToProcess IS FALSE) THEN
			varSignEligibleToProcess := TRUE;
		END IF;

		IF (varSignEligibleToProcess IS TRUE) THEN
		END IF;

	---[ Data Processing ]--------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			INSERT INTO 
				"SchCache"."TblStatistic_CacheFunctionResultAccess"
					(
					"Sys_Data_Annotation",
					"Sys_Data_Entry_LoginSession_RefID",
					"Sys_Data_Entry_DateTimeTZ",
					"Sys_Partition_RemovableRecord_Key_RefID",
					"Sys_Branch_RefID",
					"Sys_BaseCurrency_RefID",
					------------------------------
					"Cache_FunctionResult_RefID",
					"LastReadDateTimeTZ",
					"ReadFrequencies"
					)
				VALUES
					(
					varSysDataAnnotation,
					varIDSession,
					varEntryDateTimeTZ,
					varSysPartitionRemovableRecordKeyRefID,
					varBranch_RefID,
					varBaseCurrency_RefID,
					------------------------------
					varCache_FunctionResult_RefID,
					varLastReadDateTimeTZ,
					varReadFrequencies
					);
		END IF;

	---[ Data Return ]-----------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			varRecSetOutput."SignSuccess" := 1;
			varRecSetOutput."SignRecordType" := 'Sys_RPK';
			varRecSetOutput."SignRecordID" := CURRVAL('"SchCache"."TblStatistic_CacheFunctionResultAccess_Sys_RPK_seq"');
			varRecSetOutput."SignMessage" := null;

			RETURN NEXT varRecSetOutput;
		END IF;

	---[ Exception Handling ]-----------------------------------------------------------------------
		--EXCEPTION WHEN OTHERS THEN ...

END;
$_$;


ALTER FUNCTION "SchCache"."Func_TblStatistic_CacheFunctionResultAccess_INSERT"(character varying, bigint, timestamp with time zone, bigint, bigint, bigint, bigint, timestamp with time zone, bigint) OWNER TO "SysAdmin";

--
-- TOC entry 384 (class 1255 OID 6653783)
-- Name: Func_TblStatistic_CacheFunctionResultAccess_UPDATE(bigint, bigint, timestamp with time zone, bigint, bigint, bigint, bigint, timestamp with time zone, bigint); Type: FUNCTION; Schema: SchCache; Owner: SysAdmin
--

CREATE FUNCTION "SchCache"."Func_TblStatistic_CacheFunctionResultAccess_UPDATE"(bigint, bigint, timestamp with time zone, bigint, bigint, bigint, bigint, timestamp with time zone, bigint) RETURNS SETOF "SchSystem"."HoldFuncSys_General_FeedBackQuery"
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchCache"."Func_TblStatistic_CacheFunctionResultAccess_UPDATE"
▪ Versi               :	1.00.0001
▪ Tanggal
     ► Pemutakhiran   :	2024-10-04
     ► Pembuatan      :	2024-07-08
▪ Input               :	• varID (bigint - Mandatory)
						• varIDSession (bigint - Mandatory)
						• varEditDateTimeTZ (timestamptz - Mandatory)
						• varSysPartitionRemovableRecordKeyRefID (bigint - Mandatory)
						• varBranch_RefID (bigint - Mandatory)
						• varBaseCurrency_RefID (bigint - Mandatory)
						------------------------------
						• varCache_FunctionResult_RefID (bigint - Mandatory)
						• varLastReadDateTimeTZ (timestamptz - Mandatory)
						• varReadFrequencies (bigint - Mandatory)
						------------------------------
▪ Output              :	varRecSetOutput ("SchSystem"."HoldFuncSys_General_FeedBackQuery")
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Memutakhirkan data (UPDATE) pada tabel
						  TblStatistic_CacheFunctionResultAccess
▪ Copyright           :	Zheta © 2024

----[ SQL Example(s) ]------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------*/

DECLARE
	---[ Input Variable(s) ]------------------------------------------------------------------------
		---{ Mandatory }------------------
			varID													ALIAS FOR $1;
			varIDSession											ALIAS FOR $2;
			varEditDateTimeTZ										ALIAS FOR $3;
			varSysPartitionRemovableRecordKeyRefID					ALIAS FOR $4;
			varBranch_RefID											ALIAS FOR $5;
			varBaseCurrency_RefID									ALIAS FOR $6;
			------------------------------
			varCache_FunctionResult_RefID							ALIAS FOR $7;
			varLastReadDateTimeTZ									ALIAS FOR $8;
			varReadFrequencies										ALIAS FOR $9;

		---{ Optional }-------------------

		---{ Additional }-----------------

	---[ Output Variable(s) ]-----------------------------------------------------------------------
			varRecSetOutput											"SchSystem"."HoldFuncSys_General_FeedBackQuery"%rowtype;

	---[ Intermediate Variable(s) ]-----------------------------------------------------------------
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

		---{ Additional }-----------------

BEGIN
	---[ Data Initializing ]------------------------------------------------------------------------
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		IF (varSignEligibleToProcess IS FALSE) THEN
			varSignEligibleToProcess := TRUE;
		END IF;

		IF (varSignEligibleToProcess IS TRUE) THEN
		END IF;

	---[ Data Processing ]--------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			UPDATE
				"SchCache"."TblStatistic_CacheFunctionResultAccess"
			SET
				"Sys_Data_Edit_LoginSession_RefID" = varIDSession,
				"Sys_Data_Edit_DateTimeTZ" = varEditDateTimeTZ,
				-- "Sys_Partition_RemovableRecord_Key_RefID" = varSysPartitionRemovableRecordKeyRefID,
				"Sys_Branch_RefID" = varBranch_RefID,
				"Sys_BaseCurrency_RefID" = varBaseCurrency_RefID,
				------------------------------
				"Cache_FunctionResult_RefID" = varCache_FunctionResult_RefID,
				"LastReadDateTimeTZ" = varLastReadDateTimeTZ,
				"ReadFrequencies" = varReadFrequencies
			WHERE
				"Sys_PID" = varID
				OR
				"Sys_SID" = varID;
		END IF;

	---[ Data Return ]-----------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			varRecSetOutput."SignSuccess" := 1;
			varRecSetOutput."SignRecordType" := 'Sys_RPK';
			varRecSetOutput."SignRecordID" := (SELECT "Sys_RPK" FROM "SchCache"."TblStatistic_CacheFunctionResultAccess" WHERE "Sys_PID" = varID OR "Sys_SID" = varID LIMIT 1);
			varRecSetOutput."SignMessage" := null;
		
			RETURN NEXT varRecSetOutput;
		END IF;

	---[ Exception Handling ]-----------------------------------------------------------------------
		--EXCEPTION WHEN OTHERS THEN ...

END;
$_$;


ALTER FUNCTION "SchCache"."Func_TblStatistic_CacheFunctionResultAccess_UPDATE"(bigint, bigint, timestamp with time zone, bigint, bigint, bigint, bigint, timestamp with time zone, bigint) OWNER TO "SysAdmin";

--
-- TOC entry 385 (class 1255 OID 6653784)
-- Name: Func_SQLGenerator_RptDataForm_Log_RecordDataTracking(bigint, bigint, bigint, smallint, bigint[], json); Type: FUNCTION; Schema: SchLog; Owner: SysAdmin
--

CREATE FUNCTION "SchLog"."Func_SQLGenerator_RptDataForm_Log_RecordDataTracking"(bigint, bigint, bigint, smallint, bigint[] DEFAULT NULL::bigint[], json DEFAULT NULL::json) RETURNS character varying
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchLog"."Func_SQLGenerator_RptDataForm_Log_RecordDataTracking"
▪ Versi               :	1.00.0000
▪ Tanggal
     ► Pemutakhiran   :	2026-11-05
     ► Pembuatan      :	2026-11-05
▪ Input               :	• varSysDataReadLoginSession_RefID (bigint - Mandatory)
						• varSysBranch_RefID (bigint - Mandatory)
						------------------------------
						• varID (bigint - Mandatory)
						• varRecordVersion (smallint - Mandatory)
						------------------------------
						• varEnvironmentParameter (json - Optional)
						------------------------------
▪ Output              :	varReturn (varchar)
▪ Deskripsi           :	• Mendapatkan SQL Generator untuk Form Dokumen Log Record Data Tracking
						  berdasarkan ID Branch (varSysBranch_RefID), ID Record (varID), and Version
						  Record (varRecordVersion).
					  	• Parameter (diperbolehkan parsial) pada varEnvironmentParameter yang dapat
						  digunakan adalah :
						  	- DBLink Connection String :
						 		- "DBLink.ConnectionString.FrontEnd"				-> (varchar) DBLink Connection String untuk Database FrontEnd
								- "DBLink.ConnectionString.BackEnd.DataOLAP"		-> (varchar) DBLink Connection String untuk Database BackEnd OLAP
								- "DBLink.ConnectionString.BackEnd.DataOLTP"		-> (varchar) DBLink Connection String untuk Database BackEnd OLTP
								- "DBLink.ConnectionString.BackEnd.DataWarehouse"	-> (varchar) DBLink Connection String untuk Database BackEnd Data Warehouse
								- "DBLink.ConnectionString.BackEnd.SysConfig"		-> (varchar) DBLink Connection String untuk Database BackEnd SysConfig
▪ Copyright           :	Zheta © 2026

----[ Related Database Object(s) ]------------------------------------------------------------------

▪ Tabel               :	• [BE] "SchLog"."TblLog_RecordDataTracking"

▪ Fungsi              :	• [BE] "SchSystem"."FuncSys_General_GetEnvironmentParameterExtraction"(bigint, bigint, json, varchar, json, json)
						------------------------------
						• [BE] "SchLog"."Func_SQLGenerator_RptDataForm_Log_RecordDataTracking"(bigint, bigint, bigint, smallint, bigint[], json) [ RECURSIVE ]

----[ SQL Example(s) ]------------------------------------------------------------------------------

▪ ---> With Login Session ID, Branch ID, Record ID, and Record Version
	SELECT 
		"SchLog"."Func_SQLGenerator_RptDataForm_Log_RecordDataTracking"(
			6000000000001::bigint,
			11000000000004::bigint,
			------------------------------
			46000000000041::bigint,
			0::smallint
			------------------------------
			);

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varSysDataReadLoginSession_RefID						ALIAS FOR $1;
			varSysBranch_RefID										ALIAS FOR $2;
			------------------------------
			varID													ALIAS FOR $3;
			varRecordVersion										ALIAS FOR $4;

		---{ Optional }-------------------
			------------------------------
			varArrayID												ALIAS FOR $5;
			varEnvironmentParameter									ALIAS FOR $6;

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----
			varReturn												varchar;

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

			varObjectIdentity										varchar;
			varJSONData_Detail_EnvSession									json;

			varDBLinkConnectionString_FE							varchar;
			varDBLinkConnectionString_BE_DataOLAP					varchar;
			varDBLinkConnectionString_BE_DataOLTP					varchar;
			varDBLinkConnectionString_BE_DataWarehouse				varchar;
			varDBLinkConnectionString_BE_SysConfig					varchar;

			varDataCustomize_Filter_JSON							json;
			varDataCustomize_Sort_JSON								json;
			varDataCustomize_Filter_CoreFields_JSON					json;
			varDataCustomize_Sort_CoreFields_JSON					json;
			varDataCustomize_Filter_NonCoreFields_JSON				json;
			varDataCustomize_Sort_NonCoreFields_JSON				json;

			varPagination_PageSize									bigint;
			varPagination_PageShow									bigint;

			varDataCustomize_Filter									varchar;
			varDataCustomize_Sort									varchar;
			varDataCustomize_Filter_CoreFields						varchar;
			varDataCustomize_Sort_CoreFields						varchar;
			varDataCustomize_Filter_NonCoreFields					varchar;
			varDataCustomize_Sort_NonCoreFields						varchar;

			varArraySysBranch_RefID									bigint[];
			varArraySysBaseBranch_RefID								bigint[];

			varArrayCurrency_RefID									bigint[];
			varArrayCurrencyISOCode									varchar(3)[];
			varArrayCurrencySymbol									varchar(4)[];

			varMainTable											varchar;

			varSQL													varchar;
			varSQLDefault											varchar;

		---{ Additional }-----------------
			varJSONParameter										json;
			varJSONData_Header										json;
			varJSONData_Detail										json;

BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		---> Initializing : varObjectIdentity
			varObjectIdentity :=
				'SchFinance.Func_SQLGenerator_RptDataForm_Log_RecordDataTracking';

		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------( START )-----
			IF (varSignEligibleToProcess IS FALSE) THEN
				varSignEligibleToProcess := TRUE;

				/*
				---> Reinitializing : varArrayID
					IF (varArrayID::bigint[] IS NULL) THEN
						varArrayID := '{}'::bigint[];
					END IF;
				*/

				IF (CARDINALITY(varArrayID::bigint[]) = 0) THEN
					varSignEligibleToProcess := FALSE;
				END IF;
			END IF;
		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------(  END  )-----

		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------( START )-----
			IF (varSignEligibleToProcess IS TRUE) THEN
				---> Initializing : Environment Parameter
					SELECT
						"Env_Session",
						------------------------------
						"DBLinkConnectionString_FE",
						"DBLinkConnectionString_BE_DataOLAP",
						"DBLinkConnectionString_BE_DataOLTP",
						"DBLinkConnectionString_BE_DataWarehouse",
						"DBLinkConnectionString_BE_SysConfig",
						------------------------------
						"Pagination_PageSize",
						"Pagination_PageShow",
						------------------------------
						"DataCustomize_Filter_JSON",
						"DataCustomize_Filter",
						"DataCustomize_Sort_JSON",
						"DataCustomize_Sort",
						"DataCustomize_Filter_CoreFields_JSON",
						"DataCustomize_Filter_CoreFields",
						"DataCustomize_Sort_CoreFields_JSON",
						"DataCustomize_Sort_CoreFields",
						"DataCustomize_Filter_NonCoreFields_JSON", 
						"DataCustomize_Filter_NonCoreFields", 
						"DataCustomize_Sort_NonCoreFields_JSON",
						"DataCustomize_Sort_NonCoreFields",
						------------------------------
						"Array_SysBranch_RefID",
						"Array_SysBaseBranch_RefID",
						------------------------------
						"Array_Currency_RefID",
						"Array_CurrencyISOCode",
						"Array_CurrencySymbol"
					INTO
						varJSONData_Detail_EnvSession,
						------------------------------
						varDBLinkConnectionString_FE,
						varDBLinkConnectionString_BE_DataOLAP,
						varDBLinkConnectionString_BE_DataOLTP,
						varDBLinkConnectionString_BE_DataWarehouse,
						varDBLinkConnectionString_BE_SysConfig,
						------------------------------
						varPagination_PageSize,
						varPagination_PageShow,
						------------------------------
						varDataCustomize_Filter_JSON,
						varDataCustomize_Filter,
						varDataCustomize_Sort_JSON,
						varDataCustomize_Sort,
						varDataCustomize_Filter_CoreFields_JSON,
						varDataCustomize_Filter_CoreFields,
						varDataCustomize_Sort_CoreFields_JSON,
						varDataCustomize_Sort_CoreFields,
						varDataCustomize_Filter_NonCoreFields_JSON,
						varDataCustomize_Filter_NonCoreFields,
						varDataCustomize_Sort_NonCoreFields_JSON,
						varDataCustomize_Sort_NonCoreFields,
						------------------------------
						varArraySysBranch_RefID,
						varArraySysBaseBranch_RefID,
						------------------------------
						varArrayCurrency_RefID,
						varArrayCurrencyISOCode,
						varArrayCurrencySymbol
					FROM
						"SchSystem"."FuncSys_General_GetEnvironmentParameterExtraction"(
							varSysDataReadLoginSession_RefID::bigint,
							varSysBranch_RefID::bigint,
							------------------------------
							varEnvironmentParameter::json,
							varObjectIdentity::varchar,
							------------------------------
							JSON_BUILD_ARRAY (
								'Sys_ID',
								'Sys_PID',
								'Sys_SID',
								'Sys_RPK',
								'Sys_Branch_RefID',
								'Sys_BaseBranch_RefID',
								'Sys_BaseCurrency_RefID',
								'Sys_BaseCurrencyISOCode',
								'Sys_BaseCurrencySymbol',
								------------------------------
								'BusinessDocumentType_RefID',
								'BusinessDocumentTypeName',
								------------------------------
								'BusinessDocument_RefID',
								'BusinessDocument_RefPID',
								'BusinessDocument_RefSID',
								------------------------------
								'DocumentForm_RefID',
								'DocumentForm_RefPID',
								'DocumentForm_RefSID',
								'DocumentForm_RefRPK',
								'DocumentForm_Branch_RefID',
								'DocumentForm_BaseBranch_RefID',
								'DocumentForm_BaseCurrency_RefID',
								'DocumentForm_BaseCurrencyISOCode',
								'DocumentForm_BaseCurrencySymbol',
								------------------------------
								'DocumentNumber',
								'DocumentVersion',
								'DocumentDateTimeTZ',
								'Annotation',
								------------------------------
								'JSONDataDocumentForm',
								'FormTable',
								------------------------------
								'CombinedBudgetSectionDetail_RefIDArray',
								------------------------------
								'CombinedBudgetSection_RefIDArray',
								'CombinedBudgetSectionCodeArray',
								'CombinedBudgetSectionNameArray',
								'CombinedBudgetSectionFullName',
								------------------------------
								'CombinedBudget_RefIDArray',
								'CombinedBudgetCodeArray',
								'CombinedBudgetNameArray',
								'CombinedBudgetFullName',
								------------------------------
								'Log_BusinessDocumentWorkFlowPathHistory_RefIDArray',
								'WorkFlowPath_RefIDArray',
								------------------------------
								'WorkFlowPathAction_RefIDArray',
								'WorkFlowPathActionNameArray',
								------------------------------
								'ApprovalStepSequenceArray',
								'ApproverEntity_RefIDArray',
								'ApproverEntityNameArray',
								'ApprovalDateTimeTZArray',
								'ApprovalRemarksArray',
								------------------------------
								'LatestWorkFlowPathActionName',
								'LatestApprovalStepSequence',
								'LatestApproverEntity_RefID',
								'LatestApproverEntityName',
								'LatestApproverDigitalSignatureID',
								'LatestApprovalDateTimeTZ',
								'LatestApprovalRemarks',
								------------------------------
								'JSONDataWorkFlow',
								------------------------------
								'SignMaxVersionBasedOnDataList',
								------------------------------
								'OrderSequence'
								),
							JSON_BUILD_ARRAY (
								'Sys_ID',
								'Sys_PID',
								'Sys_SID',
								'Sys_RPK',
								'Sys_Branch_RefID',
								'Sys_BaseBranch_RefID',
								'Sys_BaseCurrency_RefID',
								'Sys_BaseCurrencyISOCode',
								'Sys_BaseCurrencySymbol',
								------------------------------
								'JSONData_Log_FileUpload_Pointer',
								------------------------------
								'BusinessDocument_RefID',
								'BusinessDocumentVersion_RefID',
								------------------------------
								'FullDocumentNumber',
								'DocumentNumber',
								'DocumentVersion',
								'DocumentDateTimeTZ',
								'Annotation',
								------------------------------
								'CombinedBudget_RefIDArray',
								'CombinedBudgetCodeArray',
								'CombinedBudgetNameArray',
								'CombinedBudgetFullName',
								------------------------------
								'CombinedBudgetSection_RefIDArray',
								'CombinedBudgetSectionCodeArray',
								'CombinedBudgetSectionNameArray',
								'CombinedBudgetSectionFullName',
								------------------------------
								'LatestWorkFlowPathActionName',
								'LatestApprovalStepSequence',
								'LatestApproverEntity_RefID',
								'LatestApproverEntityName',
								'LatestApproverDigitalSignatureID',
								'LatestApprovalDateTimeTZ',
								'LatestApprovalRemarks',
								------------------------------
								'RequesterWorkerJobsPosition_RefID',
								'RequesterWorkerName',
								------------------------------
								'AmountBaseCurrencyValue',
								------------------------------
								'JSONDataDetail',
								------------------------------
								'SignMaxVersionBasedOnDataList',
								------------------------------
								'OrderSequence',
								------------------------------
								'Env_Pagination_ItemSequence',
								'Env_Information'
								)
							);

				---> Initializing : varMainTable
					varMainTable := '"SchLog"."TblLog_RecordDataTracking"';

				---> Initializing : varJSONParameter
					varSQL := '
						SELECT
							"SubSQL"."JSONData"
						FROM
							(
							SELECT
								JSON_BUILD_OBJECT (
									''sysIDArray'', "PARM_Sys_IDArray"::varchar,
									------------------------------
									''recordID'', "SubSQL"."PARM_RecordID",
									''recordPID'', "SubSQL"."PARM_RecordPID",
									''recordSID'', "SubSQL"."PARM_RecordSID",
									------------------------------
									''recordVersion'', "SubSQL"."PARM_RecordVersion",
									------------------------------
									''recordStartDateTimeTZ'', "SubSQL"."PARM_StartDateTimeTZ",
									''recordFinishDateTimeTZ'', "SubSQL"."PARM_FinishDateTimeTZ"
									) AS "JSONData"
							FROM
								(
								SELECT
									"SubSQL"."PARM_RecordID",
									"SubSQL"."Record_SysPID" AS "PARM_RecordPID",
									"SubSQL"."Record_SysSID" AS "PARM_RecordSID",
									------------------------------
									"SubSQL"."PARM_RecordVersion",
									------------------------------
									"SubSQL"."Sys_Data_Entry_DateTimeTZArray"[1] AS "PARM_StartDateTimeTZ",
									COALESCE (
										"SubSQL"."Sys_Data_Entry_DateTimeTZArray"[2],
										''9999-12-31 23:59:59''::timestamptz
										) AS "PARM_FinishDateTimeTZ",
									------------------------------
									"Sys_IDArray" AS "PARM_Sys_IDArray"
								FROM
									(
									SELECT
										CASE
											WHEN ("SubSQL"."OrderSequence" = 1) THEN
												"SubSQL"."PARM_RecordID"
											ELSE
												NULL
										END::bigint AS "PARM_RecordID",
										CASE
											WHEN ("SubSQL"."OrderSequence" = 1) THEN
												"SubSQL"."PARM_RecordVersion"
											ELSE
												NULL
										END::smallint AS "PARM_RecordVersion",
										------------------------------
										CASE
											WHEN ("SubSQL"."Record_Version" = "SubSQL"."SignMinRecordVersion") THEN
												(''{NULL,'' || COALESCE ((''"'' || REPLACE (REPLACE ("SubSQL"."Sys_ID"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''), ''NULL'') || ''}'')::bigint[]
											ELSE
												CASE
													WHEN ("SubSQL"."OrderSequence" = 1) THEN
														(
														''{'' ||
														STRING_AGG (
															COALESCE ((''"'' || REPLACE (REPLACE ("SubSQL"."Sys_ID"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''), ''NULL''),
															'', ''
															) OVER () ||
														''}''
														)
													ELSE
														NULL
												END::bigint[]
										END AS "Sys_IDArray",
										CASE
											WHEN ("SubSQL"."Record_Version" = "SubSQL"."SignMinRecordVersion") THEN
												(''{"0001-01-01 00:00:00", '' || COALESCE ((''"'' || REPLACE (REPLACE ("SubSQL"."Sys_Data_Entry_DateTimeTZ"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''), ''9999-12-31 23:59:59'') || ''}'')::timestamptz[]
											ELSE
												CASE
													WHEN ("SubSQL"."OrderSequence" = 1) THEN
														(
														''{'' ||
														STRING_AGG (
															COALESCE ((''"'' || REPLACE (REPLACE ("SubSQL"."Sys_Data_Entry_DateTimeTZ"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''), ''NULL''),
															'', ''
															) OVER () ||
														''}''
														)
													ELSE
														NULL
												END::timestamptz[]
										END AS "Sys_Data_Entry_DateTimeTZArray",
										------------------------------
										CASE
											WHEN ("SubSQL"."OrderSequence" = 1) THEN
												"SubSQL"."Record_SysPID"
											ELSE
												NULL
										END::bigint AS "Record_SysPID",
										CASE
											WHEN ("SubSQL"."OrderSequence" = 1) THEN
												"SubSQL"."Record_SysSID"
											ELSE
												NULL
										END::bigint AS "Record_SysSID",
										CASE
											WHEN ("SubSQL"."Record_Version" = "SubSQL"."SignMinRecordVersion") THEN
												(''{NULL, '' || "SubSQL"."Record_Version"::varchar || ''}'')::smallint[]
											ELSE
												CASE
													WHEN ("SubSQL"."OrderSequence" = 1) THEN
														(
														''{'' ||
														STRING_AGG (
															COALESCE ((''"'' || REPLACE (REPLACE ("SubSQL"."Record_Version"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''), ''NULL''),
															'', ''
															) OVER () ||
														''}''
														)
													ELSE
														NULL
												END::smallint[]
										END AS "Record_VersionArray",
										------------------------------
										CASE
											WHEN ("SubSQL"."Record_Version" = "SubSQL"."SignMinRecordVersion") THEN
												(''{1,2}'')::bigint[]
											ELSE
												CASE
													WHEN ("SubSQL"."OrderSequence" = 1) THEN
														(
														''{'' ||
														STRING_AGG (
															COALESCE ((''"'' || REPLACE (REPLACE ("SubSQL"."OrderSequence"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''), ''NULL''),
															'', ''
															) OVER () ||
														''}''
														)
													ELSE
														NULL
												END::bigint[]
										END AS "OrderSequenceArray"
									FROM
										(
										SELECT
											"SubSQL"."PARM_RecordID",
											"SubSQL"."PARM_RecordVersion",
											------------------------------
											"SubSQL"."Sys_ID",
											"SubSQL"."Sys_Data_Entry_DateTimeTZ",
											------------------------------
											"SubSQL"."Record_SysPID",
											"SubSQL"."Record_SysSID",
											"SubSQL"."Record_Version",
											------------------------------
											"SubSQL"."SignMinRecordVersion",
											"SubSQL"."SignMaxRecordVersion",
											------------------------------
											ROW_NUMBER () OVER (
												ORDER BY
													"SubSQL"."OrderSequence" ASC
												) AS "OrderSequence"
										FROM
											(
											SELECT
												"SubSQL"."PARM_RecordID",
												CASE
													WHEN ("SubSQL"."PARM_RecordVersion" < "SubSQL"."SignMinRecordVersion") THEN
														"SubSQL"."SignMinRecordVersion"
													WHEN ("SubSQL"."PARM_RecordVersion" > "SubSQL"."SignMaxRecordVersion") THEN
														"SubSQL"."SignMaxRecordVersion"
													ELSE
														"SubSQL"."PARM_RecordVersion"
												END AS "PARM_RecordVersion",
												------------------------------
												"SubSQL"."Sys_ID",
												"SubSQL"."Sys_Data_Entry_DateTimeTZ",
												------------------------------
												"SubSQL"."Record_SysPID",
												"SubSQL"."Record_SysSID",
												"SubSQL"."Record_Version",
												------------------------------
												"SubSQL"."SignMinRecordVersion",
												"SubSQL"."SignMaxRecordVersion",
												------------------------------
												ROW_NUMBER () OVER (
													ORDER BY
														"SubSQL"."OrderSequence" ASC
													) AS "OrderSequence"
											FROM
												(
												SELECT
													"SubSQL"."PARM_RecordID",
													"SubSQL"."PARM_RecordVersion",
													------------------------------
													"SubSQL"."Sys_ID",
													"SubSQL"."Sys_Data_Entry_DateTimeTZ",
													------------------------------
													"SubSQL"."Record_SysPID",
													"SubSQL"."Record_SysSID",
													"SubSQL"."Record_Version",
													------------------------------
													MIN (
														"SubSQL"."Record_Version"
														) OVER () AS "SignMinRecordVersion",
													MAX (
														"SubSQL"."Record_Version"
														) OVER () AS "SignMaxRecordVersion",
													------------------------------
													ROW_NUMBER () OVER (
														ORDER BY
															"SubSQL"."OrderSequence" ASC
														) AS "OrderSequence"
												FROM
													(
													SELECT
														"SubSQL"."PARM_RecordID",
														"SubSQL"."PARM_RecordVersion",
														------------------------------
														"SubSQL"."Sys_ID",
														"SubSQL"."Sys_Data_Entry_DateTimeTZ",
														------------------------------
														"SubSQL"."Record_SysPID",
														"SubSQL"."Record_SysSID",
														"SubSQL"."Record_Version",
														------------------------------
														ROW_NUMBER () OVER (
															ORDER BY
																"SubSQL"."OrderSequence" ASC
															) AS "OrderSequence"
													FROM
														(
														SELECT
															COALESCE (
																"VirtTblLog_RecordDataTracking_PID"."Record_SysPID",
																"VirtTblLog_RecordDataTracking_SID"."Record_SysPID",
																"VirtTblLog_RecordDataTracking_PID"."Record_SysSID",
																"VirtTblLog_RecordDataTracking_SID"."Record_SysSID"
																) AS "PARM_RecordID",
															"SubSQL"."PARM_RecordVersion",
															------------------------------
															COALESCE (
																"VirtTblLog_RecordDataTracking_PID"."Sys_PID",
																"VirtTblLog_RecordDataTracking_SID"."Sys_PID",
																"VirtTblLog_RecordDataTracking_PID"."Sys_SID",
																"VirtTblLog_RecordDataTracking_SID"."Sys_SID"
																) AS "Sys_ID",
															COALESCE (
																"VirtTblLog_RecordDataTracking_PID"."Sys_Data_Entry_DateTimeTZ",
																"VirtTblLog_RecordDataTracking_SID"."Sys_Data_Entry_DateTimeTZ"
																) AS "Sys_Data_Entry_DateTimeTZ",
															------------------------------
															COALESCE (
																"VirtTblLog_RecordDataTracking_PID"."Record_SysPID",
																"VirtTblLog_RecordDataTracking_SID"."Record_SysPID"
																) AS "Record_SysPID",
															COALESCE (
																"VirtTblLog_RecordDataTracking_PID"."Record_SysSID",
																"VirtTblLog_RecordDataTracking_SID"."Record_SysSID"
																) AS "Record_SysSID",
															COALESCE (
																"VirtTblLog_RecordDataTracking_PID"."Record_Version",
																"VirtTblLog_RecordDataTracking_SID"."Record_Version"
																) AS "Record_Version",
															------------------------------
															ROW_NUMBER () OVER (
																ORDER BY
																	COALESCE (
																		"VirtTblLog_RecordDataTracking_PID"."Record_Version",
																		"VirtTblLog_RecordDataTracking_SID"."Record_Version"
																		) ASC
																) AS "OrderSequence"
														FROM
															(
															SELECT
																' || COALESCE (varID::varchar, 'NULL') || '::bigint AS "PARM_RecordID",
																' || COALESCE (varRecordVersion::varchar, 'NULL') || '::smallint AS "PARM_RecordVersion"
															) AS "SubSQL"
																LEFT JOIN
																	"SchLog"."TblLog_RecordDataTracking" AS "VirtTblLog_RecordDataTracking_PID"
																		ON
																			"VirtTblLog_RecordDataTracking_PID"."Sys_Data_Delete_DateTimeTZ" IS NULL
																			AND
																			"VirtTblLog_RecordDataTracking_PID"."Sys_Data_Hidden_DateTimeTZ" IS NULL
																			AND
																			"SubSQL"."PARM_RecordID" = "VirtTblLog_RecordDataTracking_PID"."Record_SysPID"
																LEFT JOIN
																	"SchLog"."TblLog_RecordDataTracking" AS "VirtTblLog_RecordDataTracking_SID"
																		ON
																			"VirtTblLog_RecordDataTracking_SID"."Sys_Data_Delete_DateTimeTZ" IS NULL
																			AND
																			"VirtTblLog_RecordDataTracking_PID"."Sys_Data_Hidden_DateTimeTZ" IS NULL
																			AND
																			"SubSQL"."PARM_RecordID" = "VirtTblLog_RecordDataTracking_SID"."Record_SysSID"
														) AS "SubSQL"
													) AS "SubSQL"
												) AS "SubSQL"
											) AS "SubSQL"
										WHERE
											("SubSQL"."PARM_RecordVersion" - 1) = "SubSQL"."Record_Version"
											OR
											"SubSQL"."PARM_RecordVersion" = "SubSQL"."Record_Version"
										) AS "SubSQL"
									LIMIT 1
									) AS "SubSQL"
								) AS "SubSQL"
							) AS "SubSQL"
						';
					--RAISE NOTICE '%', varSQL;
					EXECUTE varSQL INTO varJSONParameter;
					--RAISE NOTICE '%', varJSONParameter;

			END IF;
		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------(  END  )-----


	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			-----[ MAIN DATA PROCESSING ]---------------------------------------------( START )-----
				---> Initializing : varJSONData_Header
					varSQL := '
						SELECT
							"SubSQL"."JSONData"
						FROM
							(
							SELECT
								JSON_BUILD_OBJECT (
									''entities'',
										JSON_BUILD_OBJECT (
											''metaData'',
												JSON_BUILD_OBJECT (
													''schemaTableName'', "Record_SchemaTableName",
													''modificationLoginSession_RefID'', "Record_ModificationLoginSession_RefID",
													''modificationType'', "Record_ModificationType",
													''modificationDateTimeTZ'', "Record_ModificationDateTimeTZ",
													''recordVersion'', "Record_BusinessDocumentVersion",
													''businessDocumentVersion'', "Record_Version"
													),
											''data'', "Record_JSONData"
											)
									) AS "JSONData"
							FROM
								"SchLog"."TblLog_RecordDataTracking"
							WHERE
								(
								"Sys_Data_Delete_DateTimeTZ" IS NULL
								AND
								"Sys_Data_Hidden_DateTimeTZ" IS NULL
								AND
									(
									"Record_SysPID" = ' || COALESCE (((varJSONParameter->>'recordPID')::bigint::varchar), 'NULL'::varchar) || '::bigint
									OR
									"Record_SysSID" = ' || COALESCE (((varJSONParameter->>'recordSID')::bigint::varchar), 'NULL'::varchar) || '::bigint
									)
								AND
								"Record_Version" = ' || COALESCE (((varJSONParameter->>'recordVersion')::smallint::varchar), 'NULL'::varchar) || '::smallint
								)
							) AS "SubSQL"
						';
					--RAISE NOTICE '%', varSQL;
					EXECUTE varSQL INTO varJSONData_Header;
					--RAISE NOTICE '%', varJSONData_Header;

				---> Initializing : varJSONData_Detail
					varSQL := '
						SELECT
							"SubSQL"."JSONData"
						FROM
							(
							SELECT
								CASE
									WHEN ("SubSQL"."OrderSequence" = 1) THEN
										(
										''{'' ||
										STRING_AGG (
											(
											''"'' || "SubSQL"."Record_SchemaTableName" || ''" : '' ||
												''{''
												||
												''"entities" : '' ||
													''{''
													||
													''"recordIDList" : ''
														||
														'''' || "SubSQL"."RecordIDList"::varchar || ''''
														||
														'', '' ||
													''"itemList" : ''
														||
														COALESCE (
															"SubSQL"."JSONData"::varchar,
															''null''::varchar
															)
														||
													''}''
												||
												''}''
											),
											'', ''
											) OVER () ||
										''}''
										)
									ELSE
										NULL
								END::json AS "JSONData"
							FROM
								(
								SELECT
									"SubSQL"."Record_SchemaTableName",
									"SubSQL"."RecordIDList",
									"SubSQL"."JSONData",
									------------------------------
									ROW_NUMBER () OVER (
										ORDER BY
											"SubSQL"."OrderSequence" ASC
										) AS "OrderSequence"
								FROM
									(
									SELECT
										CASE
											WHEN ("SubSQL"."FilterSequence" = 1) THEN
												"SubSQL"."Record_SchemaTableName"
											ELSE
												NULL
										END::varchar AS "Record_SchemaTableName",
										CASE
											WHEN ("SubSQL"."FilterSequence" = 1) THEN
												(
												''['' ||
												STRING_AGG (
													(COALESCE (("SubSQL"."JSONData"->''entities''->''data''->>''sys_PID'')::bigint::varchar, ''null'')),
													'', ''
													) OVER () ||
												'']''
												)
												
											ELSE
												NULL
										END::json::varchar AS "RecordIDList",
										CASE
											WHEN ("SubSQL"."FilterSequence" = 1) THEN
												(
												''['' ||
												STRING_AGG (
													(COALESCE ("SubSQL"."JSONData"::varchar, ''null'')),
													'', ''
													) OVER () ||
												'']''
												)
												
											ELSE
												NULL
										END::json AS "JSONData",
										------------------------------
										"SubSQL"."FilterSequence",
										ROW_NUMBER () OVER (
											ORDER BY
												"SubSQL"."OrderSequence" ASC
											) AS "OrderSequence"
									FROM
										(
										SELECT
											"SubSQL"."Record_SchemaTableName",
											"SubSQL"."JSONData",
											------------------------------
											"SubSQL"."FilterSequence",
											"SubSQL"."OrderSequence"
										FROM
											(
											SELECT
												"SubSQL"."Record_SchemaTableName",
												JSON_BUILD_OBJECT (
													''index'', "SubSQL"."IndexSequence",
													''entities'',
														JSON_BUILD_OBJECT (
															''metaData'',
																JSON_BUILD_OBJECT (
																	''schemaTableName'', "SubSQL"."Record_SchemaTableName",
																	''modificationLoginSession_RefID'', "SubSQL"."Record_ModificationLoginSession_RefID",
																	''modificationType'', "SubSQL"."Record_ModificationType",
																	''modificationDateTimeTZ'', "SubSQL"."Record_ModificationDateTimeTZ",
																	''recordVersion'', "SubSQL"."Record_Version",
																	''businessDocumentVersion'', "SubSQL"."Record_BusinessDocumentVersion"
																	),
															''data'', "SubSQL"."Record_JSONData",
															''subData'',
																(
																SELECT
																	"InnerSubSQL"."JSONData"->''document''->''content''->''subData''
																FROM
																	"SchSystem"."FuncSys_General_StrSQLExecution"(
																		(
																		SELECT 
																			"SchLog"."Func_SQLGenerator_RptDataForm_Log_RecordDataTracking"(
																				' || COALESCE (varSysDataReadLoginSession_RefID::varchar, 'NULL'::varchar) || '::bigint,
																				' || COALESCE (varSysBranch_RefID::varchar, 'NULL'::varchar) || '::bigint,
																				------------------------------
																				("SubSQL"."Record_JSONData"->>''sys_PID'')::bigint,
																				"SubSQL"."Record_Version"::smallint
																				
																				/*
																				' || 
																				CASE
																					WHEN (varID = 46000000000041) THEN
																						76000000000954
																					ELSE
																						999
																				END::varchar
																				|| '::bigint,
																				--76000000000954::bigint,
																				0::smallint
																				*/
																				
																				------------------------------
																				)
																		)
																		) AS "InnerSubSQL" ("JSONData" json)
																)
															)
													) AS "JSONData",
												------------------------------
												"SubSQL"."FilterSequence",
												"SubSQL"."OrderSequence"
											FROM
												(
												SELECT
													"SubSQL"."Record_SchemaTableName",
													"SubSQL"."Record_SysID",
													"SubSQL"."Record_SysPID",
													"SubSQL"."Record_SysSID",
													"SubSQL"."Record_ModificationLoginSession_RefID",
													"SubSQL"."Record_ModificationType",
													"SubSQL"."Record_ModificationDateTimeTZ",
													"SubSQL"."Record_DataIntegrityShadow",
													"SubSQL"."Record_JSONData",
													"SubSQL"."Record_UpperLink_RefID",
													"SubSQL"."Record_BusinessDocumentVersion_RefID",
													"SubSQL"."Record_BusinessDocumentVersion",
													"SubSQL"."Record_Version",
													------------------------------
													ROW_NUMBER () OVER (
														PARTITION BY
															"SubSQL"."Record_SchemaTableName"
														ORDER BY
															"SubSQL"."OrderSequence" ASC
														) AS "FilterSequence",
													ROW_NUMBER () OVER (
														PARTITION BY
															"SubSQL"."Record_SchemaTableName"
														ORDER BY
															"SubSQL"."OrderSequence" ASC
														) AS "IndexSequence",
													ROW_NUMBER () OVER (
														ORDER BY
															"SubSQL"."OrderSequence" ASC
														) AS "OrderSequence"
												FROM
													(
													SELECT
														"SubSQL"."Record_SchemaTableName",
														"SubSQL"."Record_SysID",
														"SubSQL"."Record_SysPID",
														"SubSQL"."Record_SysSID",
														"SubSQL"."Record_ModificationLoginSession_RefID",
														"SubSQL"."Record_ModificationType",
														"SubSQL"."Record_ModificationDateTimeTZ",
														"SubSQL"."Record_DataIntegrityShadow",
														"SubSQL"."Record_JSONData",
														"SubSQL"."Record_UpperLink_RefID",
														"SubSQL"."Record_BusinessDocumentVersion_RefID",
														"SubSQL"."Record_BusinessDocumentVersion",
														"SubSQL"."Record_Version",
														------------------------------
														ROW_NUMBER () OVER (
															ORDER BY
																"SubSQL"."OrderSequence" ASC
															) AS "OrderSequence"
													FROM
														(
														SELECT
															"SubSQL"."Record_SchemaTableName",
															"SubSQL"."Record_SysID",
															"SubSQL"."Record_SysPID",
															"SubSQL"."Record_SysSID",
															"SubSQL"."Record_ModificationLoginSession_RefID",
															"SubSQL"."Record_ModificationType",
															"SubSQL"."Record_ModificationDateTimeTZ",
															"SubSQL"."Record_DataIntegrityShadow",
															"SubSQL"."Record_JSONData",
															"SubSQL"."Record_UpperLink_RefID",
															"SubSQL"."Record_BusinessDocumentVersion_RefID",
															"SubSQL"."Record_BusinessDocumentVersion",
															"SubSQL"."Record_Version",
															------------------------------
															ROW_NUMBER () OVER (
																PARTITION BY
																	"SubSQL"."Record_SchemaTableName",
																	"SubSQL"."Record_SysID"
																ORDER BY
																	"SubSQL"."Record_Version" DESC,
																	"SubSQL"."OrderSequence" DESC
																) AS "FilterSequence",
															ROW_NUMBER () OVER (
																ORDER BY
																	"SubSQL"."OrderSequence" ASC
																) AS "OrderSequence"
														FROM
															(
															SELECT
																"Record_SchemaTableName",
																COALESCE (
																	"Record_SysPID",
																    "Record_SysSID"
																	) AS "Record_SysID",
															    "Record_SysPID",
															    "Record_SysSID",
															    "Record_ModificationLoginSession_RefID",
															    "Record_ModificationType",
															    "Record_ModificationDateTimeTZ",
															    "Record_DataIntegrityShadow",
															    "Record_JSONData",
															    "Record_UpperLink_RefID",
															    "Record_BusinessDocumentVersion_RefID",
															    "Record_BusinessDocumentVersion",
															    "Record_Version",
																------------------------------
																ROW_NUMBER () OVER (
																	ORDER BY
																		"Record_SchemaTableName" ASC,
																		"Sys_Data_Entry_DateTimeTZ" ASC
																	) AS "OrderSequence"
															FROM
																"SchLog"."TblLog_RecordDataTracking"
															WHERE
																(
																"SchLog"."TblLog_RecordDataTracking"."Sys_Data_Delete_DateTimeTZ" IS NULL
																AND
																"SchLog"."TblLog_RecordDataTracking"."Sys_Data_Hidden_DateTimeTZ" IS NULL
																AND
																	(
																	"Record_UpperLink_RefID" = ' || COALESCE (((varJSONParameter->>'recordPID')::bigint::varchar), 'NULL'::varchar) || '::bigint
																	OR
																	"Record_UpperLink_RefID" = ' || COALESCE (((varJSONParameter->>'recordSID')::bigint::varchar), 'NULL'::varchar) || '::bigint
																	)
																AND
																"Sys_Data_Entry_DateTimeTZ" >= ' || COALESCE (('''' || (varJSONParameter->>'recordStartDateTimeTZ')::timestamptz::varchar || '''')::varchar, 'NULL'::varchar) || '::timestamptz
																AND
																"Sys_Data_Entry_DateTimeTZ" <= ' || COALESCE (('''' || (varJSONParameter->>'recordFinishDateTimeTZ')::timestamptz::varchar || '''')::varchar, 'NULL'::varchar) || '::timestamptz
																)
															) AS "SubSQL"
														) AS "SubSQL"
													WHERE
														"SubSQL"."FilterSequence" = 1
													) AS "SubSQL"
												) AS "SubSQL"
											) AS "SubSQL"
										) AS "SubSQL"
									ORDER BY
										"SubSQL"."OrderSequence" ASC
									) AS "SubSQL"
								WHERE
									"SubSQL"."FilterSequence" = 1
								) AS "SubSQL"
							LIMIT 1
							) AS "SubSQL"
						';
					--RAISE NOTICE '%', varSQL;
					EXECUTE varSQL INTO varJSONData_Detail;
					--RAISE NOTICE '%', varJSONData_Detail;

				---> Initializing : varSQL
					varSQL := '
						SELECT
							*
						FROM
							(
							SELECT
								JSON_BUILD_OBJECT (
									''document'',
										JSON_BUILD_OBJECT (
											''header'',
												JSON_BUILD_OBJECT (
													''type'', ''Document Form Report'',
													''title'', ''Record Data Tracking Log Document Form'',
													''issuedDateTimeTZ'', NOW(),
													------------------------------
													''dataCount'', 1,
													''pagination'',
														JSON_BUILD_OBJECT (
															''pageSize'', 1,
															''pageCount'', 1,
															''pageShow'', 1
															),
													------------------------------
													''recordID'', ' || COALESCE (varID::varchar, 'NULL') || '::bigint,
													''recordVersion'', ' || COALESCE (varRecordVersion::varchar, 'NULL') || '::smallint
													),
											''content'',
												JSON_BUILD_OBJECT (
													''metaData'', (' || COALESCE (('''' ||varJSONData_Header::varchar || '''')::varchar, 'NULL'::varchar) || '::json)->''entities''->''metaData'',
													''data'', (' || COALESCE (('''' ||varJSONData_Header::varchar || '''')::varchar, 'NULL'::varchar) || '::json)->''entities''->''data'',
													''subData'', (' || COALESCE (('''' ||varJSONData_Detail::varchar || '''')::varchar, 'NULL'::varchar) || '::json)
													)
											)
									)
							) AS "SubSQL"
						';
					--RAISE NOTICE '%', varSQL;

			-----[ MAIN DATA PROCESSING ]---------------------------------------------(  END  )-----
		END IF;

	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----
		---> Initializing : varReturn
			EXECUTE
				varSQL
			INTO
				varReturn;

			varReturn := '
				-----[ SQL Syntax Generator : ' || varObjectIdentity || ' ]-----( START )-----
				SELECT
					*
				FROM
					(
					SELECT
						''' || REPLACE (varReturn, '''', '''''') || '''::json AS "JSONData"
					) AS "SubSQL"
				-----[ SQL Syntax Generator : ' || varObjectIdentity || ' ]-----(  END  )-----
				';

		---> Send Data Output
			RETURN
				varReturn;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		EXCEPTION
			WHEN OTHERS THEN
				NULL;

END;
$_$;


ALTER FUNCTION "SchLog"."Func_SQLGenerator_RptDataForm_Log_RecordDataTracking"(bigint, bigint, bigint, smallint, bigint[], json) OWNER TO "SysAdmin";

--
-- TOC entry 386 (class 1255 OID 6653787)
-- Name: Func_TblLog_FunctionSnapshotSignature_INSERT(character varying, bigint, timestamp with time zone, bigint, bigint, bigint, character varying, character varying, character varying); Type: FUNCTION; Schema: SchLog; Owner: SysAdmin
--

CREATE FUNCTION "SchLog"."Func_TblLog_FunctionSnapshotSignature_INSERT"(character varying, bigint, timestamp with time zone, bigint, bigint, bigint, character varying, character varying, character varying) RETURNS SETOF "SchSystem"."HoldFuncSys_General_FeedBackQuery"
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchLog"."Func_TblLog_FunctionSnapshotSignature_INSERT"
▪ Versi               :	1.00.0001
▪ Tanggal
     ► Pemutakhiran   :	2024-10-04
     ► Pembuatan      :	2024-07-10
▪ Input               :	• varSysDataAnnotation (varchar - Mandatory)
						• varIDSession (bigint - Mandatory)
						• varEntryDateTimeTZ (timestamptz - Mandatory)
						• varSysPartitionRemovableRecordKeyRefID (bigint - Mandatory)
						• varBranch_RefID (bigint - Mandatory)
						• varBaseCurrency_RefID (bigint - Mandatory)
						------------------------------
						• varSchemaName (varchar - Mandatory)
						• varFunctionName (varchar - Mandatory)
						• varSignatureID (varchar - Mandatory)
						------------------------------
▪ Output              :	varRecSetOutput ("SchSystem"."HoldFuncSys_General_FeedBackQuery")
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Memasukan data (INSERT) pada tabel TblLog_FunctionSnapshotSignature
▪ Copyright           :	Zheta © 2024

----[ SQL Example(s) ]------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------*/

DECLARE
	---[ Input Variable(s) ]------------------------------------------------------------------------
		---{ Mandatory }------------------
			varSysDataAnnotation									ALIAS FOR $1;
			varIDSession											ALIAS FOR $2;
			varEntryDateTimeTZ										ALIAS FOR $3;
			varSysPartitionRemovableRecordKeyRefID					ALIAS FOR $4;
			varBranch_RefID											ALIAS FOR $5;
			varBaseCurrency_RefID									ALIAS FOR $6;
			------------------------------
			varSchemaName											ALIAS FOR $7;
			varFunctionName											ALIAS FOR $8;
			varSignatureID											ALIAS FOR $9;

		---{ Optional }-------------------

		---{ Additional }-----------------

	---[ Output Variable(s) ]-----------------------------------------------------------------------
			varRecSetOutput											"SchSystem"."HoldFuncSys_General_FeedBackQuery"%rowtype;

	---[ Intermediate Variable(s) ]-----------------------------------------------------------------
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

		---{ Additional }-----------------

BEGIN
	---[ Data Initializing ]------------------------------------------------------------------------
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		IF (varSignEligibleToProcess IS FALSE) THEN
			varSignEligibleToProcess := TRUE;
		END IF;

		IF (varSignEligibleToProcess IS TRUE) THEN
		END IF;

	---[ Data Processing ]--------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			INSERT INTO 
				"SchLog"."TblLog_FunctionSnapshotSignature"
					(
					"Sys_Data_Annotation",
					"Sys_Data_Entry_LoginSession_RefID",
					"Sys_Data_Entry_DateTimeTZ",
					"Sys_Partition_RemovableRecord_Key_RefID",
					"Sys_Branch_RefID",
					"Sys_BaseCurrency_RefID",
					------------------------------
					"SchemaName",
					"FunctionName",
					"SignatureID"
					)
				VALUES
					(
					varSysDataAnnotation,
					varIDSession,
					varEntryDateTimeTZ,
					varSysPartitionRemovableRecordKeyRefID,
					varBranch_RefID,
					varBaseCurrency_RefID,
					------------------------------
					varSchemaName,
					varFunctionName,
					varSignatureID
					);
		END IF;

	---[ Data Return ]-----------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			varRecSetOutput."SignSuccess" := 1;
			varRecSetOutput."SignRecordType" := 'Sys_RPK';
			varRecSetOutput."SignRecordID" := CURRVAL('"SchLog"."TblLog_FunctionSnapshotSignature_Sys_RPK_seq"');
			varRecSetOutput."SignMessage" := null;

			RETURN NEXT varRecSetOutput;
		END IF;

	---[ Exception Handling ]-----------------------------------------------------------------------
		--EXCEPTION WHEN OTHERS THEN ...

END;
$_$;


ALTER FUNCTION "SchLog"."Func_TblLog_FunctionSnapshotSignature_INSERT"(character varying, bigint, timestamp with time zone, bigint, bigint, bigint, character varying, character varying, character varying) OWNER TO "SysAdmin";

--
-- TOC entry 387 (class 1255 OID 6653788)
-- Name: Func_TblLog_FunctionSnapshotSignature_UPDATE(bigint, bigint, timestamp with time zone, bigint, bigint, bigint, character varying, character varying, character varying); Type: FUNCTION; Schema: SchLog; Owner: SysAdmin
--

CREATE FUNCTION "SchLog"."Func_TblLog_FunctionSnapshotSignature_UPDATE"(bigint, bigint, timestamp with time zone, bigint, bigint, bigint, character varying, character varying, character varying) RETURNS SETOF "SchSystem"."HoldFuncSys_General_FeedBackQuery"
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchLog"."Func_TblLog_FunctionSnapshotSignature_UPDATE"
▪ Versi               :	1.00.0001
▪ Tanggal
     ► Pemutakhiran   :	2024-10-04
     ► Pembuatan      :	2024-07-10
▪ Input               :	• varID (bigint - Mandatory)
						• varIDSession (bigint - Mandatory)
						• varEditDateTimeTZ (timestamptz - Mandatory)
						• varSysPartitionRemovableRecordKeyRefID (bigint - Mandatory)
						• varBranch_RefID (bigint - Mandatory)
						• varBaseCurrency_RefID (bigint - Mandatory)
						------------------------------
						• varSchemaName (varchar - Mandatory)
						• varFunctionName (varchar - Mandatory)
						• varSignatureID (varchar - Mandatory)
						------------------------------
▪ Output              :	varRecSetOutput ("SchSystem"."HoldFuncSys_General_FeedBackQuery")
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Memutakhirkan data (UPDATE) pada tabel TblLog_FunctionSnapshotSignature
▪ Copyright           :	Zheta © 2024

----[ SQL Example(s) ]------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------*/

DECLARE
	---[ Input Variable(s) ]------------------------------------------------------------------------
		---{ Mandatory }------------------
			varID													ALIAS FOR $1;
			varIDSession											ALIAS FOR $2;
			varEditDateTimeTZ										ALIAS FOR $3;
			varSysPartitionRemovableRecordKeyRefID					ALIAS FOR $4;
			varBranch_RefID											ALIAS FOR $5;
			varBaseCurrency_RefID									ALIAS FOR $6;
			------------------------------
			varSchemaName											ALIAS FOR $7;
			varFunctionName											ALIAS FOR $8;
			varSignatureID											ALIAS FOR $9;

		---{ Optional }-------------------

		---{ Additional }-----------------

	---[ Output Variable(s) ]-----------------------------------------------------------------------
			varRecSetOutput											"SchSystem"."HoldFuncSys_General_FeedBackQuery"%rowtype;

	---[ Intermediate Variable(s) ]-----------------------------------------------------------------
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

		---{ Additional }-----------------

BEGIN
	---[ Data Initializing ]------------------------------------------------------------------------
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		IF (varSignEligibleToProcess IS FALSE) THEN
			varSignEligibleToProcess := TRUE;
		END IF;

		IF (varSignEligibleToProcess IS TRUE) THEN
		END IF;

	---[ Data Processing ]--------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			UPDATE
				"SchLog"."TblLog_FunctionSnapshotSignature"
			SET
				"Sys_Data_Edit_LoginSession_RefID" = varIDSession,
				"Sys_Data_Edit_DateTimeTZ" = varEditDateTimeTZ,
				-- "Sys_Partition_RemovableRecord_Key_RefID" = varSysPartitionRemovableRecordKeyRefID,
				"Sys_Branch_RefID" = varBranch_RefID,
				"Sys_BaseCurrency_RefID" = varBaseCurrency_RefID,
				------------------------------
				"SchemaName" = varSchemaName,
				"FunctionName" = varFunctionName,
				"SignatureID" = varSignatureID
			WHERE
				"Sys_PID" = varID
				OR
				"Sys_SID" = varID;
		END IF;

	---[ Data Return ]-----------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			varRecSetOutput."SignSuccess" := 1;
			varRecSetOutput."SignRecordType" := 'Sys_RPK';
			varRecSetOutput."SignRecordID" := (SELECT "Sys_RPK" FROM "SchLog"."TblLog_FunctionSnapshotSignature" WHERE "Sys_PID" = varID OR "Sys_SID" = varID LIMIT 1);
			varRecSetOutput."SignMessage" := null;
		
			RETURN NEXT varRecSetOutput;
		END IF;

	---[ Exception Handling ]-----------------------------------------------------------------------
		--EXCEPTION WHEN OTHERS THEN ...

END;
$_$;


ALTER FUNCTION "SchLog"."Func_TblLog_FunctionSnapshotSignature_UPDATE"(bigint, bigint, timestamp with time zone, bigint, bigint, bigint, character varying, character varying, character varying) OWNER TO "SysAdmin";

--
-- TOC entry 388 (class 1255 OID 6653789)
-- Name: Func_TblLog_RecordDataTracking_INSERT(character varying, bigint, timestamp with time zone, timestamp with time zone, timestamp with time zone, bigint, bigint, bigint, character varying, bigint, bigint, bigint, character varying, timestamp with time zone, character varying, json, bigint, bigint, smallint); Type: FUNCTION; Schema: SchLog; Owner: SysAdmin
--

CREATE FUNCTION "SchLog"."Func_TblLog_RecordDataTracking_INSERT"(character varying, bigint, timestamp with time zone, timestamp with time zone, timestamp with time zone, bigint, bigint, bigint, character varying, bigint, bigint, bigint, character varying, timestamp with time zone, character varying, json, bigint, bigint, smallint) RETURNS SETOF "SchSystem"."HoldFuncSys_General_FeedBackQuery"
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchLog"."Func_TblLog_RecordDataTracking_INSERT"
▪ Versi               :	1.01.0001
▪ Tanggal
     ► Pemutakhiran   :	2026-11-02
     ► Pembuatan      :	2026-10-26
▪ Input               :	• varSysDataAnnotation (varchar - Mandatory)
						• varSysDataEntryLoginSession_RefID (bigint - Mandatory)
						• varSysDataEntryDateTimeTZ (timestamptz - Mandatory)
						• varSysDataValidityStartDateTimeTZ (timestamptz - Mandatory)
						• varSysDataValidityFinishDateTimeTZ (timestamptz - Mandatory)
						• varSysPartitionRemovableRecordKey_RefID (bigint - Mandatory)
						• varSysBranch_RefID (bigint - Mandatory)
						• varSysBaseCurrency_RefID (bigint - Mandatory)
						------------------------------
						• varRecord_SchemaTableName (varchar - Mandatory)
						• varRecord_SysPID (bigint - Mandatory)
						• varRecord_SysSID (bigint - Mandatory)
						• varRecord_ModificationLoginSession_RefID (bigint - Mandatory)
						• varRecord_ModificationType (varchar - Mandatory)
						• varRecord_ModificationDateTimeTZ (timestamptz - Mandatory)
						• varRecord_DataIntegrityShadow (varchar - Mandatory)
						• varRecord_JSONData (json - Mandatory)
						• varRecord_UpperLink_RefID (bigint - Mandatory)
						• varRecord_BusinessDocumentVersion_RefID (bigint - Mandatory)
						• varRecord_BusinessDocumentVersion (smallint - Mandatory)
						------------------------------
▪ Output              :	varRecSetOutput ("SchSystem"."HoldFuncSys_General_FeedBackQuery")
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Memasukan data (INSERT) pada tabel TblLog_RecordDataTracking
▪ Copyright           :	Zheta © 2026

----[ SQL Example(s) ]------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varSysDataAnnotation									ALIAS FOR $1;
			varSysDataEntryLoginSession_RefID						ALIAS FOR $2;
			varSysDataEntryDateTimeTZ								ALIAS FOR $3;
			varSysDataValidityStartDateTimeTZ						ALIAS FOR $4;
			varSysDataValidityFinishDateTimeTZ						ALIAS FOR $5;
			varSysPartitionRemovableRecordKey_RefID					ALIAS FOR $6;
			varSysBranch_RefID										ALIAS FOR $7;
			varSysBaseCurrency_RefID								ALIAS FOR $8;
			------------------------------
			varRecord_SchemaTableName								ALIAS FOR $9;
			varRecord_SysPID										ALIAS FOR $10;
			varRecord_SysSID										ALIAS FOR $11;
			varRecord_ModificationLoginSession_RefID				ALIAS FOR $12;
			varRecord_ModificationType								ALIAS FOR $13;
			varRecord_ModificationDateTimeTZ						ALIAS FOR $14;
			varRecord_DataIntegrityShadow							ALIAS FOR $15;
			varRecord_JSONData										ALIAS FOR $16;
			varRecord_UpperLink_RefID								ALIAS FOR $17;
			varRecord_BusinessDocumentVersion_RefID					ALIAS FOR $18;
			varRecord_BusinessDocumentVersion						ALIAS FOR $19;

		---{ Optional }-------------------

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----
			varRecSetOutput											"SchSystem"."HoldFuncSys_General_FeedBackQuery"%rowtype;

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

		---{ Additional }-----------------

BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		IF (varSignEligibleToProcess IS FALSE) THEN
			varSignEligibleToProcess := TRUE;
		END IF;

		IF (varSignEligibleToProcess IS TRUE) THEN
		END IF;

	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			-----[ MAIN DATA PROCESSING ]---------------------------------------------( START )-----
				---> Main Data Set
					INSERT INTO 
						"SchLog"."TblLog_RecordDataTracking"
							(
							"Sys_Data_Annotation",
							"Sys_Data_Entry_LoginSession_RefID",
							"Sys_Data_Entry_DateTimeTZ",
							"Sys_Data_Validity_StartDateTimeTZ",
						    "Sys_Data_Validity_FinishDateTimeTZ",
							"Sys_Partition_RemovableRecord_Key_RefID",
							"Sys_Branch_RefID",
							"Sys_BaseCurrency_RefID",
							------------------------------
							"Record_SchemaTableName",
							"Record_SysPID",
							"Record_SysSID",
							"Record_ModificationLoginSession_RefID",
							"Record_ModificationType",
						    "Record_ModificationDateTimeTZ",
							"Record_DataIntegrityShadow",
							"Record_JSONData",
							"Record_UpperLink_RefID",
							"Record_BusinessDocumentVersion_RefID",
							"Record_BusinessDocumentVersion",
							------------------------------
							"Record_Version"
							)
						VALUES
							(
							varSysDataAnnotation,
							varSysDataEntryLoginSession_RefID,
							varSysDataEntryDateTimeTZ,
							varSysDataValidityStartDateTimeTZ,
							varSysDataValidityFinishDateTimeTZ,
							varSysPartitionRemovableRecordKey_RefID,
							varSysBranch_RefID,
							varSysBaseCurrency_RefID,
							------------------------------
							varRecord_SchemaTableName,
							varRecord_SysPID,
							varRecord_SysSID,
							varRecord_ModificationLoginSession_RefID,
							varRecord_ModificationType,
						    varRecord_ModificationDateTimeTZ,
							varRecord_DataIntegrityShadow,
							varRecord_JSONData,
							varRecord_UpperLink_RefID,
							varRecord_BusinessDocumentVersion_RefID,
							varRecord_BusinessDocumentVersion,
							------------------------------
							(
							SELECT
								COALESCE (
									(MAX ("Record_Version") + 1),
									0
									)::smallint
							FROM
								"SchLog"."TblLog_RecordDataTracking"
							WHERE
								"Record_SysPID" = varRecord_SysPID
								OR
								"Record_SysSID" = varRecord_SysSID
							)::smallint
							);

				---> Update "Sys_DataIntegrityShadow"
					PERFORM
						"SchSystem"."FuncSys_General_SetDataIntegrityShadow"(
							'SchLog.TblLog_RecordDataTracking'::varchar,
							(CURRVAL ('"SchLog"."TblLog_RecordDataTracking_Sys_RPK_seq"'))::bigint
							);

			-----[ MAIN DATA PROCESSING ]---------------------------------------------(  END  )-----
		END IF;

	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			varRecSetOutput."SignSuccess" := 1;
			varRecSetOutput."SignRecordType" := 'Sys_RPK';
			varRecSetOutput."SignRecordID" :=
				CURRVAL ('"SchLog"."TblLog_RecordDataTracking_Sys_RPK_seq"');
			varRecSetOutput."SignMessage" := null;

			---> Data Return
				RETURN
					NEXT varRecSetOutput;
		END IF;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		--EXCEPTION WHEN OTHERS THEN ...

END;
$_$;


ALTER FUNCTION "SchLog"."Func_TblLog_RecordDataTracking_INSERT"(character varying, bigint, timestamp with time zone, timestamp with time zone, timestamp with time zone, bigint, bigint, bigint, character varying, bigint, bigint, bigint, character varying, timestamp with time zone, character varying, json, bigint, bigint, smallint) OWNER TO "SysAdmin";

--
-- TOC entry 389 (class 1255 OID 6653792)
-- Name: Func_TblLog_RecordDataTracking_SET_BULK(json, json, json); Type: FUNCTION; Schema: SchLog; Owner: SysAdmin
--

CREATE FUNCTION "SchLog"."Func_TblLog_RecordDataTracking_SET_BULK"(json, json DEFAULT NULL::json, json DEFAULT NULL::json) RETURNS json
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchLog"."Func_TblLog_RecordDataTracking_SET_BULK"
▪ Versi               :	1.00.0002
▪ Tanggal
     ► Pemutakhiran   :	2026-11-02
     ► Pembuatan      :	2026-10-26
▪ Input               :	• varEnvironmentParameter (json - Mandatory)
						------------------------------
						• varJSONData (json - Optional)
						• varJSONDataDeletion (json - Optional)
						------------------------------
▪ Output              :	varReturn (json)
▪ Deskripsi           :	• Mengeset Data Bulk (INSERT dan UPDATE) pada tabel TblLog_RecordDataTracking
▪ Copyright           :	Zheta © 2026

----[ Related Database Object(s) ]------------------------------------------------------------------

▪ Tabel               :	-

▪ Fungsi              :	• [BE] "SchSystem"."FuncSys_General_GetEnvironmentParameter"(varchar)
						• [BE] "SchSystem"."FuncSys_General_SetBulkData"(json, json, json)
						------------------------------
						• [BE] "SchLog"."Func_TblLog_TableSnapshotSignature_RENEWAL"(varchar)

----[ SQL Example(s) ]------------------------------------------------------------------------------

▪ ---> ( DATA INSERTION )
	SELECT
		*
	FROM
		"SchLog"."Func_TblLog_RecordDataTracking_SET_BULK"(
			'{}'::json,
			'[
				{
				"recordID" : null,
				"entitiesMetaData" : {
					"businessDocumentTypeName" : null,
					"documentDate" : null
					},
				"entities" : {
					"sysLoginSession_RefID" : 6000000000001,
					"sysDataAnnotation" : null,
					"sysDataValidityStartDateTimeTZ" : null,
					"sysDataValidityFinishDateTimeTZ" : null,
					"sysPartitionRemovableRecordKeyRefName" : null,
					"sysBranch_RefID" : 11000000000004,
					"sysBaseCurrency_RefID" : 62000000000001,
					
					"record_SchemaTableName" : "SchFinance.TblAdvance",
					"record_RefPID" : 76000000000947,
					"record_RefSID" : 10076000000000947,
					"dataIntegrityShadow" : null,
					"JSONData" : {"myJSON" : "data"},
					"upperLink_RefID" : null,
					"businessDocumentVersion_RefIDLink" : null
					}
				}
			]'::json
			);

▪ ---> ( DATA UPDATE )
	SELECT
		*
	FROM
		"SchLog"."Func_TblLog_RecordDataTracking_SET_BULK"(
			'{}'::json,
			'[
				{
				"recordID" : 313000000000001,
				"entitiesMetaData" : {
					"businessDocumentTypeName" : null,
					"documentDate" : null
					},
				"entities" : {
					"sysLoginSession_RefID" : 6000000000001,
					"sysDataAnnotation" : null,
					"sysDataValidityStartDateTimeTZ" : null,
					"sysDataValidityFinishDateTimeTZ" : null,
					"sysPartitionRemovableRecordKeyRefName" : null,
					"sysBranch_RefID" : 11000000000004,
					"sysBaseCurrency_RefID" : 62000000000001,

					"record_SchemaTableName" : "SchFinance.TblAdvance",
					"record_RefPID" : 76000000000945,
					"record_RefSID" : 10076000000000945,
					"dataIntegrityShadow" : null,
					"JSONData" : {"myJSON" : "data"},
					"upperLink_RefID" : null,
					"businessDocumentVersion_RefIDLink" : null
					}
				}
			]'::json
			);

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varEnvironmentParameter									ALIAS FOR $1;
			------------------------------
			varJSONData												ALIAS FOR $2;
			varJSONDataDeletion										ALIAS FOR $3;

		---{ Optional }-------------------

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----
			varReturn												json;

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

			varSQL													varchar;

			varFrontEndSchemaTableName								varchar;
			varJSONFunctionName										json;
			varJSONFunctionParameterParsing							json;

		---{ Additional }-----------------

BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		IF (varSignEligibleToProcess IS FALSE) THEN
			varSignEligibleToProcess := TRUE;
		END IF;

		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------( START )-----
			IF (varSignEligibleToProcess IS TRUE) THEN
			END IF;
		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------(  END  )-----

		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------( START )-----
			IF (varSignEligibleToProcess IS TRUE) THEN
				-----[ INPUT VARIABLES REINITIALIZATION ]-------------------------------------( START )-----
					---> Reinitializing : varJSONData
						varJSONData :=
							COALESCE (
								varJSONData,
								'{}'::json
								);

					---> Reinitializing : varJSONDataDeletion
						varJSONDataDeletion :=
							COALESCE (
								varJSONDataDeletion,
								'{}'::json
								);
				-----[ INPUT VARIABLES REINITIALIZATION ]-------------------------------------(  END  )-----

				-----[ INTERMEDIATE VARIABLES INITIALIZATION ]--------------------------------( START )-----
					---> Initializing : varFrontEndSchemaTableName
						varFrontEndSchemaTableName :=
							'SchData-Warehouse-Log.TblLog_RecordDataTracking';

					---> Initializing : varJSONFunctionName
						varJSONFunctionName :=
							JSON_BUILD_OBJECT (
								'insertFunction', 'SchLog.Func_TblLog_RecordDataTracking_INSERT',
								'updateFunction', 'SchLog.Func_TblLog_RecordDataTracking_UPDATE'
								);
							--RAISE NOTICE '%', varJSONFunctionName;

					---> Initializing : varJSONFunctionParameterParsing
						varJSONFunctionParameterParsing :=
							JSON_BUILD_ARRAY (
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''sysDataAnnotation''',
									'dataType', 'varchar'
									),
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''sysLoginSession_RefID''',
									'dataType', 'bigint'
									),
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''sysDataSetDateTimeTZ''',
									'dataType', 'timestamptz'
									),
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''sysDataValidityStartDateTimeTZ''',
									'dataType', 'timestamptz'
									),
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''sysDataValidityFinishDateTimeTZ''',
									'dataType', 'timestamptz'
									),
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''sysPartitionRemovableRecordKey_RefID''',
									'dataType', 'bigint'
									),
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''sysBranch_RefID''',
									'dataType', 'bigint'
									),
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''sysBaseCurrency_RefID''',
									'dataType', 'bigint'
									),
								------------------------------
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''record_SchemaTableName''',
									'dataType', 'varchar'
									),								
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''record_SysPID''',
									'dataType', 'bigint'
									),
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''record_SysSID''',
									'dataType', 'bigint'
									),
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''record_ModificationLoginSession_RefID''',
									'dataType', 'bigint'
									),
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''record_ModificationType''',
									'dataType', 'varchar'
									),
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''record_ModificationDateTimeTZ''',
									'dataType', 'timestamptz'
									),
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''record_DataIntegrityShadow''',
									'dataType', 'varchar'
									),
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''record_JSONData''',
									'dataType', 'json'
									),
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''record_UpperLink_RefID''',
									'dataType', 'bigint'
									),
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''record_BusinessDocumentVersion_RefIDLink''',
									'dataType', 'bigint'
									),
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''record_BusinessDocumentVersion''',
									'dataType', 'smallint'
									)
								);
						--RAISE NOTICE '%', varJSONFunctionParameterParsing;
				-----[ INTERMEDIATE VARIABLES INITIALIZATION ]--------------------------------(  END  )-----
			END IF;
		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------(  END  )-----

	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			-----[ PRELIMINARY ADDITIONAL DATA PROCESSING ]---------------------------( START )-----
			-----[ PRELIMINARY ADDITIONAL DATA PROCESSING ]---------------------------(  END  )-----

			-----[ MAIN DATA PROCESSING ]---------------------------------------------( START )-----
				---> Initializing : varReturn
					varReturn := (
						SELECT
							"SchSystem"."FuncSys_General_SetBulkData"(
								NULL::json,
								JSON_BUILD_OBJECT (
									'metadata.control',
										JSON_BUILD_OBJECT (
											'frontEndSchemaTableName',varFrontEndSchemaTableName,
											'functionName', varJSONFunctionName,
											'functionParameterParsing', varJSONFunctionParameterParsing
											),
									'data', varJSONData
									),
								varJSONDataDeletion::json
								)
						);
					--RAISE NOTICE '%', varReturn;

				---> Data Renewal : SchLog.TblLog_TableSnapshotSignature
					varSQL := '
						SELECT
							"SubSQL"."SignatureID"
						FROM
							DBLINK (
								''' || REPLACE ((SELECT "SchSystem"."FuncSys_General_GetEnvironmentParameter"('DBLink.ConnectionString.BackEnd.DataWarehouse')), '''', '''''') || ''',
								''
								SELECT
									"SchLog"."Func_TblLog_TableSnapshotSignature_RENEWAL"(
										''''' || varFrontEndSchemaTableName || '''''
										)
								''
								) AS "SubSQL" ("SignatureID" varchar)
						';
					--RAISE NOTICE '%', varSQL;
					EXECUTE
						varSQL;
			-----[ MAIN DATA PROCESSING ]---------------------------------------------(  END  )-----

			-----[ AFTERWARDS ADDITIONAL DATA PROCESSING ]----------------------------( START )-----
			-----[ AFTERWARDS ADDITIONAL DATA PROCESSING ]----------------------------(  END  )-----
		END IF;

	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----
		RETURN
			varReturn;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		EXCEPTION
			WHEN OTHERS THEN
				NULL;

END;
$_$;


ALTER FUNCTION "SchLog"."Func_TblLog_RecordDataTracking_SET_BULK"(json, json, json) OWNER TO "SysAdmin";

--
-- TOC entry 390 (class 1255 OID 6653795)
-- Name: Func_TblLog_RecordDataTracking_SET_BULK_SUBMISSION(bigint[], json, smallint[]); Type: FUNCTION; Schema: SchLog; Owner: SysAdmin
--

CREATE FUNCTION "SchLog"."Func_TblLog_RecordDataTracking_SET_BULK_SUBMISSION"(bigint[] DEFAULT NULL::bigint[], json DEFAULT NULL::json, smallint[] DEFAULT NULL::smallint[]) RETURNS character varying
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchLog"."Func_TblLog_RecordDataTracking_SET_BULK_SUBMISSION"
▪ Versi               :	1.01.0003
▪ Tanggal
     ► Pemutakhiran   :	2026-11-25
     ► Pembuatan      :	2026-10-27
▪ Input               :	• varRecord_IDArray (bigint[] - Mandatory)
						------------------------------
						• varJSON_RecordContent (json - Optional)
						• varRecord_BusinessDocumentVersionArray (smallint[] - Optional)
						------------------------------
▪ Output              :	varReturn (json)
▪ Deskripsi           :	• Mengeset Pemasukan Data Auto Trigger untuk Record Data Tracking
▪ Copyright           :	Zheta © 2026

----[ Related Database Object(s) ]------------------------------------------------------------------

▪ Tabel               :	• [BE] "SchSysConfig"."TblDBObject_Table"

▪ Fungsi              :	• [BE] "SchSystem"."FuncSys_General_GetEnvironmentParameter"(varchar)
						• [BE] "SchSystem"."FuncSys_General_StrSQLExecution"(varchar)
						------------------------------
						• [BE] "SchLog"."Func_TblLog_RecordDataTracking_SET_BULK"(json, json, json)

----[ SQL Example(s) ]------------------------------------------------------------------------------

▪ --->
	SELECT
		"SchLog"."Func_TblLog_RecordDataTracking_SET_BULK_SUBMISSION"(
			'{46000000000042}'::bigint[],
			------------------------------
			'[{"Sys_PID":46000000000001,"Sys_SID":10046000000000042,"Sys_RPK":42,"Sys_Data_Annotation":null,"Sys_Data_Entry_LoginSession_RefID":6000000000001,"Sys_Data_Entry_DateTimeTZ":"2026-11-02T17:43:40.454623+07:00","Sys_Data_Edit_LoginSession_RefID":null,"Sys_Data_Edit_DateTimeTZ":null,"Sys_Data_Delete_LoginSession_RefID":null,"Sys_Data_Delete_DateTimeTZ":null,"Sys_Data_Hidden_LoginSession_RefID":null,"Sys_Data_Hidden_DateTimeTZ":null,"Sys_Data_Authentication_LoginSession_RefID":null,"Sys_Data_Authentication_DateTimeTZ":null,"Sys_Data_Cancelation_LoginSession_RefID":null,"Sys_Data_Cancelation_DateTimeTZ":null,"Sys_Data_Validity_StartDateTimeTZ":"0001-01-01T07:07:12+07:07:12","Sys_Data_Validity_FinishDateTimeTZ":"10000-01-01T06:59:59+07:00","Sys_Partition_RemovableRecord_Key_RefID":null,"Sys_Branch_RefID":11000000000001,"Sys_BaseCurrency_RefID":null,"Sys_DataIntegrityShadow":"5a595ec2cf90dff0c438d90230bc3bc0","BusinessDocumentVersion_RefID":null,"Log_FileUpload_Pointer_RefID":null,"RequesterWorkerJobsPosition_RefID":6000000000001,"Name":"NEW PROJECT","MaterialProductAssembly_RefID":null,"ValidStartDateTimeTZ":"2026-01-01T00:00:00+07:00","ValidFinishDateTimeTZ":"2028-01-01T00:00:00+07:00","Code":"NP"}]'::json,
			'{null}'::smallint[]
			);

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varRecord_IDArray										ALIAS FOR $1;
			------------------------------

		---{ Optional }-------------------
			varJSON_RecordContent									ALIAS FOR $2;
			varRecord_BusinessDocumentVersionArray					ALIAS FOR $3;

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----
			varReturn												varchar;

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

			varSQL													varchar;
			varSQL2													varchar;
			varRecTemp												record;

			varRecord_SchemaTableName								varchar;
			varRecord_SysPID										bigint;
			varRecord_SysSID										bigint;
			varRecord_ModificationLoginSession_RefID				bigint;
			varRecord_ModificationType								varchar;
			varRecord_ModificationDateTimeTZ						timestamptz;
			varRecord_DataIntegrityShadow							varchar;
			varRecord_JSONData										json;
			varRecord_UpperLink_RefID								bigint;
			varRecord_BusinessDocumentVersion_RefID					bigint;

			varSignTable											bigint;
			varIndex												bigint;

			varSchemaTableRPKArray									bigint[];
			varSchemaTableNameArray									varchar[];

		---{ Additional }-----------------

BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		IF (varSignEligibleToProcess IS FALSE) THEN
			varSignEligibleToProcess := TRUE;

			IF ((varRecord_IDArray::varchar IS NULL) OR (varRecord_IDArray::varchar = '{}')) THEN
				varSignEligibleToProcess := FALSE;
			END IF;
		END IF;

		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------( START )-----
			IF (varSignEligibleToProcess IS FALSE) THEN
				varSignEligibleToProcess := TRUE;
			END IF;
		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------(  END  )-----

		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------( START )-----
			IF (varSignEligibleToProcess IS TRUE) THEN
				---> Reinitializing : varRecord_BusinessDocumentVersionArray
					IF ((varRecord_BusinessDocumentVersionArray IS NULL) OR (varRecord_BusinessDocumentVersionArray::varchar = '[]')) THEN
						varRecord_BusinessDocumentVersionArray := (
							SELECT
								('{' || REPLACE (TRIM (REPEAT ('NULL ', CARDINALITY (varRecord_IDArray))), ' ', ',') || '}')::smallint[]
							);
						RAISE NOTICE '%', varRecord_BusinessDocumentVersionArray;
					END IF;

				---> Initializing : varSchemaTableRPKArray, varSchemaTableNameArray
					SELECT
						"SubSQL"."ID",
						"SubSQL"."Value"
					INTO
						varSchemaTableRPKArray,
						varSchemaTableNameArray
					FROM
						DBLINK (
							(SELECT "SchSystem"."FuncSys_General_GetEnvironmentParameter"('DBLink.ConnectionString.BackEnd.SysConfig')),
							'
							SELECT
								"SubSQL"."ID",
								"SubSQL"."Value"
							FROM
								(
								SELECT
									CASE
										WHEN ("SubSQL"."OrderSequence" = 1) THEN
											''{'' ||
											STRING_AGG (
												"SubSQL"."SchemaTableID"::varchar,
												'', ''
												) OVER () ||
											''}''
										ELSE
											NULL
									END::bigint[] AS "ID",
									CASE
										WHEN ("SubSQL"."OrderSequence" = 1) THEN
											''{'' ||
											STRING_AGG (
												(''"'' || REPLACE (REPLACE ("SubSQL"."SchemaTableName"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''),
												'', ''
												) OVER () ||
											''}''
										ELSE
											NULL
									END::varchar[] AS "Value"
								FROM
									(
									SELECT
										"SubSQL"."SchemaTableID",
										"SubSQL"."SchemaTableName",
										ROW_NUMBER () OVER () AS "OrderSequence"
									FROM
										(
										SELECT
											"SchemaTableID",
											(
											COALESCE (
												"TblSchema_PID"."Name",
												"TblSchema_SID"."Name"
												) || ''.'' || "SubSQL"."TableName"
											) AS "SchemaTableName"
										FROM
											(
											SELECT
												"Sys_RPK" AS "SchemaTableID",
												"Schema_RefID",
												"Name" AS "TableName"
											FROM
												"SchSysConfig"."TblDBObject_Table"
											WHERE
												"Sys_RPK" IN '
													||
													(
													SELECT
														CASE
															WHEN ("SubSQL"."OrderSequence" = 1) THEN
																'(' ||
																STRING_AGG (
																	"SubSQL"."ID"::varchar,
																	', '
																	) OVER () ||
																')'
															ELSE
																NULL
														END
													FROM
														(
														SELECT
															"SubSQL"."ID",
															ROW_NUMBER () OVER () AS "OrderSequence"
														FROM
															(
															SELECT DISTINCT
																((UNNEST (COALESCE (varRecord_IDArray, '{NULL}'::bigint[])) / 1000000000000) % 10000) AS "ID"
															) AS "SubSQL"
														) AS "SubSQL"
													LIMIT 1
													)
													||
													'
											) AS "SubSQL"
												LEFT JOIN
													"SchSysConfig"."TblDBObject_Schema" AS "TblSchema_PID"
														ON
															"SubSQL"."Schema_RefID" = "TblSchema_PID"."Sys_PID"
												LEFT JOIN
													"SchSysConfig"."TblDBObject_Schema" AS "TblSchema_SID"
														ON
															"SubSQL"."Schema_RefID" = "TblSchema_SID"."Sys_PID"
										) AS "SubSQL"
									) AS "SubSQL"
								LIMIT 1
								) AS "SubSQL"
							'
							) AS "SubSQL" (
								"ID" bigint[],
								"Value" varchar[]
								);
					--RAISE NOTICE 'varSchemaTableRPKArray : %', varSchemaTableRPKArray;
					--RAISE NOTICE 'varSchemaTableNameArray : %', varSchemaTableNameArray;
			END IF;
		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------(  END  )-----

	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			-----[ MAIN DATA PROCESSING ]---------------------------------------------( START )-----

				---> Main Data
					varSQL := '
						SELECT
							"SubSQL"."JSONData",
							------------------------------
							"SubSQL"."OrderSequence"
						FROM
							(
							SELECT
								(
								SELECT
									CASE
										WHEN ("InnerSubSQL"."InnerOrderSequence" = 1) THEN
											(
											''{'' ||
											STRING_AGG (
												SUBSTRING ("InnerSubSQL"."JSONData"::varchar, 2, (LENGTH("InnerSubSQL"."JSONData"::varchar) - 2)),
												'',''
												) OVER (
													PARTITION BY
														"SubSQL"."OrderSequence"
													) ||
											''}''
											)
										ELSE
											NULL
									END::json AS "JSONData"
								FROM
									(
									SELECT
										JSON_BUILD_OBJECT (
											CASE
												WHEN (SUBSTRING (("InnerSubSQL"."JSONData"->>''key''::varchar), 2, 1) = UPPER (SUBSTRING (("InnerSubSQL"."JSONData"->>''key''::varchar), 2, 1))) THEN
													"InnerSubSQL"."JSONData"->>''key''
												ELSE
													(LOWER (SUBSTRING (("InnerSubSQL"."JSONData"->>''key''::varchar), 1, 1)) || SUBSTRING (("InnerSubSQL"."JSONData"->>''key''::varchar), 2, (LENGTH("InnerSubSQL"."JSONData"->>''key''::varchar) - 1)))
											END,
											"InnerSubSQL"."JSONData"->''value''
											) AS "JSONData",
										------------------------------
										"InnerSubSQL"."InnerOrderSequence"
									FROM
										(
										SELECT
											ROW_TO_JSON("InnerSubSQL"."JSONData") AS "JSONData",
											------------------------------
											"InnerSubSQL"."InnerOrderSequence"
										FROM
											(
											SELECT
												"InnerSubSQL"."JSONData",
												------------------------------
												ROW_NUMBER () OVER (
													PARTITION BY
														"SubSQL"."OrderSequence"
													) AS "InnerOrderSequence"
											FROM
												(
												SELECT
													JSON_EACH ("SubSQL"."JSONData") AS "JSONData"
												) AS "InnerSubSQL"
											) AS "InnerSubSQL"
										) AS "InnerSubSQL"
									) AS "InnerSubSQL"
								LIMIT 1
								) AS "JSONData",
								------------------------------
								"SubSQL"."OrderSequence"
							FROM
								(
								SELECT
									"SubSQL"."JSONData",
									------------------------------
									ROW_NUMBER () OVER (
										) AS "OrderSequence"
								FROM
									(
									SELECT
										JSON_ARRAY_ELEMENTS (''' || varJSON_RecordContent::varchar || '''::json) AS "JSONData"
									) AS "SubSQL"
								) AS "SubSQL"
							) AS "SubSQL"
					';
				--RAISE NOTICE '%', varSQL;

				---> Initializing : varRecord_JSONData, varRecord_SchemaTableName, varRecord_SysPID, varRecord_SysSID, varRecord_DataIntegrityShadow, varRecord_BusinessDocumentVersion_RefID, varSignTable
					varIndex := 0;
					varSQL2 := '';
					FOR varRecTemp IN EXECUTE varSQL
						LOOP
							varIndex :=
								varIndex + 1;

							varRecord_JSONData := varRecTemp."JSONData";

							varRecord_SchemaTableName := varSchemaTableNameArray[ARRAY_POSITION(varSchemaTableRPKArray, (((varRecord_JSONData->>'sys_PID')::bigint / 1000000000000) % 10000))];

							varRecord_SysPID := (varRecord_JSONData->>'sys_PID')::bigint;
							varRecord_SysSID := (varRecord_JSONData->>'sys_SID')::bigint;

							varRecord_ModificationLoginSession_RefID := (
								CASE
									WHEN ((varRecord_JSONData->>'sys_Data_Delete_DateTimeTZ')::timestamptz IS NOT NULL) THEN
										(varRecord_JSONData->>'sys_Data_Delete_LoginSession_RefID')::bigint
									WHEN ((varRecord_JSONData->>'sys_Data_Edit_DateTimeTZ')::timestamptz IS NOT NULL) THEN
										(varRecord_JSONData->>'sys_Data_Edit_LoginSession_RefID')::bigint
									WHEN ((varRecord_JSONData->>'sys_Data_Entry_DateTimeTZ')::timestamptz IS NOT NULL) THEN
										(varRecord_JSONData->>'sys_Data_Entry_LoginSession_RefID')::bigint
									ELSE
										NULL::bigint
								END
								);

							varRecord_ModificationType := (
								CASE
									WHEN ((varRecord_JSONData->>'sys_Data_Delete_DateTimeTZ')::timestamptz IS NOT NULL) THEN
										'Data Deletion'::varchar
									WHEN ((varRecord_JSONData->>'sys_Data_Edit_DateTimeTZ')::timestamptz IS NOT NULL) THEN
										'Data Update'::varchar
									WHEN ((varRecord_JSONData->>'sys_Data_Entry_DateTimeTZ')::timestamptz IS NOT NULL) THEN
										'Data Insertion'::varchar
									ELSE
										NULL::varchar
								END
								);

							varRecord_ModificationDateTimeTZ :=
								COALESCE (
									(varRecord_JSONData->>'sys_Data_Delete_DateTimeTZ')::timestamptz,
									(varRecord_JSONData->>'sys_Data_Edit_DateTimeTZ')::timestamptz,
									(varRecord_JSONData->>'sys_Data_Entry_DateTimeTZ')::timestamptz
									);						

							varRecord_DataIntegrityShadow := (varRecord_JSONData->>'sys_DataIntegrityShadow')::varchar;
							
							varRecord_BusinessDocumentVersion_RefID := (varRecord_JSONData->>'businessDocumentVersion_RefID')::bigint;

							varSignTable := (
								(
								COALESCE (
									varRecord_SysPID,
									varRecord_SysSID
									)
								/ 1000000000000
								) % 10000
								);

							varRecord_UpperLink_RefID := (
								CASE
									---> SchCustomerRelation
										---> TblSalesContractDetail
											WHEN (varSignTable = 132) THEN
												(varRecord_JSONData->>'salesContract_RefID')::bigint
										---> TblSalesOrderDetail
											WHEN (varSignTable = 130) THEN
												(varRecord_JSONData->>'salesOrder_RefID')::bigint

									---> SchFinance
										---> TblAdvanceDetail
											WHEN (varSignTable = 82) THEN
												(varRecord_JSONData->>'advance_RefID')::bigint
										---> TblAdvanceSettlementDetail
											WHEN (varSignTable = 204) THEN
												(varRecord_JSONData->>'advanceSettlement_RefID')::bigint
										---> TblCashDisbursementDetail
											WHEN (varSignTable = 193) THEN
												(varRecord_JSONData->>'cashDisbursement_RefID')::bigint
										---> TblCreditNoteDetail
											WHEN (varSignTable = 243) THEN
												(varRecord_JSONData->>'creditNote_RefID')::bigint
										---> TblDebitNoteDetail
											WHEN (varSignTable = 241) THEN
												(varRecord_JSONData->>'debitNote_RefID')::bigint
										---> TblLoanDetail
											WHEN (varSignTable = 294) THEN
												(varRecord_JSONData->>'loan_RefID')::bigint
										---> TblLoanSettlementDetail
											WHEN (varSignTable = 296) THEN
												(varRecord_JSONData->>'loanSettlement_RefID')::bigint
										---> TblPaymentInstructionDetail
											WHEN (varSignTable = 212) THEN
												(varRecord_JSONData->>'paymentInstruction_RefID')::bigint
										---> TblPurchaseInvoiceDetail
											WHEN (varSignTable = 209) THEN
												(varRecord_JSONData->>'purchaseInvoice_RefID')::bigint
										---> TblPurchaseProformaInvoiceDetail
											WHEN (varSignTable = 206) THEN
												(varRecord_JSONData->>'purchaseProformaInvoice_RefID')::bigint
										---> TblReimbursementDetail
											WHEN (varSignTable = 289) THEN
												(varRecord_JSONData->>'reimbursement_RefID')::bigint
										---> TblSalesInvoiceDetail
											WHEN (varSignTable = 139) THEN
												(varRecord_JSONData->>'salesInvoice_RefID')::bigint
										---> TblSalesInvoiceRequisitionDetail
											WHEN (varSignTable = 245) THEN
												(varRecord_JSONData->>'salesInvoiceRequisition_RefID')::bigint

									---> SchProduction
										---> TblBillOfMaterial
											WHEN (varSignTable = 148) THEN
												(varRecord_JSONData->>'billOfMaterial_RefID')::bigint

									---> SchProject
										---> TblBillOfQuantityDetail
											WHEN (varSignTable = 317) THEN
												(varRecord_JSONData->>'billOfQuantity_RefID')::bigint
										---> TblProjectSection
											WHEN (varSignTable = 110) THEN
												(varRecord_JSONData->>'project_RefID')::bigint
										---> TblProjectSectionItem
											WHEN (varSignTable = 143) THEN
												(varRecord_JSONData->>'projectSection_RefID')::bigint
										---> TblProjectSectionItemWork
											WHEN (varSignTable = 158) THEN
												(varRecord_JSONData->>'projectSectionItem_RefID')::bigint

									---> SchSupplyChain
										---> TblDeliveryOrderDetail
											WHEN (varSignTable = 181) THEN
												(varRecord_JSONData->>'deliveryOrder_RefID')::bigint
										---> TblMaterialServiceRequisitionDetail
											WHEN (varSignTable = 263) THEN
												(varRecord_JSONData->>'materialServiceRequisition_RefID')::bigint
										---> TblOrderPickingDetail
											WHEN (varSignTable = 251) THEN
												(varRecord_JSONData->>'orderPicking_RefID')::bigint
										---> TblOrderPickingRequisitionDetail
											WHEN (varSignTable = 249) THEN
												(varRecord_JSONData->>'orderPickingRequisition_RefID')::bigint
										---> TblPurchaseOrderDetail
											WHEN (varSignTable = 86) THEN
												(varRecord_JSONData->>'purchaseOrder_RefID')::bigint
										---> TblPurchaseRequisitionDetail
											WHEN (varSignTable = 84) THEN
												(varRecord_JSONData->>'purchaseRequisition_RefID')::bigint
										---> TblWarehouseInboundOrderDetail
											WHEN (varSignTable = 177) THEN
												(varRecord_JSONData->>'warehouseInboundOrder_RefID')::bigint
										---> TblWarehouseOutboundOrderDetail
											WHEN (varSignTable = 179) THEN
												(varRecord_JSONData->>'warehouseOutboundOrder_RefID')::bigint

									---> Others
										ELSE
											NULL
								END
								);

							/*
							RAISE NOTICE '--------------------------------';
							RAISE NOTICE 'varRecord_SysPID                         : %', varRecord_SysPID;
							RAISE NOTICE 'varRecord_SysSID                         : %', varRecord_SysSID;
							RAISE NOTICE 'varRecord_ModificationLoginSession_RefID : %', varRecord_ModificationLoginSession_RefID;
							RAISE NOTICE 'varRecord_ModificationType               : %', varRecord_ModificationType;
							RAISE NOTICE 'varRecord_ModificationDateTimeTZ         : %', varRecord_ModificationDateTimeTZ;
							RAISE NOTICE 'varRecord_DataIntegrityShadow            : %', varRecord_DataIntegrityShadow;						
							RAISE NOTICE 'varRecord_JSONData                       : %', varRecord_JSONData;
							RAISE NOTICE 'varSignTable                             : %', varSignTable;
							RAISE NOTICE 'varRecord_UpperLink_RefID                : %', varRecord_UpperLink_RefID;
							RAISE NOTICE 'varRecord_BusinessDocumentVersion_RefID  : %', varRecord_BusinessDocumentVersion_RefID;
							RAISE NOTICE 'varRecord_BusinessDocumentVersionArray   : %', varRecord_BusinessDocumentVersionArray;
							*/

							IF (varSQL2 != '') THEN
								varSQL2 := (
									varSQL2 || ', '
									);
							END IF;

							varSQL2 := (
								varSQL2 ||
									'
									{
									"recordID" : null,
									"entitiesMetaData" : {
										"businessDocumentTypeName" : null,
										"documentDate" : null
										},
									"entities" : {
										"sysLoginSession_RefID" : 6000000000001,
										"sysDataAnnotation" : null,
										"sysDataValidityStartDateTimeTZ" : null,
										"sysDataValidityFinishDateTimeTZ" : null,
										"sysPartitionRemovableRecordKeyRefName" : null,
										"sysBranch_RefID" : null,
										"sysBaseCurrency_RefID" : null,

										"record_SchemaTableName" : ' || COALESCE (('"' || varRecord_SchemaTableName::varchar || '"'), 'null'::varchar) || ',
										"record_SysPID" : ' || COALESCE (varRecord_SysPID::varchar, 'null'::varchar) || ',
										"record_SysSID" : ' || COALESCE (varRecord_SysSID::varchar, 'null'::varchar) || ',
										"record_ModificationLoginSession_RefID" : ' || COALESCE (varRecord_ModificationLoginSession_RefID::varchar, 'null'::varchar) || ',
										"record_ModificationType" : ' || COALESCE (('"' || varRecord_ModificationType::varchar || '"'), 'null'::varchar) || ',
										"record_ModificationDateTimeTZ" : ' || 
											COALESCE (
												(
												'"'
												||
												(
												JSON_BUILD_OBJECT (
													'record_ModificationDateTimeTZ', varRecord_ModificationDateTimeTZ::timestamptz
													)->>'record_ModificationDateTimeTZ'
												)::varchar
												||
												'"'
												),
												'null'::varchar
												) || 
											',
										"record_DataIntegrityShadow" : ' || COALESCE (('"' || varRecord_DataIntegrityShadow::varchar || '"'), 'null'::varchar) || ',
										"record_JSONData" : ' || COALESCE (varRecord_JSONData::varchar, 'null'::varchar) || ',
										"record_UpperLink_RefID" : ' || COALESCE (varRecord_UpperLink_RefID::varchar, 'null'::varchar) || ',
										"record_BusinessDocumentVersion_RefIDLink" : ' || COALESCE (varRecord_BusinessDocumentVersion_RefID::varchar, 'null'::varchar) || ',
										"record_BusinessDocumentVersion" : ' || COALESCE (varRecord_BusinessDocumentVersionArray[varIndex]::varchar, 'null'::varchar) || '
										}
									}
									'
								);
							--RAISE NOTICE 'varSQL2 %', varSQL2;
						END LOOP;

					varSQL := (
						'[' || varSQL2 || ']'
						);
					--RAISE NOTICE 'varSQL %', varSQL;

				---> Reinitializing : varSQL ► Final
					varSQL := '
						SELECT
							*
						FROM
							"SchLog"."Func_TblLog_RecordDataTracking_SET_BULK"(
								''{}''::json,
								''' || REPLACE (varSQL, '''', '''''') || '''::json
								)
						';
					--RAISE NOTICE 'varSQL  : %', varSQL;

				---> varSQL Execution
					EXECUTE varSQL INTO varReturn;

			-----[ MAIN DATA PROCESSING ]---------------------------------------------(  END  )-----
		END IF;

	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			---> Send Data Output
				RETURN
					varReturn;
		END IF;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		EXCEPTION
			WHEN OTHERS THEN
				NULL;

END;
$_$;


ALTER FUNCTION "SchLog"."Func_TblLog_RecordDataTracking_SET_BULK_SUBMISSION"(bigint[], json, smallint[]) OWNER TO "SysAdmin";

--
-- TOC entry 391 (class 1255 OID 6653798)
-- Name: Func_TblLog_RecordDataTracking_UPDATE(bigint, bigint, timestamp with time zone, timestamp with time zone, timestamp with time zone, bigint, bigint, bigint, character varying, bigint, bigint, bigint, character varying, timestamp with time zone, character varying, json, bigint, bigint, smallint); Type: FUNCTION; Schema: SchLog; Owner: SysAdmin
--

CREATE FUNCTION "SchLog"."Func_TblLog_RecordDataTracking_UPDATE"(bigint, bigint, timestamp with time zone, timestamp with time zone, timestamp with time zone, bigint, bigint, bigint, character varying, bigint, bigint, bigint, character varying, timestamp with time zone, character varying, json, bigint, bigint, smallint) RETURNS SETOF "SchSystem"."HoldFuncSys_General_FeedBackQuery"
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchLog"."Func_TblLog_RecordDataTracking_UPDATE"
▪ Versi               :	1.01.0001
▪ Tanggal
     ► Pemutakhiran   :	2026-11-02
     ► Pembuatan      :	2026-10-26
▪ Input               :	• varID (bigint - Mandatory)
						• varSysDataEditLoginSession_RefID (bigint - Mandatory)
						• varSysDataEditDateTimeTZ (timestamptz - Mandatory)
						• varSysDataValidityStartDateTimeTZ (timestamptz - Mandatory)
						• varSysDataValidityFinishDateTimeTZ (timestamptz - Mandatory)
						• varSysPartitionRemovableRecordKey_RefID (bigint - Mandatory)
						• varSysBranch_RefID (bigint - Mandatory)
						• varSysBaseCurrency_RefID (bigint - Mandatory)
						------------------------------
						• varRecord_SchemaTableName (varchar - Mandatory)
						• varRecord_SysPID (bigint - Mandatory)
						• varRecord_SysSID (bigint - Mandatory)
						• varRecord_ModificationLoginSession_RefID (bigint - Mandatory)
						• varRecord_ModificationType (varchar - Mandatory)
						• varRecord_ModificationDateTimeTZ (timestamptz - Mandatory)
						• varRecord_DataIntegrityShadow (varchar - Mandatory)
						• varRecord_JSONData (json - Mandatory)
						• varRecord_UpperLink_RefID (bigint - Mandatory)
						• varRecord_BusinessDocumentVersion_RefID (bigint - Mandatory)
						• varRecord_BusinessDocumentVersion (smallint - Mandatory)
						------------------------------
▪ Output              :	varRecSetOutput ("SchSystem"."HoldFuncSys_General_FeedBackQuery")
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Memutakhirkan data (UPDATE) pada tabel TblLog_RecordDataTracking
▪ Copyright           :	Zheta © 2026

----[ SQL Example(s) ]------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varID													ALIAS FOR $1;
			varSysDataEditLoginSession_RefID						ALIAS FOR $2;
			varSysDataEditDateTimeTZ								ALIAS FOR $3;
			varSysDataValidityStartDateTimeTZ						ALIAS FOR $4;
			varSysDataValidityFinishDateTimeTZ						ALIAS FOR $5;
			varSysPartitionRemovableRecordKey_RefID					ALIAS FOR $6;
			varSysBranch_RefID										ALIAS FOR $7;
			varSysBaseCurrency_RefID								ALIAS FOR $8;
			------------------------------
			varRecord_SchemaTableName								ALIAS FOR $9;
			varRecord_SysPID										ALIAS FOR $10;
			varRecord_SysSID										ALIAS FOR $11;
			varRecord_ModificationLoginSession_RefID				ALIAS FOR $12;
			varRecord_ModificationType								ALIAS FOR $13;
			varRecord_ModificationDateTimeTZ						ALIAS FOR $14;
			varRecord_DataIntegrityShadow							ALIAS FOR $15;
			varRecord_JSONData										ALIAS FOR $16;
			varRecord_UpperLink_RefID								ALIAS FOR $17;
			varRecord_BusinessDocumentVersion_RefID					ALIAS FOR $18;
			varRecord_BusinessDocumentVersion						ALIAS FOR $19;

		---{ Optional }-------------------

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----
			varRecSetOutput											"SchSystem"."HoldFuncSys_General_FeedBackQuery"%rowtype;

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

		---{ Additional }-----------------

BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		IF (varSignEligibleToProcess IS FALSE) THEN
			varSignEligibleToProcess := TRUE;
		END IF;

		IF (varSignEligibleToProcess IS TRUE) THEN
		END IF;

	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			-----[ MAIN DATA PROCESSING ]---------------------------------------------( START )-----
				---> Main Data Set
					UPDATE
						"SchLog"."TblLog_RecordDataTracking"
					SET
						"Sys_Data_Edit_LoginSession_RefID" = varSysDataEditLoginSession_RefID,
						"Sys_Data_Edit_DateTimeTZ" = varSysDataEditDateTimeTZ,
						"Sys_Data_Validity_StartDateTimeTZ" = varSysDataValidityStartDateTimeTZ,
						"Sys_Data_Validity_FinishDateTimeTZ" = varSysDataValidityFinishDateTimeTZ,
						"Sys_Partition_RemovableRecord_Key_RefID" = varSysPartitionRemovableRecordKey_RefID,
						"Sys_Branch_RefID" = varSysBranch_RefID,
						"Sys_BaseCurrency_RefID" = varSysBaseCurrency_RefID,
						------------------------------
						"Record_SchemaTableName" = varRecord_SchemaTableName,
						"Record_SysPID" = varRecord_SysPID,
						"Record_SysSID" = varRecord_SysSID,
						"Record_ModificationLoginSession_RefID" = varRecord_ModificationLoginSession_RefID,
						"Record_ModificationType" = varRecord_ModificationType,
						"Record_ModificationDateTimeTZ" = varRecord_ModificationDateTimeTZ,
						"Record_DataIntegrityShadow" = varRecord_DataIntegrityShadow,
						"Record_JSONData" = varRecord_JSONData,
						"Record_UpperLink_RefID" = varRecord_UpperLink_RefID,
						"Record_BusinessDocumentVersion_RefID" = varRecord_BusinessDocumentVersion_RefID,
						"Record_BusinessDocumentVersion" = varRecord_BusinessDocumentVersion,
						------------------------------
						"Record_BusinessDocumentVersion" = 
							(
							SELECT
								COALESCE (
									(MAX ("Record_Version") + 1),
									0
									)::smallint
							FROM
								"SchLog"."TblLog_RecordDataTracking"
							WHERE
								"Record_SysPID" = varRecord_SysPID
								OR
								"Record_SysSID" = varRecord_SysSID
							)::smallint
					WHERE
						"Sys_PID" = varID
						OR
						"Sys_SID" = varID;

				---> Update "Sys_DataIntegrityShadow"
					PERFORM
						"SchSystem"."FuncSys_General_SetDataIntegrityShadow"(
							'SchLog.TblLog_RecordDataTracking'::varchar,
							varID::bigint
							);

			-----[ MAIN DATA PROCESSING ]---------------------------------------------(  END  )-----
		END IF;

	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			---> Initializing : varRecSetOutput
				varRecSetOutput."SignSuccess" := 1;
				varRecSetOutput."SignRecordType" := 'Sys_RPK';
				varRecSetOutput."SignRecordID" := (
					SELECT
						"Sys_RPK"
					FROM
						"SchLog"."TblLog_RecordDataTracking"
					WHERE
						"Sys_PID" = varID
						OR
						"Sys_SID" = varID
					ORDER BY
						"Sys_RPK" ASC
					LIMIT 1
					);
				varRecSetOutput."SignMessage" := null;

			---> Data Return
				RETURN
					NEXT varRecSetOutput;
		END IF;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		--EXCEPTION WHEN OTHERS THEN ...

END;
$_$;


ALTER FUNCTION "SchLog"."Func_TblLog_RecordDataTracking_UPDATE"(bigint, bigint, timestamp with time zone, timestamp with time zone, timestamp with time zone, bigint, bigint, bigint, character varying, bigint, bigint, bigint, character varying, timestamp with time zone, character varying, json, bigint, bigint, smallint) OWNER TO "SysAdmin";

--
-- TOC entry 392 (class 1255 OID 6653801)
-- Name: Func_TblLog_TableSnapshotSignature_INSERT(character varying, bigint, timestamp with time zone, timestamp with time zone, timestamp with time zone, bigint, bigint, bigint, character varying, character varying, character varying); Type: FUNCTION; Schema: SchLog; Owner: SysAdmin
--

CREATE FUNCTION "SchLog"."Func_TblLog_TableSnapshotSignature_INSERT"(character varying, bigint, timestamp with time zone, timestamp with time zone, timestamp with time zone, bigint, bigint, bigint, character varying, character varying, character varying) RETURNS SETOF "SchSystem"."HoldFuncSys_General_FeedBackQuery"
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchLog"."Func_TblLog_TableSnapshotSignature_INSERT"
▪ Versi               :	1.01.0000
▪ Tanggal
     ► Pemutakhiran   :	2026-06-09
     ► Pembuatan      :	2023-03-24
▪ Input               :	• varSysDataAnnotation (varchar - Mandatory)
						• varSysDataEntryLoginSession_RefID (bigint - Mandatory)
						• varSysDataEntryDateTimeTZ (timestamptz - Mandatory)
						• varSysDataValidityStartDateTimeTZ (timestamptz - Mandatory)
						• varSysDataValidityFinishDateTimeTZ (timestamptz - Mandatory)
						• varSysPartitionRemovableRecordKey_RefID (bigint - Mandatory)
						• varSysBranch_RefID (bigint - Mandatory)
						• varSysBaseCurrency_RefID (bigint - Mandatory)
						------------------------------
						• varSchemaName (varchar - Mandatory)
						• varTableName (varchar - Mandatory)
						• varSignatureID (varchar - Mandatory)
						------------------------------
▪ Output              :	varRecSetOutput ("SchSystem"."HoldFuncSys_General_FeedBackQuery")
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Memasukan data (INSERT) pada tabel TblLog_TableSnapshotSignature
▪ Copyright           :	Zheta © 2023 - 2026

----[ SQL Example(s) ]------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varSysDataAnnotation									ALIAS FOR $1;
			varSysDataEntryLoginSession_RefID						ALIAS FOR $2;
			varSysDataEntryDateTimeTZ								ALIAS FOR $3;
			varSysDataValidityStartDateTimeTZ						ALIAS FOR $4;
			varSysDataValidityFinishDateTimeTZ						ALIAS FOR $5;
			varSysPartitionRemovableRecordKey_RefID					ALIAS FOR $6;
			varSysBranch_RefID										ALIAS FOR $7;
			varSysBaseCurrency_RefID								ALIAS FOR $8;
			------------------------------
			varSchemaName											ALIAS FOR $9;
			varTableName											ALIAS FOR $10;
			varSignatureID											ALIAS FOR $11;

		---{ Optional }-------------------

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----
			varRecSetOutput											"SchSystem"."HoldFuncSys_General_FeedBackQuery"%rowtype;

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

		---{ Additional }-----------------

BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		IF (varSignEligibleToProcess IS FALSE) THEN
			varSignEligibleToProcess := TRUE;
		END IF;

		IF (varSignEligibleToProcess IS TRUE) THEN
		END IF;

	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			-----[ MAIN DATA PROCESSING ]---------------------------------------------( START )-----
				---> Main Data Set
					INSERT INTO 
						"SchLog"."TblLog_TableSnapshotSignature"
							(
							"Sys_Data_Annotation",
							"Sys_Data_Entry_LoginSession_RefID",
							"Sys_Data_Entry_DateTimeTZ",
							"Sys_Data_Validity_StartDateTimeTZ",
							"Sys_Data_Validity_FinishDateTimeTZ",
							"Sys_Partition_RemovableRecord_Key_RefID",
							"Sys_Branch_RefID",
							"Sys_BaseCurrency_RefID",
							------------------------------
							"SchemaName",
							"TableName",
							"SignatureID"
							)
						VALUES
							(
							varSysDataAnnotation,
							varSysDataEntryLoginSession_RefID,
							varSysDataEntryDateTimeTZ,
							varSysDataValidityStartDateTimeTZ,
							varSysDataValidityFinishDateTimeTZ,
							varSysPartitionRemovableRecordKey_RefID,
							varSysBranch_RefID,
							varSysBaseCurrency_RefID,
							------------------------------
							varSchemaName,
							varTableName,
							varSignatureID
							);

				---> Update "Sys_DataIntegrityShadow"
					PERFORM
						"SchSystem"."FuncSys_General_SetDataIntegrityShadow"(
							'SchLog.TblLog_TableSnapshotSignature'::varchar,
							(CURRVAL ('"SchLog"."TblLog_TableSnapshotSignature_Sys_RPK_seq"'))::bigint
							);

			-----[ MAIN DATA PROCESSING ]---------------------------------------------(  END  )-----
		END IF;

	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			---> Initializing : varRecSetOutput
				varRecSetOutput."SignSuccess" := 1;
				varRecSetOutput."SignRecordType" := 'Sys_RPK';
				varRecSetOutput."SignRecordID" :=
					CURRVAL ('"SchLog"."TblLog_TableSnapshotSignature_Sys_RPK_seq"');
				varRecSetOutput."SignMessage" := null;

			---> Data Return
				RETURN
					NEXT varRecSetOutput;
		END IF;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		--EXCEPTION WHEN OTHERS THEN ...

END;
$_$;


ALTER FUNCTION "SchLog"."Func_TblLog_TableSnapshotSignature_INSERT"(character varying, bigint, timestamp with time zone, timestamp with time zone, timestamp with time zone, bigint, bigint, bigint, character varying, character varying, character varying) OWNER TO "SysAdmin";

--
-- TOC entry 376 (class 1255 OID 6653802)
-- Name: Func_TblLog_TableSnapshotSignature_RENEWAL(character varying); Type: FUNCTION; Schema: SchLog; Owner: SysAdmin
--

CREATE FUNCTION "SchLog"."Func_TblLog_TableSnapshotSignature_RENEWAL"(character varying) RETURNS character varying
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchLog"."Func_TblLog_TableSnapshotSignature_RENEWAL"
▪ Versi               :	1.00.0000
▪ Tanggal
     ► Pemutakhiran   :	2026-06-09
     ► Pembuatan      :	2026-06-09
▪ Input               :	• varFrontEndSchemaTableName (varchar - Mandatory)
						------------------------------
						------------------------------
▪ Output              :	varRecSetOutput ("SchSystem"."HoldFuncSys_General_FeedBackQuery")
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Memutakhirkan data (RENEWAL) pada tabel TblLog_TableSnapshotSignature
▪ Copyright           :	Zheta © 2026

----[ SQL Example(s) ]------------------------------------------------------------------------------

▪ --->
	SELECT
		"SchLog"."Func_TblLog_TableSnapshotSignature_RENEWAL"(
			'SchData-OLTP-Master.TblBank'::varchar
			);

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varFrontEndSchemaTableName								ALIAS FOR $1;
			------------------------------

		---{ Optional }-------------------

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----
			varReturn												varchar;

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

			varSQL													varchar;

			varFrontEndSchema										varchar;
			varSchema												varchar;
			varTable												varchar;

		---{ Additional }-----------------
	
BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		IF (varSignEligibleToProcess IS FALSE) THEN
			varSignEligibleToProcess := TRUE;
		END IF;

		IF (varSignEligibleToProcess IS TRUE) THEN
			---> Initializing : varFrontEndSchema, varSchema, varTable
				varSQL := '
					SELECT
						"Data"[1] AS "FrontEndSchema",
						REPLACE (REPLACE (REPLACE ("Data"[1], ''Data-OLTP-'', ''''), ''Data-OLAP-'', ''''), ''Data-Warehouse-'', '''') AS "SchemaName",
						"Data"[2] AS "TableName"
					FROM
						(
						SELECT
							(''{"' || (REPLACE (varFrontEndSchemaTableName, '.', '", "')) || '"}'')::varchar[] AS "Data"
						) AS "SubSQL"
					';
				--RAISE NOTICE '%', varSQL;

				EXECUTE
					varSQL
				INTO
					varFrontEndSchema,
					varSchema,
					varTable;
				--RAISE NOTICE '%', varFrontEndSchema;
				--RAISE NOTICE '%', varSchema;
				--RAISE NOTICE '%', varTable;
		END IF;

	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			-----[ MAIN DATA PROCESSING ]---------------------------------------------( START )-----
				---> Initializing : varReturn
					varSQL := '
						SELECT
							"SubSQL"."SignatureID"
						FROM
							(
							SELECT
								"SubSQL"."TableName",
								------------------------------
								(
								MD5 (
									MD5 ("TableName"::varchar) || ''<rotarapeSataDZht>'' ||
									MD5 ("RecordCount_Insert"::varchar) || ''<rotarapeSataDZht>'' ||
									MD5 ("RecordCount_Update"::varchar) || ''<rotarapeSataDZht>'' ||
									MD5 ("RecordCount_Delete"::varchar)
									)
								) AS "SignatureID",
								------------------------------
								"SubSQL"."OrderSequence"
							FROM
								(
								SELECT
									"relname" AS "TableName",
									"n_tup_ins" AS "RecordCount_Insert",
									"n_tup_upd" AS "RecordCount_Update",
									"n_tup_del" AS "RecordCount_Delete",
									"last_vacuum" AS "DateTimeTZ_LastVacuum",
									"last_autovacuum" AS "DateTimeTZ_AutoLastVacuum",
									"last_analyze" AS "DateTimeTZ_LastAnalyze",
									"last_autoanalyze" AS "DateTimeTZ_AutoLastAnalyze",
									------------------------------
									ROW_NUMBER () OVER (
										ORDER BY
											"relname" ASC
										) AS "OrderSequence"
								FROM
									"pg_catalog"."pg_stat_all_tables" AS "VirtTblSource"
								WHERE
									"relname" ILIKE ''Tbl%''
									AND
									"relname" = ''' || varTable || '''
								) AS "SubSQL"
							) AS "SubSQL"
						';
					--RAISE NOTICE '%', varSQL;

					varSQL := '
						SELECT
							"SubSQL"."SignatureID"
						FROM
							DBLINK (
								''dbname='''''
									||
									CASE
										WHEN (varFrontEndSchema ILIKE '%Data-OLTP-%') THEN
											'dbERPReborn-Data-OLTP'
										WHEN (varFrontEndSchema ILIKE '%Data-OLAP-%') THEN
											'dbERPReborn-Data-OLAP'
										WHEN (varFrontEndSchema ILIKE '%Data-Warehouse-%') THEN
											'dbERPReborn-Data-Warehouse'
										WHEN (varFrontEndSchema ILIKE '%SysConfig%') THEN
											'dbERPReborn-SysConfig'
										ELSE
											varFrontEndSchema
									END
									||
									''''' host=127.0.0.1 port=5432 user=''''SysEngine'''' password=''''748159263'''''',
								''' || REPLACE (varSQL, '''', '''''') || '''
								) AS "SubSQL" ("SignatureID" varchar)
						';

					EXECUTE
						varSQL
					INTO
						varReturn;
					--RAISE NOTICE '%', varReturn;

				---> Update Snapshot
					varSQL := '
						SELECT
							"JSONData"
						FROM
							"SchLog"."Func_TblLog_TableSnapshotSignature_SET_BULK"(
								''{}''::json,
								''[
									{
									"recordID" : '
										||
										((
										SELECT
											COALESCE (
												"SubSQL"."Sys_ID"::varchar,
												'null'::varchar
												) AS "Sys_ID"
										FROM
											(
											SELECT
												COALESCE (
													"Sys_PID",
													"Sys_SID"
													) AS "Sys_ID"
											FROM
												"SchLog"."TblLog_TableSnapshotSignature"
											WHERE
												"SchemaName" = varFrontEndSchema::varchar
												AND
												"TableName" = varTable::varchar
											) AS "SubSQL"
										))
										|| ',
									"entities" : {
										"sysLoginSession_RefID" : 6000000000001,
										"sysDataAnnotation" : null,
										"sysDataSetDateTimeTZ" : null,
										"sysDataValidityStartDateTimeTZ" : null,
										"sysDataValidityFinishDateTimeTZ" : null,
										"sysPartitionRemovableRecordKey_RefID" : null,
										"sysBranch_RefID" : 11000000000001,
										"sysBaseCurrency_RefID" : null,
					
										"schemaName" : "' || varFrontEndSchema::varchar || '",
										"tableName" : "' || varTable::varchar || '",
										"signatureID" : "' || varReturn::varchar || '"
										}
									}
								]''::json
								) AS "JSONData";
						';
					--RAISE NOTICE '%', varSQL;
					EXECUTE
						varSQL;

			-----[ MAIN DATA PROCESSING ]---------------------------------------------(  END  )-----
		END IF;

	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----
		RETURN
			varReturn;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		--EXCEPTION WHEN OTHERS THEN ...

END;
$_$;


ALTER FUNCTION "SchLog"."Func_TblLog_TableSnapshotSignature_RENEWAL"(character varying) OWNER TO "SysAdmin";

--
-- TOC entry 377 (class 1255 OID 6653805)
-- Name: Func_TblLog_TableSnapshotSignature_SET_BULK(json, json, json); Type: FUNCTION; Schema: SchLog; Owner: SysAdmin
--

CREATE FUNCTION "SchLog"."Func_TblLog_TableSnapshotSignature_SET_BULK"(json, json DEFAULT NULL::json, json DEFAULT NULL::json) RETURNS json
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchLog"."Func_TblLog_TableSnapshotSignature_SET_BULK"
▪ Versi               :	1.00.0000
▪ Tanggal
     ► Pemutakhiran   :	2026-06-09
     ► Pembuatan      :	2026-06-09
▪ Input               :	• varEnvironmentParameter (json)
						------------------------------
						• varJSONData (json)
						• varJSONDataDeletion (json)
▪ Output              :	varReturn (json)
▪ Keterkaitan Fungsi  :	• "SchSystem"."FuncSys_General_SetBulkData"(json, json, json)
▪ Deskripsi           :	• Mengeset Data Bulk (INSERT dan UPDATE) pada tabel TblLog_TableSnapshotSignature
▪ Copyright           :	Zheta © 2026

----[ SQL Example(s) ]------------------------------------------------------------------------------

▪ ---> ( DATA INSERTION )
	SELECT
		"JSONData"
	FROM
		"SchLog"."Func_TblLog_TableSnapshotSignature_SET_BULK"(
			'{}'::json,
			'[
				{
				"recordID" : null,
				"entities" : {
					"sysLoginSession_RefID" : 6000000000001,
					"sysDataAnnotation" : null,
					"sysDataSetDateTimeTZ" : null,
					"sysDataValidityStartDateTimeTZ" : null,
					"sysDataValidityFinishDateTimeTZ" : null,
					"sysPartitionRemovableRecordKey_RefID" : null,
					"sysBranch_RefID" : 11000000000001,
					"sysBaseCurrency_RefID" : null,

					"schemaName" : "SchSysConfig",
					"tableName" : "TblAppObject_InstitutionBranch",
					"signatureID" : "c5fbeb1a978298f041b719f99c52a459"
					}
				}, 
				{
				"recordID" : null,
				"entities" : {
					"sysLoginSession_RefID" : 6000000000001,
					"sysDataAnnotation" : null,
					"sysDataSetDateTimeTZ" : null,
					"sysDataValidityStartDateTimeTZ" : null,
					"sysDataValidityFinishDateTimeTZ" : null,
					"sysPartitionRemovableRecordKey_RefID" : null,
					"sysBranch_RefID" : 11000000000001,
					"sysBaseCurrency_RefID" : null,

					"schemaName" : "SchSysConfig",
					"tableName" : "TblAppObject_InstitutionCompany",
					"signatureID" : "26c979b97ae396509b793317c03d2ef5"
					}
				}
			]'::json
			) AS "JSONData";

▪ ---> ( DATA UPDATE )
	SELECT
		"JSONData"
	FROM
		"SchLog"."Func_TblLog_TableSnapshotSignature_SET_BULK"(
			'{}'::json,
			'[
				{
				"recordID" : 235000000000002,
				"entities" : {
					"sysLoginSession_RefID" : 6000000000001,
					"sysDataAnnotation" : null,
					"sysDataSetDateTimeTZ" : null,
					"sysDataValidityStartDateTimeTZ" : null,
					"sysDataValidityFinishDateTimeTZ" : null,
					"sysPartitionRemovableRecordKey_RefID" : null,
					"sysBranch_RefID" : 11000000000001,
					"sysBaseCurrency_RefID" : null,

					"schemaName" : "SchSysConfig",
					"tableName" : "TblAppObject_InstitutionBranch",
					"signatureID" : "c5fbeb1a978298f041b719f99c52a459"
					}
				}, 
				{
				"recordID" : 235000000000003,
				"entities" : {
					"sysLoginSession_RefID" : 6000000000001,
					"sysDataAnnotation" : null,
					"sysDataSetDateTimeTZ" : null,
					"sysDataValidityStartDateTimeTZ" : null,
					"sysDataValidityFinishDateTimeTZ" : null,
					"sysPartitionRemovableRecordKey_RefID" : null,
					"sysBranch_RefID" : 11000000000001,
					"sysBaseCurrency_RefID" : null,

					"schemaName" : "SchSysConfig",
					"tableName" : "TblAppObject_InstitutionCompany",
					"signatureID" : "26c979b97ae396509b793317c03d2ef5"
					}
				}
			]'::json
			) AS "JSONData";

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varEnvironmentParameter									ALIAS FOR $1;
			------------------------------
			varJSONData												ALIAS FOR $2;
			varJSONDataDeletion										ALIAS FOR $3;

		---{ Optional }-------------------

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----
			varReturn												json;

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

			varSQL													varchar;

			varFrontEndSchemaTableName								varchar;
			varJSONFunctionName										json;
			varJSONFunctionParameterParsing							json;

			varArraySysRPK											bigint[];

		---{ Additional }-----------------

BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		IF (varSignEligibleToProcess IS FALSE) THEN
			varSignEligibleToProcess := TRUE;
		END IF;

		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------( START )-----
			IF (varSignEligibleToProcess IS TRUE) THEN
			END IF;
		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------(  END  )-----

		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------( START )-----
			IF (varSignEligibleToProcess IS TRUE) THEN
				-----[ INPUT VARIABLES REINITIALIZATION ]-------------------------------------( START )-----
					---> Reinitializing : varJSONData
						varJSONData :=
							COALESCE (
								varJSONData,
								'{}'::json
								);

					---> Reinitializing : varJSONDataDeletion
						varJSONDataDeletion :=
							COALESCE (
								varJSONDataDeletion,
								'{}'::json
								);
				-----[ INPUT VARIABLES REINITIALIZATION ]-------------------------------------(  END  )-----

				-----[ INTERMEDIATE VARIABLES INITIALIZATION ]--------------------------------( START )-----
					---> Initializing : varFrontEndSchemaTableName
						varFrontEndSchemaTableName :=
							'SchData-Warehouse-Log.TblLog_TableSnapshotSignature';

					---> Initializing : varJSONFunctionName
						varJSONFunctionName :=
							JSON_BUILD_OBJECT (
								'insertFunction', 'SchLog.Func_TblLog_TableSnapshotSignature_INSERT',
								'updateFunction', 'SchLog.Func_TblLog_TableSnapshotSignature_UPDATE'
								);
							--RAISE NOTICE '%', varJSONFunctionName;

					---> Initializing : varJSONFunctionParameterParsing
						varJSONFunctionParameterParsing :=
							JSON_BUILD_ARRAY (
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''sysDataAnnotation''',
									'dataType', 'varchar'
									),
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''sysLoginSession_RefID''',
									'dataType', 'bigint'
									),
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''sysDataSetDateTimeTZ''',
									'dataType', 'timestamptz'
									),
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''sysDataValidityStartDateTimeTZ''',
									'dataType', 'timestamptz'
									),
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''sysDataValidityFinishDateTimeTZ''',
									'dataType', 'timestamptz'
									),
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''sysPartitionRemovableRecordKey_RefID''',
									'dataType', 'bigint'
									),
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''sysBranch_RefID''',
									'dataType', 'bigint'
									),
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''sysBaseCurrency_RefID''',
									'dataType', 'bigint'
									),
								------------------------------
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''schemaName''',
									'dataType', 'varchar'
									),
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''tableName''',
									'dataType', 'varchar'
									),
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''signatureID''',
									'dataType', 'varchar'
									)
								);
						--RAISE NOTICE '%', varJSONFunctionParameterParsing;
				-----[ INTERMEDIATE VARIABLES INITIALIZATION ]--------------------------------(  END  )-----
			END IF;
		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------(  END  )-----

	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			-----[ PRELIMINARY ADDITIONAL DATA PROCESSING ]---------------------------( START )-----
			-----[ PRELIMINARY ADDITIONAL DATA PROCESSING ]---------------------------(  END  )-----

			-----[ MAIN DATA PROCESSING ]---------------------------------------------( START )-----
					varReturn := (
						SELECT
							"SchSystem"."FuncSys_General_SetBulkData"(
								NULL::json,
								JSON_BUILD_OBJECT (
									'metadata.control',
										JSON_BUILD_OBJECT (
											'frontEndSchemaTableName',varFrontEndSchemaTableName,
											'functionName', varJSONFunctionName,
											'functionParameterParsing', varJSONFunctionParameterParsing
											),
									'data', varJSONData
									),
								varJSONDataDeletion::json
								)
						);
					--RAISE NOTICE '%', varSQL;

			-----[ MAIN DATA PROCESSING ]---------------------------------------------(  END  )-----

			-----[ AFTERWARDS ADDITIONAL DATA PROCESSING ]----------------------------( START )-----
			-----[ AFTERWARDS ADDITIONAL DATA PROCESSING ]----------------------------(  END  )-----
		END IF;

	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----
		RETURN
			varReturn;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		EXCEPTION
			WHEN OTHERS THEN
				NULL;

END;
$_$;


ALTER FUNCTION "SchLog"."Func_TblLog_TableSnapshotSignature_SET_BULK"(json, json, json) OWNER TO "SysAdmin";

--
-- TOC entry 393 (class 1255 OID 6653808)
-- Name: Func_TblLog_TableSnapshotSignature_UPDATE(bigint, bigint, timestamp with time zone, timestamp with time zone, timestamp with time zone, bigint, bigint, bigint, character varying, character varying, character varying); Type: FUNCTION; Schema: SchLog; Owner: SysAdmin
--

CREATE FUNCTION "SchLog"."Func_TblLog_TableSnapshotSignature_UPDATE"(bigint, bigint, timestamp with time zone, timestamp with time zone, timestamp with time zone, bigint, bigint, bigint, character varying, character varying, character varying) RETURNS SETOF "SchSystem"."HoldFuncSys_General_FeedBackQuery"
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchLog"."Func_TblLog_TableSnapshotSignature_UPDATE"
▪ Versi               :	1.01.0000
▪ Tanggal
     ► Pemutakhiran   :	2026-06-09
     ► Pembuatan      :	2023-03-24
▪ Input               :	• varID (bigint - Mandatory)
						• varSysDataEditLoginSession_RefID (bigint - Mandatory)
						• varSysDataEditDateTimeTZ (timestamptz - Mandatory)
						• varSysDataValidityStartDateTimeTZ (timestamptz - Mandatory)
						• varSysDataValidityFinishDateTimeTZ (timestamptz - Mandatory)
						• varSysPartitionRemovableRecordKey_RefID (bigint - Mandatory)
						• varSysBranch_RefID (bigint - Mandatory)
						• varSysBaseCurrency_RefID (bigint - Mandatory)
						------------------------------
						• varSchemaName (varchar - Mandatory)
						• varTableName (varchar - Mandatory)
						• varSignatureID (varchar - Mandatory)
						------------------------------
▪ Output              :	varRecSetOutput ("SchSystem"."HoldFuncSys_General_FeedBackQuery")
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Memutakhirkan data (UPDATE) pada tabel TblLog_TableSnapshotSignature
▪ Copyright           :	Zheta © 2023 - 2026

----[ SQL Example(s) ]------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varID													ALIAS FOR $1;
			varSysDataEditLoginSession_RefID						ALIAS FOR $2;
			varSysDataEditDateTimeTZ								ALIAS FOR $3;
			varSysDataValidityStartDateTimeTZ						ALIAS FOR $4;
			varSysDataValidityFinishDateTimeTZ						ALIAS FOR $5;
			varSysPartitionRemovableRecordKey_RefID					ALIAS FOR $6;
			varSysBranch_RefID										ALIAS FOR $7;
			varSysBaseCurrency_RefID								ALIAS FOR $8;
			------------------------------
			varSchemaName											ALIAS FOR $9;
			varTableName											ALIAS FOR $10;
			varSignatureID											ALIAS FOR $11;

		---{ Optional }-------------------

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----
			varRecSetOutput											"SchSystem"."HoldFuncSys_General_FeedBackQuery"%rowtype;

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

		---{ Additional }-----------------

BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		IF (varSignEligibleToProcess IS FALSE) THEN
			varSignEligibleToProcess := TRUE;
		END IF;

		IF (varSignEligibleToProcess IS TRUE) THEN
		END IF;

	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			-----[ MAIN DATA PROCESSING ]---------------------------------------------( START )-----
				---> Main Data Set
					UPDATE
						"SchLog"."TblLog_TableSnapshotSignature"
					SET
						"Sys_Data_Edit_LoginSession_RefID" = varSysDataEditLoginSession_RefID,
						"Sys_Data_Edit_DateTimeTZ" = varSysDataEditDateTimeTZ,
						"Sys_Data_Validity_StartDateTimeTZ" = varSysDataValidityStartDateTimeTZ,
						"Sys_Data_Validity_FinishDateTimeTZ" = varSysDataValidityFinishDateTimeTZ,
						"Sys_Partition_RemovableRecord_Key_RefID" = varSysPartitionRemovableRecordKey_RefID,
						"Sys_Branch_RefID" = varSysBranch_RefID,
						"Sys_BaseCurrency_RefID" = varSysBaseCurrency_RefID,
						------------------------------
						"SchemaName" = varSchemaName,
						"TableName" = varTableName,
						"SignatureID" = varSignatureID
					WHERE
						"Sys_PID" = varID
						OR
						"Sys_SID" = varID;

				---> Update "Sys_DataIntegrityShadow"
					PERFORM
						"SchSystem"."FuncSys_General_SetDataIntegrityShadow"(
							'SchLog.TblLog_TableSnapshotSignature'::varchar,
							varID::bigint
							);

		END IF;

	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----	
		IF (varSignEligibleToProcess IS TRUE) THEN
			---> Initializing : varRecSetOutput
				varRecSetOutput."SignSuccess" := 1;
				varRecSetOutput."SignRecordType" := 'Sys_RPK';
				varRecSetOutput."SignRecordID" := (
					SELECT
						"Sys_RPK"
					FROM
						"SchLog"."TblLog_TableSnapshotSignature"
					WHERE
						"Sys_PID" = varID
						OR
						"Sys_SID" = varID
					ORDER BY
						"Sys_RPK" ASC
					LIMIT 1
					);
				varRecSetOutput."SignMessage" := null;

			---> Data Return
				RETURN
					NEXT varRecSetOutput;
		END IF;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		--EXCEPTION WHEN OTHERS THEN ...

END;
$_$;


ALTER FUNCTION "SchLog"."Func_TblLog_TableSnapshotSignature_UPDATE"(bigint, bigint, timestamp with time zone, timestamp with time zone, timestamp with time zone, bigint, bigint, bigint, character varying, character varying, character varying) OWNER TO "SysAdmin";

--
-- TOC entry 394 (class 1255 OID 6653809)
-- Name: Func_TblLog_TransactionHistory_INSERT(character varying, bigint, timestamp with time zone, bigint, bigint, bigint, bigint, bigint, bigint, timestamp with time zone, json, bigint, character varying); Type: FUNCTION; Schema: SchLog; Owner: SysEngine
--

CREATE FUNCTION "SchLog"."Func_TblLog_TransactionHistory_INSERT"(character varying, bigint, timestamp with time zone, bigint, bigint, bigint, bigint, bigint, bigint, timestamp with time zone, json, bigint, character varying) RETURNS SETOF "SchSystem"."HoldFuncSys_General_FeedBackQuery"
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchLog"."Func_TblLog_TransactionHistory_INSERT"
▪ Versi               :	1.00.0001
▪ Tanggal
     ► Pemutakhiran   :	2024-10-04
     ► Pembuatan      :	2023-12-01
▪ Input               :	• varSysDataAnnotation (varchar - Mandatory)
						• varIDSession (bigint - Mandatory)
						• varEntryDateTimeTZ (timestamptz - Mandatory)
						• varSysPartitionRemovableRecordKeyRefID (bigint - Mandatory)
						• varBranch_RefID (bigint - Mandatory)
						• varBaseCurrency_RefID (bigint - Mandatory)
						------------------------------
						• varSource_RefPID (bigint - Mandatory)
						• varSource_RefSID (bigint - Mandatory)
						• varSource_RefRPK (bigint - Mandatory)
						• varSource_EntryDateTimeTZ (timestamptz - Mandatory)
						• varContent (json - Mandatory)
						• varSource_RefHeaderID (bigint - Mandatory)
						• varType (varchar - Mandatory)
						------------------------------
▪ Output              :	varRecSetOutput ("SchSystem"."HoldFuncSys_General_FeedBackQuery")
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Memasukan data (INSERT) pada tabel TblLog_TransactionHistory
▪ Copyright           :	Zheta © 2023 - 2024

----[ SQL Example(s) ]------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------*/

DECLARE
	---[ Input Variable(s) ]------------------------------------------------------------------------
		---{ Mandatory }------------------
			varSysDataAnnotation									ALIAS FOR $1;
			varIDSession											ALIAS FOR $2;
			varEntryDateTimeTZ										ALIAS FOR $3;
			varSysPartitionRemovableRecordKeyRefID					ALIAS FOR $4;
			varBranch_RefID											ALIAS FOR $5;
			varBaseCurrency_RefID									ALIAS FOR $6;
			------------------------------
			varSource_RefPID										ALIAS FOR $7;
			varSource_RefSID										ALIAS FOR $8;
			varSource_RefRPK										ALIAS FOR $9;
			varSource_EntryDateTimeTZ								ALIAS FOR $10;
			varContent												ALIAS FOR $11;
			varSource_RefHeaderID									ALIAS FOR $12;
			varType													ALIAS FOR $13;

		---{ Optional }-------------------

		---{ Additional }-----------------

	---[ Output Variable(s) ]-----------------------------------------------------------------------
			varRecSetOutput											"SchSystem"."HoldFuncSys_General_FeedBackQuery"%rowtype;

	---[ Intermediate Variable(s) ]-----------------------------------------------------------------
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

		---{ Additional }-----------------

BEGIN
	---[ Data Initializing ]------------------------------------------------------------------------
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		IF (varSignEligibleToProcess IS FALSE) THEN
			varSignEligibleToProcess := TRUE;
		END IF;

		IF (varSignEligibleToProcess IS TRUE) THEN
		END IF;

	---[ Data Processing ]--------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			INSERT INTO 
				"SchLog"."TblLog_TransactionHistory"
					(
					"Sys_Data_Annotation",
					"Sys_Data_Entry_LoginSession_RefID",
					"Sys_Data_Entry_DateTimeTZ",
					"Sys_Partition_RemovableRecord_Key_RefID",
					"Sys_Branch_RefID",
					"Sys_BaseCurrency_RefID",
					------------------------------
					"Source_RefPID",
					"Source_RefSID",
					"Source_RefRPK",
					"Source_EntryDateTimeTZ",
					"Content",
					"Source_RefHeaderID",
					"Type"
					)
				VALUES
					(
					varSysDataAnnotation,
					varIDSession,
					varEntryDateTimeTZ,
					varSysPartitionRemovableRecordKeyRefID,
					varBranch_RefID,
					varBaseCurrency_RefID,
					------------------------------
					varSource_RefPID,
					varSource_RefSID,
					varSource_RefRPK,
					varSource_EntryDateTimeTZ,
					varContent,
					varSource_RefHeaderID,
					varType
					);
		END IF;

	---[ Data Return ]-----------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			varRecSetOutput."SignSuccess" := 1;
			varRecSetOutput."SignRecordType" := 'Sys_RPK';
			varRecSetOutput."SignRecordID" := CURRVAL('"SchLog"."TblLog_TransactionHistory_Sys_RPK_seq"');
			varRecSetOutput."SignMessage" := null;

			RETURN NEXT varRecSetOutput;
		END IF;

	---[ Exception Handling ]-----------------------------------------------------------------------
		--EXCEPTION WHEN OTHERS THEN ...

END;
$_$;


ALTER FUNCTION "SchLog"."Func_TblLog_TransactionHistory_INSERT"(character varying, bigint, timestamp with time zone, bigint, bigint, bigint, bigint, bigint, bigint, timestamp with time zone, json, bigint, character varying) OWNER TO "SysEngine";

--
-- TOC entry 395 (class 1255 OID 6653810)
-- Name: Func_TblLog_TransactionHistory_UPDATE(bigint, bigint, timestamp with time zone, bigint, bigint, bigint, bigint, bigint, bigint, timestamp with time zone, json, bigint, character varying); Type: FUNCTION; Schema: SchLog; Owner: SysEngine
--

CREATE FUNCTION "SchLog"."Func_TblLog_TransactionHistory_UPDATE"(bigint, bigint, timestamp with time zone, bigint, bigint, bigint, bigint, bigint, bigint, timestamp with time zone, json, bigint, character varying) RETURNS SETOF "SchSystem"."HoldFuncSys_General_FeedBackQuery"
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchLog"."Func_TblLog_TransactionHistory_UPDATE"
▪ Versi               :	1.00.0001
▪ Tanggal
     ► Pemutakhiran   :	2024-10-04
     ► Pembuatan      :	2023-12-01
▪ Input               :	• varID (bigint - Mandatory)
						• varIDSession (bigint - Mandatory)
						• varEditDateTimeTZ (timestamptz - Mandatory)
						• varSysPartitionRemovableRecordKeyRefID (bigint - Mandatory)
						• varBranch_RefID (bigint - Mandatory)
						• varBaseCurrency_RefID (bigint - Mandatory)
						------------------------------
						• varSource_RefPID (bigint - Mandatory)
						• varSource_RefSID (bigint - Mandatory)
						• varSource_RefRPK (bigint - Mandatory)
						• varSource_EntryDateTimeTZ (timestamptz - Mandatory)
						• varContent (json - Mandatory)
						• varSource_RefHeaderID (bigint - Mandatory)
						• varType (varchar - Mandatory)
						------------------------------
▪ Output              :	varRecSetOutput ("SchSystem"."HoldFuncSys_General_FeedBackQuery")
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Memutakhirkan data (UPDATE) pada tabel TblLog_TransactionHistory
▪ Copyright           :	Zheta © 2023 - 2024

----[ SQL Example(s) ]------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------*/

DECLARE
	---[ Input Variable(s) ]------------------------------------------------------------------------
		---{ Mandatory }------------------
			varSysDataAnnotation									ALIAS FOR $1;
			varIDSession											ALIAS FOR $2;
			varEntryDateTimeTZ										ALIAS FOR $3;
			varSysPartitionRemovableRecordKeyRefID					ALIAS FOR $4;
			varBranch_RefID											ALIAS FOR $5;
			varBaseCurrency_RefID									ALIAS FOR $6;
			------------------------------
			varSource_RefPID										ALIAS FOR $7;
			varSource_RefSID										ALIAS FOR $8;
			varSource_RefRPK										ALIAS FOR $9;
			varSource_EntryDateTimeTZ								ALIAS FOR $10;
			varContent												ALIAS FOR $11;
			varSource_RefHeaderID									ALIAS FOR $12;
			varType													ALIAS FOR $13;

		---{ Optional }-------------------

		---{ Additional }-----------------

	---[ Output Variable(s) ]-----------------------------------------------------------------------
			varRecSetOutput											"SchSystem"."HoldFuncSys_General_FeedBackQuery"%rowtype;

	---[ Intermediate Variable(s) ]-----------------------------------------------------------------
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

		---{ Additional }-----------------

BEGIN
	---[ Data Initializing ]------------------------------------------------------------------------
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		IF (varSignEligibleToProcess IS FALSE) THEN
			varSignEligibleToProcess := TRUE;
		END IF;

		IF (varSignEligibleToProcess IS TRUE) THEN
		END IF;

	---[ Data Processing ]--------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			UPDATE
				"SchLog"."TblLog_TransactionHistory"
			SET
				"Sys_Data_Edit_LoginSession_RefID" = varIDSession,
				"Sys_Data_Edit_DateTimeTZ" = varEditDateTimeTZ,
				"Sys_Partition_RemovableRecord_Key_RefID" = varSysPartitionRemovableRecordKeyRefID,
				"Sys_Branch_RefID" = varBranch_RefID,
				"Sys_BaseCurrency_RefID" = varBaseCurrency_RefID,
				------------------------------
				"Source_RefPID" = varSource_RefPID,
				"Source_RefSID" = varSource_RefSID,
				"Source_RefRPK" = varSource_RefRPK,
				"Source_EntryDateTimeTZ" = varSource_EntryDateTimeTZ,
				"Content" = varContent,
				"Source_RefHeaderID" = varSource_RefHeaderID,
				"Type" = varType
			WHERE
				"Sys_PID" = varID
				OR
				"Sys_SID" = varID;
		END IF;

	---[ Data Return ]-----------------------------------------------------------------------------
		IF (varSignEligibleToProcess IS TRUE) THEN
			varRecSetOutput."SignSuccess" := 1;
			varRecSetOutput."SignRecordType" := 'Sys_RPK';
			varRecSetOutput."SignRecordID" := (SELECT "Sys_RPK" FROM "SchLog"."TblLog_TransactionHistory" WHERE "Sys_PID" = varID OR "Sys_SID" = varID LIMIT 1);
			varRecSetOutput."SignMessage" := null;

			RETURN NEXT varRecSetOutput;
		END IF;

	---[ Exception Handling ]-----------------------------------------------------------------------
		--EXCEPTION WHEN OTHERS THEN ...

END;
$_$;


ALTER FUNCTION "SchLog"."Func_TblLog_TransactionHistory_UPDATE"(bigint, bigint, timestamp with time zone, bigint, bigint, bigint, bigint, bigint, bigint, timestamp with time zone, json, bigint, character varying) OWNER TO "SysEngine";

--
-- TOC entry 396 (class 1255 OID 6653811)
-- Name: Func_TblStructure_DBObject_INSERT(character varying, bigint, timestamp with time zone, timestamp with time zone, timestamp with time zone, bigint, bigint, bigint, bigint, character varying, character varying, character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: SchRecovery; Owner: SysAdmin
--

CREATE FUNCTION "SchRecovery"."Func_TblStructure_DBObject_INSERT"(character varying, bigint, timestamp with time zone, timestamp with time zone, timestamp with time zone, bigint, bigint, bigint, bigint, character varying, character varying, character varying, character varying, character varying, character varying) RETURNS SETOF "SchSystem"."HoldFuncSys_General_FeedBackQuery"
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchRecovery"."Func_TblStructure_DBObject_INSERT"
▪ Versi               :	1.00.0000
▪ Tanggal
     ► Pemutakhiran   :	2026-10-13
     ► Pembuatan      :	2026-10-13
▪ Input               :	• varSysDataAnnotation (varchar - Mandatory)
						• varSysDataEntryLoginSession_RefID (bigint - Mandatory)
						• varSysDataEntryDateTimeTZ (timestamptz - Mandatory)
						• varSysDataValidityStartDateTimeTZ (timestamptz - Mandatory)
						• varSysDataValidityFinishDateTimeTZ (timestamptz - Mandatory)
						• varSysPartitionRemovableRecordKey_RefID (bigint - Mandatory)
						• varSysBranch_RefID (bigint - Mandatory)
						• varSysBaseCurrency_RefID (bigint - Mandatory)
						------------------------------
						• varObjectID (bigint - Mandatory)
						• varType (varchar - Mandatory)
						• varDatabaseName (varchar - Mandatory)
						• varSchemaName (varchar - Mandatory)
						• varObjectName (varchar - Mandatory)
						• varConstructionSQL (varchar - Mandatory)
						• varDeconstructionSQL (varchar - Mandatory)
						------------------------------
▪ Output              :	varRecSetOutput ("SchSystem"."HoldFuncSys_General_FeedBackQuery")
▪ Deskripsi           :	• Memasukan data (INSERT) pada tabel TblStructure_DBObject
▪ Copyright           :	Zheta © 2026

----[ Related Database Object(s) ]------------------------------------------------------------------

▪ Tabel               :	• [BE] "SchRecovery"."TblStructure_DBObject"

▪ Fungsi              :	• [BE] "SchSystem"."FuncSys_General_SetDataIntegrityShadow"(varchar, bigint)

----[ SQL Example(s) ]------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varSysDataAnnotation									ALIAS FOR $1;
			varSysDataEntryLoginSession_RefID						ALIAS FOR $2;
			varSysDataEntryDateTimeTZ								ALIAS FOR $3;
			varSysDataValidityStartDateTimeTZ						ALIAS FOR $4;
			varSysDataValidityFinishDateTimeTZ						ALIAS FOR $5;
			varSysPartitionRemovableRecordKey_RefID					ALIAS FOR $6;
			varSysBranch_RefID										ALIAS FOR $7;
			varSysBaseCurrency_RefID								ALIAS FOR $8;
			------------------------------
			varObjectID												ALIAS FOR $9;
			varType													ALIAS FOR $10;
			varDatabaseName											ALIAS FOR $11;
			varSchemaName											ALIAS FOR $12;
			varObjectName											ALIAS FOR $13;
			varConstructionSQL										ALIAS FOR $14;
			varDeconstructionSQL									ALIAS FOR $15;

		---{ Optional }-------------------

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----
			varRecSetOutput											"SchSystem"."HoldFuncSys_General_FeedBackQuery"%rowtype;

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

		---{ Additional }-----------------

BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		IF (varSignEligibleToProcess IS FALSE) THEN
			varSignEligibleToProcess := TRUE;
		END IF;

		IF (varSignEligibleToProcess IS TRUE) THEN
		END IF;

	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			-----[ MAIN DATA PROCESSING ]---------------------------------------------( START )-----
				---> Main Data Set
					INSERT INTO 
						"SchRecovery"."TblStructure_DBObject"
							(
							"Sys_Data_Annotation",
							"Sys_Data_Entry_LoginSession_RefID",
							"Sys_Data_Entry_DateTimeTZ",
							"Sys_Data_Validity_StartDateTimeTZ",
							"Sys_Data_Validity_FinishDateTimeTZ",
							"Sys_Partition_RemovableRecord_Key_RefID",
							"Sys_Branch_RefID",
							"Sys_BaseCurrency_RefID",
							------------------------------
							"ObjectID",
							"Type",
							"DatabaseName",
							"SchemaName",
							"ObjectName",
							"ConstructionSQL",
							"DeconstructionSQL"
							)
						VALUES
							(
							varSysDataAnnotation,
							varSysDataEntryLoginSession_RefID,
							varSysDataEntryDateTimeTZ,
							varSysDataValidityStartDateTimeTZ,
							varSysDataValidityFinishDateTimeTZ,
							varSysPartitionRemovableRecordKey_RefID,
							varSysBranch_RefID,
							varSysBaseCurrency_RefID,
							------------------------------
							varObjectID,
							varType,
							varDatabaseName,
							varSchemaName,
							varObjectName,
							varConstructionSQL,
							varDeconstructionSQL
							);

				---> Update "Sys_DataIntegrityShadow"
					PERFORM
						"SchSystem"."FuncSys_General_SetDataIntegrityShadow"(
							'SchRecovery.TblStructure_DBObject'::varchar,
							(CURRVAL ('"SchRecovery"."TblStructure_DBObject_Sys_RPK_seq"'))::bigint
							);

			-----[ MAIN DATA PROCESSING ]---------------------------------------------(  END  )-----
		END IF;

	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			---> Initializing : varRecSetOutput
				varRecSetOutput."SignSuccess" := 1;
				varRecSetOutput."SignRecordType" := 'Sys_RPK';
				varRecSetOutput."SignRecordID" :=
					CURRVAL ('"SchRecovery"."TblStructure_DBObject_Sys_RPK_seq"');
				varRecSetOutput."SignMessage" := null;

			---> Data Return
				RETURN
					NEXT varRecSetOutput;
		END IF;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		--EXCEPTION WHEN OTHERS THEN ...

END;
$_$;


ALTER FUNCTION "SchRecovery"."Func_TblStructure_DBObject_INSERT"(character varying, bigint, timestamp with time zone, timestamp with time zone, timestamp with time zone, bigint, bigint, bigint, bigint, character varying, character varying, character varying, character varying, character varying, character varying) OWNER TO "SysAdmin";

--
-- TOC entry 397 (class 1255 OID 6653812)
-- Name: Func_TblStructure_DBObject_SET_BULK(json, json, json); Type: FUNCTION; Schema: SchRecovery; Owner: SysAdmin
--

CREATE FUNCTION "SchRecovery"."Func_TblStructure_DBObject_SET_BULK"(json, json DEFAULT NULL::json, json DEFAULT NULL::json) RETURNS json
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchRecovery"."Func_TblStructure_DBObject_SET_BULK"
▪ Versi               :	1.00.0000
▪ Tanggal
     ► Pemutakhiran   :	2026-10-13
     ► Pembuatan      :	2026-10-13
▪ Input               :	• varEnvironmentParameter (json - Mandatory)
						------------------------------
						• varJSONData (json - Optional)
						• varJSONDataDeletion (json - Optional)
						------------------------------
▪ Output              :	varReturn (json)
▪ Deskripsi           :	• Mengeset Data Bulk (INSERT dan UPDATE) pada tabel TblStructure_DBObject
▪ Copyright           :	Zheta © 2026

----[ Related Database Object(s) ]------------------------------------------------------------------

▪ Tabel               :	-

▪ Fungsi              :	• [BE] "SchSystem"."FuncSys_General_GetEnvironmentParameter"(varchar)
						• [BE] "SchSystem"."FuncSys_General_SetBulkData"(json, json, json)
						------------------------------
						• [BE] "SchLog"."Func_TblLog_TableSnapshotSignature_RENEWAL"(varchar)

----[ SQL Example(s) ]------------------------------------------------------------------------------

▪ ---> ( DATA INSERTION WITHOUT ADDITIONAL DATA )
	SELECT
		"JSONData"
	FROM
		"SchRecovery"."Func_TblStructure_DBObject_SET_BULK"(
			'{}'::json,
			'[
				{
				"recordID" : null,
				"entitiesMetaData" : null,
				"entities" : {
					"sysLoginSession_RefID" : 6000000000001,
					"sysDataAnnotation" : null,
					"sysDataSetDateTimeTZ" : null,
					"sysDataValidityStartDateTimeTZ" : null,
					"sysDataValidityFinishDateTimeTZ" : null,
					"sysPartitionRemovableRecordKey_RefID" : null,
					"sysBranch_RefID" : 11000000000001,
					"sysBaseCurrency_RefID" : null,

					"objectID" : ...,
					"type" : "...",
					"databaseName" : "...",
					"schemaName" : "...",
					"objectName" : "...",
					"constructionSQL" : "...",
					"deconstructionSQL" : "..."
					}
				}, 
				{
				"recordID" : null,
				"entitiesMetaData" : null,
				"entities" : {
					"sysLoginSession_RefID" : 6000000000001,
					"sysDataAnnotation" : null,
					"sysDataSetDateTimeTZ" : null,
					"sysDataValidityStartDateTimeTZ" : null,
					"sysDataValidityFinishDateTimeTZ" : null,
					"sysPartitionRemovableRecordKey_RefID" : null,
					"sysBranch_RefID" : 11000000000001,
					"sysBaseCurrency_RefID" : null,

					"objectID" : ...,
					"type" : "...",
					"databaseName" : "...",
					"schemaName" : "...",
					"objectName" : "...",
					"constructionSQL" : "...",
					"deconstructionSQL" : "..."
					}
				}
			]'::json
			) AS "JSONData";

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varEnvironmentParameter									ALIAS FOR $1;
			------------------------------
			varJSONData												ALIAS FOR $2;
			varJSONDataDeletion										ALIAS FOR $3;

		---{ Optional }-------------------

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----
			varReturn												json;

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

			varSQL													varchar;

			varFrontEndSchemaTableName								varchar;
			varJSONFunctionName										json;
			varJSONFunctionParameterParsing							json;

			varArraySysRPK											bigint[];

		---{ Additional }-----------------

BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		IF (varSignEligibleToProcess IS FALSE) THEN
			varSignEligibleToProcess := TRUE;
		END IF;

		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------( START )-----
			IF (varSignEligibleToProcess IS TRUE) THEN
			END IF;
		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------(  END  )-----

		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------( START )-----
			IF (varSignEligibleToProcess IS TRUE) THEN
				-----[ INPUT VARIABLES REINITIALIZATION ]-------------------------------------( START )-----
					---> Reinitializing : varJSONData
						varJSONData :=
							COALESCE (
								varJSONData,
								'{}'::json
								);

					---> Reinitializing : varJSONDataDeletion
						varJSONDataDeletion :=
							COALESCE (
								varJSONDataDeletion,
								'{}'::json
								);
				-----[ INPUT VARIABLES REINITIALIZATION ]-------------------------------------(  END  )-----

				-----[ INTERMEDIATE VARIABLES INITIALIZATION ]--------------------------------( START )-----
					---> Initializing : varFrontEndSchemaTableName
						varFrontEndSchemaTableName :=
							'SchData-Warehouse-Recovery.TblStructure_DBObject';

					---> Initializing : varJSONFunctionName
						varJSONFunctionName :=
							JSON_BUILD_OBJECT (
								'insertFunction', 'SchRecovery.Func_TblStructure_DBObject_INSERT',
								'updateFunction', 'SchRecovery.Func_TblStructure_DBObject_UPDATE'
								);
							--RAISE NOTICE '%', varJSONFunctionName;

					---> Initializing : varJSONFunctionParameterParsing
						varJSONFunctionParameterParsing :=
							JSON_BUILD_ARRAY (
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''sysDataAnnotation''',
									'dataType', 'varchar'
									),
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''sysLoginSession_RefID''',
									'dataType', 'bigint'
									),
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''sysDataSetDateTimeTZ''',
									'dataType', 'timestamptz'
									),
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''sysDataValidityStartDateTimeTZ''',
									'dataType', 'timestamptz'
									),
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''sysDataValidityFinishDateTimeTZ''',
									'dataType', 'timestamptz'
									),
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''sysPartitionRemovableRecordKey_RefID''',
									'dataType', 'bigint'
									),
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''sysBranch_RefID''',
									'dataType', 'bigint'
									),
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''sysBaseCurrency_RefID''',
									'dataType', 'bigint'
									),
								------------------------------
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''objectID''',
									'dataType', 'bigint'
									),
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''type''',
									'dataType', 'varchar'
									),
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''databaseName''',
									'dataType', 'varchar'
									),
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''schemaName''',
									'dataType', 'varchar'
									),
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''objectName''',
									'dataType', 'varchar'
									),
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''constructionSQL''',
									'dataType', 'varchar'
									),
								JSON_BUILD_OBJECT (
									'dataSource', '"SubSQL"."JSONData"->''entities''->>''deconstructionSQL''',
									'dataType', 'varchar'
									)
								);
						--RAISE NOTICE '%', varJSONFunctionParameterParsing;
				-----[ INTERMEDIATE VARIABLES INITIALIZATION ]--------------------------------(  END  )-----
			END IF;
		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------(  END  )-----

	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			-----[ PRELIMINARY ADDITIONAL DATA PROCESSING ]---------------------------( START )-----
			-----[ PRELIMINARY ADDITIONAL DATA PROCESSING ]---------------------------(  END  )-----

			-----[ MAIN DATA PROCESSING ]---------------------------------------------( START )-----
				---> Initializing : varReturn
					varReturn := (
						SELECT
							"SchSystem"."FuncSys_General_SetBulkData"(
								NULL::json,
								JSON_BUILD_OBJECT (
									'metadata.control',
										JSON_BUILD_OBJECT (
											'frontEndSchemaTableName',varFrontEndSchemaTableName,
											'functionName', varJSONFunctionName,
											'functionParameterParsing', varJSONFunctionParameterParsing
											),
									'data', varJSONData
									),
								varJSONDataDeletion::json
								)
						);
					--RAISE NOTICE '%', varReturn;

				---> Data Renewal : SchLog.TblLog_TableSnapshotSignature
					varSQL := '
						SELECT
							"SubSQL"."SignatureID"
						FROM
							DBLINK (
								''' || REPLACE ((SELECT "SchSystem"."FuncSys_General_GetEnvironmentParameter"('DBLink.ConnectionString.BackEnd.DataWarehouse')), '''', '''''') || ''',
								''
								SELECT
									"SchLog"."Func_TblLog_TableSnapshotSignature_RENEWAL"(
										''''' || varFrontEndSchemaTableName || '''''
										)
								''
								) AS "SubSQL" ("SignatureID" varchar)
						';
					--RAISE NOTICE '%', varSQL;
					EXECUTE
						varSQL;

			-----[ MAIN DATA PROCESSING ]---------------------------------------------(  END  )-----

			-----[ AFTERWARDS ADDITIONAL DATA PROCESSING ]----------------------------( START )-----
			-----[ AFTERWARDS ADDITIONAL DATA PROCESSING ]----------------------------(  END  )-----
		END IF;

	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----
		RETURN
			varReturn;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		EXCEPTION
			WHEN OTHERS THEN
				NULL;

END;
$_$;


ALTER FUNCTION "SchRecovery"."Func_TblStructure_DBObject_SET_BULK"(json, json, json) OWNER TO "SysAdmin";

--
-- TOC entry 398 (class 1255 OID 6653815)
-- Name: Func_TblStructure_DBObject_UPDATE(bigint, bigint, timestamp with time zone, timestamp with time zone, timestamp with time zone, bigint, bigint, bigint, bigint, character varying, character varying, character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: SchRecovery; Owner: SysAdmin
--

CREATE FUNCTION "SchRecovery"."Func_TblStructure_DBObject_UPDATE"(bigint, bigint, timestamp with time zone, timestamp with time zone, timestamp with time zone, bigint, bigint, bigint, bigint, character varying, character varying, character varying, character varying, character varying, character varying) RETURNS SETOF "SchSystem"."HoldFuncSys_General_FeedBackQuery"
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchRecovery"."Func_TblStructure_DBObject_UPDATE"
▪ Versi               :	1.00.0000
▪ Tanggal
     ► Pemutakhiran   :	2026-10-13
     ► Pembuatan      :	2026-10-13
▪ Input               :	• varID (bigint - Mandatory)
						• varSysDataEditLoginSession_RefID (bigint - Mandatory)
						• varSysDataEditDateTimeTZ (timestamptz - Mandatory)
						• varSysDataValidityStartDateTimeTZ (timestamptz - Mandatory)
						• varSysDataValidityFinishDateTimeTZ (timestamptz - Mandatory)
						• varSysPartitionRemovableRecordKey_RefID (bigint - Mandatory)
						• varSysBranch_RefID (bigint - Mandatory)
						• varSysBaseCurrency_RefID (bigint - Mandatory)
						------------------------------
						• varObjectID (bigint - Mandatory)
						• varType (varchar - Mandatory)
						• varDatabaseName (varchar - Mandatory)
						• varSchemaName (varchar - Mandatory)
						• varObjectName (varchar - Mandatory)
						• varConstructionSQL (varchar - Mandatory)
						• varDeconstructionSQL (varchar - Mandatory)
						------------------------------
▪ Output              :	varRecSetOutput ("SchSystem"."HoldFuncSys_General_FeedBackQuery")
▪ Deskripsi           :	• Memutakhirkan data (UPDATE) pada tabel TblStructure_DBObject
▪ Copyright           :	Zheta © 2026

----[ Related Database Object(s) ]------------------------------------------------------------------

▪ Tabel               :	• [BE] "SchRecovery"."TblStructure_DBObject"

▪ Fungsi              :	• [BE] "SchSystem"."FuncSys_General_SetDataIntegrityShadow"(varchar, bigint)

----[ SQL Example(s) ]------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varID													ALIAS FOR $1;
			varSysDataEditLoginSession_RefID						ALIAS FOR $2;
			varSysDataEditDateTimeTZ								ALIAS FOR $3;
			varSysDataValidityStartDateTimeTZ						ALIAS FOR $4;
			varSysDataValidityFinishDateTimeTZ						ALIAS FOR $5;
			varSysPartitionRemovableRecordKey_RefID					ALIAS FOR $6;
			varSysBranch_RefID										ALIAS FOR $7;
			varSysBaseCurrency_RefID								ALIAS FOR $8;
			------------------------------
			varObjectID												ALIAS FOR $9;
			varType													ALIAS FOR $10;
			varDatabaseName											ALIAS FOR $11;
			varSchemaName											ALIAS FOR $12;
			varObjectName											ALIAS FOR $13;
			varConstructionSQL										ALIAS FOR $14;
			varDeconstructionSQL									ALIAS FOR $15;

		---{ Optional }-------------------

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----
			varRecSetOutput											"SchSystem"."HoldFuncSys_General_FeedBackQuery"%rowtype;

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

		---{ Additional }-----------------

BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		IF (varSignEligibleToProcess IS FALSE) THEN
			varSignEligibleToProcess := TRUE;
		END IF;

		IF (varSignEligibleToProcess IS TRUE) THEN
		END IF;

	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			-----[ MAIN DATA PROCESSING ]---------------------------------------------( START )-----
				---> Main Data Set
					UPDATE
						"SchRecovery"."TblStructure_DBObject"
					SET
						"Sys_Data_Edit_LoginSession_RefID" = varSysDataEditLoginSession_RefID,
						"Sys_Data_Edit_DateTimeTZ" = varSysDataEditDateTimeTZ,
						"Sys_Data_Validity_StartDateTimeTZ" = varSysDataValidityStartDateTimeTZ,
						"Sys_Data_Validity_FinishDateTimeTZ" = varSysDataValidityFinishDateTimeTZ,
						"Sys_Partition_RemovableRecord_Key_RefID" = varSysPartitionRemovableRecordKey_RefID,
						"Sys_Branch_RefID" = varSysBranch_RefID,
						"Sys_BaseCurrency_RefID" = varSysBaseCurrency_RefID,
						------------------------------
						"ObjectID" = varObjectID,
						"Type" = varType,
						"DatabaseName" = varDatabaseName,
						"SchemaName" = varSchemaName,
						"ObjectName" = varObjectName,
						"ConstructionSQL" = varConstructionSQL,
						"DeconstructionSQL" = varDeconstructionSQL
					WHERE
						"Sys_PID" = varID
						OR
						"Sys_SID" = varID;

				---> Update "Sys_DataIntegrityShadow"
					PERFORM
						"SchSystem"."FuncSys_General_SetDataIntegrityShadow"(
							'SchRecovery.TblStructure_DBObject'::varchar,
							varID::bigint
							);

		END IF;

	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----	
		IF (varSignEligibleToProcess IS TRUE) THEN
			---> Initializing : varRecSetOutput
				varRecSetOutput."SignSuccess" := 1;
				varRecSetOutput."SignRecordType" := 'Sys_RPK';
				varRecSetOutput."SignRecordID" := (
					SELECT
						"Sys_RPK"
					FROM
						"SchRecovery"."TblStructure_DBObject"
					WHERE
						"Sys_PID" = varID
						OR
						"Sys_SID" = varID
					ORDER BY
						"Sys_RPK" ASC
					LIMIT 1
					);
				varRecSetOutput."SignMessage" := null;

			---> Data Return
				RETURN
					NEXT varRecSetOutput;
		END IF;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		--EXCEPTION WHEN OTHERS THEN ...

END;
$_$;


ALTER FUNCTION "SchRecovery"."Func_TblStructure_DBObject_UPDATE"(bigint, bigint, timestamp with time zone, timestamp with time zone, timestamp with time zone, bigint, bigint, bigint, bigint, character varying, character varying, character varying, character varying, character varying, character varying) OWNER TO "SysAdmin";

--
-- TOC entry 399 (class 1255 OID 6653816)
-- Name: FuncSys_Cryptography_CryptHash_Check(character varying, character varying); Type: FUNCTION; Schema: SchSystem; Owner: SysAdmin
--

CREATE FUNCTION "SchSystem"."FuncSys_Cryptography_CryptHash_Check"(character varying, character varying DEFAULT NULL::character varying) RETURNS json
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchSystem"."FuncSys_Cryptography_CryptHash_Check"
▪ Versi               :	1.00.0000
▪ Tanggal
     ► Pemutakhiran   :	2026-09-03
     ► Pembuatan      :	2026-09-03
▪ Input               :	• varPlainData (varchar - Mandatory)
						------------------------------
						• varHash (varchar - Mandatory)
						------------------------------
▪ Output              :	varReturn (json)
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Mendapatkan Dekripsi PGP dengan Key Simetris
▪ Copyright           :	Zheta © 2026

----[ Related Database Object(s) ]------------------------------------------------------------------

▪ Tabel               :	-

▪ Fungsi              :	-

----[ SQL Example(s) ]------------------------------------------------------------------------------

▪ ---> Dalam Bentuk Hash Non Base64
	SELECT
		"SchSystem"."FuncSys_Cryptography_CryptHash_Check"(
			'My Plain Data',
			'$2a$06$rhvsbDlKSMHkly6m5MHKyu5Mt5EKsSytXXCHAMc6HpQ78TzwyEtPq'
			);

▪ ---> Dalam Bentuk Hash Base64
	SELECT
		"SchSystem"."FuncSys_Cryptography_CryptHash_Check"(
			'My Plain Data',
			'JDJhJDA2JHJodnNiRGxLU01Ia2x5Nm01TUhLeXU1TXQ1RUtzU3l0WFhDSEFNYzZIcFE3OFR6d3lFdFBx'
			);

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varPlainData											ALIAS FOR $1;
			------------------------------

		---{ Optional }-------------------
			varHash													ALIAS FOR $2;
			------------------------------

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----
			varReturn												json;

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

			varHashRegenate											varchar;

		---{ Additional }-----------------

BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------( START )-----
			IF (varSignEligibleToProcess IS FALSE) THEN
				varSignEligibleToProcess := TRUE;
			END IF;
		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------(  END  )-----

		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------( START )-----
			IF (varSignEligibleToProcess IS TRUE) THEN
			END IF;
		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------(  END  )-----

	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			-----[ MAIN DATA PROCESSING ]---------------------------------------------( START )-----
				---> Reinitializing : varHash
					varHash	:=
						(
						CASE
							---> Bila varHash berbentuk Base64
							WHEN (varHash ~ '^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$') THEN
								CONVERT_FROM (
									DECODE (
										varHash,
										'base64'
										),
									'UTF-8'
									)
							---> Bila varHash tidak berbentuk Base64
							ELSE
								varHash							
						END
						);

				---> Reinitializing : varHashRegenate
					varHashRegenate := 
						CRYPT (
							varPlainData,
							varHash
							)::varchar;

			-----[ MAIN DATA PROCESSING ]---------------------------------------------(  END  )-----
		END IF;

	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----
		---> Initializing : varReturn
			varReturn :=
				JSON_BUILD_OBJECT (
					'plainData', varPlainData,
					'hash', varHash,
					'hashRegenate', varHashRegenate,
					'signIdentic',
						CASE
							WHEN (varHash = varHashRegenate) THEN
								TRUE
							ELSE
								FALSE
						END
					);

		---> Send Data Output
			RETURN
				varReturn;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		EXCEPTION
			WHEN OTHERS THEN
				NULL;

END;
$_$;


ALTER FUNCTION "SchSystem"."FuncSys_Cryptography_CryptHash_Check"(character varying, character varying) OWNER TO "SysAdmin";

--
-- TOC entry 400 (class 1255 OID 6653817)
-- Name: FuncSys_Cryptography_CryptHash_Generate(character varying, character varying); Type: FUNCTION; Schema: SchSystem; Owner: SysAdmin
--

CREATE FUNCTION "SchSystem"."FuncSys_Cryptography_CryptHash_Generate"(character varying, character varying DEFAULT NULL::character varying) RETURNS json
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchSystem"."FuncSys_Cryptography_CryptHash_Generate"
▪ Versi               :	1.00.0000
▪ Tanggal
     ► Pemutakhiran   :	2026-09-03
     ► Pembuatan      :	2026-09-03
▪ Input               :	• varPlainData (varchar - Mandatory)
						------------------------------
						• varSalt (varchar - Mandatory)
						------------------------------
▪ Output              :	varReturn (json)
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Mendapatkan Hash Crypt
▪ Copyright           :	Zheta © 2026

----[ Related Database Object(s) ]------------------------------------------------------------------

▪ Tabel               :	-

▪ Fungsi              :	-

----[ SQL Example(s) ]------------------------------------------------------------------------------

▪ --->
	SELECT
		"SchSystem"."FuncSys_Cryptography_CryptHash_Generate"(
			'My Plain Data'
			);

▪ --->
	SELECT
		"SchSystem"."FuncSys_Cryptography_CryptHash_Generate"(
			'My Plain Data',
			'My Salt'
			);

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varPlainData											ALIAS FOR $1;
			------------------------------

		---{ Optional }-------------------
			varSalt													ALIAS FOR $2;
			------------------------------

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----
			varReturn												json;

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

			varHash													varchar;
			varBase64Hash											varchar;

		---{ Additional }-----------------

BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------( START )-----
			IF (varSignEligibleToProcess IS FALSE) THEN
				varSignEligibleToProcess := TRUE;
			END IF;
		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------(  END  )-----

		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------( START )-----
			IF (varSignEligibleToProcess IS TRUE) THEN
				---> Reinitializing : varSalt
					varSalt :=
						COALESCE (
							varSalt,
							(GEN_SALT ('bf'))::varchar
							);
			END IF;
		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------(  END  )-----

	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			-----[ MAIN DATA PROCESSING ]---------------------------------------------( START )-----
				---> Initializing : varHash
					varHash :=
						(
						CRYPT (
							varPlainData,
							varSalt
							)
						)::varchar;

				---> Initializing : varBase64Hash
					varBase64Hash :=
						REPLACE(
							(
							ENCODE (
								CONVERT_TO (
									varHash,
									'UTF-8'
									), 
								'base64'
								)
							)::varchar,
							E'\n',
							''
							);


			-----[ MAIN DATA PROCESSING ]---------------------------------------------(  END  )-----
		END IF;

	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----
		---> Initializing : varReturn
			varReturn :=
				JSON_BUILD_OBJECT (
					'plainData', varPlainData,
					'salt', varSalt,
					'hash', varHash,
					'base64Hash', varBase64Hash
					);

		---> Send Data Output
			RETURN
				varReturn;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		EXCEPTION
			WHEN OTHERS THEN
				NULL;

END;
$_$;


ALTER FUNCTION "SchSystem"."FuncSys_Cryptography_CryptHash_Generate"(character varying, character varying) OWNER TO "SysAdmin";

--
-- TOC entry 378 (class 1255 OID 6653818)
-- Name: FuncSys_Cryptography_PGPSymmetric_Decryption(character varying, character varying); Type: FUNCTION; Schema: SchSystem; Owner: SysAdmin
--

CREATE FUNCTION "SchSystem"."FuncSys_Cryptography_PGPSymmetric_Decryption"(character varying, character varying DEFAULT NULL::character varying) RETURNS json
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchSystem"."FuncSys_Cryptography_PGPSymmetric_Decryption"
▪ Versi               :	1.00.0000
▪ Tanggal
     ► Pemutakhiran   :	2026-09-02
     ► Pembuatan      :	2026-09-02
▪ Input               :	• varBase64EncryptedData (varchar - Mandatory)
						------------------------------
						• varKey (varchar - Mandatory)
						------------------------------
▪ Output              :	varReturn (json)
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Mendapatkan Dekripsi PGP dengan Key Simetris
▪ Copyright           :	Zheta © 2026

----[ Related Database Object(s) ]------------------------------------------------------------------

▪ Tabel               :	-

▪ Fungsi              :	-

----[ SQL Example(s) ]------------------------------------------------------------------------------

▪ --->
	SELECT
		"SchSystem"."FuncSys_Cryptography_PGPSymmetric_Decryption"(
			'ww0EBwMCfLm7UILgj+to0j4BRcmtrDXioEBKXjEIE1wBZ/GksDjIqGz4nBWUnbqBUrEvAmHSbORbca/hFG+x08IAW0qB5mTyTm89PrMZ3Q==',
			'My Key'
			);

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varBase64EncryptedData									ALIAS FOR $1;
			------------------------------

		---{ Optional }-------------------
			varKey													ALIAS FOR $2;
			------------------------------

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----
			varReturn												json;

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

			varDecryptedData										varchar;

		---{ Additional }-----------------

BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------( START )-----
			IF (varSignEligibleToProcess IS FALSE) THEN
				varSignEligibleToProcess := TRUE;
			END IF;
		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------(  END  )-----

		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------( START )-----
			IF (varSignEligibleToProcess IS TRUE) THEN
			END IF;
		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------(  END  )-----

	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			-----[ MAIN DATA PROCESSING ]---------------------------------------------( START )-----
				---> Main Process
					varDecryptedData :=
						(
						PGP_SYM_DECRYPT (
							DECODE (
								REPLACE (
									varBase64EncryptedData,
									E'\n',
									''
									),
								'base64'
								),
							varKey
							)
						)::varchar;

			-----[ MAIN DATA PROCESSING ]---------------------------------------------(  END  )-----
		END IF;

	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----
		---> Initializing : varReturn
			varReturn :=
				JSON_BUILD_OBJECT (
					'base64EncryptedData', varBase64EncryptedData,
					'key', varKey,
					'decryptedData', varDecryptedData
					);

		---> Send Data Output
			RETURN
				varReturn;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		EXCEPTION
			WHEN OTHERS THEN
				NULL;

END;
$_$;


ALTER FUNCTION "SchSystem"."FuncSys_Cryptography_PGPSymmetric_Decryption"(character varying, character varying) OWNER TO "SysAdmin";

--
-- TOC entry 401 (class 1255 OID 6653819)
-- Name: FuncSys_Cryptography_PGPSymmetric_Encryption(character varying, character varying); Type: FUNCTION; Schema: SchSystem; Owner: SysAdmin
--

CREATE FUNCTION "SchSystem"."FuncSys_Cryptography_PGPSymmetric_Encryption"(character varying, character varying DEFAULT NULL::character varying) RETURNS json
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchSystem"."FuncSys_Cryptography_PGPSymmetric_Encryption"
▪ Versi               :	1.00.0000
▪ Tanggal
     ► Pemutakhiran   :	2026-09-02
     ► Pembuatan      :	2026-09-02
▪ Input               :	• varPlainData (varchar - Mandatory)
						------------------------------
						• varKey (varchar - Mandatory)
						------------------------------
▪ Output              :	varReturn (json)
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Mendapatkan Enkripsi PGP dengan Key Simetris
▪ Copyright           :	Zheta © 2026

----[ Related Database Object(s) ]------------------------------------------------------------------

▪ Tabel               :	-

▪ Fungsi              :	-

----[ SQL Example(s) ]------------------------------------------------------------------------------

▪ --->
	SELECT
		"SchSystem"."FuncSys_Cryptography_PGPSymmetric_Encryption"(
			'My Plain Data',
			'My Key'
			);

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varPlainData											ALIAS FOR $1;
			------------------------------

		---{ Optional }-------------------
			varKey													ALIAS FOR $2;
			------------------------------

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----
			varReturn												json;

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

			varEncryptedData										varchar;

		---{ Additional }-----------------

BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------( START )-----
			IF (varSignEligibleToProcess IS FALSE) THEN
				varSignEligibleToProcess := TRUE;
			END IF;
		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------(  END  )-----

		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------( START )-----
			IF (varSignEligibleToProcess IS TRUE) THEN
				---> Reinitializing : varKey
					varKey :=
						COALESCE (
							varKey,
							(GEN_SALT ('bf'))::varchar
							);
			END IF;
		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------(  END  )-----

	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			-----[ MAIN DATA PROCESSING ]---------------------------------------------( START )-----
				---> Main Process
					varEncryptedData :=
						REPLACE(
							(
							ENCODE (
								PGP_SYM_ENCRYPT (
									varPlainData,
									varKey
									), 
								'base64'
								)
							)::varchar,
							E'\n',
							''
							);

			-----[ MAIN DATA PROCESSING ]---------------------------------------------(  END  )-----
		END IF;

	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----
		---> Initializing : varReturn
			varReturn :=
				JSON_BUILD_OBJECT (
					'plainData', varPlainData,
					'key', varKey,
					'base64EncryptedData', varEncryptedData
					);

		---> Send Data Output
			RETURN
				varReturn;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		EXCEPTION
			WHEN OTHERS THEN
				NULL;

END;
$_$;


ALTER FUNCTION "SchSystem"."FuncSys_Cryptography_PGPSymmetric_Encryption"(character varying, character varying) OWNER TO "SysAdmin";

--
-- TOC entry 402 (class 1255 OID 6653820)
-- Name: FuncSys_General_CreateSequence(character varying, character varying); Type: FUNCTION; Schema: SchSystem; Owner: SysEngine
--

CREATE FUNCTION "SchSystem"."FuncSys_General_CreateSequence"(character varying, character varying) RETURNS void
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama               : "SchSystem""."FuncSys_General_CreateSequence"
▪ Versi              : 1.00.0000
▪ Tanggal            : 2020-12-02
▪ Input              : varSchemaName (varchar) 
					   varSequenceName (varchar)
▪ Output             : void
▪ Keterkaitan Fungsi : -
▪ Deskripsi          : Fungsi ini digunakan untuk membangun Sequence
▪ Copyright          : Zheta © 2020
----------------------------------------------------------------------------------------------------*/

DECLARE
   	varSchemaName		ALIAS FOR $1;
   	varSequenceName		ALIAS FOR $2;
   	varSQL				varchar;

BEGIN
	varSQL := '
		CREATE SEQUENCE IF NOT EXISTS "' || varSchemaName || '"."' || varSequenceName || '"
			INCREMENT 1
			START 1
			MINVALUE 1
			MAXVALUE 9223372036854775807
			CACHE 1;
		';
	EXECUTE varSQL;
END;
$_$;


ALTER FUNCTION "SchSystem"."FuncSys_General_CreateSequence"(character varying, character varying) OWNER TO "SysEngine";

--
-- TOC entry 403 (class 1255 OID 6653821)
-- Name: FuncSys_General_GetDataIntegrityShadow(character varying, bigint); Type: FUNCTION; Schema: SchSystem; Owner: SysAdmin
--

CREATE FUNCTION "SchSystem"."FuncSys_General_GetDataIntegrityShadow"(character varying, bigint) RETURNS character varying
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchSystem"."FuncSys_General_GetDataIntegrityShadow"
▪ Versi               :	1.00.0001
▪ Tanggal
     ► Pemutakhiran   :	2026-04-28
     ► Pembuatan      :	2026-04-23
▪ Input               :	• varSchemaTable (varchar - Mandatory)
						• varID (bigint - Mandatory)
						------------------------------
						------------------------------
						------------------------------
▪ Output              :	varReturn (varchar)
▪ Keterkaitan Fungsi  : -
▪ Deskripsi           :	• Mendapatkan Data Integrity Shadow dari Record berdasarkan Nama SchemaTable
						  (varSchemaTable) dan Record ID (varID) berupa "Sys_RPK", "Sys_PID", atau
						  "Sys_SID".
▪ Copyright           :	Zheta © 2026

----[ SQL Example(s) ]------------------------------------------------------------------------------

▪ --->
	SELECT
		"SchSystem"."FuncSys_General_GetDataIntegrityShadow"(
			'SchFinance.TblDebitNote'::varchar,
			240000000000001::bigint
			);

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varSchemaTable									 		ALIAS FOR $1;
			varID 													ALIAS FOR $2;
			------------------------------

		---{ Optional }-------------------

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----
			varReturn												varchar;

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

			varSchema												varchar;
			varTable												varchar;

			varSQL													varchar;
			varShadow												varchar;

		---{ Additional }-----------------

BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------( START )-----
			IF (varSignEligibleToProcess IS FALSE) THEN
				varSignEligibleToProcess := TRUE;
			END IF;
		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------(  END  )-----

		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------( START )-----
			IF (varSignEligibleToProcess IS TRUE) THEN
				---> Initializing : varSchema, varTable
					varSQL := '
						SELECT
							"Data"[1] AS "SchemaName",
							"Data"[2] AS "TableName"
						FROM
							(
							SELECT
								(''{"' || (REPLACE(varSchemaTable, '.', '", "')) || '"}'')::varchar[] AS "Data"
							) AS "SubSQL"
						';

					EXECUTE
						varSQL
					INTO
						varSchema,
						varTable;
					--RAISE NOTICE '%', varSchema;
					--RAISE NOTICE '%', varTable;
			END IF;
		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------(  END  )-----

	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			-----[ MAIN DATA PROCESSING ]---------------------------------------------( START )-----
				---> Initializing : varShadow
					varSQL := '
						SELECT
							(
							''
							SELECT 
								'' 
								|| "SubSQL"."Syntax" || 
								'' AS "ShadowCode"
							FROM
								"' || varSchema || '"."' || varTable || '"
							WHERE
								CASE
									WHEN ((' || varID || '::bigint / 1000000000000) = 0) THEN
										(
										"Sys_RPK" = ' || varID || '::bigint
										)
									ELSE
										(
										"Sys_PID" = ' || varID || '::bigint
										OR
										"Sys_SID" = ' || varID || '::bigint
										)
								END
							''
							) AS "Syntax"
						FROM
							(
							SELECT
								(
								''(MD5 ('' ||
								STRING_AGG (
									"SubSQL"."Syntax",
									('' || ''''<rotarapeSataDatehZ>'''' || MD5 ('')
									) OVER (
										ORDER BY
											"SubSQL"."OrderSequence" DESC
										) ||
								REPEAT ('')''::varchar, ("SubSQL"."MaxSequence" - 0)::int) ||
								'')''
								) AS "Syntax",
								------------------------------
								"SubSQL"."MaxSequence",
								------------------------------
								"SubSQL"."OrderSequence"
							FROM
								(
								SELECT
									"SubSQL"."Syntax",
									------------------------------
									(MAX ("SubSQL"."OrderSequence") OVER ()) AS "MaxSequence",
									------------------------------
									"SubSQL"."OrderSequence"
								FROM
									(
									SELECT
										(
										''COALESCE ("'' || "SubSQL"."FieldName" || ''"::varchar, ''''''''::varchar)''
										)::varchar AS "Syntax",
										------------------------------
										ROW_NUMBER () OVER (
											ORDER BY
												"SubSQL"."OrderSequence" ASC
											) AS "OrderSequence"
									FROM
										(
										SELECT
											"SubSQL"."FieldName",
											"SubSQL"."FieldType", 
											"SubSQL"."FieldMaxChar",
											"SubSQL"."FieldNumericPrecission",
											"SubSQL"."FieldNumericScale",
											------------------------------
											MAX ("SubSQL"."FilterSequence") OVER () AS "FilterSequence",
											"SubSQL"."OrderSequence"
										FROM
											(
											SELECT
												"SubSQL"."FieldName",
												"SubSQL"."FieldType", 
												"SubSQL"."FieldMaxChar",
												"SubSQL"."FieldNumericPrecission",
												"SubSQL"."FieldNumericScale",
												------------------------------
												(
												CASE
													WHEN ("SubSQL"."FieldName" = ''Sys_DataIntegrityShadow'') THEN
														"SubSQL"."OrderSequence"
													ELSE
														0
												END
												) AS "FilterSequence",
												ROW_NUMBER () OVER (
													ORDER BY
														"SubSQL"."OrderSequence" ASC
													) AS "OrderSequence"
											FROM
												(
												SELECT
													"VirtTblInfo"."column_name" AS "FieldName",
													CASE
														WHEN (SUBSTR ("VirtTblInfo"."udt_name", 1, 1) = ''_'') THEN
															(SUBSTR ("VirtTblInfo"."udt_name", 2, LENGTH("udt_name")) || ''[]'')
														ELSE
															"VirtTblInfo"."udt_name"
													END AS "FieldType", 
													"VirtTblInfo"."character_maximum_length" AS "FieldMaxChar",
													"VirtTblInfo"."numeric_precision" AS "FieldNumericPrecission",
													"VirtTblInfo"."numeric_scale" AS "FieldNumericScale",
													------------------------------
													ROW_NUMBER () OVER (
														ORDER BY
															ordinal_position ASC
														) AS "OrderSequence"
												FROM
													"information_schema"."columns" AS "VirtTblInfo"
												WHERE
													"VirtTblInfo"."table_schema" = ''' || varSchema || '''
													AND
													"VirtTblInfo"."table_name" = ''' || varTable || '''
												) AS "SubSQL"
											) AS "SubSQL"
										) AS "SubSQL"
									WHERE
										"SubSQL"."OrderSequence" > "SubSQL"."FilterSequence"
										--AND
										--"SubSQL"."OrderSequence" <= 25
									) AS "SubSQL"
								) AS "SubSQL"
							) AS "SubSQL"
						WHERE
							"SubSQL"."OrderSequence" = 1
						';
					EXECUTE varSQL INTO varSQL;

					IF (varSQL IS NOT NULL) THEN
						EXECUTE varSQL INTO varShadow;
					END IF;

				---> Initializing : varReturn
					varReturn := varShadow;

			-----[ MAIN DATA PROCESSING ]---------------------------------------------(  END  )-----
		END IF;

	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			---> Send Data Output
				RETURN
					varReturn;
		END IF;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		EXCEPTION
			WHEN OTHERS THEN
				RETURN NULL;

END;
$_$;


ALTER FUNCTION "SchSystem"."FuncSys_General_GetDataIntegrityShadow"(character varying, bigint) OWNER TO "SysAdmin";

--
-- TOC entry 404 (class 1255 OID 6653824)
-- Name: FuncSys_General_GetEnvironmentParameter(character varying); Type: FUNCTION; Schema: SchSystem; Owner: SysAdmin
--

CREATE FUNCTION "SchSystem"."FuncSys_General_GetEnvironmentParameter"(character varying) RETURNS character varying
    LANGUAGE plpgsql IMMUTABLE STRICT
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchSystem"."FuncSys_General_GetEnvironmentParameter"
▪ Versi               :	1.00.0000
▪ Tanggal
     ► Pemutakhiran   :	2026-06-09
     ► Pembuatan      :	2026-06-09
▪ Input               :	• varParameter (varchar - Mandatory)
						------------------------------
						------------------------------
▪ Output              :	varReturn (varchar)
▪ Keterkaitan Fungsi  : -
▪ Deskripsi           :	• Mendapatkan Data Environment berdasarkan Parameter (varParameter).
▪ Copyright           :	Zheta © 2026

----[ SQL Example(s) ]------------------------------------------------------------------------------

▪ ---> Parameter : DBLink.ConnectionString.FrontEnd
	SELECT
		"SchSystem"."FuncSys_General_GetEnvironmentParameter"('DBLink.ConnectionString.FrontEnd');

▪ ---> Parameter : DBLink.ConnectionString.BackEnd.DataWarehouse
	SELECT
		"SchSystem"."FuncSys_General_GetEnvironmentParameter"('DBLink.ConnectionString.BackEnd.DataWarehouse');

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varParameter											ALIAS FOR $1;

		---{ Optional }-------------------

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----
			varReturn												varchar;

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

		---{ Additional }-----------------

BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------( START )-----
		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------(  END  )-----

		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------( START )-----
		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------(  END  )-----

	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
		---> Initializing : varReturn
			varReturn := (
				CASE
					WHEN (varParameter = 'DBLink.ConnectionString.FrontEnd') THEN
						'dbname=''dbERPReborn'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263'''
					WHEN (varParameter = 'DBLink.ConnectionString.BackEnd.DataOLAP') THEN
						'dbname=''dbERPReborn-Data-OLAP'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263'''
					WHEN (varParameter = 'DBLink.ConnectionString.BackEnd.DataOLTP') THEN
						'dbname=''dbERPReborn-Data-OLTP'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263'''
					WHEN (varParameter = 'DBLink.ConnectionString.BackEnd.DataWarehouse') THEN
						'dbname=''dbERPReborn-Data-Warehouse'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263'''
					WHEN (varParameter = 'DBLink.ConnectionString.BackEnd.SysConfig') THEN
						'dbname=''dbERPReborn-SysConfig'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263'''			
					ELSE
						NULL
				END
				);

	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----
		---> Send Data Output
			RETURN
				varReturn;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		EXCEPTION
			WHEN OTHERS THEN
				NULL;

END;
$_$;


ALTER FUNCTION "SchSystem"."FuncSys_General_GetEnvironmentParameter"(character varying) OWNER TO "SysAdmin";

--
-- TOC entry 381 (class 1255 OID 6653825)
-- Name: FuncSys_General_GetEnvironmentParameterExtraction(bigint, bigint, json, character varying, json, json); Type: FUNCTION; Schema: SchSystem; Owner: SysAdmin
--

CREATE FUNCTION "SchSystem"."FuncSys_General_GetEnvironmentParameterExtraction"(bigint, bigint, json DEFAULT NULL::json, character varying DEFAULT NULL::character varying, json DEFAULT NULL::json, json DEFAULT NULL::json) RETURNS "SchSystem"."HoldFuncSys_General_GetEnvironmentParameterExtraction"
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchSystem"."FuncSys_General_GetEnvironmentParameterExtraction"
▪ Versi               :	1.00.0002
▪ Tanggal
     ► Pemutakhiran   :	2026-07-24
     ► Pembuatan      :	2026-07-07
▪ Input               :	• varSysDataReadLoginSession_RefID (bigint - Mandatory)
						• varSysBranch_RefID (bigint - Mandatory)
						------------------------------
						• varEnvironmentParameter (json - Optional)
						• varObjectIdentity (varchar - Optional)
						• varJSONCoreFields (json - Optional)
						• varJSONAllFields (json - Optional)
						------------------------------
▪ Output              :	varReturn (varchar)
▪ Deskripsi           :	• Mendapatkan Ekstrasi Paremeter Environment.
▪ Copyright           :	Zheta © 2026

----[ Related Database Object(s) ]------------------------------------------------------------------

▪ Tabel               :	-

▪ Fungsi              :	• [BE] "SchSystem"."FuncSys_General_GetEnvironmentParameter"(varchar)
						• [BE] "SchSystem"."FuncSys_General_StrSQLBuilder_FilterAndSort"(json, json)
	 					• [BE] "SchSystem"."FuncSys_General_StrSQLExecution"(varchar)
						• [BE] "SchSystem"."FuncSys_General_GetIDInformation"(bigint)
						------------------------------
						• [BE] "SchSysConfig"."Func_SQLGenerator_Array_BaseBranch"(bigint)
						------------------------------
	 					• [BE] "SchMaster"."Func_SQLGenerator_Array_Currency"(bigint, json)

----[ SQL Example(s) ]------------------------------------------------------------------------------

▪ --->
	SELECT
		*
	FROM
		"SchSystem"."FuncSys_General_GetEnvironmentParameterExtraction"(
			6000000000001::bigint,
			11000000000004::bigint
			------------------------------
			------------------------------
			);

▪ --->
	SELECT
		*
	FROM
		"SchSystem"."FuncSys_General_GetEnvironmentParameterExtraction"(
			6000000000001::bigint,
			11000000000004::bigint,
			------------------------------
			NULL::json,
			'SchSupplyChain.Func_SQLGenerator_DataList_Supplier'::varchar
			);

▪ --->
	SELECT
		*
	FROM
		"SchSystem"."FuncSys_General_GetEnvironmentParameterExtraction"(
			6000000000001::bigint,
			11000000000004::bigint,
			------------------------------
			JSON_BUILD_OBJECT (
				'DBLink.ConnectionString.FrontEnd', 'dbname=''dbERPReborn'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263''',
					'DBLink.ConnectionString.BackEnd.DataOLAP', 'dbname=''dbERPReborn-Data-OLAP'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263''',
					'DBLink.ConnectionString.BackEnd.DataOLTP', 'dbname=''dbERPReborn-Data-OLTP'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263''',
					'DBLink.ConnectionString.BackEnd.DataWarehouse', 'dbname=''dbERPReborn-Data-Warehouse'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263''',
					'DBLink.ConnectionString.BackEnd.SysConfig', 'dbname=''dbERPReborn-SysConfig'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263''',
					------------------------------
					'Pagination.PageSize', 10,
					'Pagination.PageShow', 2,
					------------------------------
					'DataCustomize.Filter', JSON_BUILD_ARRAY (
						JSON_BUILD_ARRAY (
							'Name', 'varchar', 'ILIKE', ''
							)
						),
					'DataCustomize.Sort', JSON_BUILD_ARRAY (
						JSON_BUILD_ARRAY (
							'Name', 'ASC'
							)
						),
					------------------------------
					'DataReference.Array.BaseBranch', JSON_BUILD_OBJECT (
						'ID', '{11000000000001,10011000000000001,11000000000002,10011000000000002,11000000000003,10011000000000003,11000000000004,10011000000000004}'::bigint[]::varchar,
						'Value_BaseBranchID', '{11000000000004,11000000000004,11000000000004,11000000000004,11000000000004,11000000000004,11000000000004,11000000000004}'::bigint[]::varchar
						),
					'DataReference.Array.Currency', JSON_BUILD_OBJECT (
						'ID', '{62000000000001,10062000000000001,62000000000002,10062000000000002,62000000000003,10062000000000003,62000000000004,10062000000000004,62000000000005,10062000000000005,62000000000006,10062000000000006,62000000000007,10062000000000007,62000000000008,10062000000000008,62000000000009,10062000000000009,62000000000010,10062000000000010,62000000000011,10062000000000011,62000000000012,10062000000000012,62000000000013,10062000000000013,62000000000014,10062000000000014,62000000000015,10062000000000015,62000000000016,10062000000000016,62000000000017,10062000000000017,62000000000018,10062000000000018,62000000000019,10062000000000019,62000000000020,10062000000000020,62000000000021,10062000000000021,62000000000022,10062000000000022,62000000000023,10062000000000023,62000000000024,10062000000000024,62000000000025,10062000000000025,62000000000026,10062000000000026,62000000000027,10062000000000027,62000000000028,10062000000000028,62000000000029,10062000000000029,62000000000030,10062000000000030,62000000000031,10062000000000031,62000000000032,10062000000000032,62000000000033,10062000000000033,62000000000034,10062000000000034,62000000000035,10062000000000035,62000000000036,10062000000000036,62000000000037,10062000000000037,62000000000038,10062000000000038,62000000000039,10062000000000039,62000000000040,10062000000000040,62000000000041,10062000000000041,62000000000042,10062000000000042,62000000000043,10062000000000043,62000000000044,10062000000000044,62000000000045,10062000000000045,62000000000046,10062000000000046,62000000000047,10062000000000047,62000000000048,10062000000000048,62000000000049,10062000000000049,62000000000050,10062000000000050,62000000000051,10062000000000051,62000000000052,10062000000000052,62000000000053,10062000000000053,62000000000054,10062000000000054,62000000000055,10062000000000055,62000000000056,10062000000000056,62000000000057,10062000000000057,62000000000058,10062000000000058,62000000000059,10062000000000059,62000000000060,10062000000000060,62000000000061,10062000000000061,62000000000062,10062000000000062,62000000000063,10062000000000063,62000000000064,10062000000000064,62000000000065,10062000000000065,62000000000066,10062000000000066,62000000000067,10062000000000067,62000000000068,10062000000000068,62000000000069,10062000000000069,62000000000070,10062000000000070,62000000000071,10062000000000071,62000000000072,10062000000000072,62000000000073,10062000000000073,62000000000074,10062000000000074,62000000000075,10062000000000075,62000000000076,10062000000000076,62000000000077,10062000000000077,62000000000078,10062000000000078,62000000000079,10062000000000079,62000000000080,10062000000000080,62000000000081,10062000000000081,62000000000082,10062000000000082,62000000000083,10062000000000083,62000000000084,10062000000000084,62000000000085,10062000000000085,62000000000086,10062000000000086,62000000000087,10062000000000087,62000000000088,10062000000000088,62000000000089,10062000000000089,62000000000090,10062000000000090,62000000000091,10062000000000091,62000000000092,10062000000000092,62000000000093,10062000000000093,62000000000094,10062000000000094,62000000000095,10062000000000095,62000000000096,10062000000000096,62000000000097,10062000000000097,62000000000098,10062000000000098,62000000000099,10062000000000099,62000000000100,10062000000000100,62000000000101,10062000000000101,62000000000102,10062000000000102,62000000000103,10062000000000103,62000000000104,10062000000000104,62000000000105,10062000000000105,62000000000106,10062000000000106,62000000000107,10062000000000107,62000000000108,10062000000000108,62000000000109,10062000000000109,62000000000110,10062000000000110,62000000000111,10062000000000111,62000000000112,10062000000000112,62000000000113,10062000000000113,62000000000114,10062000000000114,62000000000115,10062000000000115,62000000000116,10062000000000116,62000000000117,10062000000000117,62000000000118,10062000000000118,62000000000119,10062000000000119,62000000000120,10062000000000120}'::bigint[]::varchar,
						'Value_ISOCode', '{IDR,IDR,USD,USD,AUD,AUD,CAD,CAD,DKK,DKK,HKD,HKD,MYR,MYR,NZD,NZD,NOK,NOK,GBP,GBP,SGD,SGD,SEK,SEK,CHF,CHF,JPY,JPY,MMK,MMK,INR,INR,KWD,KWD,PKR,PKR,PHP,PHP,SAR,SAR,LKR,LKR,THB,THB,BND,BND,EUR,EUR,CNY,CNY,KRW,KRW,CNH,CNH,LAK,LAK,PGK,PGK,VND,VND,ID2,ID2,ALL,ALL,AFN,AFN,ARS,ARS,AWG,AWG,AZN,AZN,BSD,BSD,BBD,BBD,BYR,BYR,BZD,BZD,BMD,BMD,BOB,BOB,BAM,BAM,BWP,BWP,BGN,BGN,BRL,BRL,KHR,KHR,KYD,KYD,CLP,CLP,COP,COP,CRC,CRC,HRK,HRK,CUP,CUP,CZK,CZK,DOP,DOP,XCD,XCD,EGP,EGP,SVC,SVC,EEK,EEK,FKP,FKP,FJD,FJD,GHC,GHC,GIP,GIP,GTQ,GTQ,GGP,GGP,GYD,GYD,HNL,HNL,HUF,HUF,ISK,ISK,IRR,IRR,IMP,IMP,ILS,ILS,JMD,JMD,JEP,JEP,KZT,KZT,KPW,KPW,KGS,KGS,LVL,LVL,LBP,LBP,LRD,LRD,LTL,LTL,MKD,MKD,MUR,MUR,MXN,MXN,MNT,MNT,MZN,MZN,NAD,NAD,NPR,NPR,ANG,ANG,NIO,NIO,NGN,NGN,KPW,KPW,OMR,OMR,PAB,PAB,PYG,PYG,PEN,PEN,PLN,PLN,QAR,QAR,RON,RON,RUB,RUB,SHP,SHP,RSD,RSD,SCR,SCR,SBD,SBD,SOS,SOS,ZAR,ZAR,KRW,KRW,SRD,SRD,SYP,SYP,TWD,TWD,TTD,TTD,TRY,TRY,TRL,TRL,TVD,TVD,UAH,UAH,UYU,UYU,UZS,UZS,VEF,VEF,YER,YER,ZWD,ZWD}'::varchar[]::varchar,
						'Value_Symbol', '{Rp,Rp,$,$,$,$,$,$,kr,kr,$,$,RM,RM,$,$,kr,kr,£,£,$,$,kr,kr,₣,₣,¥,¥,K,K,NULL,NULL,NULL,NULL,₨,₨,₱,₱,﷼,﷼,රු,රු,฿,฿,$,$,€,€,¥,¥,₩,₩,¥,¥,₭,₭,K,K,₫,₫,Rp,Rp,Lek,Lek,؋,؋,$,$,ƒ,ƒ,ман,ман,$,$,$,$,p.,p.,BZ$,BZ$,$,$,$b,$b,KM,KM,P,P,лв,лв,R$,R$,៛,៛,$,$,$,$,$,$,₡,₡,kn,kn,₱,₱,Kč,Kč,RD$,RD$,$,$,£,£,$,$,kr,kr,£,£,$,$,¢,¢,£,£,Q,Q,£,£,$,$,L,L,Ft,Ft,kr,kr,﷼,﷼,£,£,₪,₪,J$,J$,£,£,лв,лв,₩,₩,лв,лв,Ls,Ls,£,£,$,$,Lt,Lt,ден,ден,₨,₨,$,$,₮,₮,MT,MT,$,$,₨,₨,ƒ,ƒ,C$,C$,₦,₦,₩,₩,﷼,﷼,B/.,B/.,Gs,Gs,S/.,S/.,zł,zł,﷼,﷼,lei,lei,руб,руб,£,£,Дин.,Дин.,₨,₨,$,$,S,S,R,R,₩,₩,$,$,£,£,NT$,NT$,TT$,TT$,TL,TL,₤,₤,$,$,₴,₴,$U,$U,лв,лв,Bs,Bs,﷼,﷼,Z$,Z$}'::varchar[]::varchar
						)
				),
			'SchSupplyChain.Func_SQLGenerator_DataList_Supplier'::varchar
			);

▪ --->
	SELECT
		*
	FROM
		"SchSystem"."FuncSys_General_GetEnvironmentParameterExtraction"(
			6000000000001::bigint,
			11000000000004::bigint,
			------------------------------
			JSON_BUILD_OBJECT (
				'DBLink.ConnectionString.FrontEnd', 'dbname=''dbERPReborn'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263''',
					'DBLink.ConnectionString.BackEnd.DataOLAP', 'dbname=''dbERPReborn-Data-OLAP'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263''',
					'DBLink.ConnectionString.BackEnd.DataOLTP', 'dbname=''dbERPReborn-Data-OLTP'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263''',
					'DBLink.ConnectionString.BackEnd.DataWarehouse', 'dbname=''dbERPReborn-Data-Warehouse'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263''',
					'DBLink.ConnectionString.BackEnd.SysConfig', 'dbname=''dbERPReborn-SysConfig'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263''',
					------------------------------
					'Pagination.PageSize', 10,
					'Pagination.PageShow', 2,
					------------------------------
					'DataCustomize.Filter', JSON_BUILD_ARRAY (
						JSON_BUILD_ARRAY (
							'Name', 'varchar', 'ILIKE', ''
							)
						),
					'DataCustomize.Sort', JSON_BUILD_ARRAY (
						JSON_BUILD_ARRAY (
							'Name', 'ASC'
							)
						),
					------------------------------
					'DataReference.Array.BaseBranch', JSON_BUILD_OBJECT (
						'ID', '{11000000000001,10011000000000001,11000000000002,10011000000000002,11000000000003,10011000000000003,11000000000004,10011000000000004}'::bigint[]::varchar,
						'Value_BaseBranchID', '{11000000000004,11000000000004,11000000000004,11000000000004,11000000000004,11000000000004,11000000000004,11000000000004}'::bigint[]::varchar
						),
					'DataReference.Array.Currency', JSON_BUILD_OBJECT (
						'ID', '{62000000000001,10062000000000001,62000000000002,10062000000000002,62000000000003,10062000000000003,62000000000004,10062000000000004,62000000000005,10062000000000005,62000000000006,10062000000000006,62000000000007,10062000000000007,62000000000008,10062000000000008,62000000000009,10062000000000009,62000000000010,10062000000000010,62000000000011,10062000000000011,62000000000012,10062000000000012,62000000000013,10062000000000013,62000000000014,10062000000000014,62000000000015,10062000000000015,62000000000016,10062000000000016,62000000000017,10062000000000017,62000000000018,10062000000000018,62000000000019,10062000000000019,62000000000020,10062000000000020,62000000000021,10062000000000021,62000000000022,10062000000000022,62000000000023,10062000000000023,62000000000024,10062000000000024,62000000000025,10062000000000025,62000000000026,10062000000000026,62000000000027,10062000000000027,62000000000028,10062000000000028,62000000000029,10062000000000029,62000000000030,10062000000000030,62000000000031,10062000000000031,62000000000032,10062000000000032,62000000000033,10062000000000033,62000000000034,10062000000000034,62000000000035,10062000000000035,62000000000036,10062000000000036,62000000000037,10062000000000037,62000000000038,10062000000000038,62000000000039,10062000000000039,62000000000040,10062000000000040,62000000000041,10062000000000041,62000000000042,10062000000000042,62000000000043,10062000000000043,62000000000044,10062000000000044,62000000000045,10062000000000045,62000000000046,10062000000000046,62000000000047,10062000000000047,62000000000048,10062000000000048,62000000000049,10062000000000049,62000000000050,10062000000000050,62000000000051,10062000000000051,62000000000052,10062000000000052,62000000000053,10062000000000053,62000000000054,10062000000000054,62000000000055,10062000000000055,62000000000056,10062000000000056,62000000000057,10062000000000057,62000000000058,10062000000000058,62000000000059,10062000000000059,62000000000060,10062000000000060,62000000000061,10062000000000061,62000000000062,10062000000000062,62000000000063,10062000000000063,62000000000064,10062000000000064,62000000000065,10062000000000065,62000000000066,10062000000000066,62000000000067,10062000000000067,62000000000068,10062000000000068,62000000000069,10062000000000069,62000000000070,10062000000000070,62000000000071,10062000000000071,62000000000072,10062000000000072,62000000000073,10062000000000073,62000000000074,10062000000000074,62000000000075,10062000000000075,62000000000076,10062000000000076,62000000000077,10062000000000077,62000000000078,10062000000000078,62000000000079,10062000000000079,62000000000080,10062000000000080,62000000000081,10062000000000081,62000000000082,10062000000000082,62000000000083,10062000000000083,62000000000084,10062000000000084,62000000000085,10062000000000085,62000000000086,10062000000000086,62000000000087,10062000000000087,62000000000088,10062000000000088,62000000000089,10062000000000089,62000000000090,10062000000000090,62000000000091,10062000000000091,62000000000092,10062000000000092,62000000000093,10062000000000093,62000000000094,10062000000000094,62000000000095,10062000000000095,62000000000096,10062000000000096,62000000000097,10062000000000097,62000000000098,10062000000000098,62000000000099,10062000000000099,62000000000100,10062000000000100,62000000000101,10062000000000101,62000000000102,10062000000000102,62000000000103,10062000000000103,62000000000104,10062000000000104,62000000000105,10062000000000105,62000000000106,10062000000000106,62000000000107,10062000000000107,62000000000108,10062000000000108,62000000000109,10062000000000109,62000000000110,10062000000000110,62000000000111,10062000000000111,62000000000112,10062000000000112,62000000000113,10062000000000113,62000000000114,10062000000000114,62000000000115,10062000000000115,62000000000116,10062000000000116,62000000000117,10062000000000117,62000000000118,10062000000000118,62000000000119,10062000000000119,62000000000120,10062000000000120}'::bigint[]::varchar,
						'Value_ISOCode', '{IDR,IDR,USD,USD,AUD,AUD,CAD,CAD,DKK,DKK,HKD,HKD,MYR,MYR,NZD,NZD,NOK,NOK,GBP,GBP,SGD,SGD,SEK,SEK,CHF,CHF,JPY,JPY,MMK,MMK,INR,INR,KWD,KWD,PKR,PKR,PHP,PHP,SAR,SAR,LKR,LKR,THB,THB,BND,BND,EUR,EUR,CNY,CNY,KRW,KRW,CNH,CNH,LAK,LAK,PGK,PGK,VND,VND,ID2,ID2,ALL,ALL,AFN,AFN,ARS,ARS,AWG,AWG,AZN,AZN,BSD,BSD,BBD,BBD,BYR,BYR,BZD,BZD,BMD,BMD,BOB,BOB,BAM,BAM,BWP,BWP,BGN,BGN,BRL,BRL,KHR,KHR,KYD,KYD,CLP,CLP,COP,COP,CRC,CRC,HRK,HRK,CUP,CUP,CZK,CZK,DOP,DOP,XCD,XCD,EGP,EGP,SVC,SVC,EEK,EEK,FKP,FKP,FJD,FJD,GHC,GHC,GIP,GIP,GTQ,GTQ,GGP,GGP,GYD,GYD,HNL,HNL,HUF,HUF,ISK,ISK,IRR,IRR,IMP,IMP,ILS,ILS,JMD,JMD,JEP,JEP,KZT,KZT,KPW,KPW,KGS,KGS,LVL,LVL,LBP,LBP,LRD,LRD,LTL,LTL,MKD,MKD,MUR,MUR,MXN,MXN,MNT,MNT,MZN,MZN,NAD,NAD,NPR,NPR,ANG,ANG,NIO,NIO,NGN,NGN,KPW,KPW,OMR,OMR,PAB,PAB,PYG,PYG,PEN,PEN,PLN,PLN,QAR,QAR,RON,RON,RUB,RUB,SHP,SHP,RSD,RSD,SCR,SCR,SBD,SBD,SOS,SOS,ZAR,ZAR,KRW,KRW,SRD,SRD,SYP,SYP,TWD,TWD,TTD,TTD,TRY,TRY,TRL,TRL,TVD,TVD,UAH,UAH,UYU,UYU,UZS,UZS,VEF,VEF,YER,YER,ZWD,ZWD}'::varchar[]::varchar,
						'Value_Symbol', '{Rp,Rp,$,$,$,$,$,$,kr,kr,$,$,RM,RM,$,$,kr,kr,£,£,$,$,kr,kr,₣,₣,¥,¥,K,K,NULL,NULL,NULL,NULL,₨,₨,₱,₱,﷼,﷼,රු,රු,฿,฿,$,$,€,€,¥,¥,₩,₩,¥,¥,₭,₭,K,K,₫,₫,Rp,Rp,Lek,Lek,؋,؋,$,$,ƒ,ƒ,ман,ман,$,$,$,$,p.,p.,BZ$,BZ$,$,$,$b,$b,KM,KM,P,P,лв,лв,R$,R$,៛,៛,$,$,$,$,$,$,₡,₡,kn,kn,₱,₱,Kč,Kč,RD$,RD$,$,$,£,£,$,$,kr,kr,£,£,$,$,¢,¢,£,£,Q,Q,£,£,$,$,L,L,Ft,Ft,kr,kr,﷼,﷼,£,£,₪,₪,J$,J$,£,£,лв,лв,₩,₩,лв,лв,Ls,Ls,£,£,$,$,Lt,Lt,ден,ден,₨,₨,$,$,₮,₮,MT,MT,$,$,₨,₨,ƒ,ƒ,C$,C$,₦,₦,₩,₩,﷼,﷼,B/.,B/.,Gs,Gs,S/.,S/.,zł,zł,﷼,﷼,lei,lei,руб,руб,£,£,Дин.,Дин.,₨,₨,$,$,S,S,R,R,₩,₩,$,$,£,£,NT$,NT$,TT$,TT$,TL,TL,₤,₤,$,$,₴,₴,$U,$U,лв,лв,Bs,Bs,﷼,﷼,Z$,Z$}'::varchar[]::varchar
						)
				),
			'SchSupplyChain.Func_SQLGenerator_DataList_Supplier'::varchar,
			------------------------------
			NULL::json,
			NULL::json
			);

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varSysDataReadLoginSession_RefID						ALIAS FOR $1;
			varSysBranch_RefID										ALIAS FOR $2;
			------------------------------

		---{ Optional }-------------------
			varEnvironmentParameter									ALIAS FOR $3;
			varObjectIdentity										ALIAS FOR $4;
			------------------------------
			varJSONCoreFields										ALIAS FOR $5;
			varJSONAllFields										ALIAS FOR $6;

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----
			varReturn												"SchSystem"."HoldFuncSys_General_GetEnvironmentParameterExtraction"%rowtype;

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

			varSQL													varchar;
			
			varSchema												varchar;
			varFunction												varchar;

		---{ Additional }-----------------

BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------( START )-----
			IF (varSignEligibleToProcess IS FALSE) THEN
				varSignEligibleToProcess := TRUE;
			END IF;
		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------(  END  )-----

		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------( START )-----
			IF (varSignEligibleToProcess IS TRUE) THEN
				---> Reinitializing : varJSONCoreFields
					IF (varJSONCoreFields::varchar = '[]') THEN
						varJSONCoreFields := NULL;
					END IF;

				---> Reinitializing : varJSONAllFields
					IF (varJSONAllFields::varchar = '[]') THEN
						varJSONAllFields := NULL;
					END IF;
			END IF;
		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------(  END  )-----

	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
			-----[ MAIN DATA PROCESSING ]---------------------------------------------( START )-----
				---> Initializing : varSchema, varFunction
					SELECT
						"SubSQL"."ObjectIdentityArray"[1],
						"SubSQL"."ObjectIdentityArray"[2]
					INTO
						varSchema,
						varFunction
					FROM
						(
						SELECT
							('{"' || REPLACE(varObjectIdentity::varchar, '.', '", "') || '"}')::varchar[] AS "ObjectIdentityArray"
						) AS "SubSQL";
					--RAISE NOTICE 'varSchema : %', varSchema;
					--RAISE NOTICE 'varFunction : %', varFunction;

				---> Initializing : varReturn."Env_Session"
					varReturn."Env_Session" :=
						COALESCE (
							varEnvironmentParameter->'Environment.Session',
							((
							SELECT
								"SchSystem"."FuncSys_GetInformation_SessionID"(
									varSysDataReadLoginSession_RefID,
									varObjectIdentity
									)
							))
							);

				---> Reinitializing : varDBLinkConnectionString
					varReturn."DBLinkConnectionString_FE" :=
						COALESCE (
							(varEnvironmentParameter->>'DBLink.ConnectionString.FrontEnd')::varchar,
							(SELECT "SchSystem"."FuncSys_General_GetEnvironmentParameter"('DBLink.ConnectionString.FrontEnd'))
							);

					varReturn."DBLinkConnectionString_BE_DataOLAP" :=
						COALESCE (
							(varEnvironmentParameter->>'DBLink.ConnectionString.BackEnd.DataOLAP')::varchar,
							(SELECT "SchSystem"."FuncSys_General_GetEnvironmentParameter"('DBLink.ConnectionString.BackEnd.DataOLAP'))
							);

					varReturn."DBLinkConnectionString_BE_DataOLTP" :=
						COALESCE (
							(varEnvironmentParameter->>'DBLink.ConnectionString.BackEnd.DataOLTP')::varchar,
							(SELECT "SchSystem"."FuncSys_General_GetEnvironmentParameter"('DBLink.ConnectionString.BackEnd.DataOLTP'))
							);

					varReturn."DBLinkConnectionString_BE_DataWarehouse" :=
						COALESCE (
							(varEnvironmentParameter->>'DBLink.ConnectionString.BackEnd.DataWarehouse')::varchar,
							(SELECT "SchSystem"."FuncSys_General_GetEnvironmentParameter"('DBLink.ConnectionString.BackEnd.DataWarehouse'))
							);

					varReturn."DBLinkConnectionString_BE_SysConfig" :=
						COALESCE (
							(varEnvironmentParameter->>'DBLink.ConnectionString.BackEnd.SysConfig')::varchar,
							(SELECT "SchSystem"."FuncSys_General_GetEnvironmentParameter"('DBLink.ConnectionString.BackEnd.SysConfig'))
							);

				---> Initializing : varPagination
					varReturn."Pagination_PageSize" :=
						COALESCE (
							CASE
								WHEN ((varEnvironmentParameter->>'Pagination.PageSize')::bigint > 0) THEN
									(varEnvironmentParameter->>'Pagination.PageSize')::bigint
								ELSE
									NULL
							END
							);

					varReturn."Pagination_PageShow" :=
						COALESCE (
							CASE
								WHEN ((varEnvironmentParameter->>'Pagination.PageShow')::bigint > 0) THEN
									(varEnvironmentParameter->>'Pagination.PageShow')::bigint
								ELSE
									NULL
							END
							);

				---> Initializing : varDataCustomize_Filter, varDataCustomize_Sort, varDataCustomize_Filter_CoreFields, varDataCustomize_Sort_CoreFields, varDataCustomize_Filter_NonCoreFields, varDataCustomize_Sort_NonCoreFields
					SELECT
						"SubSQL"."JSONData"->>'filterJSON',
						"SubSQL"."JSONData"->>'filterString',
						"SubSQL"."JSONData"->>'sortJSON',
						"SubSQL"."JSONData"->>'sortString',
						"SubSQL"."JSONData"->>'filterJSON_CoreFields',
						"SubSQL"."JSONData"->>'filterString_CoreFields',
						"SubSQL"."JSONData"->>'sortJSON_CoreFields',
						"SubSQL"."JSONData"->>'sortString_CoreFields',
						"SubSQL"."JSONData"->>'filterJSON_NonCoreFields',
						"SubSQL"."JSONData"->>'filterString_NonCoreFields',
						"SubSQL"."JSONData"->>'sortJSON_NonCoreFields',
						"SubSQL"."JSONData"->>'sortString_NonCoreFields'
					INTO
						varReturn."DataCustomize_Filter_JSON",
						varReturn."DataCustomize_Filter",
						varReturn."DataCustomize_Sort_JSON",
						varReturn."DataCustomize_Sort",
						varReturn."DataCustomize_Filter_CoreFields_JSON",
						varReturn."DataCustomize_Filter_CoreFields",
						varReturn."DataCustomize_Sort_CoreFields_JSON",
						varReturn."DataCustomize_Sort_CoreFields",
						varReturn."DataCustomize_Filter_NonCoreFields_JSON",
						varReturn."DataCustomize_Filter_NonCoreFields",
						varReturn."DataCustomize_Sort_NonCoreFields_JSON",
						varReturn."DataCustomize_Sort_NonCoreFields"
					FROM
						(
						SELECT
							"SchSystem"."FuncSys_General_StrSQLBuilder_FilterAndSort"(
								(varEnvironmentParameter->>'DataCustomize.Filter')::json,
								(varEnvironmentParameter->>'DataCustomize.Sort')::json,
								------------------------------
								varJSONCoreFields,
								varJSONAllFields
								) AS "JSONData"
						) AS "SubSQL";
					--RAISE NOTICE 'varDataCustomize_Filter : %', varReturn."DataCustomize_Filter";
					--RAISE NOTICE 'varDataCustomize_Sort : %', varReturn."DataCustomize_Sort";
					--RAISE NOTICE 'varDataCustomize_Filter_CoreFields : %', varReturn."DataCustomize_Filter_CoreFields";
					--RAISE NOTICE 'varDataCustomize_Sort_CoreFields : %', varReturn."DataCustomize_Sort_CoreFields";
					--RAISE NOTICE 'varDataCustomize_Filter_NonCoreFields : %', varReturn."DataCustomize_Filter_NonCoreFields";
					--RAISE NOTICE 'varDataCustomize_Sort_NonCoreFields : %', varReturn."DataCustomize_Sort_NonCoreFields";

				---> Initializing : varReturn."Array_SysBranch_RefID", varReturn."Array_SysBaseBranch_RefID"
					varReturn."Array_SysBranch_RefID" := (varEnvironmentParameter->'DataReference.Array.BaseBranch'->>'ID')::bigint[];
					varReturn."Array_SysBaseBranch_RefID" := (varEnvironmentParameter->'DataReference.Array.BaseBranch'->>'Value_BaseBranchID')::bigint[];

					IF ((varReturn."Array_SysBranch_RefID" IS NULL) OR (varReturn."Array_SysBaseBranch_RefID" IS NULL)) THEN
						IF ((SELECT CURRENT_DATABASE()) = 'dbERPReborn-SysConfig') THEN
							SELECT
								"InstitutionBranch_RefIDArray",
								"BaseInstitutionBranch_RefIDArray"
							INTO
								varReturn."Array_SysBranch_RefID",
								varReturn."Array_SysBaseBranch_RefID"
							FROM
								"SchSystem"."FuncSys_General_StrSQLExecution"(
									'
									SELECT
										"SubSQL"."IDArray" AS "InstitutionBranch_RefIDArray",
										"SubSQL"."ValueArray_BaseInstitutionBranch_RefID" AS "BaseInstitutionBranch_RefIDArray"
									FROM
										(
										'
										||
										(
										SELECT
											"SchSysConfig"."Func_SQLGenerator_Array_BaseBranch"(
												varSysDataReadLoginSession_RefID::bigint,
												------------------------------
												varSysBranch_RefID::bigint,
												JSON_BUILD_OBJECT (
													'Environment.Session', varReturn."Env_Session",
													------------------------------
													'DBLink.ConnectionString.FrontEnd', varReturn."DBLinkConnectionString_FE",
													'DBLink.ConnectionString.BackEnd.DataOLAP', varReturn."DBLinkConnectionString_BE_DataOLAP",
													'DBLink.ConnectionString.BackEnd.DataOLTP', varReturn."DBLinkConnectionString_BE_DataOLTP",
													'DBLink.ConnectionString.BackEnd.DataWarehouse', varReturn."DBLinkConnectionString_BE_DataWarehouse",
													'DBLink.ConnectionString.BackEnd.SysConfig', varReturn."DBLinkConnectionString_BE_SysConfig",
													------------------------------
													'Pagination.PageSize', NULL,
													'Pagination.PageShow', NULL,
													------------------------------
													'DataCustomize.Filter', NULL,
													'DataCustomize.Sort', NULL,
													------------------------------
													'DataReference.Array.BaseBranch', NULL,
													'DataReference.Array.Currency', NULL
													)
												)
										)
										||
										'
										) AS "SubSQL"
									'
									) AS "SubSQL" (
										"InstitutionBranch_RefIDArray" bigint[],
										"BaseInstitutionBranch_RefIDArray" bigint[]
										);
						ELSE
							SELECT
								"InstitutionBranch_RefIDArray",
								"BaseInstitutionBranch_RefIDArray"
							INTO
								varReturn."Array_SysBranch_RefID",
								varReturn."Array_SysBaseBranch_RefID"
							FROM
								DBLINK (
									varReturn."DBLinkConnectionString_BE_SysConfig",
									'
									SELECT
										"SubSQL"."IDArray",
										"SubSQL"."ValueArray_BaseInstitutionBranch_RefID"
									FROM
										"SchSystem"."FuncSys_General_StrSQLExecution"((
											SELECT
												(
												''
												SELECT
													"SubSQL"."IDArray",
													"SubSQL"."ValueArray_BaseInstitutionBranch_RefID"
												FROM
													(
													''
													||
													(
													SELECT
														"SchSysConfig"."Func_SQLGenerator_Array_BaseBranch"(
															' || COALESCE (varSysDataReadLoginSession_RefID::varchar, 'NULL') || '::bigint,
															------------------------------
															' || COALESCE (varSysBranch_RefID::varchar, 'NULL') || '::bigint,
															'''
															||
															(
															REPLACE (
																JSON_BUILD_OBJECT (
																	'Environment.Session', varReturn."Env_Session",
																	------------------------------
																	'DBLink.ConnectionString.FrontEnd', varReturn."DBLinkConnectionString_FE",
																	'DBLink.ConnectionString.BackEnd.DataOLAP', varReturn."DBLinkConnectionString_BE_DataOLAP",
																	'DBLink.ConnectionString.BackEnd.DataOLTP', varReturn."DBLinkConnectionString_BE_DataOLTP",
																	'DBLink.ConnectionString.BackEnd.DataWarehouse', varReturn."DBLinkConnectionString_BE_DataWarehouse",
																	'DBLink.ConnectionString.BackEnd.SysConfig', varReturn."DBLinkConnectionString_BE_SysConfig",
																	------------------------------
																	'Pagination.PageSize', NULL,
																	'Pagination.PageShow', NULL,
																	------------------------------
																	'DataCustomize.Filter', NULL,
																	'DataCustomize.Sort', NULL,
																	------------------------------
																	'DataReference.Array.BaseBranch', NULL,
																	'DataReference.Array.Currency', NULL
																	)::varchar,
																'''',
																''''''
																)
															)::varchar
															||
															'''::json
															)
													)
													||
													''
													) AS "SubSQL"
												''
												)
											)) AS "SubSQL"(
												"IDArray" bigint[],
												"ValueArray_BaseInstitutionBranch_RefID" bigint[]
												)
									'
									) AS "SubSQL" (
										"InstitutionBranch_RefIDArray" bigint[],
										"BaseInstitutionBranch_RefIDArray" bigint[]
										);
						END IF;
					--RAISE NOTICE 'varReturn."Array_SysBranch_RefID" : %', varReturn."Array_SysBranch_RefID";
					--RAISE NOTICE 'varReturn."Array_SysBaseBranch_RefID" : %', varReturn."Array_SysBaseBranch_RefID";
					END IF;

				---> Initializing : varReturn."Array_Currency_RefID", varReturn."Array_CurrencyISOCode", varReturn."Array_CurrencySymbol"
					varReturn."Array_Currency_RefID" := (varEnvironmentParameter->'DataReference.Array.Currency'->>'ID')::bigint[];
					varReturn."Array_CurrencyISOCode" := (varEnvironmentParameter->'DataReference.Array.Currency'->>'Value_ISOCode')::varchar(3)[];
					varReturn."Array_CurrencySymbol" := (varEnvironmentParameter->'DataReference.Array.Currency'->>'Value_Symbol')::varchar(4)[];

					IF ((varReturn."Array_Currency_RefID" IS NULL) OR (varReturn."Array_CurrencyISOCode" IS NULL) OR (varReturn."Array_CurrencySymbol" IS NULL)) THEN
						IF ((SELECT CURRENT_DATABASE()) = 'dbERPReborn-Data-OLTP') THEN
							SELECT
								"SubSQL"."Currency_RefIDArray",
								"SubSQL"."ISOCodeArray",
								"SubSQL"."SymbolArray"
							INTO
								varReturn."Array_Currency_RefID",
								varReturn."Array_CurrencyISOCode",
								varReturn."Array_CurrencySymbol"
							FROM
								"SchSystem"."FuncSys_General_StrSQLExecution"(
									'
									SELECT
										"SubSQL"."IDArray" AS "Currency_RefIDArray",
										"SubSQL"."ValueArray_ISOCode" AS "ISOCodeArray",
										"SubSQL"."ValueArray_Symbol" AS "SymbolArray"
									FROM
										(
										'
										||
										(
										SELECT
											"SchMaster"."Func_SQLGenerator_Array_Currency"(
												varSysDataReadLoginSession_RefID::bigint,
												------------------------------
												varSysBranch_RefID::bigint,
												JSON_BUILD_OBJECT (
													'Environment.Session', varReturn."Env_Session",
													------------------------------
													'DBLink.ConnectionString.FrontEnd', varReturn."DBLinkConnectionString_FE",
													'DBLink.ConnectionString.BackEnd.DataOLAP', varReturn."DBLinkConnectionString_BE_DataOLAP",
													'DBLink.ConnectionString.BackEnd.DataOLTP', varReturn."DBLinkConnectionString_BE_DataOLTP",
													'DBLink.ConnectionString.BackEnd.DataWarehouse', varReturn."DBLinkConnectionString_BE_DataWarehouse",
													'DBLink.ConnectionString.BackEnd.SysConfig', varReturn."DBLinkConnectionString_BE_SysConfig",
													------------------------------
													'Pagination.PageSize', NULL,
													'Pagination.PageShow', NULL,
													------------------------------
													'DataCustomize.Filter', NULL,
													'DataCustomize.Sort', NULL,
													------------------------------
													'DataReference.Array.BaseBranch', NULL,
													'DataReference.Array.Currency', NULL
													)
												)
										)
										||
										'
										) AS "SubSQL"
									'
									) AS "SubSQL" (
										"Currency_RefIDArray" bigint[],
										"ISOCodeArray" varchar[],
										"SymbolArray" varchar[]
										);
						ELSE
							SELECT
								"SubSQL"."Currency_RefIDArray",
								"SubSQL"."ISOCodeArray",
								"SubSQL"."SymbolArray"
							INTO
								varReturn."Array_Currency_RefID",
								varReturn."Array_CurrencyISOCode",
								varReturn."Array_CurrencySymbol"
							FROM
								DBLINK (
									varReturn."DBLinkConnectionString_BE_DataOLTP",
									'
									SELECT
										"SubSQL"."Currency_RefIDArray",
										"SubSQL"."ISOCodeArray",
										"SubSQL"."SymbolArray"
									FROM
										"SchSystem"."FuncSys_General_StrSQLExecution"((
											SELECT
												''
												SELECT
													"SubSQL"."IDArray",
													"SubSQL"."ValueArray_ISOCode",
													"SubSQL"."ValueArray_Symbol"
												FROM
													(
													''
													||
													(
													SELECT
														"SchMaster"."Func_SQLGenerator_Array_Currency"(
															' || COALESCE (varSysDataReadLoginSession_RefID::varchar, 'NULL') || '::bigint,
															------------------------------
															' || COALESCE (varSysBranch_RefID::varchar, 'NULL') || '::bigint,
															'''
															||
															(
															REPLACE (
																JSON_BUILD_OBJECT (
																	'Environment.Session', varReturn."Env_Session",
																	------------------------------
																	'DBLink.ConnectionString.FrontEnd', varReturn."DBLinkConnectionString_FE",
																	'DBLink.ConnectionString.BackEnd.DataOLAP', varReturn."DBLinkConnectionString_BE_DataOLAP",
																	'DBLink.ConnectionString.BackEnd.DataOLTP', varReturn."DBLinkConnectionString_BE_DataOLTP",
																	'DBLink.ConnectionString.BackEnd.DataWarehouse', varReturn."DBLinkConnectionString_BE_DataWarehouse",
																	'DBLink.ConnectionString.BackEnd.SysConfig', varReturn."DBLinkConnectionString_BE_SysConfig",
																	------------------------------
																	'Pagination.PageSize', NULL,
																	'Pagination.PageShow', NULL,
																	------------------------------
																	'DataCustomize.Filter', NULL,
																	'DataCustomize.Sort', NULL,
																	------------------------------
																	'DataReference.Array.BaseBranch', NULL,
																	'DataReference.Array.Currency', NULL
																	)::varchar,
																'''',
																''''''
																)
															)::varchar
															||
															'''::json
															)
													)
													||
													''
													) AS "SubSQL"
												''
											)) AS "SubSQL" (
												"Currency_RefIDArray" bigint[],
												"ISOCodeArray" varchar[],
												"SymbolArray" varchar[]
												)
									'
									) AS "SubSQL" (
										"Currency_RefIDArray" bigint[],
										"ISOCodeArray" varchar[],
										"SymbolArray" varchar[]
										);
						END IF;
						--RAISE NOTICE 'varReturn."Array_Currency_RefID" : %', varReturn."Array_Currency_RefID";
						--RAISE NOTICE 'varReturn."Array_CurrencyISOCode" : %', varReturn."Array_CurrencyISOCode";
						--RAISE NOTICE 'varReturn."Array_CurrencySymbol" : %', varReturn."Array_CurrencySymbol";
					END IF;
			-----[ MAIN DATA PROCESSING ]---------------------------------------------(  END  )-----

	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----
		---> Send Data Output
			RETURN
				varReturn;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		EXCEPTION
			WHEN OTHERS THEN
				RETURN NULL;

END
$_$;


ALTER FUNCTION "SchSystem"."FuncSys_General_GetEnvironmentParameterExtraction"(bigint, bigint, json, character varying, json, json) OWNER TO "SysAdmin";

--
-- TOC entry 405 (class 1255 OID 6653828)
-- Name: FuncSys_General_GetIDInformation(bigint); Type: FUNCTION; Schema: SchSystem; Owner: SysAdmin
--

CREATE FUNCTION "SchSystem"."FuncSys_General_GetIDInformation"(bigint) RETURNS json
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchSystem"."FuncSys_General_GetIDInformation"
▪ Versi               :	1.00.0000
▪ Tanggal
     ► Pemutakhiran   :	2026-06-26
     ► Pembuatan      :	2026-06-26
▪ Input               :	• varID (bigint)
▪ Output              :	varReturn (json)
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Mendapatkan Informasi dari ID
▪ Copyright           :	Zheta © 2026

----[ Related Database Object(s) ]------------------------------------------------------------------

▪ Tabel               :	• [BE] "SchSysConfig"."TblDBObject_Schema"
						• [BE] "SchSysConfig"."TblDBObject_Table"

▪ Fungsi              :	• [BE] "SchSystem"."FuncSys_General_GetEnvironmentParameter"(varchar)
	 					• [BE] "SchSystem"."FuncSys_General_StrSQLExecution"(varchar)

----[ SQL Example(s) ]------------------------------------------------------------------------------

▪ --->
	SELECT
		"SchSystem"."FuncSys_General_GetIDInformation"(
			97000000000001::bigint);

▪ --->
	SELECT
		"SchSystem"."FuncSys_General_GetIDInformation"(
			10097000000000001::bigint);

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varID													ALIAS FOR $1;
			------------------------------

		---{ Optional }-------------------

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----
			varReturn												json;

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

			varSQL													varchar;

BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------( START )-----
			IF (varSignEligibleToProcess IS FALSE) THEN
				varSignEligibleToProcess := TRUE;
			END IF;
		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------(  END  )-----

		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------( START )-----
			IF (varSignEligibleToProcess IS TRUE) THEN
			END IF;
		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------(  END  )-----

	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			-----[ MAIN DATA PROCESSING ]---------------------------------------------( START )-----
				---> Initializing : varReturn
					varReturn := (
						SELECT
							"SubSQL"."JSONData"
						FROM
							(
							SELECT
								(
								SELECT
									(
									SELECT
										"SubSQL"."JSONData"
									FROM
										DBLINK (
											(SELECT "SchSystem"."FuncSys_General_GetEnvironmentParameter"('DBLink.ConnectionString.BackEnd.SysConfig')),
											'SELECT ' ||
												'JSON_BUILD_OBJECT (' ||
													'''schemaTable'', "InnerSubSQL"."SchemaTable", '
													'''clusterID'', "InnerSubSQL"."ClusterID", '
													'''sys_ID'', ' ||
														'COALESCE (' || 
															'"InnerSubSQL"."Sys_PID",' || 
															'"InnerSubSQL"."Sys_SID"' || 
															'), ' ||
													'''sys_PID'', "InnerSubSQL"."Sys_PID", '
													'''sys_SID'', "InnerSubSQL"."Sys_SID", '
													'''sys_RPK'', "InnerSubSQL"."Sys_RPK" '
													') AS "JSONData"' ||
											'FROM ' ||
												'(' ||
												'SELECT ' ||
													'(''' ||
													COALESCE (
														"VirtTblSchema_PID"."Name",
														"VirtTblSchema_SID"."Name"
														) ||
													'.' ||
													"VirtTblTable"."Name" ||
													''') AS "SchemaTable", ' ||
													'(("Sys_SID" / 1000000000000) / 10000) AS "ClusterID", ' ||
													'"Sys_PID", ' ||
													'"Sys_SID", ' ||
													'"Sys_RPK"' ||
												'FROM "' ||
													COALESCE (
														"VirtTblSchema_PID"."Name",
														"VirtTblSchema_SID"."Name"
														) ||
													'"."' ||
													"VirtTblTable"."Name" ||
												'" WHERE "Sys_PID" = ' || COALESCE ("SubSQL"."ID"::varchar, 'NULL'::varchar) || '::bigint OR "Sys_SID" = ' || COALESCE ("SubSQL"."ID"::varchar, 'NULL'::varchar) || '::bigint' ||
												') AS "InnerSubSQL"'
											) AS "SubSQL" ("JSONData" json)
										) AS "JSONData"
									FROM
										"SchSysConfig"."TblDBObject_Table" AS "VirtTblTable"
											LEFT JOIN
												"SchSysConfig"."TblDBObject_Schema" AS "VirtTblSchema_PID"
													ON
														"VirtTblTable"."Schema_RefID" = "VirtTblSchema_PID"."Sys_PID"
											LEFT JOIN
												"SchSysConfig"."TblDBObject_Schema" AS "VirtTblSchema_SID"
													ON
														"VirtTblTable"."Schema_RefID" = "VirtTblSchema_SID"."Sys_SID"
									WHERE
										"VirtTblTable"."Sys_RPK" = "SubSQL"."TableID"
								)
							FROM
								(
								SELECT
									"SubSQL"."ID",
									(("SubSQL"."ID" / 1000000000000) % 1000) AS "TableID"
								FROM
									(
									SELECT
										varID AS "ID"
									) AS "SubSQL"
								) AS "SubSQL"
							) AS "SubSQL"
						);
			END IF;

	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----
		---> Send Data Output
			RETURN
				varReturn;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		EXCEPTION
			WHEN OTHERS THEN
				RETURN NULL;

END;
$_$;


ALTER FUNCTION "SchSystem"."FuncSys_General_GetIDInformation"(bigint) OWNER TO "SysAdmin";

--
-- TOC entry 406 (class 1255 OID 6653829)
-- Name: FuncSys_General_GetIDTablePartition(character varying, character varying, character varying); Type: FUNCTION; Schema: SchSystem; Owner: SysAdmin
--

CREATE FUNCTION "SchSystem"."FuncSys_General_GetIDTablePartition"(character varying, character varying, character varying) RETURNS bigint
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchSystem"."FuncSys_General_GetIDTablePartition"
▪ Versi               :	1.00.0000
▪ Tanggal
     ► Pemutakhiran   :	2026-11-18
     ► Pembuatan      :	2026-11-18
▪ Input               :	• varSchemaName (varchar)
						• varTableName (varchar)
						• varKey (varchar)
▪ Output              :	varReturn (bigint)
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Mendapatkan ID Partisi Table dari Schema Name, Table Name, dan Key
▪ Copyright           :	Zheta © 2026

----[ Related Database Object(s) ]------------------------------------------------------------------

▪ Tabel               :	• [BE] "SchSysConfig"."TblDBObject_Schema"
						• [BE] "SchSysConfig"."TblDBObject_Table"

▪ Fungsi              :	• [BE] "SchSystem"."FuncSys_General_GetEnvironmentParameter"(varchar)
	 					• [BE] "SchSystem"."FuncSys_General_StrSQLExecution"(varchar)

----[ SQL Example(s) ]------------------------------------------------------------------------------

▪ --->
	SELECT
		"SchSystem"."FuncSys_General_GetIDTablePartition"(
			'SchData-OLTP-Budgeting',
			'TblCombinedBudgetSectionDetail',
			'2026'
			)

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varSchemaName											ALIAS FOR $1;
			varTableName											ALIAS FOR $2;
			varKey													ALIAS FOR $3;
			------------------------------

		---{ Optional }-------------------

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----
			varReturn												bigint;

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

			varSQL													varchar;

BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------( START )-----
			IF (varSignEligibleToProcess IS FALSE) THEN
				varSignEligibleToProcess := TRUE;
			END IF;
		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------(  END  )-----

		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------( START )-----
			IF (varSignEligibleToProcess IS TRUE) THEN
			END IF;
		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------(  END  )-----

	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			-----[ MAIN DATA PROCESSING ]---------------------------------------------( START )-----
				---> Initializing : varReturn
					varReturn :=
						NULL::bigint;
			-----[ MAIN DATA PROCESSING ]---------------------------------------------(  END  )-----
		END IF;
		
	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----
		---> Send Data Output
			RETURN
				varReturn;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		EXCEPTION
			WHEN OTHERS THEN
				RETURN NULL;

END;
$_$;


ALTER FUNCTION "SchSystem"."FuncSys_General_GetIDTablePartition"(character varying, character varying, character varying) OWNER TO "SysAdmin";

--
-- TOC entry 407 (class 1255 OID 6653830)
-- Name: FuncSys_General_GetSequence(character varying[], boolean); Type: FUNCTION; Schema: SchSystem; Owner: SysAdmin
--

CREATE FUNCTION "SchSystem"."FuncSys_General_GetSequence"(character varying[], boolean DEFAULT false) RETURNS bigint[]
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchSystem"."FuncSys_General_GetSequence"
▪ Versi               :	1.00.0001
▪ Tanggal
     ► Pemutakhiran   :	2026-05-23
     ► Pembuatan      :	2026-05-18
▪ Input               :	• varObjectSequenceArray (varchar[] - Mandatory)
						------------------------------
						• varObjectAutoCreate (boolean - Optional)
						------------------------------
▪ Output              :	varReturn (bigint[])
▪ Keterkaitan Fungsi  : -
▪ Deskripsi           :	• Mendapatkan Nomor Next Sequence dari Array Object Sequence
						  (varObjectSequenceArray).
						• varObjectAutoCreate (Default : FALSE) apabila diset TRUE maka akan membuat
						  Object Sequence baru apabila tidak ditemukan.
▪ Copyright           :	Zheta © 2026

----[ SQL Example(s) ]------------------------------------------------------------------------------

▪ ---> Without Auto Create If Sequence Is Not Exist
	SELECT
		"SchSystem"."FuncSys_General_GetSequence"(
			'{"SchMaster.AAA_seq", "SchMaster.AAA_seq", "SchMaster.BBB_seq"}'::character varying[]
			);

	SELECT
		"SchSystem"."FuncSys_General_GetSequence"(
			'{"SchMaster.AAA_seq", "SchMaster.AAA_seq", "SchMaster.BBB_seq"}'::character varying[],
			FALSE
			);

▪ ---> With Auto Create If Sequence Is Not Exist
	SELECT
		"SchSystem"."FuncSys_General_GetSequence"(
			'{NULL, "SchMaster.AAA_seq", "SchMaster.AAA_seq", "SchMaster.BBB_seq"}'::character varying[],
			TRUE
			);

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varObjectSequenceArray									ALIAS FOR $1;
			------------------------------

		---{ Optional }-------------------
			varObjectAutoCreate										ALIAS FOR $2;
			------------------------------

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----
			varReturn												bigint[];

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

			varSQL													varchar;

		---{ Additional }-----------------

BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------( START )-----
			IF (varSignEligibleToProcess IS FALSE) THEN
				varSignEligibleToProcess := TRUE;
			END IF;
		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------(  END  )-----

		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------( START )-----
			IF (varSignEligibleToProcess IS TRUE) THEN
			END IF;
		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------(  END  )-----

	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			-----[ MAIN DATA PROCESSING ]---------------------------------------------( START )-----
				---> Initializing : varSQL
					varSQL := '
						SELECT
							"SubSQL"."NextSequenceNumberArray"
						FROM
							(
							SELECT
								CASE
									WHEN ("SubSQL"."OrderSequence" = 1) THEN
										(
										''{'' ||
										STRING_AGG (
											COALESCE (
												"SubSQL"."NextSequenceNumber"::varchar,
												''NULL''
												),
											'', ''
											) OVER () ||
										''}''
										)::bigint[]
									ELSE
										NULL
								END AS "NextSequenceNumberArray"
							FROM
								(
								SELECT
									CASE
										WHEN ("SubSQL"."SignObjectSequenceExist" IS TRUE) THEN
											NEXTVAL(''"'' || REPLACE ("SubSQL"."ObjectSequence", ''.'', ''"."'') || ''"'')
										ELSE
											NULL
									END AS "NextSequenceNumber",
									------------------------------
									"SubSQL"."OrderSequence"
								FROM
									(
									SELECT
										"SubSQL"."ObjectSequence",
										"SubSQL"."SignAutoCreate",
										"SubSQL"."SignSchemaExist",
										"SubSQL"."SignObjectSequenceExist",
										------------------------------
										"SubSQL"."OrderSequence"
									FROM
										(
										SELECT
											"SubSQL"."ObjectSequence",
											"SubSQL"."SignAutoCreate",
											"SubSQL"."SignSchemaExist",
											CASE
												WHEN (("SubSQL"."SignAutoCreate" IS TRUE) AND ("SubSQL"."SignSchemaExist" IS TRUE) AND ("SubSQL"."SignObjectSequenceExist" IS FALSE)) THEN
													TRUE
												ELSE
													"SubSQL"."SignObjectSequenceExist"
											END AS "SignObjectSequenceExist",
											CASE
												WHEN (("SubSQL"."SignAutoCreate" IS TRUE) AND ("SubSQL"."SignSchemaExist" IS TRUE) AND ("SubSQL"."SignObjectSequenceExist" IS FALSE)) THEN
													(
													SELECT
														"SchSystem"."FuncSys_General_StrSQLExecution"(
															''
															CREATE SEQUENCE IF NOT EXISTS "'' || REPLACE ("SubSQL"."ObjectSequence", ''.'', ''"."'') || ''"
															    INCREMENT 1
															    START 1
															    MINVALUE 1
															    MAXVALUE 9223372036854775807
															    CACHE 1
															''
															)
													)
												ELSE
													NULL
											END AS "CreateObjectExec",
											------------------------------
											"SubSQL"."OrderSequence"
										FROM
											(
											SELECT
												"SubSQL"."ObjectSequence",
												"SubSQL"."SignAutoCreate",
												(
												SELECT
													EXISTS (
														SELECT
															nspname
														FROM
															pg_catalog.pg_namespace
														WHERE
															nspname = "InnerSubSQL"."SchemaSequenceNameArray"[1]
														)
												FROM
													(
													SELECT
														(''{"'' || REPLACE (REPLACE (REPLACE ("SubSQL"."ObjectSequence", ''\'', ''\\''), ''"'', ''\"''), ''.'', ''", "'') || ''"}'')::varchar[] AS "SchemaSequenceNameArray"
													) AS "InnerSubSQL"
												) AS "SignSchemaExist",
												(
												SELECT
													EXISTS (
														SELECT
															1
														FROM
															information_schema.sequences 
														WHERE
															sequence_schema = "InnerSubSQL"."SchemaSequenceNameArray"[1]
															AND
															sequence_name = "InnerSubSQL"."SchemaSequenceNameArray"[2]
														)
												FROM
													(
													SELECT
														(''{"'' || REPLACE (REPLACE (REPLACE ("SubSQL"."ObjectSequence", ''\'', ''\\''), ''"'', ''\"''), ''.'', ''", "'') || ''"}'')::varchar[] AS "SchemaSequenceNameArray"
													) AS "InnerSubSQL"
												) AS "SignObjectSequenceExist",
												------------------------------
												ROW_NUMBER () OVER () AS "OrderSequence"
											FROM
												(
												SELECT
													UNNEST(''' || varObjectSequenceArray::varchar || '''::varchar[]) AS "ObjectSequence",
													''' || varObjectAutoCreate::varchar || '''::boolean AS "SignAutoCreate"
												) AS "SubSQL"
											) AS "SubSQL"
										) AS "SubSQL"
									) AS "SubSQL"
								) AS "SubSQL"
							LIMIT 1
							) AS "SubSQL"
						';
					--RAISE NOTICE '%', varSQL;
					EXECUTE varSQL INTO varReturn;
			-----[ MAIN DATA PROCESSING ]---------------------------------------------(  END  )-----
		END IF;

	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----
		RETURN
			varReturn;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		EXCEPTION
			WHEN OTHERS THEN
				RETURN NULL;

END;
$_$;


ALTER FUNCTION "SchSystem"."FuncSys_General_GetSequence"(character varying[], boolean) OWNER TO "SysAdmin";

--
-- TOC entry 408 (class 1255 OID 6653833)
-- Name: FuncSys_General_GetSequence(character varying, character varying, bigint); Type: FUNCTION; Schema: SchSystem; Owner: SysEngine
--

CREATE FUNCTION "SchSystem"."FuncSys_General_GetSequence"(character varying, character varying, bigint DEFAULT (1)::bigint) RETURNS bigint
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama               : "SchSystem""."FuncSys_General_GetSequence"
▪ Versi              : 1.00.0002
▪ Tanggal            : 
▪ Tanggal 
     ► Pembuatan     : 2020-12-02
     ► Pemutakhiran  : 2022-01-14
▪ Input              : varSchemaName (varchar - Mandatory) 
					   varSequenceName (varchar - Mandatory)
					   varOffset (bigint - Optional)
▪ Output             : varOutput (bigint)
▪ Keterkaitan Fungsi : -
▪ Deskripsi          : Fungsi ini digunakan untuk mendapatkan nilai dari Sequence
▪ Copyright          : Zheta © 2020 - 2022

----[ SQL Example(s) ]------------------------------------------------------------------------------

▪ SELECT * FROM "SchSystem"."FuncSys_General_GetSequence"('SchBudgeting', 'TblTEMP_BudgetExpenseLineCeilingObjects_Sys_RPK_seq')

----------------------------------------------------------------------------------------------------*/

DECLARE
	varSchemaName		ALIAS FOR $1;
	varSequenceName		ALIAS FOR $2;
	varOffset			ALIAS FOR $3;
	
	varSQL				varchar;

	varOutput			bigint;

	varTemp				bigint;

BEGIN
	varSQL := '
		SELECT NEXTVAL(''"' || varSchemaName || '"."' || varSequenceName || '"'')
		';
	EXECUTE varSQL INTO varOutput;

    IF (varOffset > 1) THEN
		varSQL := '
			SELECT SETVAL(''"' || varSchemaName || '"."' || varSequenceName || '"'', (LASTVAL() + ' || varOffset || ' - 1))
			';
		EXECUTE varSQL INTO varOutput;
	END IF;
	
	RETURN varOutput;
END;

$_$;


ALTER FUNCTION "SchSystem"."FuncSys_General_GetSequence"(character varying, character varying, bigint) OWNER TO "SysEngine";

--
-- TOC entry 409 (class 1255 OID 6653834)
-- Name: FuncSys_General_SetBulkData(json, json, json); Type: FUNCTION; Schema: SchSystem; Owner: SysAdmin
--

CREATE FUNCTION "SchSystem"."FuncSys_General_SetBulkData"(json, json DEFAULT NULL::json, json DEFAULT NULL::json) RETURNS json
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchSystem"."FuncSys_General_SetBulkData"
▪ Versi               :	1.01.0010
▪ Tanggal
     ► Pemutakhiran   :	2026-10-29
     ► Pembuatan      :	2026-04-29
▪ Input               :	• varJSONEnvironment (json)
						------------------------------
						• varJSONData (json)
						• varJSONDataDeletion (json)
						------------------------------
▪ Output              :	varReturn (json)
▪ Deskripsi           :	• Mengeset Bulk Data
▪ Copyright           :	Zheta © 2026

----[ Related Database Object(s) ]------------------------------------------------------------------

▪ Tabel               :	-

▪ Fungsi              :	• [BE] "SchSystem"."FuncSys_General_SetPIDAndSIDOnTableEntireRecords"(varchar, smallint)
						• [BE] "SchSystem"."FuncSys_General_StrSQLExecution"(varchar)
						• [BE] "SchSystem"."FuncSys_General_StrSQLFlattenToSingleRecord"(json, character varying)
						------------------------------
						• [BE] "SchMaster"."Func_GetDataPreparation_BusinessDocument"(json)

----[ SQL Example(s) ]------------------------------------------------------------------------------

▪ --->
	SELECT
		*
	FROM
		"SchSystem"."FuncSys_General_SetBulkData"(
			...::json,
			...::json,
			...::varchar
			);

▪ ---> ( varJSONData->'data' IS NOT EMPTY )
	SELECT
		"SchSystem"."FuncSys_General_SetBulkData"(
			NULL::json,
			'{"metadata.control" : {"frontEndSchemaTableName" : "SchData-OLTP-Master.TblBusinessDocument", "functionName" : {"insertFunction" : "SchMaster.Func_TblBusinessDocument_INSERT", "updateFunction" : "SchMaster.Func_TblBusinessDocument_UPDATE"}, "functionParameterParsing" : [{"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''sysDataAnnotation''", "dataType" : "varchar"}, {"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''sysLoginSession_RefID''", "dataType" : "bigint"}, {"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''sysDataSetDateTimeTZ''", "dataType" : "timestamptz"}, {"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''sysDataValidityStartDateTimeTZ''", "dataType" : "timestamptz"}, {"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''sysDataValidityFinishDateTimeTZ''", "dataType" : "timestamptz"}, {"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''sysPartitionRemovableRecordKey_RefID''", "dataType" : "bigint"}, {"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''sysBranch_RefID''", "dataType" : "bigint"}, {"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''sysBaseCurrency_RefID''", "dataType" : "bigint"}, {"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''businessDocumentType_RefID''", "dataType" : "bigint"}, {"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''documentNumber''", "dataType" : "varchar"}, {"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''cancelationBusinessDocument_RefID''", "dataType" : "bigint"}]}, "data" : [null, {"recordID" : null, "entities" : {"sysLoginSession_RefID" : 6000000000001, "sysDataAnnotation" : null, "sysDataSetDateTimeTZ" : null, "sysDataValidityStartDateTimeTZ" : null, "sysDataValidityFinishDateTimeTZ" : null, "sysPartitionRemovableRecordKey_RefID" : null, "sysBranch_RefID" : 11000000000004, "sysBaseCurrency_RefID" : null, "businessDocumentType_RefID" : 77000000000057, "documentNumber" : "Adv/QDC/2020/000187", "cancelationBusinessDocument_RefID" : null, "additionalData" : [{"functionName" : "SchMaster.Func_TblBusinessDocumentVersion_SET_BULK", "dataLinkerName" : "businessDocument_RefID", "data" : [{"recordID" : null, "entities" : {"sysLoginSession_RefID" : 6000000000001, "sysDataAnnotation" : null, "sysDataSetDateTimeTZ" : null, "sysDataValidityStartDateTimeTZ" : null, "sysDataValidityFinishDateTimeTZ" : null, "sysPartitionRemovableRecordKey_RefID" : null, "sysBranch_RefID" : 11000000000004, "sysBaseCurrency_RefID" : null, "businessDocument_RefID" : null, "version" : 10, "documentDateTimeTZ" : "2020-02-02T00:00:00+07:00", "annotation" : null, "documentOwner_RefID" : null}}, {"recordID" : null, "entities" : {"sysLoginSession_RefID" : 6000000000001, "sysDataAnnotation" : null, "sysDataSetDateTimeTZ" : null, "sysDataValidityStartDateTimeTZ" : null, "sysDataValidityFinishDateTimeTZ" : null, "sysPartitionRemovableRecordKey_RefID" : null, "sysBranch_RefID" : 11000000000004, "sysBaseCurrency_RefID" : null, "businessDocument_RefID" : null, "version" : 0, "documentDateTimeTZ" : "2020-02-02T00:00:00+07:00", "annotation" : null, "documentOwner_RefID" : null}}]}]}}, {"recordID" : null, "entities" : {"sysLoginSession_RefID" : 6000000000001, "sysDataAnnotation" : null, "sysDataSetDateTimeTZ" : null, "sysDataValidityStartDateTimeTZ" : null, "sysDataValidityFinishDateTimeTZ" : null, "sysPartitionRemovableRecordKey_RefID" : null, "sysBranch_RefID" : 11000000000004, "sysBaseCurrency_RefID" : null, "businessDocumentType_RefID" : 77000000000097, "documentNumber" : "AdvStl/QDC/2020/000191", "cancelationBusinessDocument_RefID" : null, "additionalData" : [{"functionName" : "SchMaster.Func_TblBusinessDocumentVersion_SET_BULK", "dataLinkerName" : "businessDocument_RefID", "data" : [{"recordID" : null, "entities" : {"sysLoginSession_RefID" : 6000000000001, "sysDataAnnotation" : null, "sysDataSetDateTimeTZ" : null, "sysDataValidityStartDateTimeTZ" : null, "sysDataValidityFinishDateTimeTZ" : null, "sysPartitionRemovableRecordKey_RefID" : null, "sysBranch_RefID" : 11000000000004, "sysBaseCurrency_RefID" : null, "businessDocument_RefID" : null, "version" : 0, "documentDateTimeTZ" : "2020-03-23T00:00:00+07:00", "annotation" : null, "documentOwner_RefID" : null}}]}]}}]}'::json,
			'{}'::json
			);

▪ ---> ( varJSONData->'data' IS EMPTY )
	SELECT
		"SchSystem"."FuncSys_General_SetBulkData"(
			NULL::json,
			'{"metadata.control" : {"frontEndSchemaTableName" : "SchData-OLTP-Master.TblBusinessDocument", "functionName" : {"insertFunction" : "SchMaster.Func_TblBusinessDocument_INSERT", "updateFunction" : "SchMaster.Func_TblBusinessDocument_UPDATE"}, "functionParameterParsing" : [{"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''sysDataAnnotation''", "dataType" : "varchar"}, {"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''sysLoginSession_RefID''", "dataType" : "bigint"}, {"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''sysDataSetDateTimeTZ''", "dataType" : "timestamptz"}, {"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''sysDataValidityStartDateTimeTZ''", "dataType" : "timestamptz"}, {"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''sysDataValidityFinishDateTimeTZ''", "dataType" : "timestamptz"}, {"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''sysPartitionRemovableRecordKey_RefID''", "dataType" : "bigint"}, {"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''sysBranch_RefID''", "dataType" : "bigint"}, {"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''sysBaseCurrency_RefID''", "dataType" : "bigint"}, {"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''businessDocumentType_RefID''", "dataType" : "bigint"}, {"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''documentNumber''", "dataType" : "varchar"}, {"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''cancelationBusinessDocument_RefID''", "dataType" : "bigint"}]}, "data" : []}'::json,
			'{}'::json
			);

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varJSONEnvironment										ALIAS FOR $1;
			------------------------------
			varJSONData												ALIAS FOR $2;
			varJSONDataDeletion										ALIAS FOR $3;

		---{ Optional }-------------------

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----
			varReturn												json;

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;
			varSignExecutionTime									timestamptz;

			varSQL													varchar;
			varSQL2													varchar;

			varFrontEndSchemaTableName								varchar;
			varSchema												varchar;
			varTable												varchar;

			varJSONFunctionName										json;
			varJSONFunctionParameterParsing							json;
			varJSONData_BusDoc										json;

			varParameterParsingArray_DataSource						varchar;
			varParameterParsingArray_DataType						varchar;

			varArraySysRPK											bigint[];
			varArraySysPID											bigint[];
			varArraySysSID											bigint[];

BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignExecutionTime := CLOCK_TIMESTAMP();
		varSignEligibleToProcess := FALSE;

		IF (varSignEligibleToProcess IS FALSE) THEN
			varSignEligibleToProcess := TRUE;
		END IF;

		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------( START )-----
			IF (varSignEligibleToProcess IS TRUE) THEN
				varSignEligibleToProcess := (
					SELECT
						CASE
							WHEN (
								(("SubSQL"."JSONData"->>'data')::varchar IS NULL)
								OR
								(("SubSQL"."JSONData"->>'data')::varchar = '[]')
								) THEN
								FALSE
							ELSE
								TRUE
						END
					FROM
						(
						SELECT
							varJSONData AS "JSONData"
						) AS "SubSQL"
					);
			END IF;
		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------(  END  )-----

		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------( START )-----
			IF (varSignEligibleToProcess IS TRUE) THEN
				-----[ INPUT VARIABLES REINITIALIZATION ]-------------------------------------( START )-----
					---> Reinitializing : varJSONData
						varJSONData :=
							COALESCE (
								varJSONData,
								'{}'::json
								);

					---> Reinitializing : varJSONDataDeletion
						varJSONDataDeletion :=
							COALESCE (
								varJSONDataDeletion,
								'{}'::json
								);
				-----[ INPUT VARIABLES REINITIALIZATION ]-------------------------------------(  END  )-----

				-----[ INTERMEDIATE VARIABLES INITIALIZATION ]--------------------------------( START )-----
					---> Initializing : varFrontEndSchemaTableName
						varFrontEndSchemaTableName :=
							(varJSONData->'metadata.control'->>'frontEndSchemaTableName')::varchar;

					---> Initializing : varSchema, varTable
						IF (varFrontEndSchemaTableName IS NOT NULL) THEN
							varSQL := '
								SELECT
									REPLACE (REPLACE (REPLACE ("Data"[1], ''Data-OLTP-'', ''''), ''Data-OLAP-'', ''''), ''Data-Warehouse-'', '''') AS "SchemaName",
									"Data"[2] AS "TableName"
								FROM
									(
									SELECT
										(''{"' || (REPLACE (varFrontEndSchemaTableName, '.', '", "')) || '"}'')::varchar[] AS "Data"
									) AS "SubSQL"
								';
		
							EXECUTE
								varSQL
							INTO
								varSchema,
								varTable;
						END IF;
						--RAISE NOTICE '%', varSchema;
						--RAISE NOTICE '%', varTable;

					---> Initializing : varJSONFunctionName
						varJSONFunctionName :=
							(varJSONData->'metadata.control'->'functionName')::json;

					---> Initializing : varJSONFunctionParameterParsing
						varJSONFunctionParameterParsing :=
							(varJSONData->'metadata.control'->'functionParameterParsing')::json;

					---> Initializing : varJSONData
						varJSONData :=
							(varJSONData->'data')::json;

					---> Initializing : varParameterParsingArray_DataSource, varParameterParsingArray_DataType
						SELECT
							"SubSQL"."DataSourceArray",
							"SubSQL"."DataTypeArray"
						INTO
							varParameterParsingArray_DataSource,
							varParameterParsingArray_DataType
						FROM
							(
							SELECT
								"SubSQL"."DataSourceArray",
								"SubSQL"."DataTypeArray"
							FROM
								(
								SELECT
									CASE
										WHEN ("SubSQL"."OrderSequence" = 1) THEN
											(
											'{' ||
											STRING_AGG (
												COALESCE (('"' || REPLACE (REPLACE ("SubSQL"."DataSource", '\', '\'), '"', '\"') || '"'), 'NULL'),
												', '
												) OVER () ||
											'}'
											)
										ELSE
											NULL
									END::varchar[] AS "DataSourceArray",
									CASE
										WHEN ("SubSQL"."OrderSequence" = 1) THEN
											(
											'{' ||
											STRING_AGG (
												COALESCE (('"' || REPLACE (REPLACE ("SubSQL"."DataType", '\', '\'), '"', '\"') || '"'), 'NULL'),
												', '
												) OVER () ||
											'}'
											)
										ELSE
											NULL
									END::varchar[] AS "DataTypeArray",
									------------------------------
									"SubSQL"."OrderSequence"
								FROM
									(
									SELECT
										("SubSQL"."JSONData"->>'dataSource') AS "DataSource",
										("SubSQL"."JSONData"->>'dataType') AS "DataType",
										------------------------------
										ROW_NUMBER () OVER () AS "OrderSequence"
									FROM
										(
										SELECT
											JSON_ARRAY_ELEMENTS (
												varJSONFunctionParameterParsing::JSON
												) AS "JSONData"
										) AS "SubSQL"
									) AS "SubSQL"
								) AS "SubSQL"
							WHERE
								"SubSQL"."OrderSequence" = 1
							) AS "SubSQL"
							;
						--RAISE NOTICE '%', varParameterParsingArray_DataSource;
						--RAISE NOTICE '%', varParameterParsingArray_DataType;
				-----[ INTERMEDIATE VARIABLES INITIALIZATION ]--------------------------------(  END  )-----
			END IF;
		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------(  END  )-----

	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			-----[ PRELIMINARY ADDITIONAL DATA PROCESSING ]---------------------------( START )-----
			-----[ PRELIMINARY ADDITIONAL DATA PROCESSING ]---------------------------(  END  )-----

			-----[ MAIN DATA PROCESSING ]---------------------------------------------( START )-----
				---> Reinitilizing : varJSONDataDeletion
					IF (varJSONDataDeletion::varchar != '{}') THEN
						varSQL := '
							UPDATE
								"' || varSchema || '"."' || varTable || '"
							SET
								"Sys_Data_Delete_LoginSession_RefID" = ' || (varJSONDataDeletion->>'sysLoginSession_RefID')::varchar || '::bigint,
								"Sys_Data_Delete_DateTimeTZ" = CLOCK_TIMESTAMP()
							WHERE
								' || (varJSONDataDeletion->>'SQLSyntaxCriteria')::varchar || '; ';
						--RAISE NOTICE 'Delete : %', varSQL;
						IF (varSQL IS NOT NULL) THEN
							EXECUTE varSQL;
						END IF;
					END IF;

/*
 ||
										(
										''
										SELECT
											"SchSystem"."FuncSys_General_SetPIDAndSIDOnTableEntireRecords"(
												''''' || varFrontEndSchemaTableName || '''''::varchar,
												------------------------------
												1::smallint
												);
										''
										)
*/


				---> Reinitilizing : varArraySysRPK + (Main Data Storing)
					varSQL := '
						SELECT
							"SubSQL"."SQLSyntax",
							"SubSQL"."JSONData_BusDoc"
						FROM
							(
							SELECT
								(
								''
								SET MAX_STACK_DEPTH = ''''4MB'''';
								''
								||
								''
								SELECT
									"SubSQL"."Sys_RPKArray"
								FROM
									(
									''
									|| 
									"SubSQL"."SQLSyntax"
									||
									''
									) AS "SubSQL"
								''
								) AS "SQLSyntax",
								(
								CASE
									WHEN ("SubSQL"."SignExistBusinessDocumentVersionRefID" IS TRUE) THEN
										JSON_BUILD_OBJECT (
											''businessDocument_RefIDArray'', "SubSQL"."BusinessDocument_RefIDArray",
											''businessDocumentNumberArray'', "SubSQL"."BusinessDocumentNumberArray",
											''fullBusinessDocumentNumberArray'', "SubSQL"."FullBusinessDocumentNumberArray",
											------------------------------
											''businessDocumentType_RefIDArray'', "SubSQL"."BusinessDocumentType_RefIDArray",
											''businessDocumentTypeNameArray'', "SubSQL"."BusinessDocumentTypeNameArray",
											------------------------------
											''businessDocumentVersion_RefIDArray'', "SubSQL"."BusinessDocumentVersion_RefIDArray",
											''businessDocumentVersionArray'', "SubSQL"."BusinessDocumentVersionArray",
											''businessDocumentDateTimeTZArray'', "SubSQL"."BusinessDocumentDateTimeTZArray"
											)
									ELSE
										NULL
								END
								)::json AS "JSONData_BusDoc"
							FROM
								(
								SELECT
									"SubSQL"."SignExistBusinessDocumentVersionRefID",
									------------------------------
									CASE
										WHEN ("SubSQL"."OrderSequence" = 1) THEN
											(
											''SELECT (''''{'''' || '' ||
											STRING_AGG (
												CASE
													--WHEN (("SubSQL"."SignNull" IS TRUE) AND ("SubSQL"."SignInsertMode" IS FALSE)) THEN
													WHEN ("SubSQL"."SignNull" IS TRUE) THEN
														''''''NULL''''''
													ELSE
														(''(COALESCE (('' || "SubSQL"."SQLSyntax" || '')::varchar, ''''NULL''''::varchar))::varchar'')
												END,
												('' || '''',''''::varchar || '')
												) OVER () ||
											'' || ''''}'''')::bigint[] AS "Sys_RPKArray"'' ||
											'','' ||
											(
											''
											(
											SELECT
												"SchSystem"."FuncSys_General_SetPIDAndSIDOnTableEntireRecords"(
													''''' || varFrontEndSchemaTableName || '''''::varchar,
													------------------------------
													1::smallint
													)
											)
											''
											)
											)
										ELSE
											NULL
									END AS "SQLSyntax",
									------------------------------
									(
									CASE
										WHEN ("SubSQL"."OrderSequence" = 1) THEN
											(
											''{'' ||
											STRING_AGG (
												COALESCE (
													(''"'' || REPLACE (REPLACE ("SubSQL"."BusinessDocument_RefID"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''),
													''NULL''
													),
												'', ''
												) OVER () ||
											''}''
											)
										ELSE
											NULL
									END
									)::bigint[] AS "BusinessDocument_RefIDArray",
									(
									CASE
										WHEN ("SubSQL"."OrderSequence" = 1) THEN
											(
											''{'' ||
											STRING_AGG (
												COALESCE (
													(''"'' || REPLACE (REPLACE ("SubSQL"."BusinessDocumentNumber"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''),
													''NULL''
													),
												'', ''
												) OVER () ||
											''}''
											)
										ELSE
											NULL
									END
									)::varchar[] AS "BusinessDocumentNumberArray",
									(
									CASE
										WHEN ("SubSQL"."OrderSequence" = 1) THEN
											(
											''{'' ||
											STRING_AGG (
												COALESCE (
													(''"'' || REPLACE (REPLACE ("SubSQL"."FullBusinessDocumentNumber"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''),
													''NULL''
													),
												'', ''
												) OVER () ||
											''}''
											)
										ELSE
											NULL
									END
									)::varchar[] AS "FullBusinessDocumentNumberArray",
									------------------------------
									(
									CASE
										WHEN ("SubSQL"."OrderSequence" = 1) THEN
											(
											''{'' ||
											STRING_AGG (
												COALESCE (
													(''"'' || REPLACE (REPLACE ("SubSQL"."BusinessDocumentType_RefID"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''),
													''NULL''
													),
												'', ''
												) OVER () ||
											''}''
											)
										ELSE
											NULL
									END
									)::bigint[] AS "BusinessDocumentType_RefIDArray",
									(
									CASE
										WHEN ("SubSQL"."OrderSequence" = 1) THEN
											(
											''{'' ||
											STRING_AGG (
												COALESCE (
													(''"'' || REPLACE (REPLACE ("SubSQL"."BusinessDocumentTypeName"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''),
													''NULL''
													),
												'', ''
												) OVER () ||
											''}''
											)
										ELSE
											NULL
									END
									)::varchar[] AS "BusinessDocumentTypeNameArray",
									------------------------------
									(
									CASE
										WHEN ("SubSQL"."OrderSequence" = 1) THEN
											(
											''{'' ||
											STRING_AGG (
												COALESCE (
													(''"'' || REPLACE (REPLACE ("SubSQL"."BusinessDocumentVersion_RefID"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''),
													''NULL''
													),
												'', ''
												) OVER () ||
											''}''
											)
										ELSE
											NULL
									END
									)::bigint[] AS "BusinessDocumentVersion_RefIDArray",
									(
									CASE
										WHEN ("SubSQL"."OrderSequence" = 1) THEN
											(
											''{'' ||
											STRING_AGG (
												COALESCE (
													(''"'' || REPLACE (REPLACE ("SubSQL"."BusinessDocumentVersion"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''),
													''NULL''
													),
												'', ''
												) OVER () ||
											''}''
											)
										ELSE
											NULL
									END
									)::smallint[] AS "BusinessDocumentVersionArray",
									(
									CASE
										WHEN ("SubSQL"."OrderSequence" = 1) THEN
											(
											''{'' ||
											STRING_AGG (
												COALESCE (
													(''"'' || REPLACE (REPLACE ("SubSQL"."BusinessDocumentDateTimeTZ"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''),
													''NULL''
													),
												'', ''
												) OVER () ||
											''}''
											)
										ELSE
											NULL
									END
									)::timestamptz[] AS "BusinessDocumentDateTimeTZArray",
									------------------------------
									"SubSQL"."OrderSequence"
								FROM
									(
									SELECT
										"SubSQL"."SignNull",
										"SubSQL"."SignInsertMode",
										"SubSQL"."SignExistBusinessDocumentVersionRefID",
										------------------------------
										"SubSQL"."SQLSyntax",
										------------------------------
										"SubSQL"."BusinessDocument_RefID",
										"SubSQL"."BusinessDocumentNumber",
										"SubSQL"."FullBusinessDocumentNumber",
										------------------------------
										"SubSQL"."BusinessDocumentType_RefID",
										"SubSQL"."BusinessDocumentTypeName",
										------------------------------
										"SubSQL"."BusinessDocumentVersion_RefID",
										"SubSQL"."BusinessDocumentVersion",
										"SubSQL"."BusinessDocumentDateTimeTZ",
										------------------------------
										"SubSQL"."OrderSequence"
									FROM
										(
										SELECT
											"SubSQL"."SignNull",
											"SubSQL"."SignInsertMode",
											"SubSQL"."SignExistBusinessDocumentVersionRefID",
											------------------------------
											(
											''
											SELECT
												"SignRecordID"
											FROM
												''
												||
												(
												CASE
													---> INSERT MODE
													WHEN ("SubSQL"."RecordID" IS NULL ) THEN
														''
														"' || REPLACE ((varJSONFunctionName->>'insertFunction')::varchar, '.', '"."') || '"(
														''
													---> UPDATE MODE
													ELSE
														''
														"' || REPLACE ((varJSONFunctionName->>'updateFunction')::varchar, '.', '"."') || '"(
														''
												END
												)
												||
												''
													'' ||
														REPLACE (
															"SubSQL"."SQLSyntax",
															''<<ZhtTag::DynamicDataType>>'',
															CASE
																WHEN ("SubSQL"."RecordID" IS NULL) THEN
																	''varchar''
																ELSE
																	''bigint''
															END
															) ||
													''
													)
											''
											) AS "SQLSyntax",
											------------------------------
											"SubSQL"."BusinessDocument_RefID",
											"SubSQL"."BusinessDocumentNumber",
											"SubSQL"."FullBusinessDocumentNumber",
											------------------------------
											"SubSQL"."BusinessDocumentType_RefID",
											"SubSQL"."BusinessDocumentTypeName",
											------------------------------
											"SubSQL"."BusinessDocumentVersion_RefID",
											"SubSQL"."BusinessDocumentVersion",
											"SubSQL"."BusinessDocumentDateTimeTZ",
											------------------------------
											"SubSQL"."OrderSequence"
										FROM
											(
											SELECT
												"SubSQL"."SignNull",
												"SubSQL"."SignInsertMode",
												"SubSQL"."SignExistBusinessDocumentVersionRefID",
												------------------------------
												"SubSQL"."RecordID",
												CASE
													WHEN ("SubSQL"."SignNull" IS TRUE) THEN
														NULL
													ELSE
														(
														'
														||
														(
														SELECT
															(
															"InnerSubSQL"."SQLSyntax"
															)
														FROM
															(
															SELECT
																CASE
																	WHEN ("InnerSubSQL"."OrderSequence" = 1) THEN
																		STRING_AGG (
																			(
																				(
																				('(COALESCE (' || '('''''''' || ' || '"SubSQL"."Parameter_' || 
																					(
																					CASE
																						WHEN ("InnerSubSQL"."OrderSequence" = 1) THEN
																							'Dynamic'::varchar
																						WHEN ("InnerSubSQL"."OrderSequence" = 3) THEN
																							'3_Replacement'::varchar
																						WHEN ("InnerSubSQL"."OrderSequence" = 4) THEN
																							'4_Replacement'::varchar
																						WHEN ("InnerSubSQL"."OrderSequence" = 5) THEN
																							'5_Replacement'::varchar
																						ELSE
																							"InnerSubSQL"."OrderSequence"::varchar
																					END
																					) || 
																					'"::varchar' || ' || '''''''')' || ', ''NULL''))')::varchar ||
																					' || (''::' || 
																					(CASE WHEN ("InnerSubSQL"."OrderSequence" = 1) THEN '<<ZhtTag::DynamicDataType>>'::varchar ELSE "InnerSubSQL"."DataType"::varchar END) || 
																					''')'
																				)
																			),
																			(' || '', '' || ')
																			) OVER ()
																	ELSE
																		NULL
																END AS "SQLSyntax",
																------------------------------
																"InnerSubSQL"."OrderSequence"
															FROM
																(
																SELECT
																	"InnerSubSQL"."DataType",
																	------------------------------
																	"InnerSubSQL"."OrderSequence"
																FROM
																	(
																	SELECT
																		"InnerSubSQL"."DataType",
																		------------------------------
																		ROW_NUMBER () OVER () AS "OrderSequence"
																	FROM
																		(
																		SELECT
																			UNNEST (varParameterParsingArray_DataType::varchar[]) AS "DataType"
																		) AS "InnerSubSQL"
																	) AS "InnerSubSQL"
																) AS "InnerSubSQL"
															) AS "InnerSubSQL"
														WHERE
															"InnerSubSQL"."OrderSequence" = 1
														)
														||
														'::varchar
														)
												END AS "SQLSyntax",
												------------------------------
												"SubSQL"."BusinessDocument_RefID",
												"SubSQL"."BusinessDocumentNumber",
												"SubSQL"."FullBusinessDocumentNumber",
												------------------------------
												"SubSQL"."BusinessDocumentType_RefID",
												"SubSQL"."BusinessDocumentTypeName",
												------------------------------
												"SubSQL"."BusinessDocumentVersion_RefID",
												"SubSQL"."BusinessDocumentVersion",
												"SubSQL"."BusinessDocumentDateTimeTZ",
												------------------------------
												"SubSQL"."OrderSequence"
											FROM
												(
												-----[ MAIN DATA ]-----( START )-----
												SELECT
													CASE
														WHEN ("SubSQL"."SignNull" IS TRUE) THEN
															NULL
														ELSE
															(
															CASE
																WHEN ("SubSQL"."RecordID" IS NULL) THEN
																	"SubSQL"."Parameter_1"::varchar
																ELSE
																	"SubSQL"."RecordID"::varchar
															END
															)
													END AS "Parameter_Dynamic",
													/*
													CASE
														WHEN ("SubSQL"."SignNull" IS TRUE) THEN
															NULL
														ELSE
															(
															CASE
																WHEN ("SubSQL"."RecordID" IS NULL) THEN
																	"SubSQL"."Parameter_1"::varchar
																ELSE
																	"SubSQL"."RecordID"::varchar
															END
															)
													END AS "Parameter_BusDocVersion",												
													*/
													CASE
														WHEN ("SubSQL"."SignNull" IS TRUE) THEN
															NULL
														ELSE
															(
															COALESCE (
																"SubSQL"."Parameter_3"::varchar,
																CLOCK_TIMESTAMP()::varchar
																)
															)
													END AS "Parameter_3_Replacement",
													CASE
														WHEN ("SubSQL"."SignNull" IS TRUE) THEN
															NULL
														ELSE
															(
															COALESCE (
																"SubSQL"."Parameter_4"::varchar,
																''0001-01-01 00:00:00+00''::timestamptz::varchar
																)
															)
													END AS "Parameter_4_Replacement",
													CASE
														WHEN ("SubSQL"."SignNull" IS TRUE) THEN
															NULL
														ELSE
															(
															COALESCE (
																"SubSQL"."Parameter_5"::varchar,
																''9999-12-31 23:59:59+00''::timestamptz::varchar
																)
															)
													END AS "Parameter_5_Replacement",
													------------------------------
													*
												FROM
													(
													SELECT
														"SubSQL"."SignNull",
														"SubSQL"."SignInsertMode",
														"SubSQL"."SignExistBusinessDocumentVersionRefID",
														------------------------------
														("SubSQL"."JSONData"->>''recordID'')::bigint AS "RecordID",
														------------------------------
														'
														||
														(
														SELECT
															"SubSQL"."SQLSyntax"
														FROM
															(
															SELECT
																CASE
																	WHEN ("SubSQL"."OrderSequence" = 1) THEN
																		(
																		STRING_AGG (
																			("SubSQL"."SQLSyntax" || ' AS "Parameter_' || "SubSQL"."OrderSequence" || '"'),
																			', '
																			) OVER ()
																		)
																	ELSE
																		NULL
																END::varchar AS "SQLSyntax",
																------------------------------
																"SubSQL"."OrderSequence"
															FROM
																(
																SELECT
																	(
																	'(REPLACE ((' ||
																		"SubSQL"."DataSource" 
																		|| 
																		')::varchar, '''''''', '''''''''''')::' || "SubSQL"."DataType" || ')') AS "SQLSyntax",
																	------------------------------
																	"SubSQL"."OrderSequence"
																FROM
																	(
																	SELECT
																		CASE
																			WHEN ("SubSQL"."DataSource" ILIKE '%->>''businessDocumentVersion_RefID''') THEN
																				'"SubSQL"."BusinessDocumentVersion_RefIDReplacement"'
																			ELSE
																				"SubSQL"."DataSource"
																		END AS "DataSource",
																		"SubSQL"."DataType",
																		------------------------------
																		ROW_NUMBER () OVER () AS "OrderSequence"
																	FROM
																		(
																		SELECT
																			UNNEST (varParameterParsingArray_DataSource::varchar[]) AS "DataSource",
																			UNNEST (varParameterParsingArray_DataType::varchar[]) AS "DataType"
																		) AS "SubSQL"
																	) AS "SubSQL"
																) AS "SubSQL"
															) AS "SubSQL"
														WHERE
															"SubSQL"."OrderSequence" = 1
														)
														||
														',
														------------------------------
														"SubSQL"."BusinessDocument_RefID",
														"SubSQL"."BusinessDocumentNumber",
														"SubSQL"."FullBusinessDocumentNumber",
														------------------------------
														"SubSQL"."BusinessDocumentType_RefID",
														"SubSQL"."BusinessDocumentTypeName",
														------------------------------
														"SubSQL"."BusinessDocumentVersion_RefID",
														"SubSQL"."BusinessDocumentVersion",
														"SubSQL"."BusinessDocumentDateTimeTZ",
														------------------------------
														"SubSQL"."OrderSequence"
													FROM
														(
														SELECT
															"SubSQL"."SignNull",
															"SubSQL"."SignInsertMode",
															"SubSQL"."SignExistBusinessDocumentVersionRefID",
															"SubSQL"."SignKeyPositionBusinessDocumentVersionRefID",
															------------------------------
															"SubSQL"."BusinessDocumentVersion_RefIDReplacement",
															------------------------------
															"SubSQL"."BusinessDocument_RefID",
															"SubSQL"."BusinessDocumentNumber",
															"SubSQL"."FullBusinessDocumentNumber",
															------------------------------
															"SubSQL"."BusinessDocumentType_RefID",
															"SubSQL"."BusinessDocumentTypeName",
															------------------------------
															"SubSQL"."BusinessDocumentVersion_RefID",
															"SubSQL"."BusinessDocumentVersion",
															"SubSQL"."BusinessDocumentDateTimeTZ",
															------------------------------
															"SubSQL"."JSONData",
															------------------------------
															"SubSQL"."OrderSequence"
														FROM
															(
															SELECT
																UNNEST ("SubSQL"."SignNullArray") AS "SignNull",
																UNNEST ("SubSQL"."SignInsertModeArray") AS "SignInsertMode",
																"SubSQL"."SignExistBusinessDocumentVersionRefID",
																"SubSQL"."SignKeyPositionBusinessDocumentVersionRefID",
																------------------------------
																UNNEST ("SubSQL"."BusinessDocumentVersion_RefIDReplacementArray") AS "BusinessDocumentVersion_RefIDReplacement",
																------------------------------
																UNNEST ("SubSQL"."BusinessDocument_RefIDArray") AS "BusinessDocument_RefID",
																UNNEST ("SubSQL"."BusinessDocumentNumberArray") AS "BusinessDocumentNumber",
																UNNEST ("SubSQL"."FullBusinessDocumentNumberArray") AS "FullBusinessDocumentNumber",
																------------------------------
																UNNEST ("SubSQL"."BusinessDocumentType_RefIDArray") AS "BusinessDocumentType_RefID",
																UNNEST ("SubSQL"."BusinessDocumentTypeNameArray") AS "BusinessDocumentTypeName",
																------------------------------
																UNNEST ("SubSQL"."BusinessDocumentVersion_RefIDArray") AS "BusinessDocumentVersion_RefID",
																UNNEST ("SubSQL"."BusinessDocumentVersionArray") AS "BusinessDocumentVersion",
																UNNEST ("SubSQL"."BusinessDocumentDateTimeTZArray") AS "BusinessDocumentDateTimeTZ",
																------------------------------
																(UNNEST ("SubSQL"."JSONDataArray"))::json AS "JSONData",
																------------------------------
																UNNEST ("SubSQL"."OrderSequenceArray") AS "OrderSequence"
															FROM
																(
																SELECT
																	"SubSQL"."SignNullArray",
																	"SubSQL"."SignInsertModeArray",
																	"SubSQL"."SignExistBusinessDocumentVersionRefID",
																	"SubSQL"."SignKeyPositionBusinessDocumentVersionRefID",
																	------------------------------
																	("SubSQL"."JSONData_BusDoc"->>''businessDocumentVersion_RefIDArray'')::varchar::bigint[] AS "BusinessDocumentVersion_RefIDReplacementArray",
																	------------------------------
																	("SubSQL"."JSONData_BusDoc"->>''businessDocument_RefIDArray'')::varchar::bigint[] AS "BusinessDocument_RefIDArray",
																	("SubSQL"."JSONData_BusDoc"->>''businessDocumentNumberArray'')::varchar::varchar[] AS "BusinessDocumentNumberArray",
																	("SubSQL"."JSONData_BusDoc"->>''fullBusinessDocumentNumberArray'')::varchar::varchar[] AS "FullBusinessDocumentNumberArray",
																	------------------------------
																	("SubSQL"."JSONData_BusDoc"->>''businessDocumentType_RefIDArray'')::varchar::bigint[] AS "BusinessDocumentType_RefIDArray",
																	("SubSQL"."JSONData_BusDoc"->>''businessDocumentTypeNameArray'')::varchar::varchar[] AS "BusinessDocumentTypeNameArray",
																	------------------------------
																	("SubSQL"."JSONData_BusDoc"->>''businessDocumentVersion_RefIDArray'')::varchar::bigint[] AS "BusinessDocumentVersion_RefIDArray",
																	("SubSQL"."JSONData_BusDoc"->>''businessDocumentVersionArray'')::varchar::smallint[] AS "BusinessDocumentVersionArray",
																	("SubSQL"."JSONData_BusDoc"->>''businessDocumentDateTimeTZArray'')::varchar::timestamptz[] AS "BusinessDocumentDateTimeTZArray",
																	------------------------------
																	"SubSQL"."JSONDataArray",
																	------------------------------
																	"SubSQL"."OrderSequenceArray"
																FROM
																	(
																	SELECT
																		"SubSQL"."StrSQLBusDoc",
																		------------------------------
																		"SubSQL"."SignNullArray",
																		"SubSQL"."SignInsertModeArray",
																		"SubSQL"."SignExistBusinessDocumentVersionRefID",
																		"SubSQL"."SignKeyPositionBusinessDocumentVersionRefID",
																		------------------------------
																		(
																		CASE
																			WHEN (
																				("SubSQL"."SignExistBusinessDocumentVersionRefID" IS TRUE) AND
																				("SubSQL"."StrSQLBusDoc" IS NOT NULL)
																				) THEN
																				(
																				SELECT
																					JSON_BUILD_OBJECT (
																						''businessDocument_RefIDArray'', "InnerSubSQL"."BusinessDocument_RefIDArray"::varchar,
																						''businessDocumentNumberArray'', "InnerSubSQL"."BusinessDocumentNumberArray"::varchar,
																						''fullBusinessDocumentNumberArray'', "InnerSubSQL"."FullBusinessDocumentNumberArray"::varchar,
																						------------------------------
																						''businessDocumentType_RefIDArray'', "InnerSubSQL"."BusinessDocumentType_RefIDArray"::varchar,
																						''businessDocumentTypeNameArray'', "InnerSubSQL"."BusinessDocumentTypeNameArray"::varchar,
																						------------------------------
																						''businessDocumentVersion_RefIDArray'', "InnerSubSQL"."BusinessDocumentVersion_RefIDArray"::varchar,
																						''businessDocumentVersionArray'', "InnerSubSQL"."BusinessDocumentVersionArray"::varchar,
																						''businessDocumentDateTimeTZArray'', "InnerSubSQL"."BusinessDocumentDateTimeTZArray"::varchar,
																						------------------------------
																						''orderSequenceArray'', "InnerSubSQL"."OrderSequenceArray"::varchar
																					) AS "JSONData_BusDoc"
																				FROM
																					(
																					SELECT
																						"InnerSubSQL"."BusinessDocument_RefIDArray",
																						"InnerSubSQL"."BusinessDocumentNumberArray",
																						"InnerSubSQL"."FullBusinessDocumentNumberArray",
																						------------------------------
																						"InnerSubSQL"."BusinessDocumentType_RefIDArray",
																						"InnerSubSQL"."BusinessDocumentTypeNameArray",
																						------------------------------
																						"InnerSubSQL"."BusinessDocumentVersion_RefIDArray",
																						"InnerSubSQL"."BusinessDocumentVersionArray",
																						"InnerSubSQL"."BusinessDocumentDateTimeTZArray",
																						------------------------------
																						"InnerSubSQL"."OrderSequenceArray"
																					FROM
																						(
																						SELECT
																							CASE
																								WHEN ("InnerSubSQL"."OrderSequence" = 1) THEN
																									(
																									''{'' ||
																									STRING_AGG (
																										COALESCE (
																											(''"'' || REPLACE (REPLACE ("InnerSubSQL"."BusinessDocument_RefID"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''),
																											''NULL''::varchar
																											),
																										'', ''
																										) OVER () ||
																									''}''
																									)
																								ELSE
																									NULL
																							END::bigint[] AS "BusinessDocument_RefIDArray",
																							CASE
																								WHEN ("InnerSubSQL"."OrderSequence" = 1) THEN
																									(
																									''{'' ||
																									STRING_AGG (
																										COALESCE (
																											(''"'' || REPLACE (REPLACE ("InnerSubSQL"."BusinessDocumentNumber"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''),
																											''NULL''::varchar
																											),
																										'', ''
																										) OVER () ||
																									''}''
																									)
																								ELSE
																									NULL
																							END::varchar[] AS "BusinessDocumentNumberArray",
																							CASE
																								WHEN ("InnerSubSQL"."OrderSequence" = 1) THEN
																									(
																									''{'' ||
																									STRING_AGG (
																										COALESCE (
																											(''"'' || REPLACE (REPLACE ("InnerSubSQL"."FullBusinessDocumentNumber"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''),
																											''NULL''::varchar
																											),
																										'', ''
																										) OVER () ||
																									''}''
																									)
																								ELSE
																									NULL
																							END::varchar[] AS "FullBusinessDocumentNumberArray",
																							------------------------------
																							CASE
																								WHEN ("InnerSubSQL"."OrderSequence" = 1) THEN
																									(
																									''{'' ||
																									STRING_AGG (
																										COALESCE (
																											(''"'' || REPLACE (REPLACE ("InnerSubSQL"."BusinessDocumentType_RefID"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''),
																											''NULL''::varchar
																											),
																										'', ''
																										) OVER () ||
																									''}''
																									)
																								ELSE
																									NULL
																							END::bigint[] AS "BusinessDocumentType_RefIDArray",
																							CASE
																								WHEN ("InnerSubSQL"."OrderSequence" = 1) THEN
																									(
																									''{'' ||
																									STRING_AGG (
																										COALESCE (
																											(''"'' || REPLACE (REPLACE ("InnerSubSQL"."BusinessDocumentTypeName"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''),
																											''NULL''::varchar
																											),
																										'', ''
																										) OVER () ||
																									''}''
																									)
																								ELSE
																									NULL
																							END::varchar[] AS "BusinessDocumentTypeNameArray",
																							------------------------------
																							CASE
																								WHEN ("InnerSubSQL"."OrderSequence" = 1) THEN
																									(
																									''{'' ||
																									STRING_AGG (
																										COALESCE (
																											(''"'' || REPLACE (REPLACE ("InnerSubSQL"."BusinessDocumentVersion_RefID"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''),
																											''NULL''::varchar
																											),
																										'', ''
																										) OVER () ||
																									''}''
																									)
																								ELSE
																									NULL
																							END::bigint[] AS "BusinessDocumentVersion_RefIDArray",
																							CASE
																								WHEN ("InnerSubSQL"."OrderSequence" = 1) THEN
																									(
																									''{'' ||
																									STRING_AGG (
																										COALESCE (
																											(''"'' || REPLACE (REPLACE ("InnerSubSQL"."BusinessDocumentVersion"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''),
																											''NULL''::varchar
																											),
																										'', ''
																										) OVER () ||
																									''}''
																									)
																								ELSE
																									NULL
																							END::smallint[] AS "BusinessDocumentVersionArray",
																							CASE
																								WHEN ("InnerSubSQL"."OrderSequence" = 1) THEN
																									(
																									''{'' ||
																									STRING_AGG (
																										COALESCE (
																											(''"'' || REPLACE (REPLACE ("InnerSubSQL"."BusinessDocumentDateTimeTZ"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''),
																											''NULL''::varchar
																											),
																										'', ''
																										) OVER () ||
																									''}''
																									)
																								ELSE
																									NULL
																							END::timestamptz[] AS "BusinessDocumentDateTimeTZArray",
																							------------------------------
																							CASE
																								WHEN ("InnerSubSQL"."OrderSequence" = 1) THEN
																									(
																									''{'' ||
																									STRING_AGG (
																										COALESCE (
																											(''"'' || REPLACE (REPLACE ("InnerSubSQL"."OrderSequence"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''),
																											''NULL''::varchar
																											),
																										'', ''
																										) OVER () ||
																									''}''
																									)
																								ELSE
																									NULL
																							END::bigint[] AS "OrderSequenceArray"
																						FROM
																							(
																							SELECT
																								("InnerSubSQL"."JSONDataBusDoc"->>''businessDocument_RefID'')::bigint AS "BusinessDocument_RefID",
																								("InnerSubSQL"."JSONDataBusDoc"->>''businessDocumentNumber'')::varchar AS "BusinessDocumentNumber",
																								(
																									("InnerSubSQL"."JSONDataBusDoc"->>''businessDocumentNumber'')::varchar ||
																									CASE
																										WHEN (("InnerSubSQL"."JSONDataBusDoc"->>''businessDocumentVersion'')::smallint IS NOT NULL) THEN
																											('' (Version : '' || ("InnerSubSQL"."JSONDataBusDoc"->>''businessDocumentVersion'')::varchar || '')'')
																										ELSE
																											''''
																									END
																								) "FullBusinessDocumentNumber",
																								------------------------------
																								("InnerSubSQL"."JSONDataBusDoc"->>''businessDocumentType_RefID'')::bigint AS "BusinessDocumentType_RefID",
																								("InnerSubSQL"."JSONDataBusDoc"->>''businessDocumentTypeName'')::varchar AS "BusinessDocumentTypeName",
																								------------------------------
																								("InnerSubSQL"."JSONDataBusDoc"->>''businessDocumentVersion_RefID'')::bigint AS "BusinessDocumentVersion_RefID",
																								("InnerSubSQL"."JSONDataBusDoc"->>''businessDocumentVersion'')::smallint AS "BusinessDocumentVersion",
																								("InnerSubSQL"."JSONDataBusDoc"->>''businessDocumentDateTimeTZ'')::timestamptz AS "BusinessDocumentDateTimeTZ",
																								------------------------------
																								ROW_NUMBER () OVER () AS "OrderSequence"
																							FROM
																								(
																								SELECT
																									JSON_ARRAY_ELEMENTS (
																										"InnerSubSQL"."JSONDataBusDoc"
																										) AS "JSONDataBusDoc"
																								FROM
																									"SchSystem"."FuncSys_General_StrSQLExecution"(
																										"SubSQL"."StrSQLBusDoc"
																										) AS "InnerSubSQL" (
																											"JSONDataBusDoc" json
																											)
																								) AS "InnerSubSQL"
																							) AS "InnerSubSQL"
																						LIMIT 1
																						) AS "InnerSubSQL"
																					) AS "InnerSubSQL"
																				)
																			ELSE
																				NULL
																		END
																		) AS "JSONData_BusDoc",
																		------------------------------
																		"SubSQL"."JSONDataArray",
																		------------------------------
																		"SubSQL"."OrderSequenceArray"
																	FROM
																		(
																		SELECT
																			"SubSQL"."StrSQLBusDocArray"[1] AS "StrSQLBusDoc",
																			------------------------------
																			"SubSQL"."SignNullArray",
																			"SubSQL"."SignInsertModeArray",
																			"SubSQL"."SignExistBusinessDocumentVersionRefIDArray"[1] AS "SignExistBusinessDocumentVersionRefID",
																			"SubSQL"."SignKeyPositionBusinessDocumentVersionRefIDArray"[1] AS "SignKeyPositionBusinessDocumentVersionRefID",
																			------------------------------
																			"SubSQL"."JSONDataArray",
																			------------------------------
																			"SubSQL"."OrderSequenceArray"
																		FROM
																			"SchSystem"."FuncSys_General_StrSQLExecution"(
																				(
																				'
																				||
																				'
																				SELECT
																					"SchSystem"."FuncSys_General_StrSQLFlattenToSingleRecord"(
																						(
																						JSON_BUILD_OBJECT (
																							''sortFieldName'', ''SubSQL.OrderSequence'',
																							''structures'',
																								JSON_BUILD_ARRAY (
																									JSON_BUILD_OBJECT (
																										''name'', ''StrSQLBusDoc'',
																										''dataType'', ''varchar''
																										),
																									JSON_BUILD_OBJECT (
																										''name'', ''SignNull'',
																										''dataType'', ''boolean''
																										),
																									JSON_BUILD_OBJECT (
																										''name'', ''SignInsertMode'',
																										''dataType'', ''boolean''
																										),
																									JSON_BUILD_OBJECT (
																										''name'', ''SignExistBusinessDocumentVersionRefID'',
																										''dataType'', ''boolean''
																										),
																									JSON_BUILD_OBJECT (
																										''name'', ''SignKeyPositionBusinessDocumentVersionRefID'',
																										''dataType'', ''bigint''
																										),
																									JSON_BUILD_OBJECT (
																										''name'', ''JSONData'',
																										''dataType'', ''json''
																										),
																									JSON_BUILD_OBJECT (
																										''name'', ''OrderSequence'',
																										''dataType'', ''bigint''
																										)
																									)
																							)
																						),
																						'''
																						||
																						REPLACE (
																							'
																							SELECT
																								"SubSQL"."StrSQLBusDoc",
																								------------------------------
																								"SubSQL"."SignNull",
																								"SubSQL"."SignInsertMode",
																								"SubSQL"."SignExistBusinessDocumentVersionRefID",
																								"SubSQL"."SignKeyPositionBusinessDocumentVersionRefID",
																								------------------------------
																								"SubSQL"."JSONData",
																								------------------------------
																								"SubSQL"."OrderSequence"
																							FROM
																								(
																								SELECT
																									(
																									CASE
																										WHEN (
																											("SubSQL"."OrderSequence" = 1) AND
																											("SubSQL"."SignExistBusinessDocumentVersionRefID" IS TRUE) AND
																											((SELECT ("SubSQL"."JSONData")::jsonb ? ''entitiesMetaData'') IS TRUE) AND
																											((SELECT ("SubSQL"."JSONData"->''entitiesMetaData'')::jsonb ? ''businessDocumentTypeName'') IS TRUE) AND
																											((SELECT ("SubSQL"."JSONData"->''entitiesMetaData'')::jsonb ? ''documentDate'') IS TRUE)
																											) THEN
																												(
																												''
																												SELECT
																													"SchMaster"."Func_GetDataPreparation_BusinessDocument" (''''
																												''
																												||
																												(
																												''['' ||
																												STRING_AGG (
																													(
																													CASE
																														WHEN (
																															--("SubSQL"."SignInsertMode" IS TRUE) AND
																															((SELECT ("SubSQL"."JSONData")::jsonb ? ''entitiesMetaData'') IS TRUE) AND
																															((SELECT ("SubSQL"."JSONData"->''entitiesMetaData'')::jsonb ? ''businessDocumentTypeName'') IS TRUE) AND
																															((SELECT ("SubSQL"."JSONData"->''entitiesMetaData'')::jsonb ? ''documentDate'') IS TRUE)
																															) THEN
																																(
																																JSON_BUILD_OBJECT (
																																	''recordID'', ("SubSQL"."JSONData"->''entities''->>''businessDocumentVersion_RefID'')::bigint,
																																	''entities'', JSON_BUILD_OBJECT (
																																		''branch_RefID'', ("SubSQL"."JSONData"->''entities''->>''sysBranch_RefID'')::bigint,
																																		''businessDocumentTypeName'', ("SubSQL"."JSONData"->''entitiesMetaData''->>''businessDocumentTypeName'')::varchar,
																																		''documentDate'', ("SubSQL"."JSONData"->''entitiesMetaData''->>''documentDate'')::date
																																		)
																																	)
																																)::varchar
																														ELSE
																															''null''
																													END
																													)::varchar,
																													'', ''
																													) OVER () ||
																												'']''
																												)::json::varchar
																												||
																												''
																												''''::json
																												)
																												''
																												)
																										ELSE
																											NULL
																									END::varchar
																									) AS "StrSQLBusDoc",
																									------------------------------
																									"SubSQL"."SignNull",
																									"SubSQL"."SignInsertMode",
																									"SubSQL"."SignExistBusinessDocumentVersionRefID",
																									"SubSQL"."SignKeyPositionBusinessDocumentVersionRefID",
																									------------------------------
																									"SubSQL"."JSONData",
																									------------------------------
																									"SubSQL"."OrderSequence"
																								FROM
																									(
																									SELECT
																										"SubSQL"."SignNull",
																										"SubSQL"."SignInsertMode",
																										"SubSQL"."SignExistBusinessDocumentVersionRefID",
																										"SubSQL"."SignKeyPositionBusinessDocumentVersionRefID",
																										------------------------------
																										JSON_BUILD_OBJECT (
																											''recordID'', "SubSQL"."JSONData"->''recordID'',
																											''entitiesMetaData'', "SubSQL"."JSONData"->''entitiesMetaData'',
																											''entities'', 
																												(
																												SELECT
																													"InnerSubSQL"."JSONDataEntities"
																												FROM
																													(
																													SELECT
																														CASE
																															WHEN ("InnerSubSQL"."InnerOrderSequence" = 1) THEN
																																(
																																''{''
																																||
																																STRING_AGG (
																																	SUBSTRING ("InnerSubSQL"."JSONDataEntities"::varchar, 2, (LENGTH("InnerSubSQL"."JSONDataEntities"::varchar) - 2)),
																																	'',''
																																	) OVER ()
																																||
																																''}''
																																)
																															ELSE
																																NULL
																														END::json AS "JSONDataEntities"
																													FROM
																														(
																														SELECT
																															JSON_BUILD_OBJECT (
																																("InnerSubSQL"."JSONDataEntities"->>''key'')::varchar,
																																"InnerSubSQL"."JSONDataEntities"->''value''
																																) AS "JSONDataEntities",
																															------------------------------
																															ROW_NUMBER () OVER (
																																ORDER BY
																																	"InnerSubSQL"."InnerOrderSequence" ASC
																																) AS "InnerOrderSequence"
																														FROM
																															(
																															SELECT
																																CASE
																																	WHEN (("InnerSubSQL"."RecordID" IS NULL) AND ("InnerSubSQL"."JSONDataEntities"->>''key'' = ''businessDocumentVersion_RefID'')) THEN
																																		JSON_BUILD_OBJECT (
																																			''key'', "InnerSubSQL"."JSONDataEntities"->>''key'',
																																			''value'', NULL
																																			)
																																	ELSE
																																		"InnerSubSQL"."JSONDataEntities"
																																END AS "JSONDataEntities",
																																------------------------------
																																ROW_NUMBER () OVER () AS "InnerOrderSequence"
																															FROM
																																(
																																SELECT
																																	("InnerSubSQL"."JSONDataEntities"->>''recordID'')::bigint AS "RecordID",
																																	ROW_TO_JSON (JSON_EACH ("InnerSubSQL"."JSONDataEntities"->''entities'')) AS "JSONDataEntities"
																																FROM
																																	(
																																	SELECT
																																		"SubSQL"."JSONData" AS "JSONDataEntities"
																																	) AS "InnerSubSQL"
																																) AS "InnerSubSQL"
																															) AS "InnerSubSQL"
																														) AS "InnerSubSQL"
																													LIMIT 1
																													) AS "InnerSubSQL"
																												)
																										) AS "JSONData",
																										------------------------------
																										"SubSQL"."OrderSequence"
																									FROM
																										(
																										SELECT
																											"SubSQL"."SignNull",
																											"SubSQL"."SignInsertMode",
																											"SubSQL"."SignExistBusinessDocumentVersionRefID",
																											CASE
																												WHEN ("SubSQL"."SignExistBusinessDocumentVersionRefID" IS TRUE) THEN
																													(
																													SELECT
																														"InnerSubSQL"."OrderSequence"
																													FROM
																														(
																														SELECT
																															"InnerSubSQL"."Key",
																															ROW_NUMBER () OVER () AS "OrderSequence"
																														FROM
																															(
																															SELECT
																																JSON_OBJECT_KEYS("SubSQL"."JSONData"->''entities'') AS "Key"
																															) AS "InnerSubSQL"
																														) AS "InnerSubSQL"
																													WHERE
																														"InnerSubSQL"."Key" = ''businessDocumentVersion_RefID''
																													LIMIT 1
																													)
																												ELSE
																													NULL
																											END AS "SignKeyPositionBusinessDocumentVersionRefID",
																											------------------------------
																											"SubSQL"."JSONData",
																											------------------------------
																											"SubSQL"."OrderSequence"
																										FROM
																											(
																											SELECT
																												"SubSQL"."SignNull",
																												"SubSQL"."SignInsertMode",
																												CASE
																													WHEN (SUM ("SubSQL"."SignExistBusinessDocumentVersionRefID") OVER () > 0) THEN
																														TRUE
																													ELSE
																														FALSE
																												END::boolean AS "SignExistBusinessDocumentVersionRefID",
																												------------------------------
																												"SubSQL"."JSONData",
																												------------------------------
																												"SubSQL"."OrderSequence"
																											FROM
																												(
																												SELECT
																													CASE
																														WHEN ("SubSQL"."JSONData"::varchar = ''null'') THEN
																															TRUE
																														ELSE
																															FALSE
																													END AS "SignNull",
																													CASE
																														WHEN (("SubSQL"."JSONData"->>''recordID'')::bigint IS NULL) THEN
																															TRUE
																														ELSE
																															FALSE
																													END AS "SignInsertMode",
																													CASE
																														WHEN ((SELECT ("SubSQL"."JSONData"->''entities'')::jsonb ? ''businessDocumentVersion_RefID'') IS TRUE) THEN
																															1
																														ELSE
																															0
																													END AS "SignExistBusinessDocumentVersionRefID",
																													------------------------------
																													"SubSQL"."JSONData",
																													------------------------------
																													ROW_NUMBER () OVER () AS "OrderSequence"
																												FROM
																													(
																													SELECT
																														JSON_ARRAY_ELEMENTS (
																															"SubSQL"."JSONData"
																															) AS "JSONData"
																													FROM
																														(
																														SELECT
																															''' || REPLACE (varJSONData::varchar, '''', '''''') || '''::json AS "JSONData"
																														) AS "SubSQL"
																													) AS "SubSQL"
																												) AS "SubSQL"
																											) AS "SubSQL"
																										) AS "SubSQL"
																									) AS "SubSQL"
																								) AS "SubSQL"
																							',
																							'''',
																							''''''
																							)
																						||
																						'''
																						)
																				)
																				'
																				||
																				'
																				) AS "SubSQL" (
																					"StrSQLBusDocArray" varchar[],
																					------------------------------
																					"SignNullArray" boolean[],
																					"SignInsertModeArray" boolean[],
																					"SignExistBusinessDocumentVersionRefIDArray" boolean[],
																					"SignKeyPositionBusinessDocumentVersionRefIDArray" bigint[],
																					------------------------------
																					"JSONDataArray" json[],
																					------------------------------
																					"OrderSequenceArray" bigint[]
																					)
																		) AS "SubSQL"
																	) AS "SubSQL"
																) AS "SubSQL"
															) AS "SubSQL"
														) AS "SubSQL"
													) AS "SubSQL"
												-----[ MAIN DATA ]-----(  END  )-----
												) AS "SubSQL"
											) AS "SubSQL"
										) AS "SubSQL"
									) AS "SubSQL"
								) AS "SubSQL"
							LIMIT 1
							) AS "SubSQL"
						';
					--RAISE NOTICE '%', varSQL;
					EXECUTE
						varSQL
					INTO
						varSQL,
						varJSONData_BusDoc;
					--RAISE NOTICE '%', varSQL;
					--RAISE NOTICE '%', varJSONData_BusDoc;

					IF (varSQL IS NOT NULL) THEN
						EXECUTE
							varSQL
						INTO
							varArraySysRPK;
						--RAISE NOTICE '%', varArraySysRPK;
					END IF;

				---> Reinitilizing : varArraySysPID, varArraySysSID
					varSQL := '
						SELECT
							"SubSQL"."Sys_PIDArray",
							"SubSQL"."Sys_SIDArray"
						FROM
							(
							SELECT
								CASE
									WHEN ("SubSQL"."OrderSequence" = 1) THEN
										(
										''{'' ||
										STRING_AGG (
											COALESCE ((''"'' || REPLACE (REPLACE ("SubSQL"."Sys_PID"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''), ''NULL''),
											'', ''
											) OVER () ||
										''}''
										)
									ELSE
										NULL
								END::bigint[] AS "Sys_PIDArray",
								CASE
									WHEN ("SubSQL"."OrderSequence" = 1) THEN
										(
										''{'' ||
										STRING_AGG (
											COALESCE ((''"'' || REPLACE (REPLACE ("SubSQL"."Sys_SID"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''), ''NULL''),
											'', ''
											) OVER () ||
										''}''
										)
									ELSE
										NULL
								END::bigint[] AS "Sys_SIDArray"
							FROM
								(
								SELECT
									"VirtTblData"."Sys_PID",
									"VirtTblData"."Sys_SID",
									"SubSQL"."Sys_RPK",
									------------------------------
									ROW_NUMBER () OVER (
										ORDER BY
											"SubSQL"."OrderSequence" ASC
										) AS "OrderSequence"
								FROM
									(
									SELECT
										"Sys_RPK",
										------------------------------
										ROW_NUMBER () OVER () AS "OrderSequence"
									FROM
										UNNEST (''' || COALESCE (varArraySysRPK::varchar, '{null}') || '''::bigint[]) AS "Sys_RPK"
									) AS "SubSQL"
										LEFT JOIN
											"' || varSchema || '"."' || varTable || '" AS "VirtTblData"
												ON
													"SubSQL"."Sys_RPK" = "VirtTblData"."Sys_RPK"
								) AS "SubSQL"
							LIMIT 1
							) AS "SubSQL"
						';
					--RAISE NOTICE 'varSQL %', varSQL;
					EXECUTE
						varSQL
					INTO
						varArraySysPID,
						varArraySysSID;
					--RAISE NOTICE 'varArraySysPID %', varArraySysPID;
					--RAISE NOTICE 'varArraySysSID %', varArraySysSID;

				---> Update Detail Based On Additional Data
					varSQL := '
						SELECT
							"SubSQL"."SQLSyntax"
						FROM
							(
							SELECT
								CASE
									WHEN ("SubSQL"."FilterSequence" = 1) THEN
										STRING_AGG (
											"SubSQL"."SQLSyntax",
											''
											'') OVER (
												)
									ELSE
										NULL
								END AS "SQLSyntax",
								------------------------------
								"SubSQL"."OrderSequence",
								ROW_NUMBER () OVER (
									ORDER BY
										"SubSQL"."OrderSequenceOverAll" ASC
									) AS "OrderSequenceOverAll"
							FROM
								(
								SELECT
									"SubSQL"."SysLoginSession_RefID",
									"SubSQL"."RecordID",
									------------------------------
									"SubSQL"."SQLSyntax",
									------------------------------
									ROW_NUMBER () OVER (
										ORDER BY
											"SubSQL"."OrderSequenceOverAll" ASC
										) AS "FilterSequence",
									"SubSQL"."OrderSequence",
									"SubSQL"."OrderSequenceExpansion",
									ROW_NUMBER () OVER (
										ORDER BY
											"SubSQL"."OrderSequenceOverAll" ASC
										) AS "OrderSequenceOverAll"
								FROM
									(
									SELECT
										"SubSQL"."SysLoginSession_RefID",
										"SubSQL"."RecordID",
										------------------------------
										''
										SELECT
											'' || (''"'' || REPLACE ("SubSQL"."FunctionName", ''.'', ''"."'') || ''"'') || ''(
												''''{}'''',
												'''''' || REPLACE ("SubSQL"."JSONData"::varchar, '''''''', '''''''''''') || ''''''::json,
												JSON_BUILD_OBJECT (
													''''sysLoginSession_RefID'''', '' || "SubSQL"."SysLoginSession_RefID" || ''::bigint,
													''''SQLSyntaxCriteria'''', '''''' || REPLACE ("SubSQL"."SQLSyntax_Delete"::varchar, '''''''', '''''''''''') || ''''''::varchar
													)
												);
										''::varchar AS "SQLSyntax",
										------------------------------
										"SubSQL"."OrderSequence",
										"SubSQL"."OrderSequenceExpansion",
										ROW_NUMBER () OVER (
											ORDER BY
												"SubSQL"."OrderSequenceOverAll" ASC
											) AS "OrderSequenceOverAll"
									FROM
										(
										SELECT
											"SubSQL"."SignExistAdditionalData",
											"SubSQL"."SignExistBusinessDocumentVersionRefID",
											------------------------------
											"SubSQL"."SysLoginSession_RefID",
											"SubSQL"."RecordID",
											------------------------------
											"SubSQL"."FunctionName",
											------------------------------
											"SubSQL"."SQLSyntax_Delete",
											------------------------------
											(
											CASE
												WHEN (("SubSQL"."SignExistAdditionalData" IS TRUE) AND ("SubSQL"."FunctionName" IS NOT NULL) AND ("SubSQL"."JSONData" IS NULL)) THEN
													''[]''::json
												ELSE
													"SubSQL"."JSONData"
											END
											) AS "JSONData",
											------------------------------
											"SubSQL"."FilterSequence",
											"SubSQL"."OrderSequence",
											"SubSQL"."OrderSequenceExpansion",
											ROW_NUMBER () OVER (
												ORDER BY
													"SubSQL"."OrderSequenceOverAll"
												) AS "OrderSequenceOverAll"
										FROM
											(
											SELECT
												"SubSQL"."SignExistAdditionalData",
												"SubSQL"."SignExistBusinessDocumentVersionRefID",
												------------------------------
												"SubSQL"."SysLoginSession_RefID",
												"SubSQL"."RecordID",
												------------------------------
												CASE
													WHEN ("SubSQL"."FilterSequence" = 1) THEN
														"SubSQL"."FunctionName"
													ELSE
														NULL
												END::varchar AS "FunctionName",
												------------------------------
												CASE
													WHEN ("SubSQL"."FilterSequence" = 1) THEN
														(
														''('' ||
														STRING_AGG (
															"SubSQL"."SQLSyntax_Delete",
															''
															OR 
															''
															) OVER (
																PARTITION BY
																	"SubSQL"."FunctionName"
																) ||
														'')''
														)
													ELSE
														NULL
												END::varchar AS "SQLSyntax_Delete",
												------------------------------
												CASE
													WHEN ("SubSQL"."FilterSequence" = 1) THEN
														(
														''['' ||
														STRING_AGG (
															"SubSQL"."JSONDataVarChar"::varchar,
															'',''
															) OVER (
																PARTITION BY
																	"SubSQL"."FunctionName"
																) ||
														'']''
														)
													ELSE
														NULL
												END::json AS "JSONData",
												------------------------------
												"SubSQL"."FilterSequence",
												"SubSQL"."OrderSequence",
												"SubSQL"."OrderSequenceExpansion",
												"SubSQL"."OrderSequenceOverAll"
											FROM
												(
												SELECT
													"SubSQL"."SignExistAdditionalData",
													"SubSQL"."SignExistBusinessDocumentVersionRefID",
													------------------------------
													"SubSQL"."SysLoginSession_RefID",
													"SubSQL"."RecordID",
													------------------------------
													"SubSQL"."FunctionName",
													------------------------------
													"SubSQL"."SQLSyntax_Delete",
													------------------------------
													"SubSQL"."JSONDataVarChar",
													------------------------------
													"SubSQL"."FilterSequence",
													"SubSQL"."OrderSequence",
													"SubSQL"."OrderSequenceExpansion",
													ROW_NUMBER () OVER (
														ORDER BY
															"SubSQL"."OrderSequenceOverAll" ASC
														) AS "OrderSequenceOverAll"
												FROM
													(
													SELECT
														"SubSQL"."SignExistAdditionalData",
														"SubSQL"."SignExistBusinessDocumentVersionRefID",
														------------------------------
														"SubSQL"."SysLoginSession_RefID",
														"SubSQL"."RecordID",
														------------------------------
														"SubSQL"."FunctionName",
														------------------------------
														"SubSQL"."SQLSyntax_Delete",
														------------------------------
														"SubSQL"."JSONDataVarChar",
														------------------------------
														ROW_NUMBER () OVER (
															PARTITION BY
																"SubSQL"."FunctionName"
															ORDER BY
																"SubSQL"."OrderSequence" ASC,
																"SubSQL"."OrderSequenceExpansion" ASC,
																"SubSQL"."OrderSequenceOverAll" ASC
															) AS "FilterSequence",
														"SubSQL"."OrderSequence",
														"SubSQL"."OrderSequenceExpansion",
														ROW_NUMBER () OVER (
															ORDER BY
																"SubSQL"."OrderSequence" ASC,
																"SubSQL"."OrderSequenceExpansion" ASC,
																"SubSQL"."OrderSequenceOverAll" ASC
															) AS "OrderSequenceOverAll"
													FROM
														(
														SELECT
															"SubSQL"."SignExistAdditionalData",
															"SubSQL"."SignExistBusinessDocumentVersionRefID",
															------------------------------
															"SubSQL"."SysLoginSession_RefID",
															"SubSQL"."RecordID",
															------------------------------
															"SubSQL"."FunctionName",
															------------------------------
															/*
															CASE
																WHEN (("SubSQL2"."RecordPID" IS NULL) AND ("SubSQL2"."RecordSID" IS NULL)) THEN
																	NULL
																ELSE*/
																	(
																		''
																		(
																		"Sys_Data_Delete_DateTimeTZ" IS NULL
																		AND
																			(
																				("'' || "SubSQL"."DataLinkerName" || ''" = '' || COALESCE ("SubSQL"."DataLinkerName_RefPID", 0::bigint) || ''::bigint)
																				OR
																				("'' || "SubSQL"."DataLinkerName" || ''" = '' || COALESCE ("SubSQL"."DataLinkerName_RefSID", 0::bigint) || ''::bigint)
																			)
																		AND
																			(
																			"Sys_PID" NOT IN (
																				SELECT
																					UNNEST('' || '''''''' || "SubSQL"."ExistingDetailRecordIDArray"::varchar || '''''''' || ''::bigint[])
																				)
																			AND
																			"Sys_SID" NOT IN (
																				SELECT
																					UNNEST('' || '''''''' || "SubSQL"."ExistingDetailRecordIDArray"::varchar || '''''''' || ''::bigint[])
																				)
																			)
																		)
																		''
																	)::varchar AS "SQLSyntax_Delete",
															--END::varchar AS "SQLSyntax_Delete",
															------------------------------
															(
															CASE
																WHEN ("SubSQL"."JSONDataVarChar"::varchar = ''null'') THEN
																	"SubSQL"."JSONDataVarChar"
																ELSE
																	REPLACE (
																		REPLACE (
																			"SubSQL"."JSONDataVarChar"::varchar,
																			''"<<ZhtTagDataLinker>>"''::varchar,
																			COALESCE (
																				"SubSQL"."DataLinkerName_RefPID"::varchar,
																				"SubSQL"."DataLinkerName_RefSID"::varchar
																				)
																			)::varchar,
																		''"<<ZhtTagLoginSessionRefID>>"''::varchar,
																		COALESCE (
																			"SubSQL"."SysLoginSession_RefID"::varchar,
																			''6000000000001''::varchar
																			)
																		)
															END
															) AS "JSONDataVarChar",
															------------------------------
															"SubSQL"."OrderSequence",
															"SubSQL"."OrderSequenceExpansion",
															"SubSQL"."OrderSequenceOverAll"
														FROM
															(
															SELECT
																"SubSQL"."SignExistAdditionalData",
																"SubSQL"."SignExistBusinessDocumentVersionRefID",
																------------------------------
																"SubSQL"."SysLoginSession_RefID",
																"SubSQL"."MainRecordID" AS "RecordID",
																------------------------------
																"SubSQL"."FunctionName",
																"SubSQL"."DataLinkerName",
																------------------------------
																"SubSQL"."DataLinkerName_RefPID",
																"SubSQL"."DataLinkerName_RefSID",
																------------------------------
																"SubSQL"."ExistingDetailRecordIDArray",
																------------------------------
																CASE
																	WHEN ("SubSQL"."JSONDataVarChar" != '''') THEN
																		"SubSQL"."JSONDataVarChar"
																	ELSE
																		NULL
																END AS "JSONDataVarChar",
																------------------------------
																"SubSQL"."OrderSequence",
																"SubSQL"."OrderSequenceExpansion",
																ROW_NUMBER () OVER (
																	ORDER BY
																		"SubSQL"."OrderSequenceOverAll"
																	) AS "OrderSequenceOverAll"
															FROM
																(
																SELECT
																	"SubSQL"."SignExistAdditionalData",
																	"SubSQL"."SignExistBusinessDocumentVersionRefID",
																	------------------------------
																	"SubSQL"."SysLoginSession_RefID",
																	"SubSQL"."MainRecordID",
																	------------------------------
																	"SubSQL"."FunctionName",
																	"SubSQL"."DataLinkerName",
																	------------------------------
																	"SubSQL"."DataLinkerName_RefPID",
																	"SubSQL"."DataLinkerName_RefSID",
																	------------------------------
																	CASE
																		WHEN ("SubSQL"."OrderSequenceExpansion2" = 1) THEN
																			(
																			''{'' ||
																			COALESCE (
																				STRING_AGG (
																					(''"'' || REPLACE (REPLACE ("SubSQL"."DetailRecordID"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''),
																					'', ''
																					) OVER (
																						PARTITION BY
																							"SubSQL"."OrderSequence",
																							"SubSQL"."OrderSequenceExpansion",
																							"SubSQL"."FunctionName"
																						),
																				''''
																				) ||
																			''}''
																			)
																		ELSE
																			NULL
																	END::bigint[] AS "ExistingDetailRecordIDArray",
																	------------------------------
																	CASE
																		WHEN ("SubSQL"."OrderSequenceExpansion2" = 1) THEN
																			(
																			COALESCE (
																				STRING_AGG (
																					COALESCE (
																						"SubSQL"."JSONData"::varchar,
																						''null''::varchar
																						),
																					'', ''
																					) OVER (
																						PARTITION BY
																							"SubSQL"."OrderSequence",
																							"SubSQL"."OrderSequenceExpansion",
																							"SubSQL"."FunctionName"
																						),
																				''''
																				)
																			)
																		ELSE
																			NULL
																	END::varchar AS "JSONDataVarChar",
																	------------------------------
																	"SubSQL"."OrderSequence",
																	"SubSQL"."OrderSequenceExpansion",
																	"SubSQL"."OrderSequenceExpansion2",
																	"SubSQL"."OrderSequenceOverAll"
																FROM
																	(
																	-----[ MAIN DATA ]-----( START )-----
																	SELECT
																		"SubSQL"."SignExistAdditionalData",
																		"SubSQL"."SignExistBusinessDocumentVersionRefID",
																		------------------------------
																		"SubSQL"."SysLoginSession_RefID",
																		"SubSQL"."MainRecordID",
																		------------------------------
																		"SubSQL"."FunctionName",
																		"SubSQL"."DataLinkerName",
																		------------------------------
																		"SubSQL"."DataLinkerName_RefPID",
																		"SubSQL"."DataLinkerName_RefSID",
																		------------------------------
																		("JSONData"->>''recordID'')::bigint AS "DetailRecordID",
																		------------------------------
																		"SubSQL"."JSONData",
																		------------------------------
																		"SubSQL"."OrderSequence",
																		"SubSQL"."OrderSequenceExpansion",
																		"SubSQL"."OrderSequenceExpansion2",
																		"SubSQL"."OrderSequenceOverAll"
																	FROM
																		(
																		SELECT
																			"SubSQL"."SignExistAdditionalData",
																			"SubSQL"."SignExistBusinessDocumentVersionRefID",
																			------------------------------
																			"SubSQL"."SysLoginSession_RefID",
																			"SubSQL"."MainRecordID",
																			------------------------------
																			"SubSQL"."FunctionName",
																			"SubSQL"."DataLinkerName",
																			------------------------------
																			"SubSQL"."DataLinkerName_RefPID",
																			"SubSQL"."DataLinkerName_RefSID",
																			------------------------------
																			("JSONData"->>''recordID'')::bigint AS "DetailRecordID",
																			------------------------------
																			"SubSQL"."JSONData",
																			------------------------------
																			"SubSQL"."OrderSequence",
																			"SubSQL"."OrderSequenceExpansion",
																			"SubSQL"."OrderSequenceExpansion2",
																			"SubSQL"."OrderSequenceOverAll"
																		FROM
																			(
																			SELECT
																				"SubSQL"."SignExistAdditionalData",
																				"SubSQL"."SignExistBusinessDocumentVersionRefID",
																				------------------------------
																				"SubSQL"."SysLoginSession_RefID",
																				"SubSQL"."MainRecordID",
																				------------------------------
																				"SubSQL"."FunctionName",
																				"SubSQL"."DataLinkerName",
																				------------------------------
																				"SubSQL"."DataLinkerName_RefPID",
																				"SubSQL"."DataLinkerName_RefSID",
																				------------------------------
																				CASE
																					WHEN ("SubSQL"."Entities" IS NOT NULL) THEN
																						JSON_BUILD_OBJECT (
																							''recordID'', "SubSQL"."RecordID",
																							''entities'', "SubSQL"."Entities"
																							)
																					ELSE
																						NULL::json
																				END AS "JSONData",
																				------------------------------
																				"SubSQL"."OrderSequence",
																				"SubSQL"."OrderSequenceExpansion",
																				"SubSQL"."OrderSequenceExpansion2",
																				"SubSQL"."OrderSequenceOverAll"
																			FROM
																				(
																				SELECT
																					"SubSQL"."SignExistAdditionalData",
																					"SubSQL"."SignExistBusinessDocumentVersionRefID",
																					------------------------------
																					"SubSQL"."SysLoginSession_RefID",
																					"SubSQL"."MainRecordID",
																					------------------------------
																					"SubSQL"."FunctionName",
																					"SubSQL"."DataLinkerName",
																					------------------------------
																					"SubSQL"."DataLinkerName_RefPID",
																					"SubSQL"."DataLinkerName_RefSID",
																					------------------------------
																					"SubSQL"."RecordID",
																					(
																					SELECT
																						CASE
																							WHEN ("InnerSubSQL"."OrderSequence" = 1) THEN
																								(
																								''{'' ||
																								STRING_AGG (
																									(''"'' || "InnerSubSQL"."Key" || ''" : '' || (CASE WHEN (UPPER("InnerSubSQL"."Key") = UPPER(''sysLoginSession_RefID'')) THEN ''"<<ZhtTagLoginSessionRefID>>"'' WHEN (UPPER("InnerSubSQL"."Key") = UPPER("SubSQL"."DataLinkerName")) THEN ''"<<ZhtTagDataLinker>>"'' ELSE "InnerSubSQL"."Value" END)::varchar),
																									'', ''
																									) OVER () ||
																								 ''}''
																								 )::json
																							ELSE
																								NULL
																						END
																					FROM
																						(
																						SELECT
																							"InnerSubSQL"."key" AS "Key",
																							"InnerSubSQL"."value" AS "Value",
																							------------------------------
																							ROW_NUMBER () OVER () AS "OrderSequence"
																						FROM
																							JSON_EACH ("SubSQL"."Entities") AS "InnerSubSQL"
																						) AS "InnerSubSQL"
																					LIMIT 1
																					) AS "Entities",
																					------------------------------
																					"SubSQL"."OrderSequence",
																					"SubSQL"."OrderSequenceExpansion",
																					"SubSQL"."OrderSequenceExpansion2",
																					"SubSQL"."OrderSequenceOverAll"
																				FROM
																					(
																					SELECT
																						"SubSQL"."SignExistAdditionalData",
																						"SubSQL"."SignExistBusinessDocumentVersionRefID",
																						------------------------------
																						"SubSQL"."SysLoginSession_RefID",
																						"SubSQL"."MainRecordID",
																						------------------------------
																						"SubSQL"."FunctionName",
																						"SubSQL"."DataLinkerName",
																						------------------------------
																						"SubSQL"."DataLinkerName_RefPID",
																						"SubSQL"."DataLinkerName_RefSID",
																						------------------------------
																						"SubSQL"."JSONData",
																						"SubSQL"."JSONData"->''recordID'' AS "RecordID",
																						"SubSQL"."JSONData"->''entities'' AS "Entities",
																						------------------------------
																						"SubSQL"."OrderSequence",
																						"SubSQL"."OrderSequenceExpansion",
																						ROW_NUMBER () OVER (
																							PARTITION BY
																								"SubSQL"."OrderSequence",
																								"SubSQL"."OrderSequenceExpansion",
																								"SubSQL"."FunctionName"
																							ORDER BY
																								"SubSQL"."OrderSequenceOverAll" ASC
																							) AS "OrderSequenceExpansion2",
																						ROW_NUMBER () OVER (
																							ORDER BY
																								"SubSQL"."OrderSequenceOverAll" ASC
																							) AS "OrderSequenceOverAll"
																					FROM
																						(
																						SELECT
																							"SubSQL"."SignExistAdditionalData",
																							"SubSQL"."SignExistBusinessDocumentVersionRefID",
																							------------------------------
																							"SubSQL"."SysLoginSession_RefID",
																							"SubSQL"."MainRecordID",
																							------------------------------
																							"SubSQL"."FunctionName",
																							(
																							CASE
																								WHEN (LENGTH ("SubSQL"."DataLinkerName") < 2) THEN
																									UPPER (SUBSTR ("SubSQL"."DataLinkerName", 1, 1))
																								ELSE
																									CASE
																										WHEN (SUBSTR ("SubSQL"."DataLinkerName", 2, 1) = UPPER (SUBSTR ("SubSQL"."DataLinkerName", 2, 1))) THEN
																											SUBSTR ("SubSQL"."DataLinkerName", 1, 1)
																										ELSE
																											UPPER (SUBSTR ("SubSQL"."DataLinkerName", 1, 1))
																									END
																							END ||
																							SUBSTR ("SubSQL"."DataLinkerName", 2, LENGTH ("SubSQL"."DataLinkerName") - 1)
																							) AS "DataLinkerName",
																							------------------------------
																							"SubSQL"."DataLinkerName_RefPID",
																							"SubSQL"."DataLinkerName_RefSID",
																							------------------------------
																							JSON_ARRAY_ELEMENTS (
																								COALESCE (
																									CASE
																										WHEN (JSON_ARRAY_LENGTH ("SubSQL"."JSONData") = 0) THEN
																											''[null]''::json
																										ELSE
																											"SubSQL"."JSONData"
																									END,
																									''[null]''::json
																									)
																								) AS "JSONData",
																							------------------------------
																							"SubSQL"."OrderSequence",
																							"SubSQL"."OrderSequenceExpansion",
																							ROW_NUMBER () OVER (
																								ORDER BY
																									"SubSQL"."OrderSequenceOverAll" ASC
																								) AS "OrderSequenceOverAll"
																						FROM
																							(
																							SELECT
																								"SubSQL"."SignExistAdditionalData",
																								"SubSQL"."SignExistBusinessDocumentVersionRefID",
																								------------------------------
																								"SubSQL"."SysLoginSession_RefID",
																								"SubSQL"."MainRecordID",
																								------------------------------
																								"SubSQL"."FunctionName",
																								"SubSQL"."DataLinkerName",
																								------------------------------
																								"SubSQL"."DataLinkerName_RefPID",
																								"SubSQL"."DataLinkerName_RefSID",
																								------------------------------
																								(
																								CASE
																									WHEN ((JSON_ARRAY_LENGTH("SubSQL"."JSONData") = 0) AND ("SubSQL"."SignExistAdditionalData" IS TRUE)) THEN
																										NULL::json
																									ELSE
																										"SubSQL"."JSONData"
																								END
																								) AS "JSONData",
																								------------------------------
																								"SubSQL"."OrderSequence",
																								"SubSQL"."OrderSequenceExpansion",
																								"SubSQL"."OrderSequenceOverAll"
																							FROM
																								(
																								SELECT
																									"SubSQL"."SignExistAdditionalData",
																									"SubSQL"."SignExistBusinessDocumentVersionRefID",
																									------------------------------
																									"SubSQL"."SysLoginSession_RefID",
																									"SubSQL"."MainRecordID",
																									------------------------------
																									("SubSQL"."JSONData"->>''functionName'')::varchar AS "FunctionName",
																									("SubSQL"."JSONData"->>''dataLinkerName'')::varchar AS "DataLinkerName",
																									------------------------------
																									"SubSQL"."DataLinkerName_RefPID",
																									"SubSQL"."DataLinkerName_RefSID",
																									------------------------------
																									("SubSQL"."JSONData"->''data'')::json AS "JSONData",
																									------------------------------
																									"SubSQL"."OrderSequence",
																									ROW_NUMBER () OVER (
																										PARTITION BY
																											"SubSQL"."OrderSequence",
																											("SubSQL"."JSONData"->>''functionName'')::varchar
																										ORDER BY
																											"SubSQL"."OrderSequenceOverAll" ASC
																										) AS "OrderSequenceExpansion",
																									ROW_NUMBER () OVER (
																										ORDER BY
																											"SubSQL"."OrderSequenceOverAll" ASC
																										) AS "OrderSequenceOverAll"
																								FROM
																									(
																									SELECT
																										"SubSQL"."SignExistAdditionalData",
																										"SubSQL"."SignExistBusinessDocumentVersionRefID",
																										------------------------------
																										"SubSQL"."DataLinkerName_RefPID",
																										"SubSQL"."DataLinkerName_RefSID",
																										------------------------------
																										"SubSQL"."SysLoginSession_RefID",
																										"SubSQL"."MainRecordID",
																										------------------------------
																										"SubSQL"."JSONData",
																										------------------------------
																										"SubSQL"."OrderSequence",
																										ROW_NUMBER () OVER (
																											ORDER BY
																												"SubSQL"."OrderSequence" ASC
																											) AS "OrderSequenceOverAll"
																									FROM
																										(
																										SELECT
																											"SubSQL"."SignExistAdditionalData",
																											"SubSQL"."SignExistBusinessDocumentVersionRefID",
																											------------------------------
																											"SubSQL"."DataLinkerName_RefPID",
																											"SubSQL"."DataLinkerName_RefSID",
																											------------------------------
																											"SubSQL"."SysLoginSession_RefID",
																											"SubSQL"."MainRecordID",
																											------------------------------
																											JSON_ARRAY_ELEMENTS ("SubSQL"."JSONData") AS "JSONData",
																											------------------------------
																											"SubSQL"."OrderSequence"
																										FROM
																											(
																											SELECT
																												"SubSQL"."SignExistAdditionalData",
																												"SubSQL"."SignExistBusinessDocumentVersionRefID",
																												------------------------------
																												"SubSQL"."DataLinkerName_RefPID",
																												"SubSQL"."DataLinkerName_RefSID",
																												------------------------------
																												("SubSQL"."JSONData"->''entities''->>''sysLoginSession_RefID'')::bigint AS "SysLoginSession_RefID",
																												("SubSQL"."JSONData"->>''recordID'')::bigint AS "MainRecordID",
																												------------------------------
																												COALESCE (
																													("SubSQL"."JSONData"->''entities''->''additionalData''),
																													''[null]''::json
																													) AS "JSONData",
																												------------------------------
																												ROW_NUMBER () OVER (
																													ORDER BY
																														"SubSQL"."OrderSequence" ASC
																													) AS "OrderSequence"
																											FROM
																												(
																												SELECT
																													(SELECT ("SubSQL"."JSONData"->''entities'')::jsonb ? ''additionalData'') AS "SignExistAdditionalData",
																													(SELECT ("SubSQL"."JSONData"->''entities'')::jsonb ? ''businessDocumentVersion_RefID'') AS "SignExistBusinessDocumentVersionRefID",
																													------------------------------
																													"SubSQL2"."RecordPID" AS "DataLinkerName_RefPID",
																													"SubSQL2"."RecordSID" AS "DataLinkerName_RefSID",
																													------------------------------
																													"SubSQL"."JSONData",
																													------------------------------
																													"SubSQL"."OrderSequence"
																												FROM
																													(
																													SELECT
																														"SubSQL"."JSONData",
																														------------------------------
																														ROW_NUMBER () OVER () AS "OrderSequence"
																													FROM
																														(
																														SELECT
																															JSON_ARRAY_ELEMENTS (
																																"SubSQL"."JSONData"
																																) AS "JSONData"
																														FROM
																															(
																															SELECT
																																' ||
																																(
																																SELECT
																																	('''' || REPLACE (varJSONData::varchar, '''', '''''') || '''')::varchar
																																)::varchar ||
																																'::json AS "JSONData"
																															) AS "SubSQL"
																														) AS "SubSQL"
																													) AS "SubSQL"
																														LEFT JOIN
																															(
																															SELECT
																																"SubSQL"."RecordPID",
																																"SubSQL"."RecordSID",
																																------------------------------
																																ROW_NUMBER () OVER () AS "OrderSequence"
																															FROM
																																(
																																SELECT
																																	UNNEST (''' || varArraySysPID::varchar || '''::bigint[]) AS "RecordPID",
																																	UNNEST (''' || varArraySysSID::varchar || '''::bigint[]) AS "RecordSID"
																																) AS "SubSQL"
																															) AS "SubSQL2"
																																ON
																																	"SubSQL"."OrderSequence" = "SubSQL2"."OrderSequence"
																												) AS "SubSQL"
																											) AS "SubSQL"
																										) AS "SubSQL"
																									) AS "SubSQL"
																								) AS "SubSQL"
																							) AS "SubSQL"
																						) AS "SubSQL"
																					) AS "SubSQL"
																				) AS "SubSQL"
																			) AS "SubSQL"
																		) AS "SubSQL"
																	-----[ MAIN DATA ]-----( START )-----
																	) AS "SubSQL"
																) AS "SubSQL"
															WHERE
																"SubSQL"."OrderSequenceExpansion2" = 1
															) AS "SubSQL"
														) AS "SubSQL"
													) AS "SubSQL"
												) AS "SubSQL"
											) AS "SubSQL"
										) AS "SubSQL"
									WHERE
										"SubSQL"."FilterSequence" = 1
									) AS "SubSQL"
								) AS "SubSQL"
							LIMIT 1
							) AS "SubSQL"
						';

					--RAISE NOTICE '%', varSQL;
					EXECUTE varSQL INTO varSQL;
					--RAISE NOTICE 'varSQL : %', varSQL;
					IF (varSQL IS NOT NULL) THEN
						EXECUTE varSQL;
					END IF;

				---> Initializing : varReturn
					IF (varArraySysPID::varchar = '{NULL}') THEN
						varArraySysPID := '{}'::bigint[];
					END IF;
				
					varReturn :=
						JSON_BUILD_OBJECT (
							'status', 'Success',
							'executionTime', (CLOCK_TIMESTAMP() - varSignExecutionTime),
							'impactedRecords',
								JSON_BUILD_OBJECT (
									'dataCount', CARDINALITY (varArraySysPID),
									'PIDList', varArraySysPID
									),
							'additionalData',
								(
								CASE
									WHEN (varJSONData_BusDoc IS NOT NULL) THEN
										JSON_BUILD_OBJECT (
											'businessDocument', varJSONData_BusDoc
											)
									ELSE
										NULL								
								END
								)
							);
					--RAISE NOTICE '%', varReturn;

			-----[ MAIN DATA PROCESSING ]---------------------------------------------(  END  )-----

			-----[ AFTERWARDS ADDITIONAL DATA PROCESSING ]----------------------------( START )-----
			-----[ AFTERWARDS ADDITIONAL DATA PROCESSING ]----------------------------(  END  )-----

		ELSE
			varReturn :=
				JSON_BUILD_OBJECT (
					'status', 'Success',
					'executionTime', (CLOCK_TIMESTAMP() - varSignExecutionTime),
					'impactedRecords',
						JSON_BUILD_OBJECT (
							'dataCount', 0,
							'PIDList', NULL
							),
					'additionalData', NULL
					);
		END IF;

	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----
		RETURN
			varReturn;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		EXCEPTION
			WHEN OTHERS THEN
				RETURN
					JSON_BUILD_OBJECT (
						'status', 'Failed',
						'executionTime', (CLOCK_TIMESTAMP() - varSignExecutionTime),
						'impactedRecords',
							JSON_BUILD_OBJECT (
								'dataCount', NULL,
								'PIDList', NULL
								),
						'additionalData', NULL
						);

END;
$_$;


ALTER FUNCTION "SchSystem"."FuncSys_General_SetBulkData"(json, json, json) OWNER TO "SysAdmin";

--
-- TOC entry 410 (class 1255 OID 6653837)
-- Name: FuncSys_General_SetDataIntegrityShadow(character varying, bigint); Type: FUNCTION; Schema: SchSystem; Owner: SysAdmin
--

CREATE FUNCTION "SchSystem"."FuncSys_General_SetDataIntegrityShadow"(character varying, bigint) RETURNS character varying
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchSystem"."FuncSys_General_SetDataIntegrityShadow"
▪ Versi               :	1.00.0001
▪ Tanggal
     ► Pemutakhiran   :	2026-04-29
     ► Pembuatan      :	2026-04-23
▪ Input               :	• varSchemaTable (varchar - Mandatory)
						• varID (bigint - Mandatory)
						------------------------------
						------------------------------
						------------------------------
▪ Output              :	varReturn (varchar)
▪ Keterkaitan Fungsi  : • "SchSystem"."FuncSys_General_GetDataIntegrityShadow"(varchar, bigint)
▪ Deskripsi           :	• Mengeset Data Integrity Shadow dari Record berdasarkan Nama SchemaTable
						  (varSchemaTable) dan Record ID (varID).
▪ Copyright           :	Zheta © 2026

----[ SQL Example(s) ]------------------------------------------------------------------------------

▪ --->
	SELECT
		"SchSystem"."FuncSys_General_SetDataIntegrityShadow"(
			'SchFinance.TblDebitNote'::varchar,
			240000000000001::bigint
			);

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varSchemaTable									 		ALIAS FOR $1;
			varID 													ALIAS FOR $2;
			------------------------------

		---{ Optional }-------------------

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----
			varReturn												varchar;

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

			varSchema												varchar;
			varTable												varchar;

			varSQL													varchar;
			varShadow												varchar;

		---{ Additional }-----------------

BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------( START )-----
			IF (varSignEligibleToProcess IS FALSE) THEN
				varSignEligibleToProcess := TRUE;
			END IF;
		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------(  END  )-----

		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------( START )-----
			IF (varSignEligibleToProcess IS TRUE) THEN
				---> Initializing : varSchema, varTable
					varSQL := '
						SELECT
							"Data"[1] AS "SchemaName",
							"Data"[2] AS "TableName"
						FROM
							(
							SELECT
								(''{"' || (REPLACE(varSchemaTable, '.', '", "')) || '"}'')::varchar[] AS "Data"
							) AS "SubSQL"
						';

					EXECUTE
						varSQL
					INTO
						varSchema,
						varTable;
					--RAISE NOTICE '%', varSchema;
					--RAISE NOTICE '%', varTable;
			END IF;
		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------(  END  )-----

	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			-----[ MAIN DATA PROCESSING ]---------------------------------------------( START )-----
				---> Initiaiizing : varShadow
					varShadow := (
						SELECT
							"SchSystem"."FuncSys_General_GetDataIntegrityShadow"(
								varSchemaTable::varchar,
								varID::bigint
								)
						);

				---> Update : Field "Sys_DataIntegrityShadow"
					IF (varShadow IS NOT NULL) THEN
						varSQL := '
							UPDATE
								"' || varSchema || '"."' || varTable || '"
							SET
								"Sys_DataIntegrityShadow" = ''' || varShadow || '''::varchar(32)
							WHERE
								CASE
									WHEN ((' || varID || '::bigint / 1000000000000) = 0) THEN
										(
										"Sys_RPK" = ' || varID || '::bigint
										)
									ELSE
										(
										"Sys_PID" = ' || varID || '::bigint
										OR
										"Sys_SID" = ' || varID || '::bigint
										)
								END
							';
						--RAISE NOTICE '%', varSQL;
						EXECUTE varSQL;
					END IF;
						
				---> Initializing : varReturn
					varReturn := varShadow;

			-----[ MAIN DATA PROCESSING ]---------------------------------------------(  END  )-----
		END IF;

	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			---> Send Data Output
				RETURN
					varReturn;
		END IF;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		EXCEPTION
			WHEN OTHERS THEN
				RETURN NULL;

END;
$_$;


ALTER FUNCTION "SchSystem"."FuncSys_General_SetDataIntegrityShadow"(character varying, bigint) OWNER TO "SysAdmin";

--
-- TOC entry 411 (class 1255 OID 6653838)
-- Name: FuncSys_General_SetPIDAndSIDOnTableEntireRecords(character varying, smallint); Type: FUNCTION; Schema: SchSystem; Owner: SysAdmin
--

CREATE FUNCTION "SchSystem"."FuncSys_General_SetPIDAndSIDOnTableEntireRecords"(character varying, smallint DEFAULT NULL::smallint) RETURNS void
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchSystem"."FuncSys_General_SetPIDAndSIDOnTableEntireRecords"
▪ Versi               :	1.00.0000
▪ Tanggal
     ► Pemutakhiran   :	2026-04-29
     ► Pembuatan      :	2026-04-29
▪ Input               :	• varFrontEndSchemaTableName (varchar - Mandatory)
						------------------------------
						• varClusterID (smallint - Optional)
						------------------------------
						------------------------------
▪ Output              :	(void)
▪ Keterkaitan Fungsi  : • "SchSystem"."FuncSys_General_SetDataIntegrityShadow"(varchar, bigint);
▪ Deskripsi           :	• Mengeset "Sys_PID" dan "Sys_SID" dari seluruh Record yang terdapat pada
						  Table berdasarkan Nama Front End Schema Table (varFrontEndSchemaTableName)
						  dan Cluster ID (varClusterID).
▪ Copyright           :	Zheta © 2026

----[ SQL Example(s) ]------------------------------------------------------------------------------

▪ --->
	SELECT
		"SchSystem"."FuncSys_General_SetPIDAndSIDOnTableEntireRecords"(
			'SchData-OLTP-Master.TblBank'::varchar,
			------------------------------
			1::smallint
			);

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varFrontEndSchemaTableName						 		ALIAS FOR $1;
			------------------------------

		---{ Optional }-------------------
			varClusterID 											ALIAS FOR $2;

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

			varFrontEndSchema										varchar;
			varSchema												varchar;
			varTable												varchar;

			varSQL													varchar;
			varHolderTemplate_PID									bigint;
			varHolderTemplate_SID									bigint;

		---{ Additional }-----------------

BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------( START )-----
			IF (varSignEligibleToProcess IS FALSE) THEN
				varSignEligibleToProcess := TRUE;
			END IF;
		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------(  END  )-----

		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------( START )-----
			IF (varSignEligibleToProcess IS TRUE) THEN
				---> Initializing : varFrontEndSchema, varTable
					varSQL := '
						SELECT
							"Data"[1] AS "SchemaName",
							"Data"[2] AS "TableName"
						FROM
							(
							SELECT
								(''{"' || (REPLACE (varFrontEndSchemaTableName, '.', '", "')) || '"}'')::varchar[] AS "Data"
							) AS "SubSQL"
						';

					EXECUTE
						varSQL
					INTO
						varFrontEndSchema,
						varTable;
					--RAISE NOTICE '%', varFrontEndSchema;
					--RAISE NOTICE '%', varTable;

				---> Initializing : varSchema
					varSchema := (
						REPLACE (
							REPLACE (
								REPLACE (varFrontEndSchema,
									'Data-OLTP-',
									''
									),
								'Data-OLAP-',
								''
								),
							'Data-Warehouse-',
							''
							)
						);
					--RAISE NOTICE '%', varSchema;

				---> Reinitialing : varClusterID
					varClusterID :=
						COALESCE (varClusterID, 1::smallint);
					--RAISE NOTICE '%', varClusterID;

			END IF;
		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------(  END  )-----

	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			-----[ MAIN DATA PROCESSING ]---------------------------------------------( START )-----
				---> Initializing : varHolderTemplate_PID, varHolderTemplate_SID
					SELECT
						'
						SELECT
							DBLINK_EXEC (
								'
								||
								'''' ||
								REPLACE (
									CASE
										WHEN (varFrontEndSchema ILIKE '%-SysConfig%') THEN
											'dbname=''dbERPReborn-SysConfig'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263'''
										WHEN (varFrontEndSchema ILIKE '%Data-OLTP-%') THEN
											'dbname=''dbERPReborn-Data-OLTP'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263'''
										WHEN (varFrontEndSchema ILIKE '%Data-OLAP-%') THEN
											'dbname=''dbERPReborn-Data-OLAP'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263'''
										WHEN (varFrontEndSchema ILIKE '%Data-Warehouse-%') THEN
											'dbname=''dbERPReborn-Data-Warehouse'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263'''
									END,
									'''',
									''''''
									) ||
								''''
								||
								',
								''
								UPDATE
									"' || varSchema || '"."' || varTable || '"
								SET
									"Sys_PID" = COALESCE ("Sys_PID", ((' || "SubSQL"."HolderTemplate_PID" || '::bigint) + "Sys_RPK")),
									"Sys_SID" = COALESCE ("Sys_SID", ((' || "SubSQL"."HolderTemplate_SID" || '::bigint) + "Sys_RPK"))
								WHERE
									(
									"Sys_RPK" IS NOT NULL
									AND
										(
										"Sys_PID" IS NULL
										OR
										"Sys_SID" IS NULL
										)
									)
								''
							);
						'
					INTO
						varSQL
					FROM
						(
						SELECT
							"SubSQL"."HolderTemplate_PID",
							"SubSQL"."HolderTemplate_SID"
						FROM
							DBLINK (
								'dbname=''dbERPReborn-SysConfig'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263''',
								'
								SELECT
									("SchSysConfig"."TblDBObject_Table"."Sys_RPK" * 1000000000000) AS "HolderTemplate_PID",
									((''' || varClusterID::varchar || ''' || LPAD ("SchSysConfig"."TblDBObject_Table"."Sys_RPK"::varchar, 4, ''0''))::bigint * 1000000000000) AS "HolderTemplate_SID"
								FROM
									"SchSysConfig"."TblDBObject_Table"
										LEFT JOIN
											"SchSysConfig"."TblDBObject_Schema"
												ON
													"SchSysConfig"."TblDBObject_Table"."Schema_RefID" = "SchSysConfig"."TblDBObject_Schema"."Sys_PID"
													OR
													"SchSysConfig"."TblDBObject_Table"."Schema_RefID" = "SchSysConfig"."TblDBObject_Schema"."Sys_SID"
								WHERE
									"SchSysConfig"."TblDBObject_Schema"."Name" = ''' || varFrontEndSchema::varchar || '''
									AND
									"SchSysConfig"."TblDBObject_Table"."Name" = ''' || varTable::varchar || '''
								'
								) AS "SubSQL" (
									"HolderTemplate_PID" bigint,
									"HolderTemplate_SID" bigint
									)
						) AS "SubSQL";
					
					SELECT
						'
						UPDATE
							"' || varSchema || '"."' || varTable || '"
						SET
							"Sys_PID" = COALESCE ("Sys_PID", ((' || "SubSQL"."HolderTemplate_PID" || '::bigint) + "Sys_RPK")),
							"Sys_SID" = COALESCE ("Sys_SID", ((' || "SubSQL"."HolderTemplate_SID" || '::bigint) + "Sys_RPK"))
						WHERE
							(
							"Sys_RPK" IS NOT NULL
							AND
								(
								"Sys_PID" IS NULL
								OR
								"Sys_SID" IS NULL
								)
							);
						'
					INTO
						varSQL
					FROM
						(
						SELECT
							"SubSQL"."HolderTemplate_PID",
							"SubSQL"."HolderTemplate_SID"
						FROM
							DBLINK (
								'dbname=''dbERPReborn-SysConfig'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263''',
								'
								SELECT
									("SchSysConfig"."TblDBObject_Table"."Sys_RPK" * 1000000000000) AS "HolderTemplate_PID",
									((''' || varClusterID::varchar || ''' || LPAD ("SchSysConfig"."TblDBObject_Table"."Sys_RPK"::varchar, 4, ''0''))::bigint * 1000000000000) AS "HolderTemplate_SID"
								FROM
									"SchSysConfig"."TblDBObject_Table"
										LEFT JOIN
											"SchSysConfig"."TblDBObject_Schema"
												ON
													"SchSysConfig"."TblDBObject_Table"."Schema_RefID" = "SchSysConfig"."TblDBObject_Schema"."Sys_PID"
													OR
													"SchSysConfig"."TblDBObject_Table"."Schema_RefID" = "SchSysConfig"."TblDBObject_Schema"."Sys_SID"
								WHERE
									"SchSysConfig"."TblDBObject_Schema"."Name" = ''' || varFrontEndSchema::varchar || '''
									AND
									"SchSysConfig"."TblDBObject_Table"."Name" = ''' || varTable::varchar || '''
								'
								) AS "SubSQL" (
									"HolderTemplate_PID" bigint,
									"HolderTemplate_SID" bigint
									)
						) AS "SubSQL";
					--RAISE NOTICE '%', varSQL;
					EXECUTE varSQL;

				---> Execute : Set Shadow For Empty Shadow Record
					varSQL := '
						SELECT
							"SubSQL"."SQLSyntax"
						FROM
							(
							SELECT
								CASE
									WHEN ("SubSQL"."OrderSequence" = 1) THEN
										(
										STRING_AGG (
											''
											SELECT
												"SchSystem"."FuncSys_General_SetDataIntegrityShadow" (
													''''' || varSchema::varchar || '.' || varTable::varchar || '''''::varchar,
													'' || "SubSQL"."Sys_RPK"::varchar || ''::bigint
													);
											'',
											''''
											) OVER ()
										)
									ELSE
										NULL
								END AS "SQLSyntax"
							FROM
								(
								SELECT
									"SubSQL"."Sys_RPK",
									------------------------------
									ROW_NUMBER () OVER () AS "OrderSequence"
								FROM
									(
									SELECT
										"Sys_RPK"
									FROM
										"' || varSchema::varchar || '"."' || varTable::varchar || '"
									WHERE
										"Sys_DataIntegrityShadow" IS NULL
										AND
										"Sys_RPK" IS NOT NULL
									ORDER BY
										"Sys_RPK" ASC
									) AS "SubSQL"
								) AS "SubSQL"
							LIMIT 1
							) AS "SubSQL"
						';
					--RAISE NOTICE '%', varSQL;
					EXECUTE varSQL INTO varSQL;
					--RAISE NOTICE '%', varSQL;

					IF (varSQL IS NOT NULL) THEN
						EXECUTE varSQL;
					END IF;
			-----[ MAIN DATA PROCESSING ]---------------------------------------------(  END  )-----
		END IF;

	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			---> Send Data Output
				--RETURN
				--	varReturn;
		END IF;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		EXCEPTION
			WHEN OTHERS THEN
				NULL;

END;
$_$;


ALTER FUNCTION "SchSystem"."FuncSys_General_SetPIDAndSIDOnTableEntireRecords"(character varying, smallint) OWNER TO "SysAdmin";

--
-- TOC entry 412 (class 1255 OID 6653841)
-- Name: FuncSys_General_SetRecordDataTracking(json, bigint); Type: FUNCTION; Schema: SchSystem; Owner: SysAdmin
--

CREATE FUNCTION "SchSystem"."FuncSys_General_SetRecordDataTracking"(json, bigint DEFAULT NULL::bigint) RETURNS void
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchSystem"."FuncSys_General_SetRecordDataTracking"
▪ Versi               :	1.00.0000
▪ Tanggal
     ► Pemutakhiran   :	2026-10-27
     ► Pembuatan      :	2026-10-27
▪ Input               :	• varJSON_RecordID (json - Mandatory)
						------------------------------
▪ Output              :	-
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Mengeset persiapan data untuk Record Data Tracking
▪ Copyright           :	Zheta © 2026

----[ SQL Example(s) ]------------------------------------------------------------------------------

▪ --->
	SELECT
		"SchSystem"."FuncSys_General_SetRecordDataTracking"(
			(
			SELECT
				(
				'
				{"status" : "Success", "executionTime" : "00:00:09.400638", "impactedRecords" : {"dataCount" : 1, "PIDList" : [76000000000949, 76000000000947]}, "additionalData" : {"businessDocument" : {"businessDocument_RefIDArray" : [null], "businessDocumentNumberArray" : [null], "fullBusinessDocumentNumberArray" : [null], "businessDocumentType_RefIDArray" : [null], "businessDocumentTypeNameArray" : [null], "businessDocumentVersion_RefIDArray" : [null], "businessDocumentVersionArray" : [null], "businessDocumentDateTimeTZArray" : [null]}}}
				'::json
				)->'impactedRecords'->'PIDList' AS "JSONData"
			)
			);

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varJSON_RecordID										ALIAS FOR $1;
			------------------------------

		---{ Optional }-------------------
			varBusinessDocumentVersion_RefID						ALIAS FOR $2;

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

			varSQL													varchar;
			varSQL2													varchar;
			varRecTemp												record;

			varRecord_RefPID										bigint;
			varRecord_RefSID										bigint;
			varDataIntegrityShadow									varchar;
			varJSONData												json;

			varSignTable											bigint;
			varUpperLink_RefID										bigint;

		---{ Additional }-----------------



BEGIN


	varSQL := '
		SELECT
			"SubSQL"."JSONData",
			------------------------------
			"SubSQL"."OrderSequence"
		FROM
			(
			SELECT
				(
				SELECT
					CASE
						WHEN ("InnerSubSQL"."InnerOrderSequence" = 1) THEN
							(
							''{'' ||
							STRING_AGG (
								SUBSTRING ("InnerSubSQL"."JSONData"::varchar, 2, (LENGTH("InnerSubSQL"."JSONData"::varchar) - 2)),
								'',''
								) OVER (
									PARTITION BY
										"SubSQL"."OrderSequence"
									) ||
							''}''
							)
						ELSE
							NULL
					END::json AS "JSONData"
				FROM
					(
					SELECT
						JSON_BUILD_OBJECT (
							CASE
								WHEN (SUBSTRING (("InnerSubSQL"."JSONData"->>''key''::varchar), 2, 1) = UPPER (SUBSTRING (("InnerSubSQL"."JSONData"->>''key''::varchar), 2, 1))) THEN
									"InnerSubSQL"."JSONData"->>''key''
								ELSE
									(LOWER (SUBSTRING (("InnerSubSQL"."JSONData"->>''key''::varchar), 1, 1)) || SUBSTRING (("InnerSubSQL"."JSONData"->>''key''::varchar), 2, (LENGTH("InnerSubSQL"."JSONData"->>''key''::varchar) - 1)))
							END,
							"InnerSubSQL"."JSONData"->''value''
							) AS "JSONData",
						------------------------------
						"InnerSubSQL"."InnerOrderSequence"
					FROM
						(
						SELECT
							ROW_TO_JSON("InnerSubSQL"."JSONData") AS "JSONData",
							------------------------------
							"InnerSubSQL"."InnerOrderSequence"
						FROM
							(
							SELECT
								"InnerSubSQL"."JSONData",
								------------------------------
								ROW_NUMBER () OVER (
									PARTITION BY
										"SubSQL"."OrderSequence"
									) AS "InnerOrderSequence"
							FROM
								(
								SELECT
									JSON_EACH ("SubSQL"."JSONData") AS "JSONData"
								) AS "InnerSubSQL"
							) AS "InnerSubSQL"
						) AS "InnerSubSQL"
					) AS "InnerSubSQL"
				LIMIT 1
				) AS "JSONData",
				------------------------------
				------------------------------
				"SubSQL"."OrderSequence"
			FROM
				(
				SELECT
					"SubSQL"."JSONData",
					ROW_NUMBER () OVER () AS "OrderSequence"
				FROM
					(
					SELECT
						JSON_ARRAY_ELEMENTS (
							"SubSQL"."JSONData"
							) AS "JSONData"
					FROM
						"SchSystem"."FuncSys_General_StrSQLExecution"(
							(
							SELECT
								"SubSQL"."StrSQL"
							FROM
								(
								SELECT
									CASE
										WHEN ("SubSQL"."OrderSequence" = 1) THEN
											(
											SELECT
												"InnerSubSQL"."StrSQL"
											FROM
												DBLINK (
													''dbname=''''dbERPReborn-SysConfig'''' host=127.0.0.1 port=5432 user=''''SysEngine'''' password=''''748159263'''''',
													''
													SELECT									
														(
														''''
														SELECT
															"InnerSubSQL"."JSONData"
														FROM
															DBLINK (
																''''''''''''
																||
																REPLACE (
																	(
																	''''dbname='''''''''''' ||
																	CASE
																		WHEN ("InnerSubSQL"."SchemaName" ILIKE ''''%-OLAP%'''') THEN
																			''''dbERPReborn-Data-OLAP''''
																		WHEN ("InnerSubSQL"."SchemaName" ILIKE ''''%-OLTP%'''') THEN
																			''''dbERPReborn-Data-OLTP''''
																		WHEN ("InnerSubSQL"."SchemaName" ILIKE ''''%-Warehouse%'''') THEN
																			''''dbERPReborn-Data-Warehouse''''
																		WHEN ("InnerSubSQL"."SchemaName" ILIKE ''''%-SysConfig'''') THEN
																			''''dbERPReborn-SysConfig''''
																		ELSE
																			''''dbERPReborn''''
																	END ||
																	'''''''''''' host=127.0.0.1 port=5432 user=''''''''SysEngine'''''''' password=''''''''748159263''''''''''''
																	),
																	'''''''''''''''',
																	''''''''''''''''''''''''
																	)
																||
																'''''''''''',
																'''''''''''' || "StrSQL" || ''''''''''''
																) AS "InnerSubSQL" (
																	"JSONData" json
																	)
														''''
														) AS "StrSQL" 
													FROM
														(
														SELECT
															"InnerSubSQL"."SchemaName",
															(
															''''
															SELECT
																CASE
																	WHEN ("InnerSubSQL"."InnerOrderSequence" = 1) THEN
																		JSON_AGG ("VirtTblData") OVER ()
																	ELSE
																		NULL
																END
															FROM
																(
																''''
																||
																"InnerSubSQL"."StrSQL" || 
																''''
																WHERE
																	"Sys_PID" IN '''' || "IDList" || ''''
																	OR
																	"Sys_SID" IN '''' || "IDList" || ''''
																ORDER BY
																	"Sys_RPK" ASC
																) AS "InnerSubSQL"
															LIMIT 1
															''''
															) AS "StrSQL"
														FROM
															(
															SELECT
																COALESCE (
																	"VirtTblSchema_PID"."Name",
																	"VirtTblSchema_SID"."Name"
																	) AS "SchemaName",
																(
																''''SELECT "VirtTblData", ROW_NUMBER () OVER () AS "InnerOrderSequence" FROM '''' ||
																''''"'''' ||
					
																REPLACE (
																	REPLACE (
																		REPLACE (
																			COALESCE (
																				"VirtTblSchema_PID"."Name",
																				"VirtTblSchema_SID"."Name"
																				),
																			''''Data-Warehouse-'''',
																			''''''''
																			),
																		''''Data-OLAP-'''',
																		''''''''
																		),
																	''''Data-OLTP-'''',
																	''''''''
																	)
																
																||
																''''"."'''' ||
																"SchSysConfig"."TblDBObject_Table"."Name" ||
																''''" AS "VirtTblData" ''''
																)::varchar AS "StrSQL",
																'''''' || "SubSQL"."IDList" || ''''''::varchar AS "IDList"
															FROM
																"SchSysConfig"."TblDBObject_Table"
																	LEFT JOIN
																		"SchSysConfig"."TblDBObject_Schema" AS "VirtTblSchema_PID"
																			ON
																				"SchSysConfig"."TblDBObject_Table"."Schema_RefID" = "VirtTblSchema_PID"."Sys_PID"
																	LEFT JOIN
																		"SchSysConfig"."TblDBObject_Schema" AS "VirtTblSchema_SID"
																			ON
																				"SchSysConfig"."TblDBObject_Table"."Schema_RefID" = "VirtTblSchema_SID"."Sys_SID"
															WHERE
																"SchSysConfig"."TblDBObject_Table"."Sys_RPK" = '' || (("SubSQL"."Sys_RefID" / 1000000000000) % 10000) || ''::bigint
															) AS "InnerSubSQL"
														LIMIT 1
														) AS "InnerSubSQL"
													''
													) AS "InnerSubSQL" (
														"StrSQL" varchar
														)
											)
										ELSE
											NULL
									END AS "StrSQL",
									(("SubSQL"."Sys_RefID" / 1000000000000) % 10000) AS "TableSign",
									------------------------------
									"SubSQL"."OrderSequence"
								FROM
									(
									SELECT
										"SubSQL"."Sys_RefID",
										CASE
											WHEN ("SubSQL"."OrderSequence" = 1) THEN
												(
												''('' ||
												STRING_AGG (
													"SubSQL"."Sys_RefID"::varchar,
													'', ''
													) OVER () ||
												'')''
												)::varchar
											ELSE
												NULL::varchar
										END AS "IDList",
										------------------------------
										"SubSQL"."OrderSequence"
									FROM
										(
										SELECT
											"SubSQL"."Sys_RefID",
											------------------------------
											ROW_NUMBER () OVER () AS "OrderSequence"
										FROM
											(
											SELECT
												JSON_ARRAY_ELEMENTS_TEXT (
													''' || varJSON_RecordID::varchar || '''::json
													)::bigint AS "Sys_RefID"
											) AS "SubSQL"
										) AS "SubSQL"
									) AS "SubSQL"
								) AS "SubSQL"
							WHERE
								"SubSQL"."OrderSequence" = 1
							)
							) AS "SubSQL" (
								"JSONData" json
								)
					) AS "SubSQL"
				) AS "SubSQL"
			) AS "SubSQL"
		';
	--RAISE NOTICE '%', varSQL;


	varSQL2 := '';
	FOR varRecTemp IN EXECUTE varSQL
		LOOP
			varJSONData := varRecTemp."JSONData";
			varRecord_RefPID := (varJSONData->>'sys_PID')::bigint;
			varRecord_RefSID := (varJSONData->>'sys_SID')::bigint;
			varDataIntegrityShadow := (varJSONData->>'sys_DataIntegrityShadow')::varchar;
			varBusinessDocumentVersion_RefID := (
				COALESCE (
					varBusinessDocumentVersion_RefID,
					(varJSONData->>'businessDocumentVersion_RefID')::bigint
					)
				);

			varSignTable := (
				(
				COALESCE (
					varRecord_RefPID,
					varRecord_RefSID
					)
				/ 1000000000000
				) % 10000
				);

			varUpperLink_RefID := (
				CASE
					---> SchFinance
						---> TblAdvanceDetail
							WHEN (varSignTable = 82) THEN
								(varJSONData->>'advance_RefID')::bigint
						---> TblAdvanceSettlementDetail
							WHEN (varSignTable = 204) THEN
								(varJSONData->>'advanceSettlement_RefID')::bigint
						---> TblCashDisbursementDetail
							WHEN (varSignTable = 193) THEN
								(varJSONData->>'cashDisbursement_RefID')::bigint
						---> TblCreditNoteDetail
							WHEN (varSignTable = 243) THEN
								(varJSONData->>'creditNote_RefID')::bigint
						---> TblDebitNoteDetail
							WHEN (varSignTable = 241) THEN
								(varJSONData->>'debitNote_RefID')::bigint
						---> TblLoanDetail
							WHEN (varSignTable = 294) THEN
								(varJSONData->>'loan_RefID')::bigint
						---> TblLoanSettlementDetail
							WHEN (varSignTable = 296) THEN
								(varJSONData->>'loanSettlement_RefID')::bigint
						---> TblPaymentInstructionDetail
							WHEN (varSignTable = 212) THEN
								(varJSONData->>'paymentInstruction_RefID')::bigint
						---> TblPurchaseInvoiceDetail
							WHEN (varSignTable = 209) THEN
								(varJSONData->>'purchaseInvoice_RefID')::bigint
						---> TblPurchaseProformaInvoiceDetail
							WHEN (varSignTable = 206) THEN
								(varJSONData->>'purchaseProformaInvoice_RefID')::bigint
						---> TblReimbursementDetail
							WHEN (varSignTable = 289) THEN
								(varJSONData->>'reimbursement_RefID')::bigint
						---> TblSalesInvoiceDetail
							WHEN (varSignTable = 139) THEN
								(varJSONData->>'salesInvoice_RefID')::bigint
						---> TblSalesInvoiceRequisitionDetail
							WHEN (varSignTable = 245) THEN
								(varJSONData->>'salesInvoiceRequisition_RefID')::bigint
					---> Others
					ELSE
						NULL
				END
				);

			RAISE NOTICE '-------------------------';
			/*
			RAISE NOTICE 'varRecord_RefPID                  : %', varRecord_RefPID;
			RAISE NOTICE 'varRecord_RefSID                  : %', varRecord_RefSID;
			RAISE NOTICE 'varDataIntegrityShadow            : %', varDataIntegrityShadow;
			
			RAISE NOTICE 'varJSONData                       : %', varJSONData;
			RAISE NOTICE 'varSignTable                      : %', varSignTable;
			RAISE NOTICE 'varUpperLink_RefID                : %', varUpperLink_RefID;
			*/
			RAISE NOTICE 'varBusinessDocumentVersion_RefID  : %', varBusinessDocumentVersion_RefID;

			IF (varSQL2 != '') THEN
				varSQL2 := (
					varSQL2 || ', '
					);
			END IF;

			varSQL2 := (
				varSQL2 ||
					'
					{
					"recordID" : null,
					"entitiesMetaData" : {
						"businessDocumentTypeName" : null,
						"documentDate" : null
						},
					"entities" : {
						"sysLoginSession_RefID" : 6000000000001,
						"sysDataAnnotation" : null,
						"sysDataValidityStartDateTimeTZ" : null,
						"sysDataValidityFinishDateTimeTZ" : null,
						"sysPartitionRemovableRecordKeyRefName" : null,
						"sysBranch_RefID" : null,
						"sysBaseCurrency_RefID" : null,
						
						"record_RefPID" : ' || COALESCE (varRecord_RefPID::varchar, 'null'::varchar) || ',
						"record_RefSID" : ' || COALESCE (varRecord_RefSID::varchar, 'null'::varchar) || ',
						"dataIntegrityShadow" : ' || COALESCE (('"' || varDataIntegrityShadow::varchar || '"'), 'null'::varchar) || ',
						"JSONData" : ' || COALESCE (varJSONData::varchar, 'null'::varchar) || ',
						"upperLink_RefID" : ' || COALESCE (varUpperLink_RefID::varchar, 'null'::varchar) || ',
						"businessDocumentVersion_RefIDLink" : ' || COALESCE (varBusinessDocumentVersion_RefID::varchar, 'null'::varchar) || '
						}
					}
					'
				);
				
		END LOOP;

		varSQL := (
			'[' || varSQL2 || ']'
			);

		varSQL := '
			SELECT
				*
			FROM
				"SchLog"."Func_TblLog_RecordDataTracking_SET_BULK"(
					''{}''::json,
					''' || REPLACE (varSQL, '''', '''''') || '''::json
					)
			';
		RAISE NOTICE 'varSQL  : %', varSQL;






END;
$_$;


ALTER FUNCTION "SchSystem"."FuncSys_General_SetRecordDataTracking"(json, bigint) OWNER TO "SysAdmin";

--
-- TOC entry 413 (class 1255 OID 6653844)
-- Name: FuncSys_General_SetSequence(character varying, character varying, bigint); Type: FUNCTION; Schema: SchSystem; Owner: SysEngine
--

CREATE FUNCTION "SchSystem"."FuncSys_General_SetSequence"(character varying, character varying, bigint) RETURNS void
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama               : "SchSysConfig"."FuncSys_General_SetSequence"
▪ Versi              : 1.00.0001
▪ Tanggal            : 2021-07-27
▪ Input              : varSchemaName (varchar)
                       varTableName (varchar)
▪ Output             : void
▪ Keterkaitan Fungsi : -
▪ Deskripsi          : Fungsi ini digunakan untuk menginisialisasi ulang sequence yang terkait 
					   dengan Skema (varSchemaName) dan Table (varTableName) tertentu kembali
                       keangka tertentu (varSequenceNumber)
▪ Copyright          : Zheta © 2018 - 2021
----------------------------------------------------------------------------------------------------*/

DECLARE
   varSchemaName		ALIAS FOR $1;
   varTableName			ALIAS FOR $2;
   varSequenceNumber	ALIAS FOR $3;
   varSQL				varchar;
   varSequenceName		varchar;

BEGIN
    IF (varSequenceNumber = 0) THEN 
        varSequenceNumber := 1; 
    END IF;

	IF ((LENGTH(varTableName) >= 13) AND (SUBSTR(varTableName, 1, 13) = 'TblRotateLog_'))  THEN
		varSequenceName :=  varTableName || '_Sys_RPK_seq';
	ELSE
		varSQL :='
			SELECT
				SUBSTRING("SubSQL"."SequenceField", (10 + LENGTH(''' || varSchemaName || ''') + 4), (LENGTH("SubSQL"."SequenceField") - LENGTH(''' || varSchemaName || ''') - 13 - 13))
			FROM
				(
				SELECT 
					column_default AS "SequenceField"
				FROM
					information_schema.columns 
				WHERE 
					table_schema LIKE ''' || varSchemaName || '''
					AND
					table_name LIKE ''' || varTableName || '''
					AND
					column_default LIKE ''nextval(%''
					AND
					column_default LIKE ''%::regclass)''
				) AS "SubSQL"
			';
		--RAISE NOTICE '%', varSQL;
		EXECUTE varSQL INTO varSequenceName;
	END IF;

   ---> Set Sequence
	varSQL :='
		ALTER SEQUENCE 
			"' || varSchemaName || '"."' || varSequenceName || '"
		RESTART WITH ' || varSequenceNumber;
--		RESTART WITH ' || (CASE WHEN (varSequenceNumber = 0) THEN 1 ELSE varSequenceNumber END);
	EXECUTE varSQL;
END;
$_$;


ALTER FUNCTION "SchSystem"."FuncSys_General_SetSequence"(character varying, character varying, bigint) OWNER TO "SysEngine";

--
-- TOC entry 414 (class 1255 OID 6653845)
-- Name: FuncSys_General_StrSQLBuilder_FilterAndSort(json, json, json, json); Type: FUNCTION; Schema: SchSystem; Owner: SysAdmin
--

CREATE FUNCTION "SchSystem"."FuncSys_General_StrSQLBuilder_FilterAndSort"(json, json, json DEFAULT NULL::json, json DEFAULT NULL::json) RETURNS json
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchSystem"."FuncSys_General_StrSQLBuilder_FilterAndSort"
▪ Versi               :	1.02.0003
▪ Tanggal
     ► Pemutakhiran   :	2026-10-05
     ► Pembuatan      :	2025-10-22
▪ Input               :	• varJSONFilter (json - Mandatory)
						• varJSONSort (json - Mandatory)
						------------------------------
						• varJSONCoreFields (json - Optional)
						• varJSONAllFields (json - Optional)
						------------------------------
						------------------------------
▪ Output              :	varReturn (record)
▪ Keterkaitan Fungsi  : -
▪ Deskripsi           :	• Mendapatkan String SQL untuk Filtering dan Sorting.
						• Secara global string Query yang terlibat dalam proses akan digenerate
						  pada 'filterString' dan 'sortString' varReturn.
						• varJSONCoreFields didefinisikan untuk menentukan Field-Field Utama yang
						  berada dalam Query Utama (Core) pada MAIN PROCESS DATA. Bila didefiniskan
						  maka 'filterString_CoreFields' dan 'sortString_CoreFields' pada varReturn
						  akan didefiniskan. Dan secara otomatis akan mengurangi definisi yang
						  terbentuk pada 'filterString_NonCoreFields' dan 'sortString_NonCoreFields'.
						• Bila varJSONCoreFields tidak didefinisikan, maka 'filterString_CoreFields'
						  dan 'sortString_CoreFields' pada varReturn akan bernilai NULL. Sehingga
						  'filterString_NonCoreFields' dan 'sortString_NonCoreFields' pada varReturn
						  akan bernilai sama dengan 'filterString' dan 'sortString'.
					  	• varJSONAllFields didefinisikan untuk menjaga agar nama-nama field yang
						  terlibat dalam proses Filtering dan Sorting tetap konsisten. Bila ada
						  Klausa yang melenceng dari data varJSONAllFields maka akan diabaikan dan
						  dibuang dari proses.
						• Secara sederhana bisa diilustrasikan sebagai berikut :
							- 'filterString' = 'filterString_CoreFields' + 'filterString_NonCoreFields'
							- 'sortString' = 'sortString_CoreFields' + 'sortString_NonCoreFields'
▪ Copyright           :	Zheta © 2025 - 2026

----[ SQL Example(s) ]------------------------------------------------------------------------------

▪ ---> Without CoreField
	SELECT 
		"SchSystem"."FuncSys_General_StrSQLBuilder_FilterAndSort"(
			JSON_BUILD_ARRAY (
				JSON_BUILD_ARRAY ('Name', 'varchar', 'ILIKE', 'Wisnu')
				--JSON_BUILD_ARRAY ('Name', 'varchar', '=', 'Wisnu')
				--JSON_BUILD_ARRAY ('OrderSequence', 'bigint', '=', '1')
				--JSON_BUILD_ARRAY ('OrderSequence', 'bigint', 'IS', 'NULL')
				--JSON_BUILD_ARRAY ('FetchDateTimeTZ', 'timestamptz', '=', '2025-01-01')
				--JSON_BUILD_ARRAY ('Name', 'varchar[]', '=ANY', 'Wisnu')
				),
			JSON_BUILD_ARRAY (
				JSON_BUILD_ARRAY ('Name', 'ASC')
				)
			------------------------------
			------------------------------
			);

▪ ---> With CoreField
	SELECT 
		"SchSystem"."FuncSys_General_StrSQLBuilder_FilterAndSort"(
			JSON_BUILD_ARRAY (
				JSON_BUILD_ARRAY ('Name', 'varchar', 'ILIKE', 'Wisnu')
				--JSON_BUILD_ARRAY ('Name', 'varchar', '=', 'Wisnu')
				--JSON_BUILD_ARRAY ('OrderSequence', 'bigint', '=', '1')
				--JSON_BUILD_ARRAY ('OrderSequence', 'bigint', 'IS', 'NULL')
				--JSON_BUILD_ARRAY ('FetchDateTimeTZ', 'timestamptz', '=', '2025-01-01')
				--JSON_BUILD_ARRAY ('Name', 'varchar[]', '=ANY', 'Wisnu')
				),
			JSON_BUILD_ARRAY (
				JSON_BUILD_ARRAY ('Name', 'ASC')
				),
			------------------------------
			JSON_BUILD_ARRAY (
				'Name'
				)
			------------------------------
			);

▪ ---> With CoreField and AllField
	SELECT
		"SchSystem"."FuncSys_General_StrSQLBuilder_FilterAndSort"(
			JSON_BUILD_ARRAY (
				JSON_BUILD_ARRAY ('Name', 'varchar', 'ILIKE', 'Wisnu')
				--JSON_BUILD_ARRAY ('Name', 'varchar', '=', 'Wisnu')
				--JSON_BUILD_ARRAY ('OrderSequence', 'bigint', '=', '1')
				--JSON_BUILD_ARRAY ('OrderSequence', 'bigint', 'IS', 'NULL')
				--JSON_BUILD_ARRAY ('FetchDateTimeTZ', 'timestamptz', '=', '2025-01-01')
				--JSON_BUILD_ARRAY ('Name', 'varchar[]', '=ANY', 'Wisnu')
				),
			JSON_BUILD_ARRAY (
				JSON_BUILD_ARRAY ('Name', 'ASC')
				),
			------------------------------
			JSON_BUILD_ARRAY (
				'Name'
				),
			JSON_BUILD_ARRAY (
				'Name'
				)
			------------------------------
			);

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varJSONFilter											ALIAS FOR $1;
			varJSONSort												ALIAS FOR $2;
			------------------------------

		---{ Optional }-------------------
			varJSONCoreFields										ALIAS FOR $3;
			varJSONAllFields										ALIAS FOR $4;

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----
			varReturn												json;

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

			varStr_Filter											varchar;
			varStr_Sort												varchar;

			varStr_Filter_CoreFields								varchar;
			varStr_Sort_CoreFields									varchar;

			varStr_Filter_NonCoreFields								varchar;
			varStr_Sort_NonCoreFields								varchar;

			varJSON_Filter											json;
			varJSON_Sort											json;

			varJSON_Filter_CoreFields								json;
			varJSON_Sort_CoreFields									json;

			varJSON_Filter_NonCoreFields							json;
			varJSON_Sort_NonCoreFields								json;

		---{ Additional }-----------------

BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------( START )-----
			IF (varSignEligibleToProcess IS FALSE) THEN
				varSignEligibleToProcess := TRUE;
			END IF;
		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------(  END  )-----

		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------( START )-----
			IF (varSignEligibleToProcess IS TRUE) THEN
				---> Reinitializing : varJSONCoreFields
					varJSONCoreFields :=
						COALESCE (
							varJSONCoreFields,
							'[]'::json
							);
			END IF;
		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------(  END  )-----

	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			-----[ MAIN DATA PROCESSING ]---------------------------------------------( START )-----
				---> Initializing : varStr_Filter, varJSON_Filter, varStr_Filter_CoreFields, varJSON_Filter_CoreFields, varStr_Filter_NonCoreFields, varJSON_Filter_NonCoreFields
					IF ((varJSONFilter::json IS NOT NULL) AND (varJSONFilter::varchar != '[]')) THEN
						IF (JSON_ARRAY_LENGTH (varJSONFilter::json) > 0) THEN
							---> Initializing : varStr_Filter
								varStr_Filter :=
									(
									SELECT
										(
										'WHERE ' ||
										STRING_AGG (
											CASE
												WHEN (
														(
														varJSONAllFields IS NULL
														)
													OR
														(
														varJSONAllFields IS NOT NULL
														AND
														(varJSONAllFields::json::jsonb @> ('"' || ("SubSQL"."JSONData"->>0)::varchar || '"')::jsonb IS TRUE)
														)
													) THEN
														(
														-----[ SECTION 1 ]-----( START )-----
															(
															CASE
																---> Jika Operator '=ANY'
																WHEN (("SubSQL"."JSONData"->>2)::varchar ILIKE '=ANY') THEN
																	(
																	'''' ||
																	("SubSQL"."JSONData"->>3)::varchar ||
																	'''::' ||
																	REPLACE (("SubSQL"."JSONData"->>1)::varchar, '[]', '') ||
																	' '
																	)
																---> Jika Operator Lainnya
																ELSE
																	(
																	'"' ||
																	("SubSQL"."JSONData"->>0)::varchar ||
																	'"' ||
																	(
																	CASE
																		WHEN (("SubSQL"."JSONData"->>2)::varchar ILIKE '%LIKE') THEN
																			'::varchar '
																		ELSE
																			('::' || ("SubSQL"."JSONData"->>1)::varchar || ' ')
																	END
																	)
																	)
															END
															)
														-----[ SECTION 1 ]-----(  END  )-----
														||
														-----[ SECTION 2 ]-----( START )-----
															(
															("SubSQL"."JSONData"->>2)::varchar ||
															' '
															) 
														-----[ SECTION 2 ]-----(  END  )-----
														||
														-----[ SECTION 3 ]-----( START )-----
															(
															CASE
																---> Jika Operator '=ANY'
																WHEN (("SubSQL"."JSONData"->>2)::varchar ILIKE '=ANY') THEN
																	(
																	'("' ||
																	("SubSQL"."JSONData"->>0)::varchar ||
																	'")'
																	)
																---> Jika Operator Lainnya
																ELSE
																	(
																		(
																		CASE
																			WHEN (("SubSQL"."JSONData"->>2)::varchar ILIKE '%LIKE') THEN
																				'''%'
																			WHEN (("SubSQL"."JSONData"->>2)::varchar ILIKE '@>') THEN
																				''''
																			WHEN (
																				(("SubSQL"."JSONData"->>1)::varchar ILIKE '%CHAR%') OR
																				(("SubSQL"."JSONData"->>1)::varchar ILIKE '%TIMESTAMP%') OR
																				(("SubSQL"."JSONData"->>1)::varchar ILIKE '%DATE%')
																				) THEN
																				''''
																			ELSE
																				''
																		END
																		)
																		||
																		("SubSQL"."JSONData"->>3)::varchar
																		||
																		(
																		CASE
																			WHEN (("SubSQL"."JSONData"->>2)::varchar ILIKE '%LIKE') THEN
																				'%''::varchar'
																			WHEN (("SubSQL"."JSONData"->>2)::varchar ILIKE '@>') THEN
																				'''::' || ("SubSQL"."JSONData"->>1)::varchar
																			WHEN (
																				(("SubSQL"."JSONData"->>1)::varchar ILIKE '%CHAR%') OR
																				(("SubSQL"."JSONData"->>1)::varchar ILIKE '%TIMESTAMP%') OR
																				(("SubSQL"."JSONData"->>1)::varchar ILIKE '%DATE%')
																				) THEN
																				'''::' || ("SubSQL"."JSONData"->>1)::varchar
																			ELSE
																				''
																		END
																		)
																	)
															END
															)
														-----[ SECTION 3 ]-----(  END  )-----
														)
												ELSE
													NULL
											END,
											' AND '
											) OVER ()
										)
									FROM
										(
										SELECT
											JSON_ARRAY_ELEMENTS (
												varJSONFilter::json
												) AS "JSONData"
										) AS "SubSQL"
									LIMIT 1
									);
								--RAISE NOTICE 'varStr_Filter : %', varStr_Filter;

							---> Initializing :  varJSON_Filter
								varJSON_Filter :=
									(
									SELECT
										'['
										||
										STRING_AGG (
											CASE
												WHEN (
														(
														varJSONAllFields IS NULL
														)
													OR
														(
														varJSONAllFields IS NOT NULL
														AND
														(varJSONAllFields::json::jsonb @> ('"' || ("SubSQL"."JSONData"->>0)::varchar || '"')::jsonb IS TRUE)
														)
													) THEN
														"SubSQL"."JSONData"::varchar
												ELSE
													NULL
											END,
											', '
											) OVER ()
										||
										']'
									FROM
										(
										SELECT
											JSON_ARRAY_ELEMENTS (
												varJSONFilter::json
												) AS "JSONData"
										) AS "SubSQL"
									LIMIT 1
									)::json;
								--RAISE NOTICE '%', varJSON_Filter;

							---> Initializing : varStr_Filter_CoreFields
								varStr_Filter_CoreFields :=
									(
									SELECT
										(
										'WHERE ' ||
										STRING_AGG (
											CASE
												WHEN (
													(varJSONCoreFields::json::jsonb @> ('"' || ("SubSQL"."JSONData"->>0)::varchar || '"')::jsonb IS TRUE)
													--AND
													--	(
													--		(
													--		varJSONAllFields IS NULL
													--		)
													--	OR
													--		(
													--		varJSONAllFields IS NOT NULL
													--		AND
													--		(varJSONAllFields::json::jsonb @> ('"' || ("SubSQL"."JSONData"->>0)::varchar || '"')::jsonb IS TRUE)
													--		)
													--	)
													) THEN
														(
														-----[ SECTION 1 ]-----( START )-----
															(
															CASE
																---> Jika Operator '=ANY'
																WHEN (("SubSQL"."JSONData"->>2)::varchar ILIKE '=ANY') THEN
																	(
																	'''' ||
																	("SubSQL"."JSONData"->>3)::varchar ||
																	'''::' ||
																	REPLACE (("SubSQL"."JSONData"->>1)::varchar, '[]', '') ||
																	' '
																	)
																---> Jika Operator Lainnya
																ELSE
																	(
																	'"' ||
																	("SubSQL"."JSONData"->>0)::varchar ||
																	'"' ||
																	(
																	CASE
																		WHEN (("SubSQL"."JSONData"->>2)::varchar ILIKE '%LIKE') THEN
																			'::varchar '
																		ELSE
																			('::' || ("SubSQL"."JSONData"->>1)::varchar || ' ')
																	END
																	)
																	)
															END
															)
														-----[ SECTION 1 ]-----(  END  )-----
														||
														-----[ SECTION 2 ]-----( START )-----
															(
															("SubSQL"."JSONData"->>2)::varchar ||
															' '
															) 
														-----[ SECTION 2 ]-----(  END  )-----
														||
														-----[ SECTION 3 ]-----( START )-----
															(
															CASE
																---> Jika Operator '=ANY'
																WHEN (("SubSQL"."JSONData"->>2)::varchar ILIKE '=ANY') THEN
																	(
																	'("' ||
																	("SubSQL"."JSONData"->>0)::varchar ||
																	'")'
																	)
																---> Jika Operator Lainnya
																ELSE
																	(
																		(
																		CASE
																			WHEN (("SubSQL"."JSONData"->>2)::varchar ILIKE '%LIKE') THEN
																				'''%'
																			WHEN (("SubSQL"."JSONData"->>2)::varchar ILIKE '@>') THEN
																				''''
																			WHEN (
																				(("SubSQL"."JSONData"->>1)::varchar ILIKE '%CHAR%') OR
																				(("SubSQL"."JSONData"->>1)::varchar ILIKE '%TIMESTAMP%') OR
																				(("SubSQL"."JSONData"->>1)::varchar ILIKE '%DATE%')
																				) THEN
																				''''
																			ELSE
																				''
																		END
																		)
																		||
																		("SubSQL"."JSONData"->>3)::varchar
																		||
																		(
																		CASE
																			WHEN (("SubSQL"."JSONData"->>2)::varchar ILIKE '%LIKE') THEN
																				'%''::varchar'
																			WHEN (("SubSQL"."JSONData"->>2)::varchar ILIKE '@>') THEN
																				'''::' || ("SubSQL"."JSONData"->>1)::varchar
																			WHEN (
																				(("SubSQL"."JSONData"->>1)::varchar ILIKE '%CHAR%') OR
																				(("SubSQL"."JSONData"->>1)::varchar ILIKE '%TIMESTAMP%') OR
																				(("SubSQL"."JSONData"->>1)::varchar ILIKE '%DATE%')
																				) THEN
																				'''::' || ("SubSQL"."JSONData"->>1)::varchar
																			ELSE
																				''
																		END
																		)
																	)
															END
															)
														-----[ SECTION 3 ]-----(  END  )-----
														)
												ELSE
													NULL
											END,
											' AND '
											) OVER ()
										)
									FROM
										(
										SELECT
											JSON_ARRAY_ELEMENTS (
												varJSONFilter::json
												) AS "JSONData"
										) AS "SubSQL"
									LIMIT 1
									);
								--RAISE NOTICE 'varStr_Filter_CoreFields : %', varStr_Filter_CoreFields;

							---> Initializing :  varJSON_Filter_CoreFields
								varJSON_Filter_CoreFields :=
									(
									SELECT
										'['
										||
										STRING_AGG (
											CASE
												WHEN (
													(varJSONCoreFields::json::jsonb @> ('"' || ("SubSQL"."JSONData"->>0)::varchar || '"')::jsonb IS TRUE)
													) THEN
														"SubSQL"."JSONData"::varchar
												ELSE
													NULL
											END,
											', '
											) OVER ()
										||
										']'
									FROM
										(
										SELECT
											JSON_ARRAY_ELEMENTS (
												varJSONFilter::json
												) AS "JSONData"
										) AS "SubSQL"
									LIMIT 1
									)::json;
								--RAISE NOTICE '%', varJSON_Filter_CoreFields;

							---> Initializing : varStr_Filter_NonCoreFields
								varStr_Filter_NonCoreFields :=
									(
									SELECT
										(
										'WHERE ' ||
										STRING_AGG (
											CASE
												WHEN (
													(varJSONCoreFields::json::jsonb @> ('"' || ("SubSQL"."JSONData"->>0)::varchar || '"')::jsonb IS FALSE)
													AND
														(
															(
															varJSONAllFields IS NULL
															)
														OR
															(
															varJSONAllFields IS NOT NULL
															AND
															(varJSONAllFields::json::jsonb @> ('"' || ("SubSQL"."JSONData"->>0)::varchar || '"')::jsonb IS TRUE)
															)
														)
													) THEN
														(
														-----[ SECTION 1 ]-----( START )-----
															(
															CASE
																---> Jika Operator '=ANY'
																WHEN (("SubSQL"."JSONData"->>2)::varchar ILIKE '=ANY') THEN
																	(
																	'''' ||
																	("SubSQL"."JSONData"->>3)::varchar ||
																	'''::' ||
																	REPLACE (("SubSQL"."JSONData"->>1)::varchar, '[]', '') ||
																	' '
																	)
																---> Jika Operator Lain
																ELSE
																	(
																	'"' ||
																	("SubSQL"."JSONData"->>0)::varchar ||
																	'"' ||
																	(
																	CASE
																		WHEN (("SubSQL"."JSONData"->>2)::varchar ILIKE '%LIKE') THEN
																			'::varchar '
																		ELSE
																			('::' || ("SubSQL"."JSONData"->>1)::varchar || ' ')
																	END
																	)
																	)
															END
															)
														-----[ SECTION 1 ]-----(  END  )-----
														||
														-----[ SECTION 2 ]-----( START )-----
															(
															("SubSQL"."JSONData"->>2)::varchar ||
															' '
															)
														-----[ SECTION 2 ]-----( END )-----
														||
														-----[ SECTION 3 ]-----( START )-----
															(
															CASE
																---> Jika Operator '=ANY'
																WHEN (("SubSQL"."JSONData"->>2)::varchar ILIKE '=ANY') THEN
																	(
																	'("' ||
																	("SubSQL"."JSONData"->>0)::varchar ||
																	'")'
																	)
																---> Jika Operator Lainnya
																ELSE
																	(
																		(
																		CASE
																			WHEN (("SubSQL"."JSONData"->>2)::varchar ILIKE '%LIKE') THEN
																				'''%'
																			WHEN (("SubSQL"."JSONData"->>2)::varchar ILIKE '@>') THEN
																				''''
																			WHEN (
																				(("SubSQL"."JSONData"->>1)::varchar ILIKE '%CHAR%') OR
																				(("SubSQL"."JSONData"->>1)::varchar ILIKE '%TIMESTAMP%') OR
																				(("SubSQL"."JSONData"->>1)::varchar ILIKE '%DATE%')
																				) THEN
																				''''
																			ELSE
																				''
																		END
																		) 
																		||
																		("SubSQL"."JSONData"->>3)::varchar
																		||
																		(
																		CASE
																			WHEN (("SubSQL"."JSONData"->>2)::varchar ILIKE '%LIKE') THEN
																				'%''::varchar'
																			WHEN (("SubSQL"."JSONData"->>2)::varchar ILIKE '@>') THEN
																				'''::' || ("SubSQL"."JSONData"->>1)::varchar
																			WHEN (
																				(("SubSQL"."JSONData"->>1)::varchar ILIKE '%CHAR%') OR
																				(("SubSQL"."JSONData"->>1)::varchar ILIKE '%TIMESTAMP%') OR
																				(("SubSQL"."JSONData"->>1)::varchar ILIKE '%DATE%')
																				) THEN
																				'''::' || ("SubSQL"."JSONData"->>1)::varchar
																			ELSE
																				''
																		END
																		)
																	)
															END
															)
														-----[ SECTION 3 ]-----(  END  )-----
														)
												ELSE
													NULL
											END,
											' AND '
											) OVER ()
										)
									FROM
										(
										SELECT
											JSON_ARRAY_ELEMENTS (
												varJSONFilter::json
												) AS "JSONData"
										) AS "SubSQL"
									LIMIT 1
									);
								--RAISE NOTICE 'varStr_Filter_NonCoreFields : %', varStr_Filter_NonCoreFields;

							---> Initializing :  varJSON_Filter_NonCoreFields
								varJSON_Filter_NonCoreFields :=
									(
									SELECT
										'['
										||
										STRING_AGG (
											CASE
												WHEN (
													(varJSONCoreFields::json::jsonb @> ('"' || ("SubSQL"."JSONData"->>0)::varchar || '"')::jsonb IS FALSE)
													AND
														(
															(
															varJSONAllFields IS NULL
															)
														OR
															(
															varJSONAllFields IS NOT NULL
															AND
															(varJSONAllFields::json::jsonb @> ('"' || ("SubSQL"."JSONData"->>0)::varchar || '"')::jsonb IS TRUE)
															)
														)
													) THEN
														"SubSQL"."JSONData"::varchar
												ELSE
													NULL
											END,
											', '
											) OVER ()
										||
										']'
									FROM
										(
										SELECT
											JSON_ARRAY_ELEMENTS (
												varJSONFilter::json
												) AS "JSONData"
										) AS "SubSQL"
									LIMIT 1
									)::json;
								--RAISE NOTICE '%', varJSON_Filter_NonCoreFields;
						END IF;
					END IF;

				---> Initializing : varStr_Sort, varJSON_Sort, varStr_Sort_CoreFields, varJSON_Sort_CoreFields, varStr_Sort_NonCoreFields, varJSON_Sort_NonCoreFields
					IF ((varJSONSort::json IS NOT NULL) AND (varJSONSort::varchar != '[]')) THEN
						IF (JSON_ARRAY_LENGTH (varJSONSort::json) > 0) THEN
							---> Initializing : varStr_Sort
								varStr_Sort :=
									(
									SELECT
										(
										'ORDER BY ' ||
										STRING_AGG (
											CASE
												WHEN (
														(
														varJSONAllFields IS NULL
														)
													OR
														(
														varJSONAllFields IS NOT NULL
														AND
														(varJSONAllFields::json::jsonb @> ('"' || ("SubSQL"."JSONData"->>0)::varchar || '"')::jsonb IS TRUE)
														)
													) THEN
														(
														'"' ||
														("SubSQL"."JSONData"->>0)::varchar ||
														'" ' ||
														("SubSQL"."JSONData"->>1)::varchar
														)
												ELSE
													NULL
											END,
											', '
											) OVER ()
										)
									FROM
										(
										SELECT
											JSON_ARRAY_ELEMENTS (
												varJSONSort::json
												) AS "JSONData"
										) AS "SubSQL"
									LIMIT 1
									);
								--RAISE NOTICE 'varStr_Sort : %', varStr_Sort;

							---> Initializing :  varJSON_Sort
								varJSON_Sort :=
									(
									SELECT
										'['
										||
										STRING_AGG (
											CASE
												WHEN (
														(
														varJSONAllFields IS NULL
														)
													OR
														(
														varJSONAllFields IS NOT NULL
														AND
														(varJSONAllFields::json::jsonb @> ('"' || ("SubSQL"."JSONData"->>0)::varchar || '"')::jsonb IS TRUE)
														)
													) THEN
														"SubSQL"."JSONData"::varchar
												ELSE
													NULL
											END,
											', '
											) OVER ()
										||
										']'
									FROM
										(
										SELECT
											JSON_ARRAY_ELEMENTS (
												varJSONSort::json
												) AS "JSONData"
										) AS "SubSQL"
									LIMIT 1
									)::json;
								--RAISE NOTICE '%', varJSON_Sort;

							---> Initializing : varStr_Sort_CoreFields
								varStr_Sort_CoreFields :=
									(
									SELECT
										(
										'ORDER BY ' ||
										STRING_AGG (
											CASE
												WHEN (
													(varJSONCoreFields::json::jsonb @> ('"' || ("SubSQL"."JSONData"->>0)::varchar || '"')::jsonb IS TRUE)
													--AND
													--	(
													--		(
													--		varJSONAllFields IS NULL
													--		)
													--	OR
													--		(
													--		varJSONAllFields IS NOT NULL
													--		AND
													--		(varJSONAllFields::json::jsonb @> ('"' || ("SubSQL"."JSONData"->>0)::varchar || '"')::jsonb IS TRUE)
													--		)
													--	)
													) THEN
														(
														'"' ||
														("SubSQL"."JSONData"->>0)::varchar ||
														'" ' ||
														("SubSQL"."JSONData"->>1)::varchar
														)
												ELSE
													NULL
											END,
											', '
											) OVER ()
										)
									FROM
										(
										SELECT
											JSON_ARRAY_ELEMENTS (
												varJSONSort::json
												) AS "JSONData"
										) AS "SubSQL"
									LIMIT 1
									);
								--RAISE NOTICE 'varStr_Sort_CoreFields : %', varStr_Sort_CoreFields;

							---> Initializing :  varJSON_Sort_CoreFields
								varJSON_Sort_CoreFields :=
									(
									SELECT
										'['
										||
										STRING_AGG (
											CASE
												WHEN (
													(varJSONCoreFields::json::jsonb @> ('"' || ("SubSQL"."JSONData"->>0)::varchar || '"')::jsonb IS TRUE)
													) THEN
														"SubSQL"."JSONData"::varchar
												ELSE
													NULL
											END,
											', '
											) OVER ()
										||
										']'
									FROM
										(
										SELECT
											JSON_ARRAY_ELEMENTS (
												varJSONSort::json
												) AS "JSONData"
										) AS "SubSQL"
									LIMIT 1
									)::json;
								--RAISE NOTICE '%', varJSON_Sort_CoreFields;

							---> Initializing : varStr_Sort_NonCoreFields
								varStr_Sort_NonCoreFields :=
									(
									SELECT
										(
										'ORDER BY ' ||
										STRING_AGG (
											CASE
												WHEN (
													(varJSONCoreFields::json::jsonb @> ('"' || ("SubSQL"."JSONData"->>0)::varchar || '"')::jsonb IS FALSE)
													AND
														(
															(
															varJSONAllFields IS NULL
															)
														OR
															(
															varJSONAllFields IS NOT NULL
															AND
															(varJSONAllFields::json::jsonb @> ('"' || ("SubSQL"."JSONData"->>0)::varchar || '"')::jsonb IS TRUE)
															)
														)
													) THEN
														(
														'"' ||
														("SubSQL"."JSONData"->>0)::varchar ||
														'" ' ||
														("SubSQL"."JSONData"->>1)::varchar
														)
												ELSE
													NULL
											END,
											', '
											) OVER ()
										)
									FROM
										(
										SELECT
											JSON_ARRAY_ELEMENTS (
												varJSONSort::json
												) AS "JSONData"
										) AS "SubSQL"
									LIMIT 1
									);
								--RAISE NOTICE 'varStr_Sort_NonCoreFields : %', varStr_Sort_NonCoreFields;

							---> Initializing :  varJSON_Sort_NonCoreFields
								varJSON_Sort_NonCoreFields :=
									(
									SELECT
										'['
										||
										STRING_AGG (
											CASE
												WHEN (
													(varJSONCoreFields::json::jsonb @> ('"' || ("SubSQL"."JSONData"->>0)::varchar || '"')::jsonb IS FALSE)
													AND
														(
															(
															varJSONAllFields IS NULL
															)
														OR
															(
															varJSONAllFields IS NOT NULL
															AND
															(varJSONAllFields::json::jsonb @> ('"' || ("SubSQL"."JSONData"->>0)::varchar || '"')::jsonb IS TRUE)
															)
														)
													) THEN
														"SubSQL"."JSONData"::varchar
												ELSE
													NULL
											END,
											', '
											) OVER ()
										||
										']'
									FROM
										(
										SELECT
											JSON_ARRAY_ELEMENTS (
												varJSONSort::json
												) AS "JSONData"
										) AS "SubSQL"
									LIMIT 1
									)::json;
								--RAISE NOTICE '%', varJSON_Sort_NonCoreFields;
						END IF;
					END IF;

				---> Initializing : varReturn
					varReturn :=
						JSON_BUILD_OBJECT (
							'filterJSON', varJSON_Filter,
							'filterString', varStr_Filter,
							------------------------------
							'sortJSON', varJSON_Sort,
							'sortString', varStr_Sort,
							------------------------------
							'filterJSON_CoreFields', varJSON_Filter_CoreFields,
							'filterString_CoreFields', varStr_Filter_CoreFields,
							------------------------------
							'sortJSON_CoreFields', varJSON_Sort_CoreFields,
							'sortString_CoreFields', varStr_Sort_CoreFields,
							------------------------------
							'filterJSON_NonCoreFields', varJSON_Filter_NonCoreFields,
							'filterString_NonCoreFields', varStr_Filter_NonCoreFields,
							------------------------------
							'sortJSON_NonCoreFields', varJSON_Sort_NonCoreFields,
							'sortString_NonCoreFields', varStr_Sort_NonCoreFields
							);

			-----[ MAIN DATA PROCESSING ]---------------------------------------------(  END  )-----
		END IF;

	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			---> Send Data Output
				RETURN
					varReturn;
		END IF;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		EXCEPTION
			WHEN OTHERS THEN
				NULL;

END;
$_$;


ALTER FUNCTION "SchSystem"."FuncSys_General_StrSQLBuilder_FilterAndSort"(json, json, json, json) OWNER TO "SysAdmin";

--
-- TOC entry 382 (class 1255 OID 6653848)
-- Name: FuncSys_General_StrSQLExecution(character varying); Type: FUNCTION; Schema: SchSystem; Owner: SysAdmin
--

CREATE FUNCTION "SchSystem"."FuncSys_General_StrSQLExecution"(character varying) RETURNS SETOF record
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchSystem"."FuncSys_General_StrSQLExecution"
▪ Versi               :	1.00.0001
▪ Tanggal
     ► Pemutakhiran   :	2026-05-18
     ► Pembuatan      :	2025-08-12
▪ Input               :	• varSQL (varchar - Mandatory)
						------------------------------
						------------------------------
						------------------------------
▪ Output              :	varReturn (record)
▪ Keterkaitan Fungsi  : -
▪ Deskripsi           :	• Mendapatkan hasil ekseskusi dari String SQL (varSQL) dalam bentuk record.
▪ Copyright           :	Zheta © 2025 - 2026

----[ SQL Example(s) ]------------------------------------------------------------------------------

▪ --->
	SELECT
		*
	FROM
		"SchSystem"."FuncSys_General_StrSQLExecution"(
			'
			SELECT
				1::smallint AS "Tag",
				''a''::varchar AS "Character" 
			UNION ALL
			SELECT
				2::smallint AS "Tag",
				''abc''::varchar AS "Character" 
			'::varchar
			) AS "SubSQL"(xxx smallint, yyy varchar);

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varSQL													ALIAS FOR $1;
			------------------------------

		---{ Optional }-------------------

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----
			varReturn												record;

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

			varRecSet												record;	
		---{ Additional }-----------------

BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------( START )-----
			IF (varSignEligibleToProcess IS FALSE) THEN
				varSignEligibleToProcess := TRUE;
			END IF;
		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------(  END  )-----

		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------( START )-----
			IF (varSignEligibleToProcess IS TRUE) THEN
			END IF;
		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------(  END  )-----

	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			-----[ MAIN DATA PROCESSING ]---------------------------------------------( START )-----
			-----[ MAIN DATA PROCESSING ]---------------------------------------------(  END  )-----
		END IF;

	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			---> Send Data Output
				---> Create Instruction
				IF (TRIM(LEADING E' \n\r\t' FROM varSQL) ILIKE 'CREATE%') THEN
					EXECUTE varSQL;
				---> Others Instruction
				ELSE
					FOR varRecSet IN EXECUTE varSQL
						LOOP
							varReturn := varRecSet;
							RETURN NEXT varReturn;
						END LOOP;
				END IF;
		END IF;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		EXCEPTION
			WHEN OTHERS THEN
				NULL;

END;
$_$;


ALTER FUNCTION "SchSystem"."FuncSys_General_StrSQLExecution"(character varying) OWNER TO "SysAdmin";

--
-- TOC entry 383 (class 1255 OID 6653849)
-- Name: FuncSys_General_StrSQLFlattenToSingleRecord(json, character varying); Type: FUNCTION; Schema: SchSystem; Owner: SysAdmin
--

CREATE FUNCTION "SchSystem"."FuncSys_General_StrSQLFlattenToSingleRecord"(json, character varying) RETURNS character varying
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchSystem"."FuncSys_General_StrSQLFlattenToSingleRecord"
▪ Versi               :	1.00.0002
▪ Tanggal
     ► Pemutakhiran   :	2026-09-30
     ► Pembuatan      :	2026-09-11
▪ Input               :	• varJSONStructure (json - Mandatory)
						• varSQL (varchar - Mandatory)
						------------------------------
						------------------------------
▪ Output              :	varReturn (varchar)
▪ Keterkaitan Fungsi  : -
▪ Deskripsi           :	• Melakukan Flattening output Recordset dari String SQL kedalam record
					 	  tunggal yang hanya terdiri dari beberapa field Array.
					   	• Apabila ditemukan Type Data yang berbentuk Array maka akan dicasting
						  sebagai varchar
▪ Copyright           :	Zheta © 2026

----[ SQL Example(s) ]------------------------------------------------------------------------------

▪ --->
	SELECT
		"SchSystem"."FuncSys_General_StrSQLFlattenToSingleRecord"(
			(
			JSON_BUILD_OBJECT (
				'sortFieldName', 'SubSQL.OrderSequence',
				'structures',
					JSON_BUILD_ARRAY (
						JSON_BUILD_OBJECT (
							'name', 'x',
							'dataType', 'bigint'
							),
						JSON_BUILD_OBJECT (
							'name', 'y',
							'dataType', 'numeric(20,2)'
							)
						)
				)
			),
			'
			SELECT
				"SubSQL"."x",
				"SubSQL"."y",
				"SubSQL"."OrderSequence"
			FROM
				(
				SELECT
					1 AS "x",
					200.02 AS "y",
					1 AS "OrderSequence"
				UNION ALL
				SELECT
					2 AS "x",
					400.01 AS "y",
					2 AS "OrderSequence"
				) AS "SubSQL"
			'
			);

▪ --->
	SELECT
		"SchSystem"."FuncSys_General_StrSQLFlattenToSingleRecord"(
			(
			JSON_BUILD_OBJECT (
				'sortFieldName', 'SubSQL.OrderSequence',
				'structures',
					JSON_BUILD_ARRAY (
						JSON_BUILD_OBJECT (
							'name', 'SubSQL.x',
							'dataType', 'bigint'
							),
						JSON_BUILD_OBJECT (
							'name', 'SubSQL.y',
							'dataType', 'numeric(20,2)'
							)
						)
				)
			),
			'
			SELECT
				"SubSQL"."x",
				"SubSQL"."y",
				"SubSQL"."OrderSequence"
			FROM
				(
				SELECT
					1 AS "x",
					200.02 AS "y",
					1 AS "OrderSequence"
				UNION ALL
				SELECT
					2 AS "x",
					400.01 AS "y",
					2 AS "OrderSequence"
				) AS "SubSQL"
			'
			);

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varJSONStructure										ALIAS FOR $1;
			varSQL													ALIAS FOR $2;
			------------------------------

		---{ Optional }-------------------

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----
			varReturn												varchar;

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

			varSubSQLName											varchar;

		---{ Additional }-----------------

BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------( START )-----
			IF (varSignEligibleToProcess IS FALSE) THEN
				varSignEligibleToProcess := TRUE;
			END IF;
		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------(  END  )-----

		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------( START )-----
			IF (varSignEligibleToProcess IS TRUE) THEN
				varSubSQLName := 
					(('{"' || REPLACE (REPLACE (REPLACE (varJSONStructure->>'sortFieldName', '\', '\\'), '"', '\"'), '.', '", "') || '"}')::varchar[])[1];
				--RAISE NOTICE '%', varSubSQLName;
			END IF;
		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------(  END  )-----

	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			-----[ MAIN DATA PROCESSING ]---------------------------------------------( START )-----
			varReturn := (
				SELECT
					CASE
						WHEN ("SubSQL"."OrderSequence" = 1) THEN
							'
							SELECT
								*
							FROM
								(
								SELECT
									'
									||
									STRING_AGG (
										"SubSQL"."StrSQL",
										', '
										) OVER ()
									||
									'
								FROM
									(
									' || varSQL || '
									) AS "' || varSubSQLName || '"
								LIMIT 1
								) AS "' || varSubSQLName || '"
							'
						ELSE
							NULL
					END
				FROM
					(
					SELECT
						(
						'
						CASE
							WHEN (' || "SubSQL"."OrderSequence" || ' = 1) THEN
								(
								''{'' ||
								STRING_AGG (
									COALESCE (
										(''"'' || REPLACE (REPLACE (' || "SubSQL"."InputFieldName" || '::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''),
										''NULL''
										),
									'',''
									) OVER () ||
								''}''
								)
							ELSE
								NULL
						END::' || "SubSQL"."OutputFieldArrayType" || ' AS ' || "SubSQL"."OutputFieldName" || '
						'
						)::varchar AS "StrSQL",
						ROW_NUMBER () OVER () AS "OrderSequence"
					FROM
						(
						SELECT
							"SubSQL"."OrderSequence",
							"SubSQL"."InputFieldName",
							"SubSQL"."OutputFieldName",
							"SubSQL"."OutputFieldArrayType",
							(
							'
							CASE
								WHEN (' || "SubSQL"."OrderSequence" || ' = 1) THEN
									(
									''{'' ||
									STRING_AGG (
										COALESCE (
											(''"'' || REPLACE (REPLACE (' || "SubSQL"."InputFieldName" || '::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''),
											''NULL''
											),
										'',''
										) OVER () ||
									''}''
									)
								ELSE
									NULL
							END::' || "SubSQL"."OutputFieldArrayType" || ' AS ' || "SubSQL"."OutputFieldName" || '
							'
							) AS "StrSQL"
						FROM
							(
							SELECT
								"SubSQL"."OrderSequence",
								('"' || REPLACE (("SubSQL"."JSONData"->>'name'), '.', '"."') || '"') AS "InputFieldName",		
								CASE
									---> Without SubSQL
									WHEN (CARDINALITY((('{"' || REPLACE (("SubSQL"."JSONData"->>'name'), '.', '", "') || '"}')::varchar[])) = 1) THEN
										('"' || REPLACE (("SubSQL"."JSONData"->>'name'), '.', '"."') || 'Array"')
									---> With SubSQL
									ELSE
										('"' || (('{"' || REPLACE (("SubSQL"."JSONData"->>'name'), '.', '", "') || '"}')::varchar[])[2] || 'Array"')
								END AS "OutputFieldName",
								CASE
									WHEN (STRPOS (("SubSQL"."JSONData"->>'dataType'), '[') > 0) THEN
										--(('{"' || REPLACE (("SubSQL"."JSONData"->>'dataType'), '[', '", "') || '"}')::varchar[])[1]
										'varchar[]'
									ELSE
										(("SubSQL"."JSONData"->>'dataType') || '[]')
								END AS "OutputFieldArrayType"
							FROM
								(
								SELECT
									('"' || REPLACE (("SubSQL"."JSONData"->>'sortFieldName'), '.', '"."') || '"')::varchar AS "OrderSequence",
									JSON_ARRAY_ELEMENTS ("SubSQL"."JSONData"->'structures') AS "JSONData"
								FROM
									(
									SELECT
										varJSONStructure AS "JSONData"
									) AS "SubSQL"
								) AS "SubSQL"
							) AS "SubSQL"
						) AS "SubSQL"
					) AS "SubSQL"
				LIMIT 1
				);
			-----[ MAIN DATA PROCESSING ]---------------------------------------------(  END  )-----
		END IF;

	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----
		RETURN
			varReturn;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		EXCEPTION
			WHEN OTHERS THEN
				NULL;

END;
$_$;


ALTER FUNCTION "SchSystem"."FuncSys_General_StrSQLFlattenToSingleRecord"(json, character varying) OWNER TO "SysAdmin";

--
-- TOC entry 415 (class 1255 OID 6653852)
-- Name: FuncSys_GetInformation_SessionID(bigint, character varying); Type: FUNCTION; Schema: SchSystem; Owner: SysAdmin
--

CREATE FUNCTION "SchSystem"."FuncSys_GetInformation_SessionID"(bigint, character varying DEFAULT NULL::character varying) RETURNS json
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchSystem"."FuncSys_GetInformation_SessionID"
▪ Versi               :	1.00.0000
▪ Tanggal
     ► Pemutakhiran   :	2026-07-03
     ► Pembuatan      :	2026-07-03
▪ Input               :	• varID (bigint - Mandatory)
						------------------------------
						• varSQLFunctionInitiator (bigint - Optional)
▪ Output              :	varReturn (json)
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Mendapatkan Informasi dari Session IS
▪ Copyright           :	Zheta © 2026

----[ Related Database Object(s) ]------------------------------------------------------------------

▪ Tabel               :	• [BE] "SchSysConfig"."TblLog_UserLoginSession"
						• [BE] "SchSysConfig"."TblDBObject_Table"

▪ Fungsi              :	• [BE] "SchSystem"."FuncSys_General_GetEnvironmentParameter"(varchar)
	 					• [BE] "SchSystem"."FuncSys_General_StrSQLExecution"(varchar)

----[ SQL Example(s) ]------------------------------------------------------------------------------

▪ --->
	SELECT
		"SchSystem"."FuncSys_GetInformation_SessionID"(
			6000000001000::bigint
			------------------------------
			);

	SELECT
		"SchSystem"."FuncSys_GetInformation_SessionID"(
			10006000000001000::bigint
			------------------------------
			);

▪ --->
	SELECT
		"SchSystem"."FuncSys_GetInformation_SessionID"(
			10006000000001000::bigint,
			------------------------------
			'Schema.FunctionName'
			);

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varID													ALIAS FOR $1;
			------------------------------

		---{ Optional }-------------------
			varSQLFunctionInitiator									ALIAS FOR $2;

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----
			varReturn												json;

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

			varSQL													varchar;

BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------( START )-----
			IF (varSignEligibleToProcess IS FALSE) THEN
				varSignEligibleToProcess := TRUE;
			END IF;
		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------(  END  )-----

		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------( START )-----
			IF (varSignEligibleToProcess IS TRUE) THEN
			END IF;
		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------(  END  )-----

	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			-----[ MAIN DATA PROCESSING ]---------------------------------------------( START )-----
				---> Initializing : varReturn
					varReturn := (
						SELECT
							"SubSQL"."JSONData"
						FROM
							DBLINK (
								(SELECT "SchSystem"."FuncSys_General_GetEnvironmentParameter"('DBLink.ConnectionString.BackEnd.SysConfig')),
								'
								SELECT
									JSON_BUILD_OBJECT (
										''identifier'',
											JSON_BUILD_OBJECT (
												''APIWebToken'', "APIWebToken",
												''SQLFunctionInitiator'', ' || COALESCE (('''' || varSQLFunctionInitiator::varchar || ''''), 'NULL'::varchar) || '::varchar
											),
										''identities'',
											JSON_BUILD_OBJECT (
												''user_RefID'', "User_RefID",
												''userRole_RefID'', "UserRole_RefID"
												),
										''session'',
											JSON_BUILD_OBJECT (
												''startDateTimeTZ'', "SessionStartDateTimeTZ",
												''finishDateTimeTZ'', "SessionFinishDateTimeTZ",
												''autoStartDateTimeTZ'', "SessionAutoStartDateTimeTZ",
												''autoFinishDateTimeTZ'', "SessionAutoFinishDateTimeTZ"
												)
										) AS "JSONData"
								FROM
									"SchSysConfig"."TblLog_UserLoginSession"
								WHERE
									"Sys_PID" = ' || COALESCE (varID::varchar, 'NULL'::varchar) || '::bigint
									OR
									"Sys_SID" = ' || COALESCE (varID::varchar, 'NULL'::varchar) || '::bigint
								'
								) AS "SubSQL" ("JSONData" json)
						);
			END IF;

	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----
		---> Send Data Output
			RETURN
				varReturn;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		EXCEPTION
			WHEN OTHERS THEN
				RETURN NULL;

END;
$_$;


ALTER FUNCTION "SchSystem"."FuncSys_GetInformation_SessionID"(bigint, character varying) OWNER TO "SysAdmin";

--
-- TOC entry 416 (class 1255 OID 6653853)
-- Name: FuncSys_Logging_SetRecordDataTracking(character varying, bigint[], smallint[]); Type: FUNCTION; Schema: SchSystem; Owner: SysAdmin
--

CREATE FUNCTION "SchSystem"."FuncSys_Logging_SetRecordDataTracking"(character varying, bigint[] DEFAULT NULL::bigint[], smallint[] DEFAULT NULL::smallint[]) RETURNS character varying
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchSystem"."FuncSys_Logging_SetRecordDataTracking"
▪ Versi               :	1.00.0000
▪ Tanggal
     ► Pemutakhiran   :	2026-11-25
     ► Pembuatan      :	2026-11-25
▪ Input               :	• varFrontEndSchemaTableName (varchar - Mandatory)
						------------------------------
						• varRecordIDArray (bigint[] - Optional)
						• varBusinessDocumentVersionArray (smallint[] - Optional)
						------------------------------
▪ Output              :	varReturn (varchar)
▪ Deskripsi           :	• Mengeset Data Data Logging RecordDataTracking pada tabel
						  TblLog_RecordDataTracking
▪ Copyright           :	Zheta © 2026

----[ Related Database Object(s) ]------------------------------------------------------------------

▪ Tabel               :	-

▪ Fungsi              :	• [BE] "SchSystem"."FuncSys_General_GetEnvironmentParameter"(varchar)
						• [BE] "SchSystem"."FuncSys_General_StrSQLExecution" (varchar)
						------------------------------
						• [BE] "SchLog"."Func_TblLog_RecordDataTracking_SET_BULK_SUBMISSION"(json, json, smallint[])

----[ SQL Example(s) ]------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varFrontEndSchemaTableName								ALIAS FOR $1;
			------------------------------

		---{ Optional }-------------------
			varRecordIDArray										ALIAS FOR $2;
			varBusinessDocumentVersionArray							ALIAS FOR $3;

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----
			varReturn												varchar;

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

			varSQL													varchar;

		---{ Additional }-----------------

BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		IF (varSignEligibleToProcess IS FALSE) THEN
			varSignEligibleToProcess := TRUE;
		END IF;

		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------( START )-----
			IF (varSignEligibleToProcess IS TRUE) THEN
			END IF;
		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------(  END  )-----

		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------( START )-----
		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------(  END  )-----

	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			-----[ MAIN DATA PROCESSING ]---------------------------------------------(  END  )-----
				---> Main Process
					IF (((varRecordIDArray)::varchar IS NOT NULL) AND ((varRecordIDArray)::varchar != '[]')) THEN
						varSQL := '
							SELECT
								"SubSQL"."ReturnValue"
							FROM
								DBLINK (
									''' || REPLACE ((SELECT "SchSystem"."FuncSys_General_GetEnvironmentParameter"('DBLink.ConnectionString.BackEnd.DataWarehouse')), '''', '''''') || ''',
									''
									SELECT
										"SchLog"."Func_TblLog_RecordDataTracking_SET_BULK_SUBMISSION"(
											' || COALESCE (('''''' || varRecordIDArray::varchar || ''''''), 'NULL') || '::bigint[],
											------------------------------
											'''''
											||
											((
											SELECT
												*
											FROM
												"SchSystem"."FuncSys_General_StrSQLExecution" (
													'
													SELECT
														CASE
															WHEN ("InnerSubSQL"."InnerOrderSequence" = 1) THEN
																JSON_AGG ("VirtTblData") OVER ()
															ELSE
																NULL
														END AS "JSONData"
													FROM
														(
														SELECT
															"VirtTblData",
															------------------------------
															ROW_NUMBER () OVER (
																ORDER BY
																	"InnerOrderSequence" ASC
																) AS "InnerOrderSequence"
														FROM
															(
															SELECT
																"VirtTblData",
																------------------------------
																ROW_NUMBER () OVER () AS "InnerOrderSequence"
															FROM
																'
																||
																(
																'"'
																|| 
																REPLACE (
																	REPLACE (
																		REPLACE (
																			REPLACE (
																				varFrontEndSchemaTableName,
																				'Data-OLTP-',
																				''
																				),
																			'Data-OLAP-',
																			''
																			),
																		'Data-Warehouse-',
																		''
																		),
																	'.',
																	'"."'
																	)
																|| 
																'"'
																) 
																||
																' AS "VirtTblData"
															WHERE
																'
																||
																'"Sys_PID" IN ' || 
																	REPLACE (
																		REPLACE (
																			(varRecordIDArray)::varchar,
																			'{',
																			'('
																			),
																		'}',
																		')'
																		)
																||
																'
																OR
																'
																||
																'"Sys_SID" IN ' ||
																	REPLACE (
																		REPLACE (
																			(varRecordIDArray)::varchar,
																			'{',
																			'('
																			),
																		'}',
																		')'
																		) 
																||
																'
															ORDER BY
																"Sys_RPK" ASC
															) AS "InnerSubSQL"
														) AS "InnerSubSQL"
													LIMIT 1
													'
													) AS "SubSQL" ("JSONData" json)
					
											))::varchar
											||
											'''''::json,
											' || COALESCE (('''''' || varBusinessDocumentVersionArray::varchar || ''''''), 'NULL') || '::smallint[]
											)
									''
									) AS "SubSQL" ("ReturnValue" varchar)
							';
						--RAISE NOTICE '%', varSQL;
						EXECUTE
							varSQL INTO varSQL;
						--RAISE NOTICE '%', varSQL;
					END IF;

				---> Initializing : varReturn
					varReturn := NULL;

			-----[ MAIN DATA PROCESSING ]---------------------------------------------(  END  )-----

		END IF;

	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----
		RETURN
			varReturn;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		EXCEPTION
			WHEN OTHERS THEN
				NULL;

END;
$_$;


ALTER FUNCTION "SchSystem"."FuncSys_Logging_SetRecordDataTracking"(character varying, bigint[], smallint[]) OWNER TO "SysAdmin";

--
-- TOC entry 234 (class 1259 OID 6653856)
-- Name: TblLog_Device_PersonAccess_Sys_RPK_seq; Type: SEQUENCE; Schema: SchAcquisition; Owner: SysEngine
--

CREATE SEQUENCE "SchAcquisition"."TblLog_Device_PersonAccess_Sys_RPK_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "SchAcquisition"."TblLog_Device_PersonAccess_Sys_RPK_seq" OWNER TO "SysEngine";

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 235 (class 1259 OID 6653857)
-- Name: TblLog_Device_PersonAccess; Type: TABLE; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE TABLE "SchAcquisition"."TblLog_Device_PersonAccess" (
    "Sys_PID" bigint,
    "Sys_SID" bigint,
    "Sys_RPK" bigint DEFAULT nextval('"SchAcquisition"."TblLog_Device_PersonAccess_Sys_RPK_seq"'::regclass) NOT NULL,
    "Sys_Data_Annotation" character varying(1024),
    "Sys_Data_Entry_LoginSession_RefID" bigint,
    "Sys_Data_Entry_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Edit_LoginSession_RefID" bigint,
    "Sys_Data_Edit_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Delete_LoginSession_RefID" bigint,
    "Sys_Data_Delete_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Hidden_LoginSession_RefID" bigint,
    "Sys_Data_Hidden_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Authentication_LoginSession_RefID" bigint,
    "Sys_Data_Authentication_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Validity_StartDateTimeTZ" timestamp with time zone,
    "Sys_Data_Validity_FinishDateTimeTZ" timestamp with time zone,
    "Sys_Partition_RemovableRecord_Key_RefID" bigint,
    "Sys_Branch_RefID" bigint,
    "Sys_BaseCurrency_RefID" bigint,
    "Sys_DataIntegrityShadow" character varying(32),
    "Log_Device_PersonAccessFetch_RefID" bigint,
    "AttendanceDateTimeTZ" timestamp with time zone,
    "PersonID" bigint,
    "PersonUserName" character varying(256)
)
WITH (autovacuum_enabled='true', autovacuum_vacuum_scale_factor='0.05', autovacuum_analyze_scale_factor='0.02', autovacuum_vacuum_cost_limit='2000');
ALTER TABLE ONLY "SchAcquisition"."TblLog_Device_PersonAccess" ALTER COLUMN "Sys_Data_Annotation" SET COMPRESSION lz4;


ALTER TABLE "SchAcquisition"."TblLog_Device_PersonAccess" OWNER TO "SysAdmin";

--
-- TOC entry 236 (class 1259 OID 6653864)
-- Name: TblLog_Device_PersonAccessFetch_Sys_RPK_seq; Type: SEQUENCE; Schema: SchAcquisition; Owner: SysEngine
--

CREATE SEQUENCE "SchAcquisition"."TblLog_Device_PersonAccessFetch_Sys_RPK_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "SchAcquisition"."TblLog_Device_PersonAccessFetch_Sys_RPK_seq" OWNER TO "SysEngine";

--
-- TOC entry 237 (class 1259 OID 6653865)
-- Name: TblLog_Device_PersonAccessFetch; Type: TABLE; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE TABLE "SchAcquisition"."TblLog_Device_PersonAccessFetch" (
    "Sys_PID" bigint,
    "Sys_SID" bigint,
    "Sys_RPK" bigint DEFAULT nextval('"SchAcquisition"."TblLog_Device_PersonAccessFetch_Sys_RPK_seq"'::regclass) NOT NULL,
    "Sys_Data_Annotation" character varying(1024),
    "Sys_Data_Entry_LoginSession_RefID" bigint,
    "Sys_Data_Entry_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Edit_LoginSession_RefID" bigint,
    "Sys_Data_Edit_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Delete_LoginSession_RefID" bigint,
    "Sys_Data_Delete_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Hidden_LoginSession_RefID" bigint,
    "Sys_Data_Hidden_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Authentication_LoginSession_RefID" bigint,
    "Sys_Data_Authentication_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Validity_StartDateTimeTZ" timestamp with time zone,
    "Sys_Data_Validity_FinishDateTimeTZ" timestamp with time zone,
    "Sys_Partition_RemovableRecord_Key_RefID" bigint,
    "Sys_Branch_RefID" bigint,
    "Sys_BaseCurrency_RefID" bigint,
    "Sys_DataIntegrityShadow" character varying(32),
    "GoodsIdentity_RefID" bigint,
    "FetchDateTimeTZ" timestamp with time zone
)
WITH (autovacuum_enabled='true', autovacuum_vacuum_scale_factor='0.05', autovacuum_analyze_scale_factor='0.02', autovacuum_vacuum_cost_limit='2000');
ALTER TABLE ONLY "SchAcquisition"."TblLog_Device_PersonAccessFetch" ALTER COLUMN "Sys_Data_Annotation" SET COMPRESSION lz4;


ALTER TABLE "SchAcquisition"."TblLog_Device_PersonAccessFetch" OWNER TO "SysAdmin";

--
-- TOC entry 238 (class 1259 OID 6653872)
-- Name: TblLog_FileUpload_Object_Sys_RPK_seq; Type: SEQUENCE; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE SEQUENCE "SchAcquisition"."TblLog_FileUpload_Object_Sys_RPK_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "SchAcquisition"."TblLog_FileUpload_Object_Sys_RPK_seq" OWNER TO "SysAdmin";

--
-- TOC entry 239 (class 1259 OID 6653873)
-- Name: TblLog_FileUpload_Object; Type: TABLE; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE TABLE "SchAcquisition"."TblLog_FileUpload_Object" (
    "Sys_PID" bigint,
    "Sys_SID" bigint,
    "Sys_RPK" bigint DEFAULT nextval('"SchAcquisition"."TblLog_FileUpload_Object_Sys_RPK_seq"'::regclass) NOT NULL,
    "Sys_Data_Annotation" character varying(1024),
    "Sys_Data_Entry_LoginSession_RefID" bigint,
    "Sys_Data_Entry_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Edit_LoginSession_RefID" bigint,
    "Sys_Data_Edit_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Delete_LoginSession_RefID" bigint,
    "Sys_Data_Delete_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Hidden_LoginSession_RefID" bigint,
    "Sys_Data_Hidden_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Authentication_LoginSession_RefID" bigint,
    "Sys_Data_Authentication_DateTimeTZ" timestamp with time zone,
    "Sys_Partition_RemovableRecord_Key_RefID" bigint,
    "Sys_Branch_RefID" bigint,
    "Sys_BaseCurrency_RefID" bigint,
    "Sys_DataIntegrityShadow" character varying(32),
    "RotateLog_FileUploadStagingArea_RefRPK" bigint
)
WITH (autovacuum_enabled='true', autovacuum_vacuum_scale_factor='0.05', autovacuum_analyze_scale_factor='0.02', autovacuum_vacuum_cost_limit='2000');
ALTER TABLE ONLY "SchAcquisition"."TblLog_FileUpload_Object" ALTER COLUMN "Sys_Data_Annotation" SET COMPRESSION lz4;


ALTER TABLE "SchAcquisition"."TblLog_FileUpload_Object" OWNER TO "SysAdmin";

--
-- TOC entry 240 (class 1259 OID 6653880)
-- Name: TblLog_FileUpload_ObjectDetail_Sys_RPK_seq; Type: SEQUENCE; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE SEQUENCE "SchAcquisition"."TblLog_FileUpload_ObjectDetail_Sys_RPK_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "SchAcquisition"."TblLog_FileUpload_ObjectDetail_Sys_RPK_seq" OWNER TO "SysAdmin";

--
-- TOC entry 241 (class 1259 OID 6653881)
-- Name: TblLog_FileUpload_ObjectDetail; Type: TABLE; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE TABLE "SchAcquisition"."TblLog_FileUpload_ObjectDetail" (
    "Sys_PID" bigint,
    "Sys_SID" bigint,
    "Sys_RPK" bigint DEFAULT nextval('"SchAcquisition"."TblLog_FileUpload_ObjectDetail_Sys_RPK_seq"'::regclass) NOT NULL,
    "Sys_Data_Annotation" character varying(1024),
    "Sys_Data_Entry_LoginSession_RefID" bigint,
    "Sys_Data_Entry_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Edit_LoginSession_RefID" bigint,
    "Sys_Data_Edit_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Delete_LoginSession_RefID" bigint,
    "Sys_Data_Delete_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Hidden_LoginSession_RefID" bigint,
    "Sys_Data_Hidden_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Authentication_LoginSession_RefID" bigint,
    "Sys_Data_Authentication_DateTimeTZ" timestamp with time zone,
    "Sys_Partition_RemovableRecord_Key_RefID" bigint,
    "Sys_Branch_RefID" bigint,
    "Sys_BaseCurrency_RefID" bigint,
    "Sys_DataIntegrityShadow" character varying(32),
    "Log_FileUpload_Object_RefID" bigint,
    "RotateLog_FileUploadStagingAreaDetail_RefRPK" bigint,
    "Sequence" smallint,
    "Name" character varying(256),
    "Size" bigint,
    "MIME" character varying(128),
    "Extension" character varying(32),
    "LastModifiedDateTimeTZ" character varying(128),
    "LastModifiedUnixTimestamp" bigint,
    "HashMethod_RefID" bigint,
    "ContentBase64Hash" character varying,
    "DataCompression_RefID" bigint,
    "StagingAreaFilePath" character varying(256)
)
WITH (autovacuum_enabled='true', autovacuum_vacuum_scale_factor='0.05', autovacuum_analyze_scale_factor='0.02', autovacuum_vacuum_cost_limit='2000');
ALTER TABLE ONLY "SchAcquisition"."TblLog_FileUpload_ObjectDetail" ALTER COLUMN "Sys_Data_Annotation" SET COMPRESSION lz4;


ALTER TABLE "SchAcquisition"."TblLog_FileUpload_ObjectDetail" OWNER TO "SysAdmin";

--
-- TOC entry 242 (class 1259 OID 6653888)
-- Name: TblLog_FileUpload_Pointer_Sys_RPK_seq; Type: SEQUENCE; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE SEQUENCE "SchAcquisition"."TblLog_FileUpload_Pointer_Sys_RPK_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "SchAcquisition"."TblLog_FileUpload_Pointer_Sys_RPK_seq" OWNER TO "SysAdmin";

--
-- TOC entry 243 (class 1259 OID 6653889)
-- Name: TblLog_FileUpload_Pointer; Type: TABLE; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE TABLE "SchAcquisition"."TblLog_FileUpload_Pointer" (
    "Sys_PID" bigint,
    "Sys_SID" bigint,
    "Sys_RPK" bigint DEFAULT nextval('"SchAcquisition"."TblLog_FileUpload_Pointer_Sys_RPK_seq"'::regclass) NOT NULL,
    "Sys_Data_Annotation" character varying(1024),
    "Sys_Data_Entry_LoginSession_RefID" bigint,
    "Sys_Data_Entry_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Edit_LoginSession_RefID" bigint,
    "Sys_Data_Edit_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Delete_LoginSession_RefID" bigint,
    "Sys_Data_Delete_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Hidden_LoginSession_RefID" bigint,
    "Sys_Data_Hidden_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Authentication_LoginSession_RefID" bigint,
    "Sys_Data_Authentication_DateTimeTZ" timestamp with time zone,
    "Sys_Partition_RemovableRecord_Key_RefID" bigint,
    "Sys_Branch_RefID" bigint,
    "Sys_BaseCurrency_RefID" bigint,
    "Sys_DataIntegrityShadow" character varying(32)
)
WITH (autovacuum_enabled='true', autovacuum_vacuum_scale_factor='0.05', autovacuum_analyze_scale_factor='0.02', autovacuum_vacuum_cost_limit='2000');
ALTER TABLE ONLY "SchAcquisition"."TblLog_FileUpload_Pointer" ALTER COLUMN "Sys_Data_Annotation" SET COMPRESSION lz4;


ALTER TABLE "SchAcquisition"."TblLog_FileUpload_Pointer" OWNER TO "SysAdmin";

--
-- TOC entry 244 (class 1259 OID 6653896)
-- Name: TblLog_FileUpload_PointerHistory_Sys_RPK_seq; Type: SEQUENCE; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE SEQUENCE "SchAcquisition"."TblLog_FileUpload_PointerHistory_Sys_RPK_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "SchAcquisition"."TblLog_FileUpload_PointerHistory_Sys_RPK_seq" OWNER TO "SysAdmin";

--
-- TOC entry 245 (class 1259 OID 6653897)
-- Name: TblLog_FileUpload_PointerHistory; Type: TABLE; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE TABLE "SchAcquisition"."TblLog_FileUpload_PointerHistory" (
    "Sys_PID" bigint,
    "Sys_SID" bigint,
    "Sys_RPK" bigint DEFAULT nextval('"SchAcquisition"."TblLog_FileUpload_PointerHistory_Sys_RPK_seq"'::regclass) NOT NULL,
    "Sys_Data_Annotation" character varying(1024),
    "Sys_Data_Entry_LoginSession_RefID" bigint,
    "Sys_Data_Entry_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Edit_LoginSession_RefID" bigint,
    "Sys_Data_Edit_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Delete_LoginSession_RefID" bigint,
    "Sys_Data_Delete_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Hidden_LoginSession_RefID" bigint,
    "Sys_Data_Hidden_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Authentication_LoginSession_RefID" bigint,
    "Sys_Data_Authentication_DateTimeTZ" timestamp with time zone,
    "Sys_Partition_RemovableRecord_Key_RefID" bigint,
    "Sys_Branch_RefID" bigint,
    "Sys_BaseCurrency_RefID" bigint,
    "Sys_DataIntegrityShadow" character varying(32),
    "Log_FileUpload_Pointer_RefID" bigint
)
WITH (autovacuum_enabled='true', autovacuum_vacuum_scale_factor='0.05', autovacuum_analyze_scale_factor='0.02', autovacuum_vacuum_cost_limit='2000');
ALTER TABLE ONLY "SchAcquisition"."TblLog_FileUpload_PointerHistory" ALTER COLUMN "Sys_Data_Annotation" SET COMPRESSION lz4;


ALTER TABLE "SchAcquisition"."TblLog_FileUpload_PointerHistory" OWNER TO "SysAdmin";

--
-- TOC entry 246 (class 1259 OID 6653904)
-- Name: TblLog_FileUpload_PointerHistoryDetail_Sys_RPK_seq; Type: SEQUENCE; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE SEQUENCE "SchAcquisition"."TblLog_FileUpload_PointerHistoryDetail_Sys_RPK_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "SchAcquisition"."TblLog_FileUpload_PointerHistoryDetail_Sys_RPK_seq" OWNER TO "SysAdmin";

--
-- TOC entry 247 (class 1259 OID 6653905)
-- Name: TblLog_FileUpload_PointerHistoryDetail; Type: TABLE; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE TABLE "SchAcquisition"."TblLog_FileUpload_PointerHistoryDetail" (
    "Sys_PID" bigint,
    "Sys_SID" bigint,
    "Sys_RPK" bigint DEFAULT nextval('"SchAcquisition"."TblLog_FileUpload_PointerHistoryDetail_Sys_RPK_seq"'::regclass) NOT NULL,
    "Sys_Data_Annotation" character varying(1024),
    "Sys_Data_Entry_LoginSession_RefID" bigint,
    "Sys_Data_Entry_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Edit_LoginSession_RefID" bigint,
    "Sys_Data_Edit_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Delete_LoginSession_RefID" bigint,
    "Sys_Data_Delete_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Hidden_LoginSession_RefID" bigint,
    "Sys_Data_Hidden_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Authentication_LoginSession_RefID" bigint,
    "Sys_Data_Authentication_DateTimeTZ" timestamp with time zone,
    "Sys_Partition_RemovableRecord_Key_RefID" bigint,
    "Sys_Branch_RefID" bigint,
    "Sys_BaseCurrency_RefID" bigint,
    "Sys_DataIntegrityShadow" character varying(32),
    "Log_FileUpload_PointerHistory_RefID" bigint,
    "Log_FileUpload_Object_RefID" bigint
)
WITH (autovacuum_enabled='true', autovacuum_vacuum_scale_factor='0.05', autovacuum_analyze_scale_factor='0.02', autovacuum_vacuum_cost_limit='2000');
ALTER TABLE ONLY "SchAcquisition"."TblLog_FileUpload_PointerHistoryDetail" ALTER COLUMN "Sys_Data_Annotation" SET COMPRESSION lz4;


ALTER TABLE "SchAcquisition"."TblLog_FileUpload_PointerHistoryDetail" OWNER TO "SysAdmin";

--
-- TOC entry 248 (class 1259 OID 6653912)
-- Name: TblRotateLog_FileUploadStagingArea; Type: TABLE; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE TABLE "SchAcquisition"."TblRotateLog_FileUploadStagingArea" (
    "Sys_RotateID" bigint NOT NULL,
    "Sys_RPK" bigint NOT NULL,
    "Sys_Data_Annotation" character varying(1024),
    "Sys_Data_Entry_LoginSession_RefID" bigint,
    "Sys_Data_Entry_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Edit_LoginSession_RefID" bigint,
    "Sys_Data_Edit_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Delete_LoginSession_RefID" bigint,
    "Sys_Data_Delete_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Hidden_LoginSession_RefID" bigint,
    "Sys_Data_Hidden_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Authentication_LoginSession_RefID" bigint,
    "Sys_Data_Authentication_DateTimeTZ" timestamp with time zone,
    "ApplicationKey" character varying(256)
)
WITH (autovacuum_enabled='true', autovacuum_vacuum_scale_factor='0.05', autovacuum_analyze_scale_factor='0.02', autovacuum_vacuum_cost_limit='2000');
ALTER TABLE ONLY "SchAcquisition"."TblRotateLog_FileUploadStagingArea" ALTER COLUMN "Sys_Data_Annotation" SET COMPRESSION lz4;


ALTER TABLE "SchAcquisition"."TblRotateLog_FileUploadStagingArea" OWNER TO "SysAdmin";

--
-- TOC entry 249 (class 1259 OID 6653919)
-- Name: TblRotateLog_FileUploadStagingAreaDetail; Type: TABLE; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE TABLE "SchAcquisition"."TblRotateLog_FileUploadStagingAreaDetail" (
    "Sys_RotateID" bigint NOT NULL,
    "Sys_RPK" bigint NOT NULL,
    "Sys_Data_Annotation" character varying(1024),
    "Sys_Data_Entry_LoginSession_RefID" bigint,
    "Sys_Data_Entry_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Edit_LoginSession_RefID" bigint,
    "Sys_Data_Edit_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Delete_LoginSession_RefID" bigint,
    "Sys_Data_Delete_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Hidden_LoginSession_RefID" bigint,
    "Sys_Data_Hidden_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Authentication_LoginSession_RefID" bigint,
    "Sys_Data_Authentication_DateTimeTZ" timestamp with time zone,
    "RotateLog_FileUploadStagingArea_RefRPK" bigint,
    "Sequence" smallint,
    "Name" character varying(256),
    "Size" bigint,
    "MIME" character varying(128),
    "Extension" character varying(32),
    "LastModifiedDateTimeTZ" character varying(128),
    "LastModifiedUnixTimestamp" bigint,
    "HashMethod_RefID" bigint,
    "ContentBase64Hash" character varying,
    "URLDelete" character varying
)
WITH (autovacuum_enabled='true', autovacuum_vacuum_scale_factor='0.05', autovacuum_analyze_scale_factor='0.02', autovacuum_vacuum_cost_limit='2000');
ALTER TABLE ONLY "SchAcquisition"."TblRotateLog_FileUploadStagingAreaDetail" ALTER COLUMN "Sys_Data_Annotation" SET COMPRESSION lz4;


ALTER TABLE "SchAcquisition"."TblRotateLog_FileUploadStagingAreaDetail" OWNER TO "SysAdmin";

--
-- TOC entry 250 (class 1259 OID 6653926)
-- Name: TblRotateLog_FileUploadStagingAreaDetail_Sys_RPK_seq; Type: SEQUENCE; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE SEQUENCE "SchAcquisition"."TblRotateLog_FileUploadStagingAreaDetail_Sys_RPK_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "SchAcquisition"."TblRotateLog_FileUploadStagingAreaDetail_Sys_RPK_seq" OWNER TO "SysAdmin";

--
-- TOC entry 251 (class 1259 OID 6653927)
-- Name: TblRotateLog_FileUploadStagingArea_Sys_RPK_seq; Type: SEQUENCE; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE SEQUENCE "SchAcquisition"."TblRotateLog_FileUploadStagingArea_Sys_RPK_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "SchAcquisition"."TblRotateLog_FileUploadStagingArea_Sys_RPK_seq" OWNER TO "SysAdmin";

--
-- TOC entry 252 (class 1259 OID 6653928)
-- Name: TblCache_FunctionResult_Sys_RPK_seq; Type: SEQUENCE; Schema: SchCache; Owner: SysAdmin
--

CREATE SEQUENCE "SchCache"."TblCache_FunctionResult_Sys_RPK_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "SchCache"."TblCache_FunctionResult_Sys_RPK_seq" OWNER TO "SysAdmin";

--
-- TOC entry 253 (class 1259 OID 6653929)
-- Name: TblCache_FunctionResult; Type: TABLE; Schema: SchCache; Owner: SysAdmin
--

CREATE TABLE "SchCache"."TblCache_FunctionResult" (
    "Sys_PID" bigint,
    "Sys_SID" bigint,
    "Sys_RPK" bigint DEFAULT nextval('"SchCache"."TblCache_FunctionResult_Sys_RPK_seq"'::regclass) NOT NULL,
    "Sys_Data_Annotation" character varying(1024),
    "Sys_Data_Entry_LoginSession_RefID" bigint,
    "Sys_Data_Entry_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Edit_LoginSession_RefID" bigint,
    "Sys_Data_Edit_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Delete_LoginSession_RefID" bigint,
    "Sys_Data_Delete_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Hidden_LoginSession_RefID" bigint,
    "Sys_Data_Hidden_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Authentication_LoginSession_RefID" bigint,
    "Sys_Data_Authentication_DateTimeTZ" timestamp with time zone,
    "Sys_Partition_RemovableRecord_Key_RefID" bigint,
    "Sys_Branch_RefID" bigint,
    "Sys_BaseCurrency_RefID" bigint,
    "Sys_DataIntegrityShadow" character varying(32),
    "SchemaFunctionName" character varying(128),
    "Parameter" jsonb,
    "ObjectsSignatureReference" jsonb,
    "SQLRecallSyntax" character varying,
    "Result" json,
    "ReturnDataType" character varying,
    "ReturnDataTypePlaceHolder" character varying,
    "RecordCount" bigint,
    "QueryExecutionInterval" interval
)
WITH (autovacuum_enabled='true', autovacuum_vacuum_scale_factor='0.05', autovacuum_analyze_scale_factor='0.02', autovacuum_vacuum_cost_limit='2000');
ALTER TABLE ONLY "SchCache"."TblCache_FunctionResult" ALTER COLUMN "Sys_Data_Annotation" SET COMPRESSION lz4;
ALTER TABLE ONLY "SchCache"."TblCache_FunctionResult" ALTER COLUMN "Parameter" SET COMPRESSION lz4;
ALTER TABLE ONLY "SchCache"."TblCache_FunctionResult" ALTER COLUMN "Result" SET COMPRESSION lz4;


ALTER TABLE "SchCache"."TblCache_FunctionResult" OWNER TO "SysAdmin";

--
-- TOC entry 254 (class 1259 OID 6653936)
-- Name: TblStatistic_CacheFunctionResultAccess_Sys_RPK_seq; Type: SEQUENCE; Schema: SchCache; Owner: SysAdmin
--

CREATE SEQUENCE "SchCache"."TblStatistic_CacheFunctionResultAccess_Sys_RPK_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "SchCache"."TblStatistic_CacheFunctionResultAccess_Sys_RPK_seq" OWNER TO "SysAdmin";

--
-- TOC entry 255 (class 1259 OID 6653937)
-- Name: TblStatistic_CacheFunctionResultAccess; Type: TABLE; Schema: SchCache; Owner: SysAdmin
--

CREATE TABLE "SchCache"."TblStatistic_CacheFunctionResultAccess" (
    "Sys_PID" bigint,
    "Sys_SID" bigint,
    "Sys_RPK" bigint DEFAULT nextval('"SchCache"."TblStatistic_CacheFunctionResultAccess_Sys_RPK_seq"'::regclass) NOT NULL,
    "Sys_Data_Annotation" character varying(1024),
    "Sys_Data_Entry_LoginSession_RefID" bigint,
    "Sys_Data_Entry_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Edit_LoginSession_RefID" bigint,
    "Sys_Data_Edit_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Delete_LoginSession_RefID" bigint,
    "Sys_Data_Delete_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Hidden_LoginSession_RefID" bigint,
    "Sys_Data_Hidden_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Authentication_LoginSession_RefID" bigint,
    "Sys_Data_Authentication_DateTimeTZ" timestamp with time zone,
    "Sys_Partition_RemovableRecord_Key_RefID" bigint,
    "Sys_Branch_RefID" bigint,
    "Sys_BaseCurrency_RefID" bigint,
    "Sys_DataIntegrityShadow" character varying(32),
    "Cache_FunctionResult_RefID" bigint,
    "LastReadDateTimeTZ" timestamp with time zone,
    "ReadFrequencies" bigint
)
WITH (autovacuum_enabled='true', autovacuum_vacuum_scale_factor='0.05', autovacuum_analyze_scale_factor='0.02', autovacuum_vacuum_cost_limit='2000');
ALTER TABLE ONLY "SchCache"."TblStatistic_CacheFunctionResultAccess" ALTER COLUMN "Sys_Data_Annotation" SET COMPRESSION lz4;


ALTER TABLE "SchCache"."TblStatistic_CacheFunctionResultAccess" OWNER TO "SysAdmin";

--
-- TOC entry 256 (class 1259 OID 6653944)
-- Name: TblLog_FunctionSnapshotSignature_Sys_RPK_seq; Type: SEQUENCE; Schema: SchLog; Owner: SysAdmin
--

CREATE SEQUENCE "SchLog"."TblLog_FunctionSnapshotSignature_Sys_RPK_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "SchLog"."TblLog_FunctionSnapshotSignature_Sys_RPK_seq" OWNER TO "SysAdmin";

--
-- TOC entry 257 (class 1259 OID 6653945)
-- Name: TblLog_FunctionSnapshotSignature; Type: TABLE; Schema: SchLog; Owner: SysAdmin
--

CREATE TABLE "SchLog"."TblLog_FunctionSnapshotSignature" (
    "Sys_PID" bigint,
    "Sys_SID" bigint,
    "Sys_RPK" bigint DEFAULT nextval('"SchLog"."TblLog_FunctionSnapshotSignature_Sys_RPK_seq"'::regclass) NOT NULL,
    "Sys_Data_Annotation" character varying(1024),
    "Sys_Data_Entry_LoginSession_RefID" bigint,
    "Sys_Data_Entry_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Edit_LoginSession_RefID" bigint,
    "Sys_Data_Edit_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Delete_LoginSession_RefID" bigint,
    "Sys_Data_Delete_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Hidden_LoginSession_RefID" bigint,
    "Sys_Data_Hidden_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Authentication_LoginSession_RefID" bigint,
    "Sys_Data_Authentication_DateTimeTZ" timestamp with time zone,
    "Sys_Partition_RemovableRecord_Key_RefID" bigint,
    "Sys_Branch_RefID" bigint,
    "Sys_BaseCurrency_RefID" bigint,
    "Sys_DataIntegrityShadow" character varying(32),
    "SchemaName" character varying(128),
    "FunctionName" character varying(128),
    "SignatureID" character varying(32),
    "Source_RefHeaderID" bigint,
    "Type" character varying(32)
)
WITH (autovacuum_enabled='true', autovacuum_vacuum_scale_factor='0.05', autovacuum_analyze_scale_factor='0.02', autovacuum_vacuum_cost_limit='2000');
ALTER TABLE ONLY "SchLog"."TblLog_FunctionSnapshotSignature" ALTER COLUMN "Sys_Data_Annotation" SET COMPRESSION lz4;


ALTER TABLE "SchLog"."TblLog_FunctionSnapshotSignature" OWNER TO "SysAdmin";

--
-- TOC entry 258 (class 1259 OID 6653952)
-- Name: TblLog_RecordDataTracking_Sys_RPK_seq; Type: SEQUENCE; Schema: SchLog; Owner: SysAdmin
--

CREATE SEQUENCE "SchLog"."TblLog_RecordDataTracking_Sys_RPK_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "SchLog"."TblLog_RecordDataTracking_Sys_RPK_seq" OWNER TO "SysAdmin";

--
-- TOC entry 259 (class 1259 OID 6653953)
-- Name: TblLog_RecordDataTracking; Type: TABLE; Schema: SchLog; Owner: SysAdmin
--

CREATE TABLE "SchLog"."TblLog_RecordDataTracking" (
    "Sys_PID" bigint,
    "Sys_SID" bigint,
    "Sys_RPK" bigint DEFAULT nextval('"SchLog"."TblLog_RecordDataTracking_Sys_RPK_seq"'::regclass) NOT NULL,
    "Sys_Data_Annotation" character varying(1024),
    "Sys_Data_Entry_LoginSession_RefID" bigint,
    "Sys_Data_Entry_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Edit_LoginSession_RefID" bigint,
    "Sys_Data_Edit_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Delete_LoginSession_RefID" bigint,
    "Sys_Data_Delete_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Hidden_LoginSession_RefID" bigint,
    "Sys_Data_Hidden_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Authentication_LoginSession_RefID" bigint,
    "Sys_Data_Authentication_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Cancelation_LoginSession_RefID" bigint,
    "Sys_Data_Cancelation_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Validity_StartDateTimeTZ" timestamp with time zone,
    "Sys_Data_Validity_FinishDateTimeTZ" timestamp with time zone,
    "Sys_Partition_RemovableRecord_Key_RefID" bigint,
    "Sys_Branch_RefID" bigint,
    "Sys_BaseCurrency_RefID" bigint,
    "Sys_DataIntegrityShadow" character varying(32),
    "Record_SchemaTableName" character varying(128),
    "Record_SysPID" bigint,
    "Record_SysSID" bigint,
    "Record_ModificationLoginSession_RefID" bigint,
    "Record_ModificationType" character varying,
    "Record_ModificationDateTimeTZ" timestamp with time zone,
    "Record_DataIntegrityShadow" character varying(32),
    "Record_JSONData" json,
    "Record_UpperLink_RefID" bigint,
    "Record_BusinessDocumentVersion_RefID" bigint,
    "Record_BusinessDocumentVersion" smallint,
    "Record_Version" smallint
)
WITH (autovacuum_enabled='true', autovacuum_analyze_scale_factor='0.02', autovacuum_vacuum_cost_limit='2000', autovacuum_vacuum_scale_factor='0.05');
ALTER TABLE ONLY "SchLog"."TblLog_RecordDataTracking" ALTER COLUMN "Sys_Data_Annotation" SET COMPRESSION lz4;


ALTER TABLE "SchLog"."TblLog_RecordDataTracking" OWNER TO "SysAdmin";

--
-- TOC entry 260 (class 1259 OID 6653960)
-- Name: TblLog_TableSnapshotSignature_Sys_RPK_seq; Type: SEQUENCE; Schema: SchLog; Owner: SysAdmin
--

CREATE SEQUENCE "SchLog"."TblLog_TableSnapshotSignature_Sys_RPK_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "SchLog"."TblLog_TableSnapshotSignature_Sys_RPK_seq" OWNER TO "SysAdmin";

--
-- TOC entry 261 (class 1259 OID 6653961)
-- Name: TblLog_TableSnapshotSignature; Type: TABLE; Schema: SchLog; Owner: SysAdmin
--

CREATE TABLE "SchLog"."TblLog_TableSnapshotSignature" (
    "Sys_PID" bigint,
    "Sys_SID" bigint,
    "Sys_RPK" bigint DEFAULT nextval('"SchLog"."TblLog_TableSnapshotSignature_Sys_RPK_seq"'::regclass) NOT NULL,
    "Sys_Data_Annotation" character varying(1024),
    "Sys_Data_Entry_LoginSession_RefID" bigint,
    "Sys_Data_Entry_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Edit_LoginSession_RefID" bigint,
    "Sys_Data_Edit_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Delete_LoginSession_RefID" bigint,
    "Sys_Data_Delete_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Hidden_LoginSession_RefID" bigint,
    "Sys_Data_Hidden_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Authentication_LoginSession_RefID" bigint,
    "Sys_Data_Authentication_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Validity_StartDateTimeTZ" timestamp with time zone,
    "Sys_Data_Validity_FinishDateTimeTZ" timestamp with time zone,
    "Sys_Partition_RemovableRecord_Key_RefID" bigint,
    "Sys_Branch_RefID" bigint,
    "Sys_BaseCurrency_RefID" bigint,
    "Sys_DataIntegrityShadow" character varying(32),
    "SchemaName" character varying(128),
    "TableName" character varying(128),
    "SignatureID" character varying(32)
)
WITH (autovacuum_enabled='true', autovacuum_vacuum_scale_factor='0.05', autovacuum_analyze_scale_factor='0.02', autovacuum_vacuum_cost_limit='2000');
ALTER TABLE ONLY "SchLog"."TblLog_TableSnapshotSignature" ALTER COLUMN "Sys_Data_Annotation" SET COMPRESSION lz4;


ALTER TABLE "SchLog"."TblLog_TableSnapshotSignature" OWNER TO "SysAdmin";

--
-- TOC entry 262 (class 1259 OID 6653968)
-- Name: TblLog_TransactionHistory_Sys_RPK_seq; Type: SEQUENCE; Schema: SchLog; Owner: SysEngine
--

CREATE SEQUENCE "SchLog"."TblLog_TransactionHistory_Sys_RPK_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "SchLog"."TblLog_TransactionHistory_Sys_RPK_seq" OWNER TO "SysEngine";

--
-- TOC entry 263 (class 1259 OID 6653969)
-- Name: TblLog_TransactionHistory; Type: TABLE; Schema: SchLog; Owner: SysAdmin
--

CREATE TABLE "SchLog"."TblLog_TransactionHistory" (
    "Sys_PID" bigint,
    "Sys_SID" bigint,
    "Sys_RPK" bigint DEFAULT nextval('"SchLog"."TblLog_TransactionHistory_Sys_RPK_seq"'::regclass) NOT NULL,
    "Sys_Data_Annotation" character varying(1024),
    "Sys_Data_Entry_LoginSession_RefID" bigint,
    "Sys_Data_Entry_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Edit_LoginSession_RefID" bigint,
    "Sys_Data_Edit_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Delete_LoginSession_RefID" bigint,
    "Sys_Data_Delete_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Hidden_LoginSession_RefID" bigint,
    "Sys_Data_Hidden_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Authentication_LoginSession_RefID" bigint,
    "Sys_Data_Authentication_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Validity_StartDateTimeTZ" timestamp with time zone,
    "Sys_Data_Validity_FinishDateTimeTZ" timestamp with time zone,
    "Sys_Partition_RemovableRecord_Key_RefID" bigint,
    "Sys_Branch_RefID" bigint,
    "Sys_BaseCurrency_RefID" bigint,
    "Sys_DataIntegrityShadow" character varying(32),
    "Source_RefPID" bigint,
    "Source_RefSID" bigint,
    "Source_RefRPK" bigint,
    "Source_EntryDateTimeTZ" timestamp with time zone,
    "Content" json,
    "Source_RefHeaderID" bigint,
    "Type" character varying(32)
)
WITH (autovacuum_enabled='true', autovacuum_vacuum_scale_factor='0.05', autovacuum_analyze_scale_factor='0.02', autovacuum_vacuum_cost_limit='2000');
ALTER TABLE ONLY "SchLog"."TblLog_TransactionHistory" ALTER COLUMN "Content" SET COMPRESSION lz4;


ALTER TABLE "SchLog"."TblLog_TransactionHistory" OWNER TO "SysAdmin";

--
-- TOC entry 264 (class 1259 OID 6653976)
-- Name: TblStructure_DBObject_Sys_RPK_seq; Type: SEQUENCE; Schema: SchRecovery; Owner: SysAdmin
--

CREATE SEQUENCE "SchRecovery"."TblStructure_DBObject_Sys_RPK_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "SchRecovery"."TblStructure_DBObject_Sys_RPK_seq" OWNER TO "SysAdmin";

--
-- TOC entry 265 (class 1259 OID 6653977)
-- Name: TblStructure_DBObject; Type: TABLE; Schema: SchRecovery; Owner: SysAdmin
--

CREATE TABLE "SchRecovery"."TblStructure_DBObject" (
    "Sys_PID" bigint,
    "Sys_SID" bigint,
    "Sys_RPK" bigint DEFAULT nextval('"SchRecovery"."TblStructure_DBObject_Sys_RPK_seq"'::regclass) NOT NULL,
    "Sys_Data_Annotation" character varying(1024),
    "Sys_Data_Entry_LoginSession_RefID" bigint,
    "Sys_Data_Entry_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Edit_LoginSession_RefID" bigint,
    "Sys_Data_Edit_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Delete_LoginSession_RefID" bigint,
    "Sys_Data_Delete_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Hidden_LoginSession_RefID" bigint,
    "Sys_Data_Hidden_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Authentication_LoginSession_RefID" bigint,
    "Sys_Data_Authentication_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Validity_StartDateTimeTZ" timestamp with time zone,
    "Sys_Data_Validity_FinishDateTimeTZ" timestamp with time zone,
    "Sys_Partition_RemovableRecord_Key_RefID" bigint,
    "Sys_Branch_RefID" bigint,
    "Sys_BaseCurrency_RefID" bigint,
    "Sys_DataIntegrityShadow" character varying(32),
    "ObjectID" bigint,
    "Type" character varying(64),
    "DatabaseName" character varying(64),
    "SchemaName" character varying(128),
    "ObjectName" character varying(128),
    "ConstructionSQL" character varying,
    "DeconstructionSQL" character varying
)
WITH (autovacuum_enabled='true', autovacuum_analyze_scale_factor='0.02', autovacuum_vacuum_cost_limit='2000', autovacuum_vacuum_scale_factor='0.05');
ALTER TABLE ONLY "SchRecovery"."TblStructure_DBObject" ALTER COLUMN "Sys_Data_Annotation" SET COMPRESSION lz4;


ALTER TABLE "SchRecovery"."TblStructure_DBObject" OWNER TO "SysAdmin";

--
-- TOC entry 3564 (class 2606 OID 6656449)
-- Name: TblLog_FileUpload_ObjectDetail TblLog_FileUpload_ObjectDetail_pkey; Type: CONSTRAINT; Schema: SchAcquisition; Owner: SysAdmin
--

ALTER TABLE ONLY "SchAcquisition"."TblLog_FileUpload_ObjectDetail"
    ADD CONSTRAINT "TblLog_FileUpload_ObjectDetail_pkey" PRIMARY KEY ("Sys_RPK");


--
-- TOC entry 3562 (class 2606 OID 6656451)
-- Name: TblLog_FileUpload_Object TblLog_FileUpload_Object_pkey; Type: CONSTRAINT; Schema: SchAcquisition; Owner: SysAdmin
--

ALTER TABLE ONLY "SchAcquisition"."TblLog_FileUpload_Object"
    ADD CONSTRAINT "TblLog_FileUpload_Object_pkey" PRIMARY KEY ("Sys_RPK");


--
-- TOC entry 3570 (class 2606 OID 6656453)
-- Name: TblLog_FileUpload_PointerHistoryDetail TblLog_FileUpload_PointerHistoryDetail_pkey; Type: CONSTRAINT; Schema: SchAcquisition; Owner: SysAdmin
--

ALTER TABLE ONLY "SchAcquisition"."TblLog_FileUpload_PointerHistoryDetail"
    ADD CONSTRAINT "TblLog_FileUpload_PointerHistoryDetail_pkey" PRIMARY KEY ("Sys_RPK");


--
-- TOC entry 3568 (class 2606 OID 6656455)
-- Name: TblLog_FileUpload_PointerHistory TblLog_FileUpload_PointerHistory_pkey; Type: CONSTRAINT; Schema: SchAcquisition; Owner: SysAdmin
--

ALTER TABLE ONLY "SchAcquisition"."TblLog_FileUpload_PointerHistory"
    ADD CONSTRAINT "TblLog_FileUpload_PointerHistory_pkey" PRIMARY KEY ("Sys_RPK");


--
-- TOC entry 3566 (class 2606 OID 6656457)
-- Name: TblLog_FileUpload_Pointer TblLog_FileUpload_Pointer_pkey; Type: CONSTRAINT; Schema: SchAcquisition; Owner: SysAdmin
--

ALTER TABLE ONLY "SchAcquisition"."TblLog_FileUpload_Pointer"
    ADD CONSTRAINT "TblLog_FileUpload_Pointer_pkey" PRIMARY KEY ("Sys_RPK");


--
-- TOC entry 3574 (class 2606 OID 6656459)
-- Name: TblRotateLog_FileUploadStagingAreaDetail TblRotateLog_FileUploadStagingAreaDetail_pkey; Type: CONSTRAINT; Schema: SchAcquisition; Owner: SysAdmin
--

ALTER TABLE ONLY "SchAcquisition"."TblRotateLog_FileUploadStagingAreaDetail"
    ADD CONSTRAINT "TblRotateLog_FileUploadStagingAreaDetail_pkey" PRIMARY KEY ("Sys_RotateID");


--
-- TOC entry 3572 (class 2606 OID 6656461)
-- Name: TblRotateLog_FileUploadStagingArea TblRotateLog_FileUploadStagingArea_pkey; Type: CONSTRAINT; Schema: SchAcquisition; Owner: SysAdmin
--

ALTER TABLE ONLY "SchAcquisition"."TblRotateLog_FileUploadStagingArea"
    ADD CONSTRAINT "TblRotateLog_FileUploadStagingArea_pkey" PRIMARY KEY ("Sys_RotateID");


--
-- TOC entry 3576 (class 2606 OID 6656463)
-- Name: TblCache_FunctionResult TblCache_FunctionResult_pkey; Type: CONSTRAINT; Schema: SchCache; Owner: SysAdmin
--

ALTER TABLE ONLY "SchCache"."TblCache_FunctionResult"
    ADD CONSTRAINT "TblCache_FunctionResult_pkey" PRIMARY KEY ("Sys_RPK");


--
-- TOC entry 3585 (class 2606 OID 6656465)
-- Name: TblStatistic_CacheFunctionResultAccess TblStatistic_CacheFunctionResultAccess_pkey; Type: CONSTRAINT; Schema: SchCache; Owner: SysAdmin
--

ALTER TABLE ONLY "SchCache"."TblStatistic_CacheFunctionResultAccess"
    ADD CONSTRAINT "TblStatistic_CacheFunctionResultAccess_pkey" PRIMARY KEY ("Sys_RPK");


--
-- TOC entry 3588 (class 2606 OID 6656467)
-- Name: TblLog_FunctionSnapshotSignature TblLog_FunctionSnapshotSignature_pkey; Type: CONSTRAINT; Schema: SchLog; Owner: SysAdmin
--

ALTER TABLE ONLY "SchLog"."TblLog_FunctionSnapshotSignature"
    ADD CONSTRAINT "TblLog_FunctionSnapshotSignature_pkey" PRIMARY KEY ("Sys_RPK");


--
-- TOC entry 3592 (class 2606 OID 6656469)
-- Name: TblLog_RecordDataTracking TblLog_RecordDataTracking_pkey; Type: CONSTRAINT; Schema: SchLog; Owner: SysAdmin
--

ALTER TABLE ONLY "SchLog"."TblLog_RecordDataTracking"
    ADD CONSTRAINT "TblLog_RecordDataTracking_pkey" PRIMARY KEY ("Sys_RPK");


--
-- TOC entry 3604 (class 2606 OID 6656471)
-- Name: TblLog_TableSnapshotSignature TblLog_TableSnapshotSignature_pkey; Type: CONSTRAINT; Schema: SchLog; Owner: SysAdmin
--

ALTER TABLE ONLY "SchLog"."TblLog_TableSnapshotSignature"
    ADD CONSTRAINT "TblLog_TableSnapshotSignature_pkey" PRIMARY KEY ("Sys_RPK");


--
-- TOC entry 3611 (class 2606 OID 6656473)
-- Name: TblStructure_DBObject TblLog_FunctionSnapshotSignature_pkey; Type: CONSTRAINT; Schema: SchRecovery; Owner: SysAdmin
--

ALTER TABLE ONLY "SchRecovery"."TblStructure_DBObject"
    ADD CONSTRAINT "TblLog_FunctionSnapshotSignature_pkey" PRIMARY KEY ("Sys_RPK");


--
-- TOC entry 3556 (class 1259 OID 6656474)
-- Name: idx0018_000001; Type: INDEX; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE INDEX idx0018_000001 ON "SchAcquisition"."TblLog_Device_PersonAccessFetch" USING btree ("Sys_PID");


--
-- TOC entry 3557 (class 1259 OID 6656475)
-- Name: idx0018_000002; Type: INDEX; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE INDEX idx0018_000002 ON "SchAcquisition"."TblLog_Device_PersonAccessFetch" USING btree ("Sys_SID");


--
-- TOC entry 3558 (class 1259 OID 6656476)
-- Name: idx0018_000003; Type: INDEX; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE INDEX idx0018_000003 ON "SchAcquisition"."TblLog_Device_PersonAccessFetch" USING btree ("Sys_RPK");


--
-- TOC entry 3559 (class 1259 OID 6656477)
-- Name: idx0018_000004; Type: INDEX; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE INDEX idx0018_000004 ON "SchAcquisition"."TblLog_Device_PersonAccessFetch" USING btree ("Sys_Data_Delete_DateTimeTZ");


--
-- TOC entry 3560 (class 1259 OID 6656478)
-- Name: idx0018_000005; Type: INDEX; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE INDEX idx0018_000005 ON "SchAcquisition"."TblLog_Device_PersonAccessFetch" USING btree ("Sys_Data_Hidden_DateTimeTZ");


--
-- TOC entry 3549 (class 1259 OID 6656479)
-- Name: idx0019_000001; Type: INDEX; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE INDEX idx0019_000001 ON "SchAcquisition"."TblLog_Device_PersonAccess" USING btree ("Sys_PID");


--
-- TOC entry 3550 (class 1259 OID 6656480)
-- Name: idx0019_000002; Type: INDEX; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE INDEX idx0019_000002 ON "SchAcquisition"."TblLog_Device_PersonAccess" USING btree ("Sys_SID");


--
-- TOC entry 3551 (class 1259 OID 6656481)
-- Name: idx0019_000003; Type: INDEX; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE INDEX idx0019_000003 ON "SchAcquisition"."TblLog_Device_PersonAccess" USING btree ("Sys_RPK");


--
-- TOC entry 3552 (class 1259 OID 6656482)
-- Name: idx0019_000004; Type: INDEX; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE INDEX idx0019_000004 ON "SchAcquisition"."TblLog_Device_PersonAccess" USING btree ("Sys_Data_Delete_DateTimeTZ");


--
-- TOC entry 3553 (class 1259 OID 6656494)
-- Name: idx0019_000005; Type: INDEX; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE INDEX idx0019_000005 ON "SchAcquisition"."TblLog_Device_PersonAccess" USING btree ("Sys_Data_Hidden_DateTimeTZ");


--
-- TOC entry 3554 (class 1259 OID 6656544)
-- Name: idx0019_000006; Type: INDEX; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE INDEX idx0019_000006 ON "SchAcquisition"."TblLog_Device_PersonAccess" USING btree ("Log_Device_PersonAccessFetch_RefID");


--
-- TOC entry 3555 (class 1259 OID 6656545)
-- Name: idx0019_000007; Type: INDEX; Schema: SchAcquisition; Owner: SysAdmin
--

CREATE INDEX idx0019_000007 ON "SchAcquisition"."TblLog_Device_PersonAccess" USING btree ("PersonID");


--
-- TOC entry 3577 (class 1259 OID 6656546)
-- Name: idx0259_000001; Type: INDEX; Schema: SchCache; Owner: SysAdmin
--

CREATE INDEX idx0259_000001 ON "SchCache"."TblCache_FunctionResult" USING btree ("SchemaFunctionName");


--
-- TOC entry 3578 (class 1259 OID 6656547)
-- Name: idx0259_000002; Type: INDEX; Schema: SchCache; Owner: SysAdmin
--

CREATE INDEX idx0259_000002 ON "SchCache"."TblCache_FunctionResult" USING btree ("Parameter");


--
-- TOC entry 3579 (class 1259 OID 6656548)
-- Name: idx0259_000003; Type: INDEX; Schema: SchCache; Owner: SysAdmin
--

CREATE INDEX idx0259_000003 ON "SchCache"."TblCache_FunctionResult" USING btree ("ObjectsSignatureReference");


--
-- TOC entry 3580 (class 1259 OID 6656549)
-- Name: idx0259_000004; Type: INDEX; Schema: SchCache; Owner: SysAdmin
--

CREATE INDEX idx0259_000004 ON "SchCache"."TblCache_FunctionResult" USING btree ("SQLRecallSyntax");


--
-- TOC entry 3581 (class 1259 OID 6656550)
-- Name: idx0259_000005; Type: INDEX; Schema: SchCache; Owner: SysAdmin
--

CREATE INDEX idx0259_000005 ON "SchCache"."TblCache_FunctionResult" USING btree ("ReturnDataType");


--
-- TOC entry 3582 (class 1259 OID 6656551)
-- Name: idx0259_000006; Type: INDEX; Schema: SchCache; Owner: SysAdmin
--

CREATE INDEX idx0259_000006 ON "SchCache"."TblCache_FunctionResult" USING btree ("ReturnDataTypePlaceHolder");


--
-- TOC entry 3583 (class 1259 OID 6656552)
-- Name: idx0259_000007; Type: INDEX; Schema: SchCache; Owner: SysAdmin
--

CREATE INDEX idx0259_000007 ON "SchCache"."TblCache_FunctionResult" USING btree ("SQLRecallSyntax", "ReturnDataType", "ReturnDataTypePlaceHolder", "Sys_Data_Delete_DateTimeTZ", "Sys_Data_Hidden_DateTimeTZ");


--
-- TOC entry 3586 (class 1259 OID 6656555)
-- Name: idx0260_000001; Type: INDEX; Schema: SchCache; Owner: SysAdmin
--

CREATE INDEX idx0260_000001 ON "SchCache"."TblStatistic_CacheFunctionResultAccess" USING btree ("Cache_FunctionResult_RefID");


--
-- TOC entry 3605 (class 1259 OID 6656557)
-- Name: idx0235_000001; Type: INDEX; Schema: SchLog; Owner: SysAdmin
--

CREATE INDEX idx0235_000001 ON "SchLog"."TblLog_TableSnapshotSignature" USING btree ("SchemaName");


--
-- TOC entry 3606 (class 1259 OID 6656559)
-- Name: idx0235_000002; Type: INDEX; Schema: SchLog; Owner: SysAdmin
--

CREATE INDEX idx0235_000002 ON "SchLog"."TblLog_TableSnapshotSignature" USING btree ("TableName");


--
-- TOC entry 3607 (class 1259 OID 6656560)
-- Name: idx0246_000001; Type: INDEX; Schema: SchLog; Owner: SysAdmin
--

CREATE INDEX idx0246_000001 ON "SchLog"."TblLog_TransactionHistory" USING btree ("Source_RefPID");


--
-- TOC entry 3608 (class 1259 OID 6656561)
-- Name: idx0246_000002; Type: INDEX; Schema: SchLog; Owner: SysAdmin
--

CREATE INDEX idx0246_000002 ON "SchLog"."TblLog_TransactionHistory" USING btree ("Source_RefSID");


--
-- TOC entry 3609 (class 1259 OID 6656562)
-- Name: idx0246_000003; Type: INDEX; Schema: SchLog; Owner: SysAdmin
--

CREATE INDEX idx0246_000003 ON "SchLog"."TblLog_TransactionHistory" USING btree ("Source_RefRPK");


--
-- TOC entry 3589 (class 1259 OID 6656563)
-- Name: idx0261_000001; Type: INDEX; Schema: SchLog; Owner: SysAdmin
--

CREATE INDEX idx0261_000001 ON "SchLog"."TblLog_FunctionSnapshotSignature" USING btree ("SchemaName");


--
-- TOC entry 3590 (class 1259 OID 6656564)
-- Name: idx0261_000002; Type: INDEX; Schema: SchLog; Owner: SysAdmin
--

CREATE INDEX idx0261_000002 ON "SchLog"."TblLog_FunctionSnapshotSignature" USING btree ("FunctionName");


--
-- TOC entry 3593 (class 1259 OID 6656565)
-- Name: idx0313_000001; Type: INDEX; Schema: SchLog; Owner: SysAdmin
--

CREATE INDEX idx0313_000001 ON "SchLog"."TblLog_RecordDataTracking" USING btree ("Sys_PID");


--
-- TOC entry 3594 (class 1259 OID 6656566)
-- Name: idx0313_000002; Type: INDEX; Schema: SchLog; Owner: SysAdmin
--

CREATE INDEX idx0313_000002 ON "SchLog"."TblLog_RecordDataTracking" USING btree ("Sys_SID");


--
-- TOC entry 3595 (class 1259 OID 6656567)
-- Name: idx0313_000003; Type: INDEX; Schema: SchLog; Owner: SysAdmin
--

CREATE INDEX idx0313_000003 ON "SchLog"."TblLog_RecordDataTracking" USING btree ("Sys_RPK");


--
-- TOC entry 3596 (class 1259 OID 6656568)
-- Name: idx0313_000004; Type: INDEX; Schema: SchLog; Owner: SysAdmin
--

CREATE INDEX idx0313_000004 ON "SchLog"."TblLog_RecordDataTracking" USING btree ("Sys_Data_Delete_DateTimeTZ");


--
-- TOC entry 3597 (class 1259 OID 6656569)
-- Name: idx0313_000005; Type: INDEX; Schema: SchLog; Owner: SysAdmin
--

CREATE INDEX idx0313_000005 ON "SchLog"."TblLog_RecordDataTracking" USING btree ("Sys_Data_Hidden_DateTimeTZ");


--
-- TOC entry 3598 (class 1259 OID 6656570)
-- Name: idx0313_000006; Type: INDEX; Schema: SchLog; Owner: SysAdmin
--

CREATE INDEX idx0313_000006 ON "SchLog"."TblLog_RecordDataTracking" USING btree ("Record_SchemaTableName");


--
-- TOC entry 3599 (class 1259 OID 6656571)
-- Name: idx0313_000007; Type: INDEX; Schema: SchLog; Owner: SysAdmin
--

CREATE INDEX idx0313_000007 ON "SchLog"."TblLog_RecordDataTracking" USING btree ("Record_SysPID");


--
-- TOC entry 3600 (class 1259 OID 6656572)
-- Name: idx0313_000008; Type: INDEX; Schema: SchLog; Owner: SysAdmin
--

CREATE INDEX idx0313_000008 ON "SchLog"."TblLog_RecordDataTracking" USING btree ("Record_SysSID");


--
-- TOC entry 3601 (class 1259 OID 6656573)
-- Name: idx0313_000009; Type: INDEX; Schema: SchLog; Owner: SysAdmin
--

CREATE INDEX idx0313_000009 ON "SchLog"."TblLog_RecordDataTracking" USING btree ("Record_UpperLink_RefID");


--
-- TOC entry 3602 (class 1259 OID 6656574)
-- Name: idx0313_000010; Type: INDEX; Schema: SchLog; Owner: SysAdmin
--

CREATE INDEX idx0313_000010 ON "SchLog"."TblLog_RecordDataTracking" USING btree ("Record_Version");


-- Completed on 2026-11-26 18:47:28 WIB

--
-- PostgreSQL database dump complete
--

\unrestrict nhzu5sLfJv6wCYclQ6WF2esp88qqNo9kjXx36BIG5j6IouzbKRZJnTLmqPApT2v

