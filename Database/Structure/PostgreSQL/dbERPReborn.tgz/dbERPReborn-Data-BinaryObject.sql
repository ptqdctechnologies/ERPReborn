--
-- PostgreSQL database dump
--

\restrict ZgCBQrI0ld890HGg2DssXRYkBZsnFAKnoRUY52B3qYHFthK5QBLcBSVf93ZRjeL

-- Dumped from database version 18.7 (Debian 18.7-1.pgdg13+2)
-- Dumped by pg_dump version 18.7 (Debian 18.7-1.pgdg13+2)

-- Started on 2026-11-26 18:47:28 WIB

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

-- Completed on 2026-11-26 18:47:28 WIB

--
-- PostgreSQL database dump complete
--

\unrestrict ZgCBQrI0ld890HGg2DssXRYkBZsnFAKnoRUY52B3qYHFthK5QBLcBSVf93ZRjeL

