--
-- PostgreSQL database dump
--

\restrict XmEICj8fK4eDvo1hUzZIEQyZpTgphVEm9moHJz4pr72zaXR80S1o9eS8dkvaX0x

-- Dumped from database version 18.6 (Debian 18.6-1.pgdg13+2)
-- Dumped by pg_dump version 18.6 (Debian 18.6-1.pgdg13+2)

-- Started on 2026-08-23 00:33:06 WIB

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

-- Completed on 2026-08-23 00:33:06 WIB

--
-- PostgreSQL database dump complete
--

\unrestrict XmEICj8fK4eDvo1hUzZIEQyZpTgphVEm9moHJz4pr72zaXR80S1o9eS8dkvaX0x

