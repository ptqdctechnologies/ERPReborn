--
-- PostgreSQL database dump
--

\restrict 1VzyYGWFnuKf6p8fajXKiIA8gJfM1eBEwbylfc6QmzMtbcAtfHsrKgVzdgQsagH

-- Dumped from database version 18.4 (Debian 18.4-1.pgdg13+1)
-- Dumped by pg_dump version 18.4 (Debian 18.4-1.pgdg13+1)

-- Started on 2026-07-27 18:32:22 WIB

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

-- Completed on 2026-07-27 18:32:22 WIB

--
-- PostgreSQL database dump complete
--

\unrestrict 1VzyYGWFnuKf6p8fajXKiIA8gJfM1eBEwbylfc6QmzMtbcAtfHsrKgVzdgQsagH

