--
-- PostgreSQL database dump
--

\restrict zUBnyIcSemeswjOI5waEVxLjKE2d7VeO6Cw8ysG0DY9lE4oewLwBVdJwLsPAR8k

-- Dumped from database version 18.4 (Debian 18.4-1.pgdg13+1)
-- Dumped by pg_dump version 18.4 (Debian 18.4-1.pgdg13+1)

-- Started on 2026-07-28 17:21:30 WIB

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

-- Completed on 2026-07-28 17:21:30 WIB

--
-- PostgreSQL database dump complete
--

\unrestrict zUBnyIcSemeswjOI5waEVxLjKE2d7VeO6Cw8ysG0DY9lE4oewLwBVdJwLsPAR8k

