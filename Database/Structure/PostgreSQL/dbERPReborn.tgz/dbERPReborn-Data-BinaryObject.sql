--
-- PostgreSQL database dump
--

\restrict UU70TNDWfnsueA4q3JmdswlSzJrHndOWcAvdLJcmQPJQSA4eDfAOIVHbGqGlH9b

-- Dumped from database version 18.6 (Debian 18.6-1.pgdg13+2)
-- Dumped by pg_dump version 18.6 (Debian 18.6-1.pgdg13+2)

-- Started on 2026-09-08 16:38:55 WIB

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

-- Completed on 2026-09-08 16:38:55 WIB

--
-- PostgreSQL database dump complete
--

\unrestrict UU70TNDWfnsueA4q3JmdswlSzJrHndOWcAvdLJcmQPJQSA4eDfAOIVHbGqGlH9b

