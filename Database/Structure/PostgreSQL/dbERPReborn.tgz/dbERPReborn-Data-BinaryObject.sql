--
-- PostgreSQL database dump
--

\restrict 0uUhDhrCeWEZhmbSblgkfLUDqg4h5AuLdiAHMNh5GfMYYWeaxhNT5mpD6HMymax

-- Dumped from database version 18.6 (Debian 18.6-1.pgdg13+2)
-- Dumped by pg_dump version 18.6 (Debian 18.6-1.pgdg13+2)

-- Started on 2026-09-14 14:22:30 WIB

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

-- Completed on 2026-09-14 14:22:30 WIB

--
-- PostgreSQL database dump complete
--

\unrestrict 0uUhDhrCeWEZhmbSblgkfLUDqg4h5AuLdiAHMNh5GfMYYWeaxhNT5mpD6HMymax

