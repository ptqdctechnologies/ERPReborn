--
-- PostgreSQL database dump
--

\restrict VrDx2aNMJgoaqrNYR7o1zfKCagq2KXldf3y3nnDfsRweO48g0ddR9yzlMOLjQGP

-- Dumped from database version 18.6 (Debian 18.6-1.pgdg13+2)
-- Dumped by pg_dump version 18.6 (Debian 18.6-1.pgdg13+2)

-- Started on 2026-09-18 19:10:43 WIB

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 8 (class 2615 OID 4967543)
-- Name: SchBudgeting; Type: SCHEMA; Schema: -; Owner: SysEngine
--

CREATE SCHEMA "SchBudgeting";


ALTER SCHEMA "SchBudgeting" OWNER TO "SysEngine";

--
-- TOC entry 9 (class 2615 OID 4967544)
-- Name: SchSystem; Type: SCHEMA; Schema: -; Owner: SysEngine
--

CREATE SCHEMA "SchSystem";


ALTER SCHEMA "SchSystem" OWNER TO "SysEngine";

--
-- TOC entry 10 (class 2615 OID 2200)
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- TOC entry 2 (class 3079 OID 4967545)
-- Name: dblink; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS dblink WITH SCHEMA public;


--
-- TOC entry 3576 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION dblink; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION dblink IS 'connect to other PostgreSQL databases from within a database';


--
-- TOC entry 3 (class 3079 OID 4967591)
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA public;


--
-- TOC entry 3577 (class 0 OID 0)
-- Dependencies: 3
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- TOC entry 4 (class 3079 OID 4967635)
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- TOC entry 3578 (class 0 OID 0)
-- Dependencies: 4
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- TOC entry 968 (class 1247 OID 4967675)
-- Name: HoldFuncSys_General_FeedBackQuery; Type: TYPE; Schema: SchSystem; Owner: SysEngine
--

CREATE TYPE "SchSystem"."HoldFuncSys_General_FeedBackQuery" AS (
	"SignSuccess" smallint,
	"SignRecordType" character varying,
	"SignRecordID" bigint,
	"SignMessage" character varying,
	"AdditionalData" json
);


ALTER TYPE "SchSystem"."HoldFuncSys_General_FeedBackQuery" OWNER TO "SysEngine";

--
-- TOC entry 971 (class 1247 OID 4967678)
-- Name: HoldFuncSys_General_GetDataPickSet; Type: TYPE; Schema: SchSystem; Owner: SysEngine
--

CREATE TYPE "SchSystem"."HoldFuncSys_General_GetDataPickSet" AS (
	"Sys_ID" bigint,
	"ProcessedData_FlatText" character varying,
	"ProcessedData_TextArray" character varying[],
	"ProcessedData_JSON" json,
	"RawData_JSON" json
);


ALTER TYPE "SchSystem"."HoldFuncSys_General_GetDataPickSet" OWNER TO "SysEngine";

--
-- TOC entry 974 (class 1247 OID 4967681)
-- Name: HoldFuncSys_General_GetEnvironmentParameterExtraction; Type: TYPE; Schema: SchSystem; Owner: SysAdmin
--

CREATE TYPE "SchSystem"."HoldFuncSys_General_GetEnvironmentParameterExtraction" AS (
	"Env_Session" json,
	"DBLinkConnectionString_FE" character varying,
	"DBLinkConnectionString_BE_DataOLAP" character varying,
	"DBLinkConnectionString_BE_DataOLTP" character varying,
	"DBLinkConnectionString_BE_DataWarehouse" character varying,
	"DBLinkConnectionString_BE_SysConfig" character varying,
	"Pagination_PageSize" bigint,
	"Pagination_PageShow" bigint,
	"DataCustomize_Filter_JSON" json,
	"DataCustomize_Filter" character varying,
	"DataCustomize_Sort_JSON" json,
	"DataCustomize_Sort" character varying,
	"DataCustomize_Filter_CoreFields_JSON" json,
	"DataCustomize_Filter_CoreFields" character varying,
	"DataCustomize_Sort_CoreFields_JSON" json,
	"DataCustomize_Sort_CoreFields" character varying,
	"DataCustomize_Filter_NonCoreFields_JSON" json,
	"DataCustomize_Filter_NonCoreFields" character varying,
	"DataCustomize_Sort_NonCoreFields_JSON" json,
	"DataCustomize_Sort_NonCoreFields" character varying,
	"Array_SysBranch_RefID" bigint[],
	"Array_SysBaseBranch_RefID" bigint[],
	"Array_Currency_RefID" bigint[],
	"Array_CurrencyISOCode" character varying(3)[],
	"Array_CurrencySymbol" character varying(4)[]
);


ALTER TYPE "SchSystem"."HoldFuncSys_General_GetEnvironmentParameterExtraction" OWNER TO "SysAdmin";

--
-- TOC entry 273 (class 1255 OID 4967682)
-- Name: Func_TblCombinedBudgetSectionDetailAbsorption_INSERT(character varying, bigint, timestamp with time zone, bigint, bigint, bigint, bigint, numeric, numeric, json); Type: FUNCTION; Schema: SchBudgeting; Owner: SysEngine
--

CREATE FUNCTION "SchBudgeting"."Func_TblCombinedBudgetSectionDetailAbsorption_INSERT"(character varying, bigint, timestamp with time zone, bigint, bigint, bigint, bigint, numeric, numeric, json) RETURNS SETOF "SchSystem"."HoldFuncSys_General_FeedBackQuery"
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                : "SchBudgeting"."Func_TblCombinedBudgetSectionDetailAbsorption_INSERT"
▪ Versi               : 1.00.0000
▪ Tanggal 
     ► Pemutakhiran   : 2023-12-04
     ► Pembuatan      : 2023-12-04
▪ Input               : varSysDataAnnotation (varchar - Mandatory)
						varIDSession (bigint - Mandatory)
						varEntryDateTimeTZ (timestamptz - Mandatory)
						varSysPartitionRemovableRecordKey_RefID (bigint - Mandatory)
						varBranch_RefID (bigint - Mandatory)
						varBaseCurrency_RefID (bigint - Mandatory)
						------------------------------
						varCombinedBudgetSectionDetail_RefID (bigint - Mandatory)
						varQuantityAbsorption (numeric - Mandatory)
						varPriceBaseCurrencyAbsorptionValue	(numeric - Mandatory)
						varAbsorptionDetail	(json - Mandatory)
						------------------------------
▪ Output              : varRecSetOutput ("SchSystem"."HoldFuncSys_General_FeedBackQuery")
▪ Keterkaitan Fungsi  : -
▪ Deskripsi           : Memasukan data (INSERT) pada tabel TblCombinedBudgetSectionDetailAbsorption
▪ Copyright           : Zheta © 2023

----------------------------------------------------------------------------------------------------*/

DECLARE
	---[ Input Variable(s) ]------------------------------------------------------------------------
		varSysDataAnnotation						ALIAS FOR $1;
		varIDSession								ALIAS FOR $2;
		varEntryDateTimeTZ							ALIAS FOR $3;
		varSysPartitionRemovableRecordKey_RefID		ALIAS FOR $4;
		varBranch_RefID								ALIAS FOR $5;
		varBaseCurrency_RefID						ALIAS FOR $6;
		------------------------------
		varCombinedBudgetSectionDetail_RefID		ALIAS FOR $7;
		varQuantityAbsorption						ALIAS FOR $8;
		varPriceBaseCurrencyAbsorptionValue			ALIAS FOR $9;
		varAbsorptionDetail							ALIAS FOR $10;

	---[ Output Variable(s) ]-----------------------------------------------------------------------
		varRecSetOutput								"SchSystem"."HoldFuncSys_General_FeedBackQuery"%rowtype;

	---[ Intermediate Variable(s) ]-----------------------------------------------------------------
		varSystemNoticeTag							varchar;
		varSignEligibleToProcess					boolean;

BEGIN
	---[ Data Initializing ]------------------------------------------------------------------------
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		IF (varSignEligibleToProcess = FALSE) THEN
			varSignEligibleToProcess := TRUE;
		END IF;

		IF (varSignEligibleToProcess = TRUE) THEN
		END IF;


	---[ Data Processing ]--------------------------------------------------------------------------
		IF (varSignEligibleToProcess = TRUE) THEN
			INSERT INTO 
				"SchBudgeting"."TblCombinedBudgetSectionDetailAbsorption"
					(
					"Sys_Data_Annotation",
					"Sys_Data_Entry_LoginSession_RefID",
					"Sys_Data_Entry_DateTimeTZ",
					"Sys_Partition_RemovableRecord_Key_RefID",
					"Sys_Branch_RefID",
					"Sys_BaseCurrency_RefID",
					------------------------------
					"CombinedBudgetSectionDetail_RefID",
					"QuantityAbsorption",
					"PriceBaseCurrencyAbsorptionValue",
					"AbsorptionDetail"
					)
				VALUES
					(
					varSysDataAnnotation,
					varIDSession,
					varEntryDateTimeTZ,
					varSysPartitionRemovableRecordKey_RefID,
					varBranch_RefID,
					varBaseCurrency_RefID,
					------------------------------
					varCombinedBudgetSectionDetail_RefID,
					varQuantityAbsorption,
					varPriceBaseCurrencyAbsorptionValue,
					varAbsorptionDetail
					);
		END IF;


	---[ Data Return ]-----------------------------------------------------------------------------
		IF (varSignEligibleToProcess = TRUE) THEN
			varRecSetOutput."SignSuccess" := 1;
			varRecSetOutput."SignRecordType" := 'Sys_RPK';
			varRecSetOutput."SignRecordID" := CURRVAL('"SchBudgeting"."TblCombinedBudgetSectionDetailAbsorption_Sys_RPK_seq"');
			varRecSetOutput."SignMessage" := null;

			RETURN NEXT varRecSetOutput;
		END IF;


	---[ Exception Handling ]-----------------------------------------------------------------------
		--EXCEPTION WHEN OTHERS THEN ...

END;
$_$;


ALTER FUNCTION "SchBudgeting"."Func_TblCombinedBudgetSectionDetailAbsorption_INSERT"(character varying, bigint, timestamp with time zone, bigint, bigint, bigint, bigint, numeric, numeric, json) OWNER TO "SysEngine";

--
-- TOC entry 301 (class 1255 OID 4967683)
-- Name: Func_TblCombinedBudgetSectionDetailAbsorption_UPDATE(bigint, bigint, timestamp with time zone, bigint, bigint, bigint, bigint, numeric, numeric, json); Type: FUNCTION; Schema: SchBudgeting; Owner: SysEngine
--

CREATE FUNCTION "SchBudgeting"."Func_TblCombinedBudgetSectionDetailAbsorption_UPDATE"(bigint, bigint, timestamp with time zone, bigint, bigint, bigint, bigint, numeric, numeric, json) RETURNS SETOF "SchSystem"."HoldFuncSys_General_FeedBackQuery"
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                : "SchBudgeting"."Func_TblCombinedBudgetSectionDetailAbsorption_UPDATE"
▪ Versi               : 1.00.0000
▪ Tanggal 
     ► Pemutakhiran   : 2023-12-04
     ► Pembuatan      : 2023-12-04
▪ Input               : varID (bigint - Mandatory)
						varIDSession (bigint - Mandatory)
						varEditDateTimeTZ (timestamptz - Mandatory)
						varSysPartitionRemovableRecordKey_RefID (bigint - Mandatory)
						varBranch_RefID (bigint - Mandatory)
						varBaseCurrency_RefID (bigint - Mandatory)
						------------------------------
						varCombinedBudgetSectionDetail_RefID (bigint - Mandatory)
						varQuantityAbsorption (numeric - Mandatory)
						varPriceBaseCurrencyAbsorptionValue	(numeric - Mandatory)
						varAbsorptionDetail	(json - Mandatory)
						------------------------------
▪ Output              : varRecSetOutput ("SchSystem"."HoldFuncSys_General_FeedBackQuery")
▪ Keterkaitan Fungsi  : -
▪ Deskripsi           : Memutakhirkan data (UPDATE) pada tabel TblCombinedBudgetSectionDetailAbsorption
▪ Copyright           : Zheta © 2023

----------------------------------------------------------------------------------------------------*/

DECLARE
	---[ Input Variable(s) ]------------------------------------------------------------------------
		varID										ALIAS FOR $1;
		varIDSession								ALIAS FOR $2;
		varEditDateTimeTZ							ALIAS FOR $3;
		varSysPartitionRemovableRecordKey_RefID		ALIAS FOR $4;
		varBranch_RefID								ALIAS FOR $5;
		varBaseCurrency_RefID						ALIAS FOR $6;
		------------------------------
		varCombinedBudgetSectionDetail_RefID		ALIAS FOR $7;
		varQuantityAbsorption						ALIAS FOR $8;
		varPriceBaseCurrencyAbsorptionValue			ALIAS FOR $9;
		varAbsorptionDetail							ALIAS FOR $10;

	---[ Output Variable(s) ]-----------------------------------------------------------------------
		varRecSetOutput								"SchSystem"."HoldFuncSys_General_FeedBackQuery"%rowtype;

	---[ Intermediate Variable(s) ]-----------------------------------------------------------------
		varSystemNoticeTag							varchar;
		varSignEligibleToProcess					boolean;

BEGIN
	---[ Data Initializing ]------------------------------------------------------------------------
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		IF (varSignEligibleToProcess = FALSE) THEN
			varSignEligibleToProcess := TRUE;
		END IF;

		IF (varSignEligibleToProcess = TRUE) THEN
		END IF;


	---[ Data Processing ]--------------------------------------------------------------------------
		IF (varSignEligibleToProcess = TRUE) THEN
			UPDATE
				"SchBudgeting"."TblCombinedBudgetSectionDetailAbsorption"
			SET
				"Sys_Data_Edit_LoginSession_RefID" = varIDSession,
				"Sys_Data_Edit_DateTimeTZ" = varEditDateTimeTZ,
				"Sys_Partition_RemovableRecord_Key_RefID" = varSysPartitionRemovableRecordKey_RefID,
				"Sys_Branch_RefID" = varBranch_RefID,
				"Sys_BaseCurrency_RefID" = varBaseCurrency_RefID,
				------------------------------
				"CombinedBudgetSectionDetail_RefID" = varCombinedBudgetSectionDetail_RefID,
				"QuantityAbsorption" = varQuantityAbsorption,
				"PriceBaseCurrencyAbsorptionValue" = varPriceBaseCurrencyAbsorptionValue,
				"AbsorptionDetail" = varAbsorptionDetail
			WHERE
				"Sys_PID" = varID
				OR
				"Sys_SID" = varID;
		END IF;


	---[ Data Return ]-----------------------------------------------------------------------------
		IF (varSignEligibleToProcess = TRUE) THEN
			varRecSetOutput."SignSuccess" := 1;
			varRecSetOutput."SignRecordType" := 'Sys_RPK';
			varRecSetOutput."SignRecordID" := (SELECT "Sys_RPK" FROM "SchBudgeting"."TblCombinedBudgetSectionDetailAbsorption" WHERE "Sys_PID" = varID OR "Sys_SID" = varID LIMIT 1);
			varRecSetOutput."SignMessage" := null;

			RETURN NEXT varRecSetOutput;
		END IF;


	---[ Exception Handling ]-----------------------------------------------------------------------
		--EXCEPTION WHEN OTHERS THEN ...

END;
$_$;


ALTER FUNCTION "SchBudgeting"."Func_TblCombinedBudgetSectionDetailAbsorption_UPDATE"(bigint, bigint, timestamp with time zone, bigint, bigint, bigint, bigint, numeric, numeric, json) OWNER TO "SysEngine";

--
-- TOC entry 307 (class 1255 OID 4967684)
-- Name: FuncSys_Cryptography_CryptHash_Check(character varying, character varying); Type: FUNCTION; Schema: SchSystem; Owner: SysAdmin
--

CREATE FUNCTION "SchSystem"."FuncSys_Cryptography_CryptHash_Check"(character varying, character varying DEFAULT NULL::character varying) RETURNS json
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchSystem"."FuncSys_Cryptography_CryptHash_Check"
▪ Versi               :	1.00.0000
▪ Tanggal
     ► Pemutakhiran   :	2026-09-03
     ► Pembuatan      :	2026-09-03
▪ Input               :	• varPlainData (varchar - Mandatory)
						------------------------------
						• varHash (varchar - Mandatory)
						------------------------------
▪ Output              :	varReturn (json)
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Mendapatkan Dekripsi PGP dengan Key Simetris
▪ Copyright           :	Zheta © 2026

----[ Related Database Object(s) ]------------------------------------------------------------------

▪ Tabel               :	-

▪ Fungsi              :	-

----[ SQL Example(s) ]------------------------------------------------------------------------------

▪ ---> Dalam Bentuk Hash Non Base64
	SELECT
		"SchSystem"."FuncSys_Cryptography_CryptHash_Check"(
			'My Plain Data',
			'$2a$06$rhvsbDlKSMHkly6m5MHKyu5Mt5EKsSytXXCHAMc6HpQ78TzwyEtPq'
			);

▪ ---> Dalam Bentuk Hash Base64
	SELECT
		"SchSystem"."FuncSys_Cryptography_CryptHash_Check"(
			'My Plain Data',
			'JDJhJDA2JHJodnNiRGxLU01Ia2x5Nm01TUhLeXU1TXQ1RUtzU3l0WFhDSEFNYzZIcFE3OFR6d3lFdFBx'
			);

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varPlainData											ALIAS FOR $1;
			------------------------------

		---{ Optional }-------------------
			varHash													ALIAS FOR $2;
			------------------------------

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----
			varReturn												json;

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

			varHashRegenate											varchar;

		---{ Additional }-----------------

BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------( START )-----
			IF (varSignEligibleToProcess IS FALSE) THEN
				varSignEligibleToProcess := TRUE;
			END IF;
		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------(  END  )-----

		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------( START )-----
			IF (varSignEligibleToProcess IS TRUE) THEN
			END IF;
		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------(  END  )-----

	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			-----[ MAIN DATA PROCESSING ]---------------------------------------------( START )-----
				---> Reinitializing : varHash
					varHash	:=
						(
						CASE
							---> Bila varHash berbentuk Base64
							WHEN (varHash ~ '^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$') THEN
								CONVERT_FROM (
									DECODE (
										varHash,
										'base64'
										),
									'UTF-8'
									)
							---> Bila varHash tidak berbentuk Base64
							ELSE
								varHash							
						END
						);

				---> Reinitializing : varHashRegenate
					varHashRegenate := 
						CRYPT (
							varPlainData,
							varHash
							)::varchar;

			-----[ MAIN DATA PROCESSING ]---------------------------------------------(  END  )-----
		END IF;

	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----
		---> Initializing : varReturn
			varReturn :=
				JSON_BUILD_OBJECT (
					'plainData', varPlainData,
					'hash', varHash,
					'hashRegenate', varHashRegenate,
					'signIdentic',
						CASE
							WHEN (varHash = varHashRegenate) THEN
								TRUE
							ELSE
								FALSE
						END
					);

		---> Send Data Output
			RETURN
				varReturn;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		EXCEPTION
			WHEN OTHERS THEN
				NULL;

END;
$_$;


ALTER FUNCTION "SchSystem"."FuncSys_Cryptography_CryptHash_Check"(character varying, character varying) OWNER TO "SysAdmin";

--
-- TOC entry 237 (class 1255 OID 4967685)
-- Name: FuncSys_Cryptography_CryptHash_Generate(character varying, character varying); Type: FUNCTION; Schema: SchSystem; Owner: SysAdmin
--

CREATE FUNCTION "SchSystem"."FuncSys_Cryptography_CryptHash_Generate"(character varying, character varying DEFAULT NULL::character varying) RETURNS json
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchSystem"."FuncSys_Cryptography_CryptHash_Generate"
▪ Versi               :	1.00.0000
▪ Tanggal
     ► Pemutakhiran   :	2026-09-03
     ► Pembuatan      :	2026-09-03
▪ Input               :	• varPlainData (varchar - Mandatory)
						------------------------------
						• varSalt (varchar - Mandatory)
						------------------------------
▪ Output              :	varReturn (json)
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Mendapatkan Hash Crypt
▪ Copyright           :	Zheta © 2026

----[ Related Database Object(s) ]------------------------------------------------------------------

▪ Tabel               :	-

▪ Fungsi              :	-

----[ SQL Example(s) ]------------------------------------------------------------------------------

▪ --->
	SELECT
		"SchSystem"."FuncSys_Cryptography_CryptHash_Generate"(
			'My Plain Data'
			);

▪ --->
	SELECT
		"SchSystem"."FuncSys_Cryptography_CryptHash_Generate"(
			'My Plain Data',
			'My Salt'
			);

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varPlainData											ALIAS FOR $1;
			------------------------------

		---{ Optional }-------------------
			varSalt													ALIAS FOR $2;
			------------------------------

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----
			varReturn												json;

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

			varHash													varchar;
			varBase64Hash											varchar;

		---{ Additional }-----------------

BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------( START )-----
			IF (varSignEligibleToProcess IS FALSE) THEN
				varSignEligibleToProcess := TRUE;
			END IF;
		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------(  END  )-----

		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------( START )-----
			IF (varSignEligibleToProcess IS TRUE) THEN
				---> Reinitializing : varSalt
					varSalt :=
						COALESCE (
							varSalt,
							(GEN_SALT ('bf'))::varchar
							);
			END IF;
		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------(  END  )-----

	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			-----[ MAIN DATA PROCESSING ]---------------------------------------------( START )-----
				---> Initializing : varHash
					varHash :=
						(
						CRYPT (
							varPlainData,
							varSalt
							)
						)::varchar;

				---> Initializing : varBase64Hash
					varBase64Hash :=
						REPLACE(
							(
							ENCODE (
								CONVERT_TO (
									varHash,
									'UTF-8'
									), 
								'base64'
								)
							)::varchar,
							E'\n',
							''
							);


			-----[ MAIN DATA PROCESSING ]---------------------------------------------(  END  )-----
		END IF;

	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----
		---> Initializing : varReturn
			varReturn :=
				JSON_BUILD_OBJECT (
					'plainData', varPlainData,
					'salt', varSalt,
					'hash', varHash,
					'base64Hash', varBase64Hash
					);

		---> Send Data Output
			RETURN
				varReturn;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		EXCEPTION
			WHEN OTHERS THEN
				NULL;

END;
$_$;


ALTER FUNCTION "SchSystem"."FuncSys_Cryptography_CryptHash_Generate"(character varying, character varying) OWNER TO "SysAdmin";

--
-- TOC entry 247 (class 1255 OID 4967686)
-- Name: FuncSys_Cryptography_PGPSymmetric_Decryption(character varying, character varying); Type: FUNCTION; Schema: SchSystem; Owner: SysAdmin
--

CREATE FUNCTION "SchSystem"."FuncSys_Cryptography_PGPSymmetric_Decryption"(character varying, character varying DEFAULT NULL::character varying) RETURNS json
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchSystem"."FuncSys_Cryptography_PGPSymmetric_Decryption"
▪ Versi               :	1.00.0000
▪ Tanggal
     ► Pemutakhiran   :	2026-09-02
     ► Pembuatan      :	2026-09-02
▪ Input               :	• varBase64EncryptedData (varchar - Mandatory)
						------------------------------
						• varKey (varchar - Mandatory)
						------------------------------
▪ Output              :	varReturn (json)
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Mendapatkan Dekripsi PGP dengan Key Simetris
▪ Copyright           :	Zheta © 2026

----[ Related Database Object(s) ]------------------------------------------------------------------

▪ Tabel               :	-

▪ Fungsi              :	-

----[ SQL Example(s) ]------------------------------------------------------------------------------

▪ --->
	SELECT
		"SchSystem"."FuncSys_Cryptography_PGPSymmetric_Decryption"(
			'ww0EBwMCfLm7UILgj+to0j4BRcmtrDXioEBKXjEIE1wBZ/GksDjIqGz4nBWUnbqBUrEvAmHSbORbca/hFG+x08IAW0qB5mTyTm89PrMZ3Q==',
			'My Key'
			);

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varBase64EncryptedData									ALIAS FOR $1;
			------------------------------

		---{ Optional }-------------------
			varKey													ALIAS FOR $2;
			------------------------------

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----
			varReturn												json;

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

			varDecryptedData										varchar;

		---{ Additional }-----------------

BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------( START )-----
			IF (varSignEligibleToProcess IS FALSE) THEN
				varSignEligibleToProcess := TRUE;
			END IF;
		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------(  END  )-----

		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------( START )-----
			IF (varSignEligibleToProcess IS TRUE) THEN
			END IF;
		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------(  END  )-----

	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			-----[ MAIN DATA PROCESSING ]---------------------------------------------( START )-----
				---> Main Process
					varDecryptedData :=
						(
						PGP_SYM_DECRYPT (
							DECODE (
								REPLACE (
									varBase64EncryptedData,
									E'\n',
									''
									),
								'base64'
								),
							varKey
							)
						)::varchar;

			-----[ MAIN DATA PROCESSING ]---------------------------------------------(  END  )-----
		END IF;

	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----
		---> Initializing : varReturn
			varReturn :=
				JSON_BUILD_OBJECT (
					'base64EncryptedData', varBase64EncryptedData,
					'key', varKey,
					'decryptedData', varDecryptedData
					);

		---> Send Data Output
			RETURN
				varReturn;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		EXCEPTION
			WHEN OTHERS THEN
				NULL;

END;
$_$;


ALTER FUNCTION "SchSystem"."FuncSys_Cryptography_PGPSymmetric_Decryption"(character varying, character varying) OWNER TO "SysAdmin";

--
-- TOC entry 338 (class 1255 OID 4967687)
-- Name: FuncSys_Cryptography_PGPSymmetric_Encryption(character varying, character varying); Type: FUNCTION; Schema: SchSystem; Owner: SysAdmin
--

CREATE FUNCTION "SchSystem"."FuncSys_Cryptography_PGPSymmetric_Encryption"(character varying, character varying DEFAULT NULL::character varying) RETURNS json
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchSystem"."FuncSys_Cryptography_PGPSymmetric_Encryption"
▪ Versi               :	1.00.0000
▪ Tanggal
     ► Pemutakhiran   :	2026-09-02
     ► Pembuatan      :	2026-09-02
▪ Input               :	• varPlainData (varchar - Mandatory)
						------------------------------
						• varKey (varchar - Mandatory)
						------------------------------
▪ Output              :	varReturn (json)
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Mendapatkan Enkripsi PGP dengan Key Simetris
▪ Copyright           :	Zheta © 2026

----[ Related Database Object(s) ]------------------------------------------------------------------

▪ Tabel               :	-

▪ Fungsi              :	-

----[ SQL Example(s) ]------------------------------------------------------------------------------

▪ --->
	SELECT
		"SchSystem"."FuncSys_Cryptography_PGPSymmetric_Encryption"(
			'My Plain Data',
			'My Key'
			);

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varPlainData											ALIAS FOR $1;
			------------------------------

		---{ Optional }-------------------
			varKey													ALIAS FOR $2;
			------------------------------

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----
			varReturn												json;

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

			varEncryptedData										varchar;

		---{ Additional }-----------------

BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------( START )-----
			IF (varSignEligibleToProcess IS FALSE) THEN
				varSignEligibleToProcess := TRUE;
			END IF;
		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------(  END  )-----

		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------( START )-----
			IF (varSignEligibleToProcess IS TRUE) THEN
				---> Reinitializing : varKey
					varKey :=
						COALESCE (
							varKey,
							(GEN_SALT ('bf'))::varchar
							);
			END IF;
		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------(  END  )-----

	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			-----[ MAIN DATA PROCESSING ]---------------------------------------------( START )-----
				---> Main Process
					varEncryptedData :=
						REPLACE(
							(
							ENCODE (
								PGP_SYM_ENCRYPT (
									varPlainData,
									varKey
									), 
								'base64'
								)
							)::varchar,
							E'\n',
							''
							);

			-----[ MAIN DATA PROCESSING ]---------------------------------------------(  END  )-----
		END IF;

	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----
		---> Initializing : varReturn
			varReturn :=
				JSON_BUILD_OBJECT (
					'plainData', varPlainData,
					'key', varKey,
					'base64EncryptedData', varEncryptedData
					);

		---> Send Data Output
			RETURN
				varReturn;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		EXCEPTION
			WHEN OTHERS THEN
				NULL;

END;
$_$;


ALTER FUNCTION "SchSystem"."FuncSys_Cryptography_PGPSymmetric_Encryption"(character varying, character varying) OWNER TO "SysAdmin";

--
-- TOC entry 284 (class 1255 OID 4967688)
-- Name: FuncSys_General_CreateSequence(character varying, character varying); Type: FUNCTION; Schema: SchSystem; Owner: SysEngine
--

CREATE FUNCTION "SchSystem"."FuncSys_General_CreateSequence"(character varying, character varying) RETURNS void
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama               : "SchSystem""."FuncSys_General_CreateSequence"
▪ Versi              : 1.00.0000
▪ Tanggal            : 2020-12-02
▪ Input              : varSchemaName (varchar) 
					   varSequenceName (varchar)
▪ Output             : void
▪ Keterkaitan Fungsi : -
▪ Deskripsi          : Fungsi ini digunakan untuk membangun Sequence
▪ Copyright          : Zheta © 2020
----------------------------------------------------------------------------------------------------*/

DECLARE
   	varSchemaName		ALIAS FOR $1;
   	varSequenceName		ALIAS FOR $2;
   	varSQL				varchar;

BEGIN
	varSQL := '
		CREATE SEQUENCE IF NOT EXISTS "' || varSchemaName || '"."' || varSequenceName || '"
			INCREMENT 1
			START 1
			MINVALUE 1
			MAXVALUE 9223372036854775807
			CACHE 1;
		';
	EXECUTE varSQL;
END;
$_$;


ALTER FUNCTION "SchSystem"."FuncSys_General_CreateSequence"(character varying, character varying) OWNER TO "SysEngine";

--
-- TOC entry 256 (class 1255 OID 4967689)
-- Name: FuncSys_General_GetEnvironmentParameter(character varying); Type: FUNCTION; Schema: SchSystem; Owner: SysAdmin
--

CREATE FUNCTION "SchSystem"."FuncSys_General_GetEnvironmentParameter"(character varying) RETURNS character varying
    LANGUAGE plpgsql IMMUTABLE STRICT
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchSystem"."FuncSys_General_GetEnvironmentParameter"
▪ Versi               :	1.00.0000
▪ Tanggal
     ► Pemutakhiran   :	2026-06-09
     ► Pembuatan      :	2026-06-09
▪ Input               :	• varParameter (varchar - Mandatory)
						------------------------------
						------------------------------
▪ Output              :	varReturn (varchar)
▪ Keterkaitan Fungsi  : -
▪ Deskripsi           :	• Mendapatkan Data Environment berdasarkan Parameter (varParameter).
▪ Copyright           :	Zheta © 2026

----[ SQL Example(s) ]------------------------------------------------------------------------------

▪ ---> Parameter : DBLink.ConnectionString.FrontEnd
	SELECT
		"SchSystem"."FuncSys_General_GetEnvironmentParameter"('DBLink.ConnectionString.FrontEnd');

▪ ---> Parameter : DBLink.ConnectionString.BackEnd.DataWarehouse
	SELECT
		"SchSystem"."FuncSys_General_GetEnvironmentParameter"('DBLink.ConnectionString.BackEnd.DataWarehouse');

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varParameter											ALIAS FOR $1;

		---{ Optional }-------------------

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----
			varReturn												varchar;

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

		---{ Additional }-----------------

BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------( START )-----
		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------(  END  )-----

		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------( START )-----
		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------(  END  )-----

	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
		---> Initializing : varReturn
			varReturn := (
				CASE
					WHEN (varParameter = 'DBLink.ConnectionString.FrontEnd') THEN
						'dbname=''dbERPReborn'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263'''
					WHEN (varParameter = 'DBLink.ConnectionString.BackEnd.DataOLAP') THEN
						'dbname=''dbERPReborn-Data-OLAP'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263'''
					WHEN (varParameter = 'DBLink.ConnectionString.BackEnd.DataOLTP') THEN
						'dbname=''dbERPReborn-Data-OLTP'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263'''
					WHEN (varParameter = 'DBLink.ConnectionString.BackEnd.DataWarehouse') THEN
						'dbname=''dbERPReborn-Data-Warehouse'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263'''
					WHEN (varParameter = 'DBLink.ConnectionString.BackEnd.SysConfig') THEN
						'dbname=''dbERPReborn-SysConfig'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263'''			
					ELSE
						NULL
				END
				);

	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----
		---> Send Data Output
			RETURN
				varReturn;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		EXCEPTION
			WHEN OTHERS THEN
				NULL;

END;
$_$;


ALTER FUNCTION "SchSystem"."FuncSys_General_GetEnvironmentParameter"(character varying) OWNER TO "SysAdmin";

--
-- TOC entry 267 (class 1255 OID 4967690)
-- Name: FuncSys_General_GetEnvironmentParameterExtraction(bigint, bigint, json, character varying, json, json); Type: FUNCTION; Schema: SchSystem; Owner: SysAdmin
--

CREATE FUNCTION "SchSystem"."FuncSys_General_GetEnvironmentParameterExtraction"(bigint, bigint, json DEFAULT NULL::json, character varying DEFAULT NULL::character varying, json DEFAULT NULL::json, json DEFAULT NULL::json) RETURNS "SchSystem"."HoldFuncSys_General_GetEnvironmentParameterExtraction"
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchSystem"."FuncSys_General_GetEnvironmentParameterExtraction"
▪ Versi               :	1.00.0002
▪ Tanggal
     ► Pemutakhiran   :	2026-07-24
     ► Pembuatan      :	2026-07-07
▪ Input               :	• varSysDataReadLoginSession_RefID (bigint - Mandatory)
						• varSysBranch_RefID (bigint - Mandatory)
						------------------------------
						• varEnvironmentParameter (json - Optional)
						• varObjectIdentity (varchar - Optional)
						• varJSONCoreFields (json - Optional)
						• varJSONAllFields (json - Optional)
						------------------------------
▪ Output              :	varReturn (varchar)
▪ Deskripsi           :	• Mendapatkan Ekstrasi Paremeter Environment.
▪ Copyright           :	Zheta © 2026

----[ Related Database Object(s) ]------------------------------------------------------------------

▪ Tabel               :	-

▪ Fungsi              :	• [BE] "SchSystem"."FuncSys_General_GetEnvironmentParameter"(varchar)
						• [BE] "SchSystem"."FuncSys_General_StrSQLBuilder_FilterAndSort"(json, json)
	 					• [BE] "SchSystem"."FuncSys_General_StrSQLExecution"(varchar)
						• [BE] "SchSystem"."FuncSys_General_GetIDInformation"(bigint)
						------------------------------
						• [BE] "SchSysConfig"."Func_SQLGenerator_Array_BaseBranch"(bigint)
						------------------------------
	 					• [BE] "SchMaster"."Func_SQLGenerator_Array_Currency"(bigint, json)

----[ SQL Example(s) ]------------------------------------------------------------------------------

▪ --->
	SELECT
		*
	FROM
		"SchSystem"."FuncSys_General_GetEnvironmentParameterExtraction"(
			6000000000001::bigint,
			11000000000004::bigint
			------------------------------
			------------------------------
			);

▪ --->
	SELECT
		*
	FROM
		"SchSystem"."FuncSys_General_GetEnvironmentParameterExtraction"(
			6000000000001::bigint,
			11000000000004::bigint,
			------------------------------
			NULL::json,
			'SchSupplyChain.Func_SQLGenerator_DataList_Supplier'::varchar
			);

▪ --->
	SELECT
		*
	FROM
		"SchSystem"."FuncSys_General_GetEnvironmentParameterExtraction"(
			6000000000001::bigint,
			11000000000004::bigint,
			------------------------------
			JSON_BUILD_OBJECT (
				'DBLink.ConnectionString.FrontEnd', 'dbname=''dbERPReborn'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263''',
					'DBLink.ConnectionString.BackEnd.DataOLAP', 'dbname=''dbERPReborn-Data-OLAP'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263''',
					'DBLink.ConnectionString.BackEnd.DataOLTP', 'dbname=''dbERPReborn-Data-OLTP'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263''',
					'DBLink.ConnectionString.BackEnd.DataWarehouse', 'dbname=''dbERPReborn-Data-Warehouse'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263''',
					'DBLink.ConnectionString.BackEnd.SysConfig', 'dbname=''dbERPReborn-SysConfig'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263''',
					------------------------------
					'Pagination.PageSize', 10,
					'Pagination.PageShow', 2,
					------------------------------
					'DataCustomize.Filter', JSON_BUILD_ARRAY (
						JSON_BUILD_ARRAY (
							'Name', 'varchar', 'ILIKE', ''
							)
						),
					'DataCustomize.Sort', JSON_BUILD_ARRAY (
						JSON_BUILD_ARRAY (
							'Name', 'ASC'
							)
						),
					------------------------------
					'DataReference.Array.BaseBranch', JSON_BUILD_OBJECT (
						'ID', '{11000000000001,10011000000000001,11000000000002,10011000000000002,11000000000003,10011000000000003,11000000000004,10011000000000004}'::bigint[]::varchar,
						'Value_BaseBranchID', '{11000000000004,11000000000004,11000000000004,11000000000004,11000000000004,11000000000004,11000000000004,11000000000004}'::bigint[]::varchar
						),
					'DataReference.Array.Currency', JSON_BUILD_OBJECT (
						'ID', '{62000000000001,10062000000000001,62000000000002,10062000000000002,62000000000003,10062000000000003,62000000000004,10062000000000004,62000000000005,10062000000000005,62000000000006,10062000000000006,62000000000007,10062000000000007,62000000000008,10062000000000008,62000000000009,10062000000000009,62000000000010,10062000000000010,62000000000011,10062000000000011,62000000000012,10062000000000012,62000000000013,10062000000000013,62000000000014,10062000000000014,62000000000015,10062000000000015,62000000000016,10062000000000016,62000000000017,10062000000000017,62000000000018,10062000000000018,62000000000019,10062000000000019,62000000000020,10062000000000020,62000000000021,10062000000000021,62000000000022,10062000000000022,62000000000023,10062000000000023,62000000000024,10062000000000024,62000000000025,10062000000000025,62000000000026,10062000000000026,62000000000027,10062000000000027,62000000000028,10062000000000028,62000000000029,10062000000000029,62000000000030,10062000000000030,62000000000031,10062000000000031,62000000000032,10062000000000032,62000000000033,10062000000000033,62000000000034,10062000000000034,62000000000035,10062000000000035,62000000000036,10062000000000036,62000000000037,10062000000000037,62000000000038,10062000000000038,62000000000039,10062000000000039,62000000000040,10062000000000040,62000000000041,10062000000000041,62000000000042,10062000000000042,62000000000043,10062000000000043,62000000000044,10062000000000044,62000000000045,10062000000000045,62000000000046,10062000000000046,62000000000047,10062000000000047,62000000000048,10062000000000048,62000000000049,10062000000000049,62000000000050,10062000000000050,62000000000051,10062000000000051,62000000000052,10062000000000052,62000000000053,10062000000000053,62000000000054,10062000000000054,62000000000055,10062000000000055,62000000000056,10062000000000056,62000000000057,10062000000000057,62000000000058,10062000000000058,62000000000059,10062000000000059,62000000000060,10062000000000060,62000000000061,10062000000000061,62000000000062,10062000000000062,62000000000063,10062000000000063,62000000000064,10062000000000064,62000000000065,10062000000000065,62000000000066,10062000000000066,62000000000067,10062000000000067,62000000000068,10062000000000068,62000000000069,10062000000000069,62000000000070,10062000000000070,62000000000071,10062000000000071,62000000000072,10062000000000072,62000000000073,10062000000000073,62000000000074,10062000000000074,62000000000075,10062000000000075,62000000000076,10062000000000076,62000000000077,10062000000000077,62000000000078,10062000000000078,62000000000079,10062000000000079,62000000000080,10062000000000080,62000000000081,10062000000000081,62000000000082,10062000000000082,62000000000083,10062000000000083,62000000000084,10062000000000084,62000000000085,10062000000000085,62000000000086,10062000000000086,62000000000087,10062000000000087,62000000000088,10062000000000088,62000000000089,10062000000000089,62000000000090,10062000000000090,62000000000091,10062000000000091,62000000000092,10062000000000092,62000000000093,10062000000000093,62000000000094,10062000000000094,62000000000095,10062000000000095,62000000000096,10062000000000096,62000000000097,10062000000000097,62000000000098,10062000000000098,62000000000099,10062000000000099,62000000000100,10062000000000100,62000000000101,10062000000000101,62000000000102,10062000000000102,62000000000103,10062000000000103,62000000000104,10062000000000104,62000000000105,10062000000000105,62000000000106,10062000000000106,62000000000107,10062000000000107,62000000000108,10062000000000108,62000000000109,10062000000000109,62000000000110,10062000000000110,62000000000111,10062000000000111,62000000000112,10062000000000112,62000000000113,10062000000000113,62000000000114,10062000000000114,62000000000115,10062000000000115,62000000000116,10062000000000116,62000000000117,10062000000000117,62000000000118,10062000000000118,62000000000119,10062000000000119,62000000000120,10062000000000120}'::bigint[]::varchar,
						'Value_ISOCode', '{IDR,IDR,USD,USD,AUD,AUD,CAD,CAD,DKK,DKK,HKD,HKD,MYR,MYR,NZD,NZD,NOK,NOK,GBP,GBP,SGD,SGD,SEK,SEK,CHF,CHF,JPY,JPY,MMK,MMK,INR,INR,KWD,KWD,PKR,PKR,PHP,PHP,SAR,SAR,LKR,LKR,THB,THB,BND,BND,EUR,EUR,CNY,CNY,KRW,KRW,CNH,CNH,LAK,LAK,PGK,PGK,VND,VND,ID2,ID2,ALL,ALL,AFN,AFN,ARS,ARS,AWG,AWG,AZN,AZN,BSD,BSD,BBD,BBD,BYR,BYR,BZD,BZD,BMD,BMD,BOB,BOB,BAM,BAM,BWP,BWP,BGN,BGN,BRL,BRL,KHR,KHR,KYD,KYD,CLP,CLP,COP,COP,CRC,CRC,HRK,HRK,CUP,CUP,CZK,CZK,DOP,DOP,XCD,XCD,EGP,EGP,SVC,SVC,EEK,EEK,FKP,FKP,FJD,FJD,GHC,GHC,GIP,GIP,GTQ,GTQ,GGP,GGP,GYD,GYD,HNL,HNL,HUF,HUF,ISK,ISK,IRR,IRR,IMP,IMP,ILS,ILS,JMD,JMD,JEP,JEP,KZT,KZT,KPW,KPW,KGS,KGS,LVL,LVL,LBP,LBP,LRD,LRD,LTL,LTL,MKD,MKD,MUR,MUR,MXN,MXN,MNT,MNT,MZN,MZN,NAD,NAD,NPR,NPR,ANG,ANG,NIO,NIO,NGN,NGN,KPW,KPW,OMR,OMR,PAB,PAB,PYG,PYG,PEN,PEN,PLN,PLN,QAR,QAR,RON,RON,RUB,RUB,SHP,SHP,RSD,RSD,SCR,SCR,SBD,SBD,SOS,SOS,ZAR,ZAR,KRW,KRW,SRD,SRD,SYP,SYP,TWD,TWD,TTD,TTD,TRY,TRY,TRL,TRL,TVD,TVD,UAH,UAH,UYU,UYU,UZS,UZS,VEF,VEF,YER,YER,ZWD,ZWD}'::varchar[]::varchar,
						'Value_Symbol', '{Rp,Rp,$,$,$,$,$,$,kr,kr,$,$,RM,RM,$,$,kr,kr,£,£,$,$,kr,kr,₣,₣,¥,¥,K,K,NULL,NULL,NULL,NULL,₨,₨,₱,₱,﷼,﷼,රු,රු,฿,฿,$,$,€,€,¥,¥,₩,₩,¥,¥,₭,₭,K,K,₫,₫,Rp,Rp,Lek,Lek,؋,؋,$,$,ƒ,ƒ,ман,ман,$,$,$,$,p.,p.,BZ$,BZ$,$,$,$b,$b,KM,KM,P,P,лв,лв,R$,R$,៛,៛,$,$,$,$,$,$,₡,₡,kn,kn,₱,₱,Kč,Kč,RD$,RD$,$,$,£,£,$,$,kr,kr,£,£,$,$,¢,¢,£,£,Q,Q,£,£,$,$,L,L,Ft,Ft,kr,kr,﷼,﷼,£,£,₪,₪,J$,J$,£,£,лв,лв,₩,₩,лв,лв,Ls,Ls,£,£,$,$,Lt,Lt,ден,ден,₨,₨,$,$,₮,₮,MT,MT,$,$,₨,₨,ƒ,ƒ,C$,C$,₦,₦,₩,₩,﷼,﷼,B/.,B/.,Gs,Gs,S/.,S/.,zł,zł,﷼,﷼,lei,lei,руб,руб,£,£,Дин.,Дин.,₨,₨,$,$,S,S,R,R,₩,₩,$,$,£,£,NT$,NT$,TT$,TT$,TL,TL,₤,₤,$,$,₴,₴,$U,$U,лв,лв,Bs,Bs,﷼,﷼,Z$,Z$}'::varchar[]::varchar
						)
				),
			'SchSupplyChain.Func_SQLGenerator_DataList_Supplier'::varchar
			);

▪ --->
	SELECT
		*
	FROM
		"SchSystem"."FuncSys_General_GetEnvironmentParameterExtraction"(
			6000000000001::bigint,
			11000000000004::bigint,
			------------------------------
			JSON_BUILD_OBJECT (
				'DBLink.ConnectionString.FrontEnd', 'dbname=''dbERPReborn'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263''',
					'DBLink.ConnectionString.BackEnd.DataOLAP', 'dbname=''dbERPReborn-Data-OLAP'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263''',
					'DBLink.ConnectionString.BackEnd.DataOLTP', 'dbname=''dbERPReborn-Data-OLTP'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263''',
					'DBLink.ConnectionString.BackEnd.DataWarehouse', 'dbname=''dbERPReborn-Data-Warehouse'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263''',
					'DBLink.ConnectionString.BackEnd.SysConfig', 'dbname=''dbERPReborn-SysConfig'' host=127.0.0.1 port=5432 user=''SysEngine'' password=''748159263''',
					------------------------------
					'Pagination.PageSize', 10,
					'Pagination.PageShow', 2,
					------------------------------
					'DataCustomize.Filter', JSON_BUILD_ARRAY (
						JSON_BUILD_ARRAY (
							'Name', 'varchar', 'ILIKE', ''
							)
						),
					'DataCustomize.Sort', JSON_BUILD_ARRAY (
						JSON_BUILD_ARRAY (
							'Name', 'ASC'
							)
						),
					------------------------------
					'DataReference.Array.BaseBranch', JSON_BUILD_OBJECT (
						'ID', '{11000000000001,10011000000000001,11000000000002,10011000000000002,11000000000003,10011000000000003,11000000000004,10011000000000004}'::bigint[]::varchar,
						'Value_BaseBranchID', '{11000000000004,11000000000004,11000000000004,11000000000004,11000000000004,11000000000004,11000000000004,11000000000004}'::bigint[]::varchar
						),
					'DataReference.Array.Currency', JSON_BUILD_OBJECT (
						'ID', '{62000000000001,10062000000000001,62000000000002,10062000000000002,62000000000003,10062000000000003,62000000000004,10062000000000004,62000000000005,10062000000000005,62000000000006,10062000000000006,62000000000007,10062000000000007,62000000000008,10062000000000008,62000000000009,10062000000000009,62000000000010,10062000000000010,62000000000011,10062000000000011,62000000000012,10062000000000012,62000000000013,10062000000000013,62000000000014,10062000000000014,62000000000015,10062000000000015,62000000000016,10062000000000016,62000000000017,10062000000000017,62000000000018,10062000000000018,62000000000019,10062000000000019,62000000000020,10062000000000020,62000000000021,10062000000000021,62000000000022,10062000000000022,62000000000023,10062000000000023,62000000000024,10062000000000024,62000000000025,10062000000000025,62000000000026,10062000000000026,62000000000027,10062000000000027,62000000000028,10062000000000028,62000000000029,10062000000000029,62000000000030,10062000000000030,62000000000031,10062000000000031,62000000000032,10062000000000032,62000000000033,10062000000000033,62000000000034,10062000000000034,62000000000035,10062000000000035,62000000000036,10062000000000036,62000000000037,10062000000000037,62000000000038,10062000000000038,62000000000039,10062000000000039,62000000000040,10062000000000040,62000000000041,10062000000000041,62000000000042,10062000000000042,62000000000043,10062000000000043,62000000000044,10062000000000044,62000000000045,10062000000000045,62000000000046,10062000000000046,62000000000047,10062000000000047,62000000000048,10062000000000048,62000000000049,10062000000000049,62000000000050,10062000000000050,62000000000051,10062000000000051,62000000000052,10062000000000052,62000000000053,10062000000000053,62000000000054,10062000000000054,62000000000055,10062000000000055,62000000000056,10062000000000056,62000000000057,10062000000000057,62000000000058,10062000000000058,62000000000059,10062000000000059,62000000000060,10062000000000060,62000000000061,10062000000000061,62000000000062,10062000000000062,62000000000063,10062000000000063,62000000000064,10062000000000064,62000000000065,10062000000000065,62000000000066,10062000000000066,62000000000067,10062000000000067,62000000000068,10062000000000068,62000000000069,10062000000000069,62000000000070,10062000000000070,62000000000071,10062000000000071,62000000000072,10062000000000072,62000000000073,10062000000000073,62000000000074,10062000000000074,62000000000075,10062000000000075,62000000000076,10062000000000076,62000000000077,10062000000000077,62000000000078,10062000000000078,62000000000079,10062000000000079,62000000000080,10062000000000080,62000000000081,10062000000000081,62000000000082,10062000000000082,62000000000083,10062000000000083,62000000000084,10062000000000084,62000000000085,10062000000000085,62000000000086,10062000000000086,62000000000087,10062000000000087,62000000000088,10062000000000088,62000000000089,10062000000000089,62000000000090,10062000000000090,62000000000091,10062000000000091,62000000000092,10062000000000092,62000000000093,10062000000000093,62000000000094,10062000000000094,62000000000095,10062000000000095,62000000000096,10062000000000096,62000000000097,10062000000000097,62000000000098,10062000000000098,62000000000099,10062000000000099,62000000000100,10062000000000100,62000000000101,10062000000000101,62000000000102,10062000000000102,62000000000103,10062000000000103,62000000000104,10062000000000104,62000000000105,10062000000000105,62000000000106,10062000000000106,62000000000107,10062000000000107,62000000000108,10062000000000108,62000000000109,10062000000000109,62000000000110,10062000000000110,62000000000111,10062000000000111,62000000000112,10062000000000112,62000000000113,10062000000000113,62000000000114,10062000000000114,62000000000115,10062000000000115,62000000000116,10062000000000116,62000000000117,10062000000000117,62000000000118,10062000000000118,62000000000119,10062000000000119,62000000000120,10062000000000120}'::bigint[]::varchar,
						'Value_ISOCode', '{IDR,IDR,USD,USD,AUD,AUD,CAD,CAD,DKK,DKK,HKD,HKD,MYR,MYR,NZD,NZD,NOK,NOK,GBP,GBP,SGD,SGD,SEK,SEK,CHF,CHF,JPY,JPY,MMK,MMK,INR,INR,KWD,KWD,PKR,PKR,PHP,PHP,SAR,SAR,LKR,LKR,THB,THB,BND,BND,EUR,EUR,CNY,CNY,KRW,KRW,CNH,CNH,LAK,LAK,PGK,PGK,VND,VND,ID2,ID2,ALL,ALL,AFN,AFN,ARS,ARS,AWG,AWG,AZN,AZN,BSD,BSD,BBD,BBD,BYR,BYR,BZD,BZD,BMD,BMD,BOB,BOB,BAM,BAM,BWP,BWP,BGN,BGN,BRL,BRL,KHR,KHR,KYD,KYD,CLP,CLP,COP,COP,CRC,CRC,HRK,HRK,CUP,CUP,CZK,CZK,DOP,DOP,XCD,XCD,EGP,EGP,SVC,SVC,EEK,EEK,FKP,FKP,FJD,FJD,GHC,GHC,GIP,GIP,GTQ,GTQ,GGP,GGP,GYD,GYD,HNL,HNL,HUF,HUF,ISK,ISK,IRR,IRR,IMP,IMP,ILS,ILS,JMD,JMD,JEP,JEP,KZT,KZT,KPW,KPW,KGS,KGS,LVL,LVL,LBP,LBP,LRD,LRD,LTL,LTL,MKD,MKD,MUR,MUR,MXN,MXN,MNT,MNT,MZN,MZN,NAD,NAD,NPR,NPR,ANG,ANG,NIO,NIO,NGN,NGN,KPW,KPW,OMR,OMR,PAB,PAB,PYG,PYG,PEN,PEN,PLN,PLN,QAR,QAR,RON,RON,RUB,RUB,SHP,SHP,RSD,RSD,SCR,SCR,SBD,SBD,SOS,SOS,ZAR,ZAR,KRW,KRW,SRD,SRD,SYP,SYP,TWD,TWD,TTD,TTD,TRY,TRY,TRL,TRL,TVD,TVD,UAH,UAH,UYU,UYU,UZS,UZS,VEF,VEF,YER,YER,ZWD,ZWD}'::varchar[]::varchar,
						'Value_Symbol', '{Rp,Rp,$,$,$,$,$,$,kr,kr,$,$,RM,RM,$,$,kr,kr,£,£,$,$,kr,kr,₣,₣,¥,¥,K,K,NULL,NULL,NULL,NULL,₨,₨,₱,₱,﷼,﷼,රු,රු,฿,฿,$,$,€,€,¥,¥,₩,₩,¥,¥,₭,₭,K,K,₫,₫,Rp,Rp,Lek,Lek,؋,؋,$,$,ƒ,ƒ,ман,ман,$,$,$,$,p.,p.,BZ$,BZ$,$,$,$b,$b,KM,KM,P,P,лв,лв,R$,R$,៛,៛,$,$,$,$,$,$,₡,₡,kn,kn,₱,₱,Kč,Kč,RD$,RD$,$,$,£,£,$,$,kr,kr,£,£,$,$,¢,¢,£,£,Q,Q,£,£,$,$,L,L,Ft,Ft,kr,kr,﷼,﷼,£,£,₪,₪,J$,J$,£,£,лв,лв,₩,₩,лв,лв,Ls,Ls,£,£,$,$,Lt,Lt,ден,ден,₨,₨,$,$,₮,₮,MT,MT,$,$,₨,₨,ƒ,ƒ,C$,C$,₦,₦,₩,₩,﷼,﷼,B/.,B/.,Gs,Gs,S/.,S/.,zł,zł,﷼,﷼,lei,lei,руб,руб,£,£,Дин.,Дин.,₨,₨,$,$,S,S,R,R,₩,₩,$,$,£,£,NT$,NT$,TT$,TT$,TL,TL,₤,₤,$,$,₴,₴,$U,$U,лв,лв,Bs,Bs,﷼,﷼,Z$,Z$}'::varchar[]::varchar
						)
				),
			'SchSupplyChain.Func_SQLGenerator_DataList_Supplier'::varchar,
			------------------------------
			NULL::json,
			NULL::json
			);

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varSysDataReadLoginSession_RefID						ALIAS FOR $1;
			varSysBranch_RefID										ALIAS FOR $2;
			------------------------------

		---{ Optional }-------------------
			varEnvironmentParameter									ALIAS FOR $3;
			varObjectIdentity										ALIAS FOR $4;
			------------------------------
			varJSONCoreFields										ALIAS FOR $5;
			varJSONAllFields										ALIAS FOR $6;

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----
			varReturn												"SchSystem"."HoldFuncSys_General_GetEnvironmentParameterExtraction"%rowtype;

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

			varSQL													varchar;
			
			varSchema												varchar;
			varFunction												varchar;

		---{ Additional }-----------------

BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------( START )-----
			IF (varSignEligibleToProcess IS FALSE) THEN
				varSignEligibleToProcess := TRUE;
			END IF;
		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------(  END  )-----

		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------( START )-----
			IF (varSignEligibleToProcess IS TRUE) THEN
				---> Reinitializing : varJSONCoreFields
					IF (varJSONCoreFields::varchar = '[]') THEN
						varJSONCoreFields := NULL;
					END IF;

				---> Reinitializing : varJSONAllFields
					IF (varJSONAllFields::varchar = '[]') THEN
						varJSONAllFields := NULL;
					END IF;
			END IF;
		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------(  END  )-----

	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
			-----[ MAIN DATA PROCESSING ]---------------------------------------------( START )-----
				---> Initializing : varSchema, varFunction
					SELECT
						"SubSQL"."ObjectIdentityArray"[1],
						"SubSQL"."ObjectIdentityArray"[2]
					INTO
						varSchema,
						varFunction
					FROM
						(
						SELECT
							('{"' || REPLACE(varObjectIdentity::varchar, '.', '", "') || '"}')::varchar[] AS "ObjectIdentityArray"
						) AS "SubSQL";
					--RAISE NOTICE 'varSchema : %', varSchema;
					--RAISE NOTICE 'varFunction : %', varFunction;

				---> Initializing : varReturn."Env_Session"
					varReturn."Env_Session" :=
						COALESCE (
							varEnvironmentParameter->'Environment.Session',
							((
							SELECT
								"SchSystem"."FuncSys_GetInformation_SessionID"(
									varSysDataReadLoginSession_RefID,
									varObjectIdentity
									)
							))
							);

				---> Reinitializing : varDBLinkConnectionString
					varReturn."DBLinkConnectionString_FE" :=
						COALESCE (
							(varEnvironmentParameter->>'DBLink.ConnectionString.FrontEnd')::varchar,
							(SELECT "SchSystem"."FuncSys_General_GetEnvironmentParameter"('DBLink.ConnectionString.FrontEnd'))
							);

					varReturn."DBLinkConnectionString_BE_DataOLAP" :=
						COALESCE (
							(varEnvironmentParameter->>'DBLink.ConnectionString.BackEnd.DataOLAP')::varchar,
							(SELECT "SchSystem"."FuncSys_General_GetEnvironmentParameter"('DBLink.ConnectionString.BackEnd.DataOLAP'))
							);

					varReturn."DBLinkConnectionString_BE_DataOLTP" :=
						COALESCE (
							(varEnvironmentParameter->>'DBLink.ConnectionString.BackEnd.DataOLTP')::varchar,
							(SELECT "SchSystem"."FuncSys_General_GetEnvironmentParameter"('DBLink.ConnectionString.BackEnd.DataOLTP'))
							);

					varReturn."DBLinkConnectionString_BE_DataWarehouse" :=
						COALESCE (
							(varEnvironmentParameter->>'DBLink.ConnectionString.BackEnd.DataWarehouse')::varchar,
							(SELECT "SchSystem"."FuncSys_General_GetEnvironmentParameter"('DBLink.ConnectionString.BackEnd.DataWarehouse'))
							);

					varReturn."DBLinkConnectionString_BE_SysConfig" :=
						COALESCE (
							(varEnvironmentParameter->>'DBLink.ConnectionString.BackEnd.SysConfig')::varchar,
							(SELECT "SchSystem"."FuncSys_General_GetEnvironmentParameter"('DBLink.ConnectionString.BackEnd.SysConfig'))
							);

				---> Initializing : varPagination
					varReturn."Pagination_PageSize" :=
						COALESCE (
							CASE
								WHEN ((varEnvironmentParameter->>'Pagination.PageSize')::bigint > 0) THEN
									(varEnvironmentParameter->>'Pagination.PageSize')::bigint
								ELSE
									NULL
							END
							);

					varReturn."Pagination_PageShow" :=
						COALESCE (
							CASE
								WHEN ((varEnvironmentParameter->>'Pagination.PageShow')::bigint > 0) THEN
									(varEnvironmentParameter->>'Pagination.PageShow')::bigint
								ELSE
									NULL
							END
							);

				---> Initializing : varDataCustomize_Filter, varDataCustomize_Sort, varDataCustomize_Filter_CoreFields, varDataCustomize_Sort_CoreFields, varDataCustomize_Filter_NonCoreFields, varDataCustomize_Sort_NonCoreFields
					SELECT
						"SubSQL"."JSONData"->>'filterJSON',
						"SubSQL"."JSONData"->>'filterString',
						"SubSQL"."JSONData"->>'sortJSON',
						"SubSQL"."JSONData"->>'sortString',
						"SubSQL"."JSONData"->>'filterJSON_CoreFields',
						"SubSQL"."JSONData"->>'filterString_CoreFields',
						"SubSQL"."JSONData"->>'sortJSON_CoreFields',
						"SubSQL"."JSONData"->>'sortString_CoreFields',
						"SubSQL"."JSONData"->>'filterJSON_NonCoreFields',
						"SubSQL"."JSONData"->>'filterString_NonCoreFields',
						"SubSQL"."JSONData"->>'sortJSON_NonCoreFields',
						"SubSQL"."JSONData"->>'sortString_NonCoreFields'
					INTO
						varReturn."DataCustomize_Filter_JSON",
						varReturn."DataCustomize_Filter",
						varReturn."DataCustomize_Sort_JSON",
						varReturn."DataCustomize_Sort",
						varReturn."DataCustomize_Filter_CoreFields_JSON",
						varReturn."DataCustomize_Filter_CoreFields",
						varReturn."DataCustomize_Sort_CoreFields_JSON",
						varReturn."DataCustomize_Sort_CoreFields",
						varReturn."DataCustomize_Filter_NonCoreFields_JSON",
						varReturn."DataCustomize_Filter_NonCoreFields",
						varReturn."DataCustomize_Sort_NonCoreFields_JSON",
						varReturn."DataCustomize_Sort_NonCoreFields"
					FROM
						(
						SELECT
							"SchSystem"."FuncSys_General_StrSQLBuilder_FilterAndSort"(
								(varEnvironmentParameter->>'DataCustomize.Filter')::json,
								(varEnvironmentParameter->>'DataCustomize.Sort')::json,
								------------------------------
								varJSONCoreFields,
								varJSONAllFields
								) AS "JSONData"
						) AS "SubSQL";
					--RAISE NOTICE 'varDataCustomize_Filter : %', varReturn."DataCustomize_Filter";
					--RAISE NOTICE 'varDataCustomize_Sort : %', varReturn."DataCustomize_Sort";
					--RAISE NOTICE 'varDataCustomize_Filter_CoreFields : %', varReturn."DataCustomize_Filter_CoreFields";
					--RAISE NOTICE 'varDataCustomize_Sort_CoreFields : %', varReturn."DataCustomize_Sort_CoreFields";
					--RAISE NOTICE 'varDataCustomize_Filter_NonCoreFields : %', varReturn."DataCustomize_Filter_NonCoreFields";
					--RAISE NOTICE 'varDataCustomize_Sort_NonCoreFields : %', varReturn."DataCustomize_Sort_NonCoreFields";

				---> Initializing : varReturn."Array_SysBranch_RefID", varReturn."Array_SysBaseBranch_RefID"
					varReturn."Array_SysBranch_RefID" := (varEnvironmentParameter->'DataReference.Array.BaseBranch'->>'ID')::bigint[];
					varReturn."Array_SysBaseBranch_RefID" := (varEnvironmentParameter->'DataReference.Array.BaseBranch'->>'Value_BaseBranchID')::bigint[];

					IF ((varReturn."Array_SysBranch_RefID" IS NULL) OR (varReturn."Array_SysBaseBranch_RefID" IS NULL)) THEN
						IF ((SELECT CURRENT_DATABASE()) = 'dbERPReborn-SysConfig') THEN
							SELECT
								"InstitutionBranch_RefIDArray",
								"BaseInstitutionBranch_RefIDArray"
							INTO
								varReturn."Array_SysBranch_RefID",
								varReturn."Array_SysBaseBranch_RefID"
							FROM
								"SchSystem"."FuncSys_General_StrSQLExecution"(
									'
									SELECT
										"SubSQL"."IDArray" AS "InstitutionBranch_RefIDArray",
										"SubSQL"."ValueArray_BaseInstitutionBranch_RefID" AS "BaseInstitutionBranch_RefIDArray"
									FROM
										(
										'
										||
										(
										SELECT
											"SchSysConfig"."Func_SQLGenerator_Array_BaseBranch"(
												varSysDataReadLoginSession_RefID::bigint,
												------------------------------
												varSysBranch_RefID::bigint,
												JSON_BUILD_OBJECT (
													'Environment.Session', varReturn."Env_Session",
													------------------------------
													'DBLink.ConnectionString.FrontEnd', varReturn."DBLinkConnectionString_FE",
													'DBLink.ConnectionString.BackEnd.DataOLAP', varReturn."DBLinkConnectionString_BE_DataOLAP",
													'DBLink.ConnectionString.BackEnd.DataOLTP', varReturn."DBLinkConnectionString_BE_DataOLTP",
													'DBLink.ConnectionString.BackEnd.DataWarehouse', varReturn."DBLinkConnectionString_BE_DataWarehouse",
													'DBLink.ConnectionString.BackEnd.SysConfig', varReturn."DBLinkConnectionString_BE_SysConfig",
													------------------------------
													'Pagination.PageSize', NULL,
													'Pagination.PageShow', NULL,
													------------------------------
													'DataCustomize.Filter', NULL,
													'DataCustomize.Sort', NULL,
													------------------------------
													'DataReference.Array.BaseBranch', NULL,
													'DataReference.Array.Currency', NULL
													)
												)
										)
										||
										'
										) AS "SubSQL"
									'
									) AS "SubSQL" (
										"InstitutionBranch_RefIDArray" bigint[],
										"BaseInstitutionBranch_RefIDArray" bigint[]
										);
						ELSE
							SELECT
								"InstitutionBranch_RefIDArray",
								"BaseInstitutionBranch_RefIDArray"
							INTO
								varReturn."Array_SysBranch_RefID",
								varReturn."Array_SysBaseBranch_RefID"
							FROM
								DBLINK (
									varReturn."DBLinkConnectionString_BE_SysConfig",
									'
									SELECT
										"SubSQL"."IDArray",
										"SubSQL"."ValueArray_BaseInstitutionBranch_RefID"
									FROM
										"SchSystem"."FuncSys_General_StrSQLExecution"((
											SELECT
												(
												''
												SELECT
													"SubSQL"."IDArray",
													"SubSQL"."ValueArray_BaseInstitutionBranch_RefID"
												FROM
													(
													''
													||
													(
													SELECT
														"SchSysConfig"."Func_SQLGenerator_Array_BaseBranch"(
															' || COALESCE (varSysDataReadLoginSession_RefID::varchar, 'NULL') || '::bigint,
															------------------------------
															' || COALESCE (varSysBranch_RefID::varchar, 'NULL') || '::bigint,
															'''
															||
															(
															REPLACE (
																JSON_BUILD_OBJECT (
																	'Environment.Session', varReturn."Env_Session",
																	------------------------------
																	'DBLink.ConnectionString.FrontEnd', varReturn."DBLinkConnectionString_FE",
																	'DBLink.ConnectionString.BackEnd.DataOLAP', varReturn."DBLinkConnectionString_BE_DataOLAP",
																	'DBLink.ConnectionString.BackEnd.DataOLTP', varReturn."DBLinkConnectionString_BE_DataOLTP",
																	'DBLink.ConnectionString.BackEnd.DataWarehouse', varReturn."DBLinkConnectionString_BE_DataWarehouse",
																	'DBLink.ConnectionString.BackEnd.SysConfig', varReturn."DBLinkConnectionString_BE_SysConfig",
																	------------------------------
																	'Pagination.PageSize', NULL,
																	'Pagination.PageShow', NULL,
																	------------------------------
																	'DataCustomize.Filter', NULL,
																	'DataCustomize.Sort', NULL,
																	------------------------------
																	'DataReference.Array.BaseBranch', NULL,
																	'DataReference.Array.Currency', NULL
																	)::varchar,
																'''',
																''''''
																)
															)::varchar
															||
															'''::json
															)
													)
													||
													''
													) AS "SubSQL"
												''
												)
											)) AS "SubSQL"(
												"IDArray" bigint[],
												"ValueArray_BaseInstitutionBranch_RefID" bigint[]
												)
									'
									) AS "SubSQL" (
										"InstitutionBranch_RefIDArray" bigint[],
										"BaseInstitutionBranch_RefIDArray" bigint[]
										);
						END IF;
					--RAISE NOTICE 'varReturn."Array_SysBranch_RefID" : %', varReturn."Array_SysBranch_RefID";
					--RAISE NOTICE 'varReturn."Array_SysBaseBranch_RefID" : %', varReturn."Array_SysBaseBranch_RefID";
					END IF;

				---> Initializing : varReturn."Array_Currency_RefID", varReturn."Array_CurrencyISOCode", varReturn."Array_CurrencySymbol"
					varReturn."Array_Currency_RefID" := (varEnvironmentParameter->'DataReference.Array.Currency'->>'ID')::bigint[];
					varReturn."Array_CurrencyISOCode" := (varEnvironmentParameter->'DataReference.Array.Currency'->>'Value_ISOCode')::varchar(3)[];
					varReturn."Array_CurrencySymbol" := (varEnvironmentParameter->'DataReference.Array.Currency'->>'Value_Symbol')::varchar(4)[];

					IF ((varReturn."Array_Currency_RefID" IS NULL) OR (varReturn."Array_CurrencyISOCode" IS NULL) OR (varReturn."Array_CurrencySymbol" IS NULL)) THEN
						IF ((SELECT CURRENT_DATABASE()) = 'dbERPReborn-Data-OLTP') THEN
							SELECT
								"SubSQL"."Currency_RefIDArray",
								"SubSQL"."ISOCodeArray",
								"SubSQL"."SymbolArray"
							INTO
								varReturn."Array_Currency_RefID",
								varReturn."Array_CurrencyISOCode",
								varReturn."Array_CurrencySymbol"
							FROM
								"SchSystem"."FuncSys_General_StrSQLExecution"(
									'
									SELECT
										"SubSQL"."IDArray" AS "Currency_RefIDArray",
										"SubSQL"."ValueArray_ISOCode" AS "ISOCodeArray",
										"SubSQL"."ValueArray_Symbol" AS "SymbolArray"
									FROM
										(
										'
										||
										(
										SELECT
											"SchMaster"."Func_SQLGenerator_Array_Currency"(
												varSysDataReadLoginSession_RefID::bigint,
												------------------------------
												varSysBranch_RefID::bigint,
												JSON_BUILD_OBJECT (
													'Environment.Session', varReturn."Env_Session",
													------------------------------
													'DBLink.ConnectionString.FrontEnd', varReturn."DBLinkConnectionString_FE",
													'DBLink.ConnectionString.BackEnd.DataOLAP', varReturn."DBLinkConnectionString_BE_DataOLAP",
													'DBLink.ConnectionString.BackEnd.DataOLTP', varReturn."DBLinkConnectionString_BE_DataOLTP",
													'DBLink.ConnectionString.BackEnd.DataWarehouse', varReturn."DBLinkConnectionString_BE_DataWarehouse",
													'DBLink.ConnectionString.BackEnd.SysConfig', varReturn."DBLinkConnectionString_BE_SysConfig",
													------------------------------
													'Pagination.PageSize', NULL,
													'Pagination.PageShow', NULL,
													------------------------------
													'DataCustomize.Filter', NULL,
													'DataCustomize.Sort', NULL,
													------------------------------
													'DataReference.Array.BaseBranch', NULL,
													'DataReference.Array.Currency', NULL
													)
												)
										)
										||
										'
										) AS "SubSQL"
									'
									) AS "SubSQL" (
										"Currency_RefIDArray" bigint[],
										"ISOCodeArray" varchar[],
										"SymbolArray" varchar[]
										);
						ELSE
							SELECT
								"SubSQL"."Currency_RefIDArray",
								"SubSQL"."ISOCodeArray",
								"SubSQL"."SymbolArray"
							INTO
								varReturn."Array_Currency_RefID",
								varReturn."Array_CurrencyISOCode",
								varReturn."Array_CurrencySymbol"
							FROM
								DBLINK (
									varReturn."DBLinkConnectionString_BE_DataOLTP",
									'
									SELECT
										"SubSQL"."Currency_RefIDArray",
										"SubSQL"."ISOCodeArray",
										"SubSQL"."SymbolArray"
									FROM
										"SchSystem"."FuncSys_General_StrSQLExecution"((
											SELECT
												''
												SELECT
													"SubSQL"."IDArray",
													"SubSQL"."ValueArray_ISOCode",
													"SubSQL"."ValueArray_Symbol"
												FROM
													(
													''
													||
													(
													SELECT
														"SchMaster"."Func_SQLGenerator_Array_Currency"(
															' || COALESCE (varSysDataReadLoginSession_RefID::varchar, 'NULL') || '::bigint,
															------------------------------
															' || COALESCE (varSysBranch_RefID::varchar, 'NULL') || '::bigint,
															'''
															||
															(
															REPLACE (
																JSON_BUILD_OBJECT (
																	'Environment.Session', varReturn."Env_Session",
																	------------------------------
																	'DBLink.ConnectionString.FrontEnd', varReturn."DBLinkConnectionString_FE",
																	'DBLink.ConnectionString.BackEnd.DataOLAP', varReturn."DBLinkConnectionString_BE_DataOLAP",
																	'DBLink.ConnectionString.BackEnd.DataOLTP', varReturn."DBLinkConnectionString_BE_DataOLTP",
																	'DBLink.ConnectionString.BackEnd.DataWarehouse', varReturn."DBLinkConnectionString_BE_DataWarehouse",
																	'DBLink.ConnectionString.BackEnd.SysConfig', varReturn."DBLinkConnectionString_BE_SysConfig",
																	------------------------------
																	'Pagination.PageSize', NULL,
																	'Pagination.PageShow', NULL,
																	------------------------------
																	'DataCustomize.Filter', NULL,
																	'DataCustomize.Sort', NULL,
																	------------------------------
																	'DataReference.Array.BaseBranch', NULL,
																	'DataReference.Array.Currency', NULL
																	)::varchar,
																'''',
																''''''
																)
															)::varchar
															||
															'''::json
															)
													)
													||
													''
													) AS "SubSQL"
												''
											)) AS "SubSQL" (
												"Currency_RefIDArray" bigint[],
												"ISOCodeArray" varchar[],
												"SymbolArray" varchar[]
												)
									'
									) AS "SubSQL" (
										"Currency_RefIDArray" bigint[],
										"ISOCodeArray" varchar[],
										"SymbolArray" varchar[]
										);
						END IF;
						--RAISE NOTICE 'varReturn."Array_Currency_RefID" : %', varReturn."Array_Currency_RefID";
						--RAISE NOTICE 'varReturn."Array_CurrencyISOCode" : %', varReturn."Array_CurrencyISOCode";
						--RAISE NOTICE 'varReturn."Array_CurrencySymbol" : %', varReturn."Array_CurrencySymbol";
					END IF;
			-----[ MAIN DATA PROCESSING ]---------------------------------------------(  END  )-----

	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----
		---> Send Data Output
			RETURN
				varReturn;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		EXCEPTION
			WHEN OTHERS THEN
				RETURN NULL;

END
$_$;


ALTER FUNCTION "SchSystem"."FuncSys_General_GetEnvironmentParameterExtraction"(bigint, bigint, json, character varying, json, json) OWNER TO "SysAdmin";

--
-- TOC entry 253 (class 1255 OID 4967693)
-- Name: FuncSys_General_GetIDInformation(bigint); Type: FUNCTION; Schema: SchSystem; Owner: SysAdmin
--

CREATE FUNCTION "SchSystem"."FuncSys_General_GetIDInformation"(bigint) RETURNS json
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchSystem"."FuncSys_General_GetIDInformation"
▪ Versi               :	1.00.0000
▪ Tanggal
     ► Pemutakhiran   :	2026-06-26
     ► Pembuatan      :	2026-06-26
▪ Input               :	• varID (bigint)
▪ Output              :	varReturn (json)
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Mendapatkan Informasi dari ID
▪ Copyright           :	Zheta © 2026

----[ Related Database Object(s) ]------------------------------------------------------------------

▪ Tabel               :	• [BE] "SchSysConfig"."TblDBObject_Schema"
						• [BE] "SchSysConfig"."TblDBObject_Table"

▪ Fungsi              :	• [BE] "SchSystem"."FuncSys_General_GetEnvironmentParameter"(varchar)
	 					• [BE] "SchSystem"."FuncSys_General_StrSQLExecution"(varchar)

----[ SQL Example(s) ]------------------------------------------------------------------------------

▪ --->
	SELECT
		"SchSystem"."FuncSys_General_GetIDInformation"(
			97000000000001::bigint);

▪ --->
	SELECT
		"SchSystem"."FuncSys_General_GetIDInformation"(
			10097000000000001::bigint);

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varID													ALIAS FOR $1;
			------------------------------

		---{ Optional }-------------------

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----
			varReturn												json;

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

			varSQL													varchar;

BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------( START )-----
			IF (varSignEligibleToProcess IS FALSE) THEN
				varSignEligibleToProcess := TRUE;
			END IF;
		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------(  END  )-----

		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------( START )-----
			IF (varSignEligibleToProcess IS TRUE) THEN
			END IF;
		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------(  END  )-----

	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			-----[ MAIN DATA PROCESSING ]---------------------------------------------( START )-----
				---> Initializing : varReturn
					varReturn := (
						SELECT
							"SubSQL"."JSONData"
						FROM
							(
							SELECT
								(
								SELECT
									(
									SELECT
										"SubSQL"."JSONData"
									FROM
										DBLINK (
											(SELECT "SchSystem"."FuncSys_General_GetEnvironmentParameter"('DBLink.ConnectionString.BackEnd.SysConfig')),
											'SELECT ' ||
												'JSON_BUILD_OBJECT (' ||
													'''schemaTable'', "InnerSubSQL"."SchemaTable", '
													'''clusterID'', "InnerSubSQL"."ClusterID", '
													'''sys_ID'', ' ||
														'COALESCE (' || 
															'"InnerSubSQL"."Sys_PID",' || 
															'"InnerSubSQL"."Sys_SID"' || 
															'), ' ||
													'''sys_PID'', "InnerSubSQL"."Sys_PID", '
													'''sys_SID'', "InnerSubSQL"."Sys_SID", '
													'''sys_RPK'', "InnerSubSQL"."Sys_RPK" '
													') AS "JSONData"' ||
											'FROM ' ||
												'(' ||
												'SELECT ' ||
													'(''' ||
													COALESCE (
														"VirtTblSchema_PID"."Name",
														"VirtTblSchema_SID"."Name"
														) ||
													'.' ||
													"VirtTblTable"."Name" ||
													''') AS "SchemaTable", ' ||
													'(("Sys_SID" / 1000000000000) / 10000) AS "ClusterID", ' ||
													'"Sys_PID", ' ||
													'"Sys_SID", ' ||
													'"Sys_RPK"' ||
												'FROM "' ||
													COALESCE (
														"VirtTblSchema_PID"."Name",
														"VirtTblSchema_SID"."Name"
														) ||
													'"."' ||
													"VirtTblTable"."Name" ||
												'" WHERE "Sys_PID" = ' || COALESCE ("SubSQL"."ID"::varchar, 'NULL'::varchar) || '::bigint OR "Sys_SID" = ' || COALESCE ("SubSQL"."ID"::varchar, 'NULL'::varchar) || '::bigint' ||
												') AS "InnerSubSQL"'
											) AS "SubSQL" ("JSONData" json)
										) AS "JSONData"
									FROM
										"SchSysConfig"."TblDBObject_Table" AS "VirtTblTable"
											LEFT JOIN
												"SchSysConfig"."TblDBObject_Schema" AS "VirtTblSchema_PID"
													ON
														"VirtTblTable"."Schema_RefID" = "VirtTblSchema_PID"."Sys_PID"
											LEFT JOIN
												"SchSysConfig"."TblDBObject_Schema" AS "VirtTblSchema_SID"
													ON
														"VirtTblTable"."Schema_RefID" = "VirtTblSchema_SID"."Sys_SID"
									WHERE
										"VirtTblTable"."Sys_RPK" = "SubSQL"."TableID"
								)
							FROM
								(
								SELECT
									"SubSQL"."ID",
									(("SubSQL"."ID" / 1000000000000) % 1000) AS "TableID"
								FROM
									(
									SELECT
										varID AS "ID"
									) AS "SubSQL"
								) AS "SubSQL"
							) AS "SubSQL"
						);
			END IF;

	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----
		---> Send Data Output
			RETURN
				varReturn;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		EXCEPTION
			WHEN OTHERS THEN
				RETURN NULL;

END;
$_$;


ALTER FUNCTION "SchSystem"."FuncSys_General_GetIDInformation"(bigint) OWNER TO "SysAdmin";

--
-- TOC entry 291 (class 1255 OID 4967694)
-- Name: FuncSys_General_GetSequence(character varying[], boolean); Type: FUNCTION; Schema: SchSystem; Owner: SysAdmin
--

CREATE FUNCTION "SchSystem"."FuncSys_General_GetSequence"(character varying[], boolean DEFAULT false) RETURNS bigint[]
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchSystem"."FuncSys_General_GetSequence"
▪ Versi               :	1.00.0001
▪ Tanggal
     ► Pemutakhiran   :	2026-05-23
     ► Pembuatan      :	2026-05-18
▪ Input               :	• varObjectSequenceArray (varchar[] - Mandatory)
						------------------------------
						• varObjectAutoCreate (boolean - Optional)
						------------------------------
▪ Output              :	varReturn (bigint[])
▪ Keterkaitan Fungsi  : -
▪ Deskripsi           :	• Mendapatkan Nomor Next Sequence dari Array Object Sequence
						  (varObjectSequenceArray).
						• varObjectAutoCreate (Default : FALSE) apabila diset TRUE maka akan membuat
						  Object Sequence baru apabila tidak ditemukan.
▪ Copyright           :	Zheta © 2026

----[ SQL Example(s) ]------------------------------------------------------------------------------

▪ ---> Without Auto Create If Sequence Is Not Exist
	SELECT
		"SchSystem"."FuncSys_General_GetSequence"(
			'{"SchMaster.AAA_seq", "SchMaster.AAA_seq", "SchMaster.BBB_seq"}'::character varying[]
			);

	SELECT
		"SchSystem"."FuncSys_General_GetSequence"(
			'{"SchMaster.AAA_seq", "SchMaster.AAA_seq", "SchMaster.BBB_seq"}'::character varying[],
			FALSE
			);

▪ ---> With Auto Create If Sequence Is Not Exist
	SELECT
		"SchSystem"."FuncSys_General_GetSequence"(
			'{NULL, "SchMaster.AAA_seq", "SchMaster.AAA_seq", "SchMaster.BBB_seq"}'::character varying[],
			TRUE
			);

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varObjectSequenceArray									ALIAS FOR $1;
			------------------------------

		---{ Optional }-------------------
			varObjectAutoCreate										ALIAS FOR $2;
			------------------------------

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----
			varReturn												bigint[];

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

			varSQL													varchar;

		---{ Additional }-----------------

BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------( START )-----
			IF (varSignEligibleToProcess IS FALSE) THEN
				varSignEligibleToProcess := TRUE;
			END IF;
		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------(  END  )-----

		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------( START )-----
			IF (varSignEligibleToProcess IS TRUE) THEN
			END IF;
		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------(  END  )-----

	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			-----[ MAIN DATA PROCESSING ]---------------------------------------------( START )-----
				---> Initializing : varSQL
					varSQL := '
						SELECT
							"SubSQL"."NextSequenceNumberArray"
						FROM
							(
							SELECT
								CASE
									WHEN ("SubSQL"."OrderSequence" = 1) THEN
										(
										''{'' ||
										STRING_AGG (
											COALESCE (
												"SubSQL"."NextSequenceNumber"::varchar,
												''NULL''
												),
											'', ''
											) OVER () ||
										''}''
										)::bigint[]
									ELSE
										NULL
								END AS "NextSequenceNumberArray"
							FROM
								(
								SELECT
									CASE
										WHEN ("SubSQL"."SignObjectSequenceExist" IS TRUE) THEN
											NEXTVAL(''"'' || REPLACE ("SubSQL"."ObjectSequence", ''.'', ''"."'') || ''"'')
										ELSE
											NULL
									END AS "NextSequenceNumber",
									------------------------------
									"SubSQL"."OrderSequence"
								FROM
									(
									SELECT
										"SubSQL"."ObjectSequence",
										"SubSQL"."SignAutoCreate",
										"SubSQL"."SignSchemaExist",
										"SubSQL"."SignObjectSequenceExist",
										------------------------------
										"SubSQL"."OrderSequence"
									FROM
										(
										SELECT
											"SubSQL"."ObjectSequence",
											"SubSQL"."SignAutoCreate",
											"SubSQL"."SignSchemaExist",
											CASE
												WHEN (("SubSQL"."SignAutoCreate" IS TRUE) AND ("SubSQL"."SignSchemaExist" IS TRUE) AND ("SubSQL"."SignObjectSequenceExist" IS FALSE)) THEN
													TRUE
												ELSE
													"SubSQL"."SignObjectSequenceExist"
											END AS "SignObjectSequenceExist",
											CASE
												WHEN (("SubSQL"."SignAutoCreate" IS TRUE) AND ("SubSQL"."SignSchemaExist" IS TRUE) AND ("SubSQL"."SignObjectSequenceExist" IS FALSE)) THEN
													(
													SELECT
														"SchSystem"."FuncSys_General_StrSQLExecution"(
															''
															CREATE SEQUENCE IF NOT EXISTS "'' || REPLACE ("SubSQL"."ObjectSequence", ''.'', ''"."'') || ''"
															    INCREMENT 1
															    START 1
															    MINVALUE 1
															    MAXVALUE 9223372036854775807
															    CACHE 1
															''
															)
													)
												ELSE
													NULL
											END AS "CreateObjectExec",
											------------------------------
											"SubSQL"."OrderSequence"
										FROM
											(
											SELECT
												"SubSQL"."ObjectSequence",
												"SubSQL"."SignAutoCreate",
												(
												SELECT
													EXISTS (
														SELECT
															nspname
														FROM
															pg_catalog.pg_namespace
														WHERE
															nspname = "InnerSubSQL"."SchemaSequenceNameArray"[1]
														)
												FROM
													(
													SELECT
														(''{"'' || REPLACE (REPLACE (REPLACE ("SubSQL"."ObjectSequence", ''\'', ''\\''), ''"'', ''\"''), ''.'', ''", "'') || ''"}'')::varchar[] AS "SchemaSequenceNameArray"
													) AS "InnerSubSQL"
												) AS "SignSchemaExist",
												(
												SELECT
													EXISTS (
														SELECT
															1
														FROM
															information_schema.sequences 
														WHERE
															sequence_schema = "InnerSubSQL"."SchemaSequenceNameArray"[1]
															AND
															sequence_name = "InnerSubSQL"."SchemaSequenceNameArray"[2]
														)
												FROM
													(
													SELECT
														(''{"'' || REPLACE (REPLACE (REPLACE ("SubSQL"."ObjectSequence", ''\'', ''\\''), ''"'', ''\"''), ''.'', ''", "'') || ''"}'')::varchar[] AS "SchemaSequenceNameArray"
													) AS "InnerSubSQL"
												) AS "SignObjectSequenceExist",
												------------------------------
												ROW_NUMBER () OVER () AS "OrderSequence"
											FROM
												(
												SELECT
													UNNEST(''' || varObjectSequenceArray::varchar || '''::varchar[]) AS "ObjectSequence",
													''' || varObjectAutoCreate::varchar || '''::boolean AS "SignAutoCreate"
												) AS "SubSQL"
											) AS "SubSQL"
										) AS "SubSQL"
									) AS "SubSQL"
								) AS "SubSQL"
							LIMIT 1
							) AS "SubSQL"
						';
					--RAISE NOTICE '%', varSQL;
					EXECUTE varSQL INTO varReturn;
			-----[ MAIN DATA PROCESSING ]---------------------------------------------(  END  )-----
		END IF;

	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----
		RETURN
			varReturn;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		EXCEPTION
			WHEN OTHERS THEN
				RETURN NULL;

END;
$_$;


ALTER FUNCTION "SchSystem"."FuncSys_General_GetSequence"(character varying[], boolean) OWNER TO "SysAdmin";

--
-- TOC entry 270 (class 1255 OID 4967697)
-- Name: FuncSys_General_GetSequence(character varying, character varying, bigint); Type: FUNCTION; Schema: SchSystem; Owner: SysEngine
--

CREATE FUNCTION "SchSystem"."FuncSys_General_GetSequence"(character varying, character varying, bigint DEFAULT (1)::bigint) RETURNS bigint
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama               : "SchSystem""."FuncSys_General_GetSequence"
▪ Versi              : 1.00.0002
▪ Tanggal            : 
▪ Tanggal 
     ► Pembuatan     : 2020-12-02
     ► Pemutakhiran  : 2022-01-14
▪ Input              : varSchemaName (varchar - Mandatory) 
					   varSequenceName (varchar - Mandatory)
					   varOffset (bigint - Optional)
▪ Output             : varOutput (bigint)
▪ Keterkaitan Fungsi : -
▪ Deskripsi          : Fungsi ini digunakan untuk mendapatkan nilai dari Sequence
▪ Copyright          : Zheta © 2020 - 2022

----[ SQL Example(s) ]------------------------------------------------------------------------------

▪ SELECT * FROM "SchSystem"."FuncSys_General_GetSequence"('SchBudgeting', 'TblTEMP_BudgetExpenseLineCeilingObjects_Sys_RPK_seq')

----------------------------------------------------------------------------------------------------*/

DECLARE
	varSchemaName		ALIAS FOR $1;
	varSequenceName		ALIAS FOR $2;
	varOffset			ALIAS FOR $3;
	
	varSQL				varchar;

	varOutput			bigint;

	varTemp				bigint;

BEGIN
	varSQL := '
		SELECT NEXTVAL(''"' || varSchemaName || '"."' || varSequenceName || '"'')
		';
	EXECUTE varSQL INTO varOutput;

    IF (varOffset > 1) THEN
		varSQL := '
			SELECT SETVAL(''"' || varSchemaName || '"."' || varSequenceName || '"'', (LASTVAL() + ' || varOffset || ' - 1))
			';
		EXECUTE varSQL INTO varOutput;
	END IF;
	
	RETURN varOutput;
END;

$_$;


ALTER FUNCTION "SchSystem"."FuncSys_General_GetSequence"(character varying, character varying, bigint) OWNER TO "SysEngine";

--
-- TOC entry 277 (class 1255 OID 4967698)
-- Name: FuncSys_General_SetBulkData(json, json, json); Type: FUNCTION; Schema: SchSystem; Owner: SysAdmin
--

CREATE FUNCTION "SchSystem"."FuncSys_General_SetBulkData"(json, json DEFAULT NULL::json, json DEFAULT NULL::json) RETURNS json
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchSystem"."FuncSys_General_SetBulkData"
▪ Versi               :	1.01.0009
▪ Tanggal
     ► Pemutakhiran   :	2026-06-19
     ► Pembuatan      :	2026-04-29
▪ Input               :	• varJSONEnvironment (json)
						------------------------------
						• varJSONData (json)
						• varJSONDataDeletion (json)
						------------------------------
▪ Output              :	varReturn (json)
▪ Deskripsi           :	• Mengeset Bulk Data
▪ Copyright           :	Zheta © 2026

----[ Related Database Object(s) ]------------------------------------------------------------------

▪ Tabel               :	-

▪ Fungsi              :	• [BE] "SchSystem"."FuncSys_General_SetPIDAndSIDOnTableEntireRecords"(varchar, smallint)
						• [BE] "SchSystem"."FuncSys_General_StrSQLExecution"(varchar)
						------------------------------
						• [BE] "SchMaster"."Func_GetDataPreparation_BusinessDocument"(json)

----[ SQL Example(s) ]------------------------------------------------------------------------------

▪ --->
	SELECT
		*
	FROM
		"SchSystem"."FuncSys_General_SetBulkData"(
			...::json,
			...::json,
			...::varchar
			);

▪ ---> ( varJSONData->'data' IS NOT EMPTY )
	SELECT
		"SchSystem"."FuncSys_General_SetBulkData"(
			NULL::json,
			'{"metadata.control" : {"frontEndSchemaTableName" : "SchData-OLTP-Master.TblBusinessDocument", "functionName" : {"insertFunction" : "SchMaster.Func_TblBusinessDocument_INSERT", "updateFunction" : "SchMaster.Func_TblBusinessDocument_UPDATE"}, "functionParameterParsing" : [{"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''sysDataAnnotation''", "dataType" : "varchar"}, {"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''sysLoginSession_RefID''", "dataType" : "bigint"}, {"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''sysDataSetDateTimeTZ''", "dataType" : "timestamptz"}, {"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''sysDataValidityStartDateTimeTZ''", "dataType" : "timestamptz"}, {"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''sysDataValidityFinishDateTimeTZ''", "dataType" : "timestamptz"}, {"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''sysPartitionRemovableRecordKey_RefID''", "dataType" : "bigint"}, {"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''sysBranch_RefID''", "dataType" : "bigint"}, {"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''sysBaseCurrency_RefID''", "dataType" : "bigint"}, {"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''businessDocumentType_RefID''", "dataType" : "bigint"}, {"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''documentNumber''", "dataType" : "varchar"}, {"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''cancelationBusinessDocument_RefID''", "dataType" : "bigint"}]}, "data" : [null, {"recordID" : null, "entities" : {"sysLoginSession_RefID" : 6000000000001, "sysDataAnnotation" : null, "sysDataSetDateTimeTZ" : null, "sysDataValidityStartDateTimeTZ" : null, "sysDataValidityFinishDateTimeTZ" : null, "sysPartitionRemovableRecordKey_RefID" : null, "sysBranch_RefID" : 11000000000004, "sysBaseCurrency_RefID" : null, "businessDocumentType_RefID" : 77000000000057, "documentNumber" : "Adv/QDC/2020/000187", "cancelationBusinessDocument_RefID" : null, "additionalData" : [{"functionName" : "SchMaster.Func_TblBusinessDocumentVersion_SET_BULK", "dataLinkerName" : "businessDocument_RefID", "data" : [{"recordID" : null, "entities" : {"sysLoginSession_RefID" : 6000000000001, "sysDataAnnotation" : null, "sysDataSetDateTimeTZ" : null, "sysDataValidityStartDateTimeTZ" : null, "sysDataValidityFinishDateTimeTZ" : null, "sysPartitionRemovableRecordKey_RefID" : null, "sysBranch_RefID" : 11000000000004, "sysBaseCurrency_RefID" : null, "businessDocument_RefID" : null, "version" : 10, "documentDateTimeTZ" : "2020-02-02T00:00:00+07:00", "annotation" : null, "documentOwner_RefID" : null}}, {"recordID" : null, "entities" : {"sysLoginSession_RefID" : 6000000000001, "sysDataAnnotation" : null, "sysDataSetDateTimeTZ" : null, "sysDataValidityStartDateTimeTZ" : null, "sysDataValidityFinishDateTimeTZ" : null, "sysPartitionRemovableRecordKey_RefID" : null, "sysBranch_RefID" : 11000000000004, "sysBaseCurrency_RefID" : null, "businessDocument_RefID" : null, "version" : 0, "documentDateTimeTZ" : "2020-02-02T00:00:00+07:00", "annotation" : null, "documentOwner_RefID" : null}}]}]}}, {"recordID" : null, "entities" : {"sysLoginSession_RefID" : 6000000000001, "sysDataAnnotation" : null, "sysDataSetDateTimeTZ" : null, "sysDataValidityStartDateTimeTZ" : null, "sysDataValidityFinishDateTimeTZ" : null, "sysPartitionRemovableRecordKey_RefID" : null, "sysBranch_RefID" : 11000000000004, "sysBaseCurrency_RefID" : null, "businessDocumentType_RefID" : 77000000000097, "documentNumber" : "AdvStl/QDC/2020/000191", "cancelationBusinessDocument_RefID" : null, "additionalData" : [{"functionName" : "SchMaster.Func_TblBusinessDocumentVersion_SET_BULK", "dataLinkerName" : "businessDocument_RefID", "data" : [{"recordID" : null, "entities" : {"sysLoginSession_RefID" : 6000000000001, "sysDataAnnotation" : null, "sysDataSetDateTimeTZ" : null, "sysDataValidityStartDateTimeTZ" : null, "sysDataValidityFinishDateTimeTZ" : null, "sysPartitionRemovableRecordKey_RefID" : null, "sysBranch_RefID" : 11000000000004, "sysBaseCurrency_RefID" : null, "businessDocument_RefID" : null, "version" : 0, "documentDateTimeTZ" : "2020-03-23T00:00:00+07:00", "annotation" : null, "documentOwner_RefID" : null}}]}]}}]}'::json,
			'{}'::json
			);

▪ ---> ( varJSONData->'data' IS EMPTY )
	SELECT
		"SchSystem"."FuncSys_General_SetBulkData"(
			NULL::json,
			'{"metadata.control" : {"frontEndSchemaTableName" : "SchData-OLTP-Master.TblBusinessDocument", "functionName" : {"insertFunction" : "SchMaster.Func_TblBusinessDocument_INSERT", "updateFunction" : "SchMaster.Func_TblBusinessDocument_UPDATE"}, "functionParameterParsing" : [{"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''sysDataAnnotation''", "dataType" : "varchar"}, {"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''sysLoginSession_RefID''", "dataType" : "bigint"}, {"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''sysDataSetDateTimeTZ''", "dataType" : "timestamptz"}, {"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''sysDataValidityStartDateTimeTZ''", "dataType" : "timestamptz"}, {"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''sysDataValidityFinishDateTimeTZ''", "dataType" : "timestamptz"}, {"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''sysPartitionRemovableRecordKey_RefID''", "dataType" : "bigint"}, {"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''sysBranch_RefID''", "dataType" : "bigint"}, {"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''sysBaseCurrency_RefID''", "dataType" : "bigint"}, {"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''businessDocumentType_RefID''", "dataType" : "bigint"}, {"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''documentNumber''", "dataType" : "varchar"}, {"dataSource" : "\"SubSQL\".\"JSONData\"->''entities''->>''cancelationBusinessDocument_RefID''", "dataType" : "bigint"}]}, "data" : []}'::json,
			'{}'::json
			);

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varJSONEnvironment										ALIAS FOR $1;
			------------------------------
			varJSONData												ALIAS FOR $2;
			varJSONDataDeletion										ALIAS FOR $3;

		---{ Optional }-------------------

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----
			varReturn												json;

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;
			varSignExecutionTime									timestamptz;

			varSQL													varchar;
			varSQL2													varchar;

			varFrontEndSchemaTableName								varchar;
			varSchema												varchar;
			varTable												varchar;

			varJSONFunctionName										json;
			varJSONFunctionParameterParsing							json;
			varJSONData_BusDoc										json;

			varParameterParsingArray_DataSource						varchar;
			varParameterParsingArray_DataType						varchar;

			varArraySysRPK											bigint[];
			varArraySysPID											bigint[];
			varArraySysSID											bigint[];

BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignExecutionTime := CLOCK_TIMESTAMP();
		varSignEligibleToProcess := FALSE;

		IF (varSignEligibleToProcess IS FALSE) THEN
			varSignEligibleToProcess := TRUE;
		END IF;

		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------( START )-----
			IF (varSignEligibleToProcess IS TRUE) THEN
				varSignEligibleToProcess := (
					SELECT
						CASE
							WHEN (
								(("SubSQL"."JSONData"->>'data')::varchar IS NULL)
								OR
								(("SubSQL"."JSONData"->>'data')::varchar = '[]')
								) THEN
								FALSE
							ELSE
								TRUE
						END
					FROM
						(
						SELECT
							varJSONData AS "JSONData"
						) AS "SubSQL"
					);
			END IF;
		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------(  END  )-----

		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------( START )-----
			IF (varSignEligibleToProcess IS TRUE) THEN
				-----[ INPUT VARIABLES REINITIALIZATION ]-------------------------------------( START )-----
					---> Reinitializing : varJSONData
						varJSONData :=
							COALESCE (
								varJSONData,
								'{}'::json
								);

					---> Reinitializing : varJSONDataDeletion
						varJSONDataDeletion :=
							COALESCE (
								varJSONDataDeletion,
								'{}'::json
								);
				-----[ INPUT VARIABLES REINITIALIZATION ]-------------------------------------(  END  )-----

				-----[ INTERMEDIATE VARIABLES INITIALIZATION ]--------------------------------( START )-----
					---> Initializing : varFrontEndSchemaTableName
						varFrontEndSchemaTableName :=
							(varJSONData->'metadata.control'->>'frontEndSchemaTableName')::varchar;

					---> Initializing : varSchema, varTable
						IF (varFrontEndSchemaTableName IS NOT NULL) THEN
							varSQL := '
								SELECT
									REPLACE (REPLACE (REPLACE ("Data"[1], ''Data-OLTP-'', ''''), ''Data-OLAP-'', ''''), ''Data-Warehouse-'', '''') AS "SchemaName",
									"Data"[2] AS "TableName"
								FROM
									(
									SELECT
										(''{"' || (REPLACE (varFrontEndSchemaTableName, '.', '", "')) || '"}'')::varchar[] AS "Data"
									) AS "SubSQL"
								';
		
							EXECUTE
								varSQL
							INTO
								varSchema,
								varTable;
						END IF;
						--RAISE NOTICE '%', varSchema;
						--RAISE NOTICE '%', varTable;

					---> Initializing : varJSONFunctionName
						varJSONFunctionName :=
							(varJSONData->'metadata.control'->'functionName')::json;

					---> Initializing : varJSONFunctionParameterParsing
						varJSONFunctionParameterParsing :=
							(varJSONData->'metadata.control'->'functionParameterParsing')::json;

					---> Initializing : varJSONData
						varJSONData :=
							(varJSONData->'data')::json;

					---> Initializing : varParameterParsingArray_DataSource, varParameterParsingArray_DataType
						SELECT
							"SubSQL"."DataSourceArray",
							"SubSQL"."DataTypeArray"
						INTO
							varParameterParsingArray_DataSource,
							varParameterParsingArray_DataType
						FROM
							(
							SELECT
								"SubSQL"."DataSourceArray",
								"SubSQL"."DataTypeArray"
							FROM
								(
								SELECT
									CASE
										WHEN ("SubSQL"."OrderSequence" = 1) THEN
											(
											'{' ||
											STRING_AGG (
												COALESCE (('"' || REPLACE (REPLACE ("SubSQL"."DataSource", '\', '\'), '"', '\"') || '"'), 'NULL'),
												', '
												) OVER () ||
											'}'
											)
										ELSE
											NULL
									END::varchar[] AS "DataSourceArray",
									CASE
										WHEN ("SubSQL"."OrderSequence" = 1) THEN
											(
											'{' ||
											STRING_AGG (
												COALESCE (('"' || REPLACE (REPLACE ("SubSQL"."DataType", '\', '\'), '"', '\"') || '"'), 'NULL'),
												', '
												) OVER () ||
											'}'
											)
										ELSE
											NULL
									END::varchar[] AS "DataTypeArray",
									------------------------------
									"SubSQL"."OrderSequence"
								FROM
									(
									SELECT
										("SubSQL"."JSONData"->>'dataSource') AS "DataSource",
										("SubSQL"."JSONData"->>'dataType') AS "DataType",
										------------------------------
										ROW_NUMBER () OVER () AS "OrderSequence"
									FROM
										(
										SELECT
											JSON_ARRAY_ELEMENTS (
												varJSONFunctionParameterParsing::JSON
												) AS "JSONData"
										) AS "SubSQL"
									) AS "SubSQL"
								) AS "SubSQL"
							WHERE
								"SubSQL"."OrderSequence" = 1
							) AS "SubSQL"
							;
						--RAISE NOTICE '%', varParameterParsingArray_DataSource;
						--RAISE NOTICE '%', varParameterParsingArray_DataType;
				-----[ INTERMEDIATE VARIABLES INITIALIZATION ]--------------------------------(  END  )-----
			END IF;
		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------(  END  )-----

	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			-----[ PRELIMINARY ADDITIONAL DATA PROCESSING ]---------------------------( START )-----
			-----[ PRELIMINARY ADDITIONAL DATA PROCESSING ]---------------------------(  END  )-----

			-----[ MAIN DATA PROCESSING ]---------------------------------------------( START )-----
				---> Reinitilizing : varJSONDataDeletion
					IF (varJSONDataDeletion::varchar != '{}') THEN
						varSQL := '
							UPDATE
								"' || varSchema || '"."' || varTable || '"
							SET
								"Sys_Data_Delete_LoginSession_RefID" = ' || (varJSONDataDeletion->>'sysLoginSession_RefID')::varchar || '::bigint,
								"Sys_Data_Delete_DateTimeTZ" = CLOCK_TIMESTAMP()
							WHERE
								' || (varJSONDataDeletion->>'SQLSyntaxCriteria')::varchar || '; ';
						--RAISE NOTICE 'Delete : %', varSQL;
						IF (varSQL IS NOT NULL) THEN
							EXECUTE varSQL;
						END IF;
					END IF;

/*
 ||
										(
										''
										SELECT
											"SchSystem"."FuncSys_General_SetPIDAndSIDOnTableEntireRecords"(
												''''' || varFrontEndSchemaTableName || '''''::varchar,
												------------------------------
												1::smallint
												);
										''
										)
*/

				---> Reinitilizing : varArraySysRPK + (Main Data Storing)
					varSQL := '
						SELECT
							"SubSQL"."SQLSyntax",
							"SubSQL"."JSONData_BusDoc"
						FROM
							(
							SELECT
								(
								''
								SET MAX_STACK_DEPTH = ''''4MB'''';
								''
								||
								''
								SELECT
									"SubSQL"."Sys_RPKArray"
								FROM
									(
									''
									|| 
									"SubSQL"."SQLSyntax"
									||
									''
									) AS "SubSQL"
								''
								) AS "SQLSyntax",
								(
								CASE
									WHEN ("SubSQL"."SignExistBusinessDocumentVersionRefID" IS TRUE) THEN
										JSON_BUILD_OBJECT (
											''businessDocument_RefIDArray'', "SubSQL"."BusinessDocument_RefIDArray",
											''businessDocumentNumberArray'', "SubSQL"."BusinessDocumentNumberArray",
											''fullBusinessDocumentNumberArray'', "SubSQL"."FullBusinessDocumentNumberArray",
											------------------------------
											''businessDocumentType_RefIDArray'', "SubSQL"."BusinessDocumentType_RefIDArray",
											''businessDocumentTypeNameArray'', "SubSQL"."BusinessDocumentTypeNameArray",
											------------------------------
											''businessDocumentVersion_RefIDArray'', "SubSQL"."BusinessDocumentVersion_RefIDArray",
											''businessDocumentVersionArray'', "SubSQL"."BusinessDocumentVersionArray",
											''businessDocumentDateTimeTZArray'', "SubSQL"."BusinessDocumentDateTimeTZArray"
											)
									ELSE
										NULL
								END
								)::json AS "JSONData_BusDoc"
							FROM
								(
								SELECT
									"SubSQL"."SignExistBusinessDocumentVersionRefID",
									------------------------------
									CASE
										WHEN ("SubSQL"."OrderSequence" = 1) THEN
											(
											''SELECT (''''{'''' || '' ||
											STRING_AGG (
												CASE
													--WHEN (("SubSQL"."SignNull" IS TRUE) AND ("SubSQL"."SignInsertMode" IS FALSE)) THEN
													WHEN ("SubSQL"."SignNull" IS TRUE) THEN
														''''''NULL''''''
													ELSE
														(''(COALESCE (('' || "SubSQL"."SQLSyntax" || '')::varchar, ''''NULL''''::varchar))::varchar'')
												END,
												('' || '''',''''::varchar || '')
												) OVER () ||
											'' || ''''}'''')::bigint[] AS "Sys_RPKArray"'' ||
											'','' ||
											(
											''
											(
											SELECT
												"SchSystem"."FuncSys_General_SetPIDAndSIDOnTableEntireRecords"(
													''''' || varFrontEndSchemaTableName || '''''::varchar,
													------------------------------
													1::smallint
													)
											)
											''
											)
											)
										ELSE
											NULL
									END AS "SQLSyntax",
									------------------------------
									(
									CASE
										WHEN ("SubSQL"."OrderSequence" = 1) THEN
											(
											''{'' ||
											STRING_AGG (
												COALESCE (
													(''"'' || REPLACE (REPLACE ("SubSQL"."BusinessDocument_RefID"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''),
													''NULL''
													),
												'', ''
												) OVER () ||
											''}''
											)
										ELSE
											NULL
									END
									)::bigint[] AS "BusinessDocument_RefIDArray",
									(
									CASE
										WHEN ("SubSQL"."OrderSequence" = 1) THEN
											(
											''{'' ||
											STRING_AGG (
												COALESCE (
													(''"'' || REPLACE (REPLACE ("SubSQL"."BusinessDocumentNumber"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''),
													''NULL''
													),
												'', ''
												) OVER () ||
											''}''
											)
										ELSE
											NULL
									END
									)::varchar[] AS "BusinessDocumentNumberArray",
									(
									CASE
										WHEN ("SubSQL"."OrderSequence" = 1) THEN
											(
											''{'' ||
											STRING_AGG (
												COALESCE (
													(''"'' || REPLACE (REPLACE ("SubSQL"."FullBusinessDocumentNumber"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''),
													''NULL''
													),
												'', ''
												) OVER () ||
											''}''
											)
										ELSE
											NULL
									END
									)::varchar[] AS "FullBusinessDocumentNumberArray",
									------------------------------
									(
									CASE
										WHEN ("SubSQL"."OrderSequence" = 1) THEN
											(
											''{'' ||
											STRING_AGG (
												COALESCE (
													(''"'' || REPLACE (REPLACE ("SubSQL"."BusinessDocumentType_RefID"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''),
													''NULL''
													),
												'', ''
												) OVER () ||
											''}''
											)
										ELSE
											NULL
									END
									)::bigint[] AS "BusinessDocumentType_RefIDArray",
									(
									CASE
										WHEN ("SubSQL"."OrderSequence" = 1) THEN
											(
											''{'' ||
											STRING_AGG (
												COALESCE (
													(''"'' || REPLACE (REPLACE ("SubSQL"."BusinessDocumentTypeName"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''),
													''NULL''
													),
												'', ''
												) OVER () ||
											''}''
											)
										ELSE
											NULL
									END
									)::varchar[] AS "BusinessDocumentTypeNameArray",
									------------------------------
									(
									CASE
										WHEN ("SubSQL"."OrderSequence" = 1) THEN
											(
											''{'' ||
											STRING_AGG (
												COALESCE (
													(''"'' || REPLACE (REPLACE ("SubSQL"."BusinessDocumentVersion_RefID"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''),
													''NULL''
													),
												'', ''
												) OVER () ||
											''}''
											)
										ELSE
											NULL
									END
									)::bigint[] AS "BusinessDocumentVersion_RefIDArray",
									(
									CASE
										WHEN ("SubSQL"."OrderSequence" = 1) THEN
											(
											''{'' ||
											STRING_AGG (
												COALESCE (
													(''"'' || REPLACE (REPLACE ("SubSQL"."BusinessDocumentVersion"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''),
													''NULL''
													),
												'', ''
												) OVER () ||
											''}''
											)
										ELSE
											NULL
									END
									)::smallint[] AS "BusinessDocumentVersionArray",
									(
									CASE
										WHEN ("SubSQL"."OrderSequence" = 1) THEN
											(
											''{'' ||
											STRING_AGG (
												COALESCE (
													(''"'' || REPLACE (REPLACE ("SubSQL"."BusinessDocumentDateTimeTZ"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''),
													''NULL''
													),
												'', ''
												) OVER () ||
											''}''
											)
										ELSE
											NULL
									END
									)::timestamptz[] AS "BusinessDocumentDateTimeTZArray",
									------------------------------
									"SubSQL"."OrderSequence"
								FROM
									(
									SELECT
										"SubSQL"."SignNull",
										"SubSQL"."SignInsertMode",
										"SubSQL"."SignExistBusinessDocumentVersionRefID",
										------------------------------
										(
										''
										SELECT
											"SignRecordID"
										FROM
											''
											||
											(
											CASE
												---> INSERT MODE
												WHEN ("SubSQL"."RecordID" IS NULL ) THEN
													''
													"' || REPLACE ((varJSONFunctionName->>'insertFunction')::varchar, '.', '"."') || '"(
													''
												---> UPDATE MODE
												ELSE
													''
													"' || REPLACE ((varJSONFunctionName->>'updateFunction')::varchar, '.', '"."') || '"(
													''
											END
											)
											||
											''
												'' ||
													REPLACE (
														"SubSQL"."SQLSyntax",
														''<<ZhtTag::DynamicDataType>>'',
														CASE
															WHEN ("SubSQL"."RecordID" IS NULL) THEN
																''varchar''
															ELSE
																''bigint''
														END
														) ||
												''
												)
										''
										) AS "SQLSyntax",
										------------------------------
										"SubSQL"."BusinessDocument_RefID",
										"SubSQL"."BusinessDocumentNumber",
										"SubSQL"."FullBusinessDocumentNumber",
										------------------------------
										"SubSQL"."BusinessDocumentType_RefID",
										"SubSQL"."BusinessDocumentTypeName",
										------------------------------
										"SubSQL"."BusinessDocumentVersion_RefID",
										"SubSQL"."BusinessDocumentVersion",
										"SubSQL"."BusinessDocumentDateTimeTZ",
										------------------------------
										"SubSQL"."OrderSequence"
									FROM
										(
										SELECT
											"SubSQL"."SignNull",
											"SubSQL"."SignInsertMode",
											"SubSQL"."SignExistBusinessDocumentVersionRefID",
											------------------------------
											"SubSQL"."RecordID",
											CASE
												WHEN ("SubSQL"."SignNull" IS TRUE) THEN
													NULL
												ELSE
													(
													'
													||
													(
													SELECT
														(
														"InnerSubSQL"."SQLSyntax"
														)
													FROM
														(
														SELECT
															CASE
																WHEN ("InnerSubSQL"."OrderSequence" = 1) THEN
																	STRING_AGG (
																		(
																			(
																			('(COALESCE (' || '('''''''' || ' || '"SubSQL"."Parameter_' || 
																				(
																				CASE
																					WHEN ("InnerSubSQL"."OrderSequence" = 1) THEN
																						'Dynamic'::varchar
																					WHEN ("InnerSubSQL"."OrderSequence" = 3) THEN
																						'3_Replacement'::varchar
																					WHEN ("InnerSubSQL"."OrderSequence" = 4) THEN
																						'4_Replacement'::varchar
																					WHEN ("InnerSubSQL"."OrderSequence" = 5) THEN
																						'5_Replacement'::varchar
																					ELSE
																						"InnerSubSQL"."OrderSequence"::varchar
																				END
																				) || 
																				'"::varchar' || ' || '''''''')' || ', ''NULL''))')::varchar ||
																				' || (''::' || 
																				(CASE WHEN ("InnerSubSQL"."OrderSequence" = 1) THEN '<<ZhtTag::DynamicDataType>>'::varchar ELSE "InnerSubSQL"."DataType"::varchar END) || 
																				''')'
																			)
																		),
																		(' || '', '' || ')
																		) OVER ()
																ELSE
																	NULL
															END AS "SQLSyntax",
															------------------------------
															"InnerSubSQL"."OrderSequence"
														FROM
															(
															SELECT
																"InnerSubSQL"."DataType",
																------------------------------
																"InnerSubSQL"."OrderSequence"
															FROM
																(
																SELECT
																	"InnerSubSQL"."DataType",
																	------------------------------
																	ROW_NUMBER () OVER () AS "OrderSequence"
																FROM
																	(
																	SELECT
																		UNNEST (varParameterParsingArray_DataType::varchar[]) AS "DataType"
																	) AS "InnerSubSQL"
																) AS "InnerSubSQL"
															) AS "InnerSubSQL"
														) AS "InnerSubSQL"
													WHERE
														"InnerSubSQL"."OrderSequence" = 1
													)
													||
													'::varchar
													)
											END AS "SQLSyntax",
											------------------------------
											"SubSQL"."BusinessDocument_RefID",
											"SubSQL"."BusinessDocumentNumber",
											"SubSQL"."FullBusinessDocumentNumber",
											------------------------------
											"SubSQL"."BusinessDocumentType_RefID",
											"SubSQL"."BusinessDocumentTypeName",
											------------------------------
											"SubSQL"."BusinessDocumentVersion_RefID",
											"SubSQL"."BusinessDocumentVersion",
											"SubSQL"."BusinessDocumentDateTimeTZ",
											------------------------------
											"SubSQL"."OrderSequence"
										FROM
											(
											-----[ MAIN DATA ]-----( START )-----
											SELECT
												CASE
													WHEN ("SubSQL"."SignNull" IS TRUE) THEN
														NULL
													ELSE
														(
														CASE
															WHEN ("SubSQL"."RecordID" IS NULL) THEN
																"SubSQL"."Parameter_1"::varchar
															ELSE
																"SubSQL"."RecordID"::varchar
														END
														)
												END AS "Parameter_Dynamic",
												/*
												CASE
													WHEN ("SubSQL"."SignNull" IS TRUE) THEN
														NULL
													ELSE
														(
														CASE
															WHEN ("SubSQL"."RecordID" IS NULL) THEN
																"SubSQL"."Parameter_1"::varchar
															ELSE
																"SubSQL"."RecordID"::varchar
														END
														)
												END AS "Parameter_BusDocVersion",												
												*/
												CASE
													WHEN ("SubSQL"."SignNull" IS TRUE) THEN
														NULL
													ELSE
														(
														COALESCE (
															"SubSQL"."Parameter_3"::varchar,
															CLOCK_TIMESTAMP()::varchar
															)
														)
												END AS "Parameter_3_Replacement",
												CASE
													WHEN ("SubSQL"."SignNull" IS TRUE) THEN
														NULL
													ELSE
														(
														COALESCE (
															"SubSQL"."Parameter_4"::varchar,
															''0001-01-01 00:00:00+00''::timestamptz::varchar
															)
														)
												END AS "Parameter_4_Replacement",
												CASE
													WHEN ("SubSQL"."SignNull" IS TRUE) THEN
														NULL
													ELSE
														(
														COALESCE (
															"SubSQL"."Parameter_5"::varchar,
															''9999-12-31 23:59:59+00''::timestamptz::varchar
															)
														)
												END AS "Parameter_5_Replacement",
												------------------------------
												*
											FROM
												(
												SELECT
													"SubSQL"."SignNull",
													"SubSQL"."SignInsertMode",
													"SubSQL"."SignExistBusinessDocumentVersionRefID",
													------------------------------
													("SubSQL"."JSONData"->>''recordID'')::bigint AS "RecordID",
													------------------------------
													'
													||
													(
													SELECT
														"SubSQL"."SQLSyntax"
													FROM
														(
														SELECT
															CASE
																WHEN ("SubSQL"."OrderSequence" = 1) THEN
																	(
																	STRING_AGG (
																		("SubSQL"."SQLSyntax" || ' AS "Parameter_' || "SubSQL"."OrderSequence" || '"'),
																		', '
																		) OVER ()
																	)
																ELSE
																	NULL
															END::varchar AS "SQLSyntax",
															------------------------------
															"SubSQL"."OrderSequence"
														FROM
															(
															SELECT
																(
																'(REPLACE ((' ||
																	"SubSQL"."DataSource" 
																	|| 
																	')::varchar, '''''''', '''''''''''')::' || "SubSQL"."DataType" || ')') AS "SQLSyntax",
																------------------------------
																"SubSQL"."OrderSequence"
															FROM
																(
																SELECT
																	CASE
																		WHEN ("SubSQL"."DataSource" ILIKE '%->>''businessDocumentVersion_RefID''') THEN
																			'"SubSQL"."BusinessDocumentVersion_RefIDReplacement"'
																		ELSE
																			"SubSQL"."DataSource"
																	END AS "DataSource",
																	"SubSQL"."DataType",
																	------------------------------
																	ROW_NUMBER () OVER () AS "OrderSequence"
																FROM
																	(
																	SELECT
																		UNNEST (varParameterParsingArray_DataSource::varchar[]) AS "DataSource",
																		UNNEST (varParameterParsingArray_DataType::varchar[]) AS "DataType"
																	) AS "SubSQL"
																) AS "SubSQL"
															) AS "SubSQL"
														) AS "SubSQL"
													WHERE
														"SubSQL"."OrderSequence" = 1
													)
													||
													',
													------------------------------
													"SubSQL"."BusinessDocument_RefID",
													"SubSQL"."BusinessDocumentNumber",
													"SubSQL"."FullBusinessDocumentNumber",
													------------------------------
													"SubSQL"."BusinessDocumentType_RefID",
													"SubSQL"."BusinessDocumentTypeName",
													------------------------------
													"SubSQL"."BusinessDocumentVersion_RefID",
													"SubSQL"."BusinessDocumentVersion",
													"SubSQL"."BusinessDocumentDateTimeTZ",
													------------------------------
													"SubSQL"."OrderSequence"
												FROM
													(
													SELECT
														"SubSQL"."SignNull",
														"SubSQL"."SignInsertMode",
														"SubSQL"."SignExistBusinessDocumentVersionRefID",
														"SubSQL"."SignKeyPositionBusinessDocumentVersionRefID",
														------------------------------
														"SubSQL"."BusinessDocumentVersion_RefIDReplacement",
														------------------------------
														"SubSQL"."BusinessDocument_RefID",
														"SubSQL"."BusinessDocumentNumber",
														"SubSQL"."FullBusinessDocumentNumber",
														------------------------------
														"SubSQL"."BusinessDocumentType_RefID",
														"SubSQL"."BusinessDocumentTypeName",
														------------------------------
														"SubSQL"."BusinessDocumentVersion_RefID",
														"SubSQL"."BusinessDocumentVersion",
														"SubSQL"."BusinessDocumentDateTimeTZ",
														------------------------------
														"SubSQL"."JSONData",
														------------------------------
														"SubSQL"."OrderSequence"
													FROM
														(
														SELECT
															UNNEST ("SubSQL"."SignNullArray") AS "SignNull",
															UNNEST ("SubSQL"."SignInsertModeArray") AS "SignInsertMode",
															"SubSQL"."SignExistBusinessDocumentVersionRefID",
															"SubSQL"."SignKeyPositionBusinessDocumentVersionRefID",
															------------------------------
															UNNEST ("SubSQL"."BusinessDocumentVersion_RefIDReplacementArray") AS "BusinessDocumentVersion_RefIDReplacement",
															------------------------------
															UNNEST ("SubSQL"."BusinessDocument_RefIDArray") AS "BusinessDocument_RefID",
															UNNEST ("SubSQL"."BusinessDocumentNumberArray") AS "BusinessDocumentNumber",
															UNNEST ("SubSQL"."FullBusinessDocumentNumberArray") AS "FullBusinessDocumentNumber",
															------------------------------
															UNNEST ("SubSQL"."BusinessDocumentType_RefIDArray") AS "BusinessDocumentType_RefID",
															UNNEST ("SubSQL"."BusinessDocumentTypeNameArray") AS "BusinessDocumentTypeName",
															------------------------------
															UNNEST ("SubSQL"."BusinessDocumentVersion_RefIDArray") AS "BusinessDocumentVersion_RefID",
															UNNEST ("SubSQL"."BusinessDocumentVersionArray") AS "BusinessDocumentVersion",
															UNNEST ("SubSQL"."BusinessDocumentDateTimeTZArray") AS "BusinessDocumentDateTimeTZ",
															------------------------------
															JSON_ARRAY_ELEMENTS (
																"SubSQL"."JSONData"
																) AS "JSONData",
															------------------------------
															UNNEST ("SubSQL"."OrderSequenceArray") AS "OrderSequence"
														FROM
															(
															SELECT
																"SubSQL"."SignNullArray",
																"SubSQL"."SignInsertModeArray",
																"SubSQL"."SignExistBusinessDocumentVersionRefID",
																"SubSQL"."SignKeyPositionBusinessDocumentVersionRefID",
																------------------------------
																("SubSQL"."JSONData_BusDoc"->>''businessDocumentVersion_RefIDArray'')::varchar::bigint[] AS "BusinessDocumentVersion_RefIDReplacementArray",
																------------------------------
																("SubSQL"."JSONData_BusDoc"->>''businessDocument_RefIDArray'')::varchar::bigint[] AS "BusinessDocument_RefIDArray",
																("SubSQL"."JSONData_BusDoc"->>''businessDocumentNumberArray'')::varchar::varchar[] AS "BusinessDocumentNumberArray",
																("SubSQL"."JSONData_BusDoc"->>''fullBusinessDocumentNumberArray'')::varchar::varchar[] AS "FullBusinessDocumentNumberArray",
																------------------------------
																("SubSQL"."JSONData_BusDoc"->>''businessDocumentType_RefIDArray'')::varchar::bigint[] AS "BusinessDocumentType_RefIDArray",
																("SubSQL"."JSONData_BusDoc"->>''businessDocumentTypeNameArray'')::varchar::varchar[] AS "BusinessDocumentTypeNameArray",
																------------------------------
																("SubSQL"."JSONData_BusDoc"->>''businessDocumentVersion_RefIDArray'')::varchar::bigint[] AS "BusinessDocumentVersion_RefIDArray",
																("SubSQL"."JSONData_BusDoc"->>''businessDocumentVersionArray'')::varchar::smallint[] AS "BusinessDocumentVersionArray",
																("SubSQL"."JSONData_BusDoc"->>''businessDocumentDateTimeTZArray'')::varchar::timestamptz[] AS "BusinessDocumentDateTimeTZArray",
																------------------------------
																"SubSQL"."JSONData",
																------------------------------
																"SubSQL"."OrderSequenceArray"
															FROM
																(
																SELECT
																	"SubSQL"."SignNullArray",
																	"SubSQL"."SignInsertModeArray",
																	"SubSQL"."SignExistBusinessDocumentVersionRefID",
																	"SubSQL"."SignKeyPositionBusinessDocumentVersionRefID",
																	------------------------------
																	(
																	CASE
																		WHEN (
																			("SubSQL"."SignExistBusinessDocumentVersionRefID" IS TRUE) AND
																			("SubSQL"."StrSQLBusDoc" IS NOT NULL)
																			) THEN
																			(
																			SELECT
																				JSON_BUILD_OBJECT (
																					''businessDocument_RefIDArray'', "InnerSubSQL"."BusinessDocument_RefIDArray"::varchar,
																					''businessDocumentNumberArray'', "InnerSubSQL"."BusinessDocumentNumberArray"::varchar,
																					''fullBusinessDocumentNumberArray'', "InnerSubSQL"."FullBusinessDocumentNumberArray"::varchar,
																					------------------------------
																					''businessDocumentType_RefIDArray'', "InnerSubSQL"."BusinessDocumentType_RefIDArray"::varchar,
																					''businessDocumentTypeNameArray'', "InnerSubSQL"."BusinessDocumentTypeNameArray"::varchar,
																					------------------------------
																					''businessDocumentVersion_RefIDArray'', "InnerSubSQL"."BusinessDocumentVersion_RefIDArray"::varchar,
																					''businessDocumentVersionArray'', "InnerSubSQL"."BusinessDocumentVersionArray"::varchar,
																					''businessDocumentDateTimeTZArray'', "InnerSubSQL"."BusinessDocumentDateTimeTZArray"::varchar,
																					------------------------------
																					''orderSequenceArray'', "InnerSubSQL"."OrderSequenceArray"::varchar
																				) AS "JSONData_BusDoc"
																			FROM
																				(
																				SELECT
																					"InnerSubSQL"."BusinessDocument_RefIDArray",
																					"InnerSubSQL"."BusinessDocumentNumberArray",
																					"InnerSubSQL"."FullBusinessDocumentNumberArray",
																					------------------------------
																					"InnerSubSQL"."BusinessDocumentType_RefIDArray",
																					"InnerSubSQL"."BusinessDocumentTypeNameArray",
																					------------------------------
																					"InnerSubSQL"."BusinessDocumentVersion_RefIDArray",
																					"InnerSubSQL"."BusinessDocumentVersionArray",
																					"InnerSubSQL"."BusinessDocumentDateTimeTZArray",
																					------------------------------
																					"InnerSubSQL"."OrderSequenceArray"
																				FROM
																					(
																					SELECT
																						CASE
																							WHEN ("InnerSubSQL"."OrderSequence" = 1) THEN
																								(
																								''{'' ||
																								STRING_AGG (
																									COALESCE (
																										(''"'' || REPLACE (REPLACE ("InnerSubSQL"."BusinessDocument_RefID"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''),
																										''NULL''::varchar
																										),
																									'', ''
																									) OVER () ||
																								''}''
																								)
																							ELSE
																								NULL
																						END::bigint[] AS "BusinessDocument_RefIDArray",
																						CASE
																							WHEN ("InnerSubSQL"."OrderSequence" = 1) THEN
																								(
																								''{'' ||
																								STRING_AGG (
																									COALESCE (
																										(''"'' || REPLACE (REPLACE ("InnerSubSQL"."BusinessDocumentNumber"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''),
																										''NULL''::varchar
																										),
																									'', ''
																									) OVER () ||
																								''}''
																								)
																							ELSE
																								NULL
																						END::varchar[] AS "BusinessDocumentNumberArray",
																						CASE
																							WHEN ("InnerSubSQL"."OrderSequence" = 1) THEN
																								(
																								''{'' ||
																								STRING_AGG (
																									COALESCE (
																										(''"'' || REPLACE (REPLACE ("InnerSubSQL"."FullBusinessDocumentNumber"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''),
																										''NULL''::varchar
																										),
																									'', ''
																									) OVER () ||
																								''}''
																								)
																							ELSE
																								NULL
																						END::varchar[] AS "FullBusinessDocumentNumberArray",
																						------------------------------
																						CASE
																							WHEN ("InnerSubSQL"."OrderSequence" = 1) THEN
																								(
																								''{'' ||
																								STRING_AGG (
																									COALESCE (
																										(''"'' || REPLACE (REPLACE ("InnerSubSQL"."BusinessDocumentType_RefID"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''),
																										''NULL''::varchar
																										),
																									'', ''
																									) OVER () ||
																								''}''
																								)
																							ELSE
																								NULL
																						END::bigint[] AS "BusinessDocumentType_RefIDArray",
																						CASE
																							WHEN ("InnerSubSQL"."OrderSequence" = 1) THEN
																								(
																								''{'' ||
																								STRING_AGG (
																									COALESCE (
																										(''"'' || REPLACE (REPLACE ("InnerSubSQL"."BusinessDocumentTypeName"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''),
																										''NULL''::varchar
																										),
																									'', ''
																									) OVER () ||
																								''}''
																								)
																							ELSE
																								NULL
																						END::varchar[] AS "BusinessDocumentTypeNameArray",
																						------------------------------
																						CASE
																							WHEN ("InnerSubSQL"."OrderSequence" = 1) THEN
																								(
																								''{'' ||
																								STRING_AGG (
																									COALESCE (
																										(''"'' || REPLACE (REPLACE ("InnerSubSQL"."BusinessDocumentVersion_RefID"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''),
																										''NULL''::varchar
																										),
																									'', ''
																									) OVER () ||
																								''}''
																								)
																							ELSE
																								NULL
																						END::bigint[] AS "BusinessDocumentVersion_RefIDArray",
																						CASE
																							WHEN ("InnerSubSQL"."OrderSequence" = 1) THEN
																								(
																								''{'' ||
																								STRING_AGG (
																									COALESCE (
																										(''"'' || REPLACE (REPLACE ("InnerSubSQL"."BusinessDocumentVersion"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''),
																										''NULL''::varchar
																										),
																									'', ''
																									) OVER () ||
																								''}''
																								)
																							ELSE
																								NULL
																						END::smallint[] AS "BusinessDocumentVersionArray",
																						CASE
																							WHEN ("InnerSubSQL"."OrderSequence" = 1) THEN
																								(
																								''{'' ||
																								STRING_AGG (
																									COALESCE (
																										(''"'' || REPLACE (REPLACE ("InnerSubSQL"."BusinessDocumentDateTimeTZ"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''),
																										''NULL''::varchar
																										),
																									'', ''
																									) OVER () ||
																								''}''
																								)
																							ELSE
																								NULL
																						END::timestamptz[] AS "BusinessDocumentDateTimeTZArray",
																						------------------------------
																						CASE
																							WHEN ("InnerSubSQL"."OrderSequence" = 1) THEN
																								(
																								''{'' ||
																								STRING_AGG (
																									COALESCE (
																										(''"'' || REPLACE (REPLACE ("InnerSubSQL"."OrderSequence"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''),
																										''NULL''::varchar
																										),
																									'', ''
																									) OVER () ||
																								''}''
																								)
																							ELSE
																								NULL
																						END::bigint[] AS "OrderSequenceArray"
																					FROM
																						(
																						SELECT
																							("InnerSubSQL"."JSONDataBusDoc"->>''businessDocument_RefID'')::bigint AS "BusinessDocument_RefID",
																							("InnerSubSQL"."JSONDataBusDoc"->>''businessDocumentNumber'')::varchar AS "BusinessDocumentNumber",
																							(
																								("InnerSubSQL"."JSONDataBusDoc"->>''businessDocumentNumber'')::varchar ||
																								CASE
																									WHEN (("InnerSubSQL"."JSONDataBusDoc"->>''businessDocumentVersion'')::smallint IS NOT NULL) THEN
																										('' (Version : '' || ("InnerSubSQL"."JSONDataBusDoc"->>''businessDocumentVersion'')::varchar || '')'')
																									ELSE
																										''''
																								END
																							) "FullBusinessDocumentNumber",
																							------------------------------
																							("InnerSubSQL"."JSONDataBusDoc"->>''businessDocumentType_RefID'')::bigint AS "BusinessDocumentType_RefID",
																							("InnerSubSQL"."JSONDataBusDoc"->>''businessDocumentTypeName'')::varchar AS "BusinessDocumentTypeName",
																							------------------------------
																							("InnerSubSQL"."JSONDataBusDoc"->>''businessDocumentVersion_RefID'')::bigint AS "BusinessDocumentVersion_RefID",
																							("InnerSubSQL"."JSONDataBusDoc"->>''businessDocumentVersion'')::smallint AS "BusinessDocumentVersion",
																							("InnerSubSQL"."JSONDataBusDoc"->>''businessDocumentDateTimeTZ'')::timestamptz AS "BusinessDocumentDateTimeTZ",
																							------------------------------
																							ROW_NUMBER () OVER () AS "OrderSequence"
																						FROM
																							(
																							SELECT
																								JSON_ARRAY_ELEMENTS (
																									"InnerSubSQL"."JSONDataBusDoc"
																									) AS "JSONDataBusDoc"
																							FROM
																								"SchSystem"."FuncSys_General_StrSQLExecution"(
																									"SubSQL"."StrSQLBusDoc"
																									) AS "InnerSubSQL" (
																										"JSONDataBusDoc" json
																										)
																							) AS "InnerSubSQL"
																						) AS "InnerSubSQL"
																					LIMIT 1
																					) AS "InnerSubSQL"
																				) AS "InnerSubSQL"
																			)
																		ELSE
																			NULL
																	END
																	) AS "JSONData_BusDoc",
																	------------------------------
																	"SubSQL"."JSONData",
																	------------------------------
																	"SubSQL"."OrderSequenceArray"
																FROM
																	(
																	SELECT
																		(
																		CASE
																			WHEN (
																				("SubSQL"."OrderSequence" = 1) AND
																				("SubSQL"."SignExistBusinessDocumentVersionRefID" IS TRUE) AND
																				((SELECT ("SubSQL"."JSONData")::jsonb ? ''entitiesMetaData'') IS TRUE) AND
																				((SELECT ("SubSQL"."JSONData"->''entitiesMetaData'')::jsonb ? ''businessDocumentTypeName'') IS TRUE) AND
																				((SELECT ("SubSQL"."JSONData"->''entitiesMetaData'')::jsonb ? ''documentDate'') IS TRUE)
																				) THEN
																					(
																					''
																					SELECT
																						"SchMaster"."Func_GetDataPreparation_BusinessDocument" (''''
																					''
																					||
																					(
																					''['' ||
																					STRING_AGG (
																						(
																						CASE
																							WHEN (
																								--("SubSQL"."SignInsertMode" IS TRUE) AND
																								((SELECT ("SubSQL"."JSONData")::jsonb ? ''entitiesMetaData'') IS TRUE) AND
																								((SELECT ("SubSQL"."JSONData"->''entitiesMetaData'')::jsonb ? ''businessDocumentTypeName'') IS TRUE) AND
																								((SELECT ("SubSQL"."JSONData"->''entitiesMetaData'')::jsonb ? ''documentDate'') IS TRUE)
																								) THEN
																									(
																									JSON_BUILD_OBJECT (
																										''recordID'', ("SubSQL"."JSONData"->''entities''->>''businessDocumentVersion_RefID'')::bigint,
																										''entities'', JSON_BUILD_OBJECT (
																											''branch_RefID'', ("SubSQL"."JSONData"->''entities''->>''sysBranch_RefID'')::bigint,
																											''businessDocumentTypeName'', ("SubSQL"."JSONData"->''entitiesMetaData''->>''businessDocumentTypeName'')::varchar,
																											''documentDate'', ("SubSQL"."JSONData"->''entitiesMetaData''->>''documentDate'')::date
																											)
																										)
																									)::varchar
																							ELSE
																								''null''
																						END
																						)::varchar,
																						'', ''
																						) OVER () ||
																					'']''
																					)::json::varchar
																					||
																					''
																					''''::json
																					)
																					''
																					)
																			ELSE
																				NULL
																		END::varchar
																		) AS "StrSQLBusDoc",
																		------------------------------	
																		CASE
																			WHEN ("SubSQL"."OrderSequence" = 1) THEN
																				(
																				''{'' ||
																				STRING_AGG (
																					COALESCE (
																						REPLACE (REPLACE ("SubSQL"."SignNull"::varchar, ''\'', ''\\''), ''"'', ''\"''),
																						''NULL''
																						),
																					'', ''
																					) OVER () ||
																				''}''
																				)
																			ELSE
																				NULL
																		END::boolean[] AS "SignNullArray",
																		CASE
																			WHEN ("SubSQL"."OrderSequence" = 1) THEN
																				(
																				''{'' ||
																				STRING_AGG (
																					COALESCE (
																						REPLACE (REPLACE ("SubSQL"."SignInsertMode"::varchar, ''\'', ''\\''), ''"'', ''\"''),
																						''NULL''
																						),
																					'', ''
																					) OVER () ||
																				''}''
																				)
																			ELSE
																				NULL
																		END::boolean[] AS "SignInsertModeArray",
																		------------------------------
																		"SubSQL"."SignInsertMode",
																		"SubSQL"."SignExistBusinessDocumentVersionRefID",
																		"SubSQL"."SignKeyPositionBusinessDocumentVersionRefID",
																		------------------------------
																		CASE
																			WHEN ("SubSQL"."OrderSequence" = 1) THEN
																				(
																				''['' ||
																				STRING_AGG (
																					COALESCE (
																						"SubSQL"."JSONData"::varchar,
																						''null''
																						),
																					'', ''
																				) OVER () ||
																				'']''
																				)
																			ELSE
																				NULL
																		END::json AS "JSONData",
																		------------------------------
																		CASE
																			WHEN ("SubSQL"."OrderSequence" = 1) THEN
																				(
																				''{'' ||
																				STRING_AGG (
																					COALESCE (
																						REPLACE (REPLACE ("SubSQL"."OrderSequence"::varchar, ''\'', ''\\''), ''"'', ''\"''),
																						''NULL''
																						),
																					'', ''
																					) OVER () ||
																				''}''
																				)
																			ELSE
																				NULL
																		END::bigint[] AS "OrderSequenceArray"
																	FROM
																		(
																		SELECT
																			"SubSQL"."SignNull",
																			"SubSQL"."SignInsertMode",
																			"SubSQL"."SignExistBusinessDocumentVersionRefID",
																			"SubSQL"."SignKeyPositionBusinessDocumentVersionRefID",
																			------------------------------
																			"SubSQL"."JSONData",
																			------------------------------
																			"SubSQL"."OrderSequence"
																		FROM
																			(
																			SELECT
																				"SubSQL"."SignNull",
																				"SubSQL"."SignInsertMode",
																				"SubSQL"."SignExistBusinessDocumentVersionRefID",
																				CASE
																					WHEN ("SubSQL"."SignExistBusinessDocumentVersionRefID" IS TRUE) THEN
																						(
																						SELECT
																							"InnerSubSQL"."OrderSequence"
																						FROM
																							(
																							SELECT
																								"InnerSubSQL"."Key",
																								ROW_NUMBER () OVER () AS "OrderSequence"
																							FROM
																								(
																								SELECT
																									JSON_OBJECT_KEYS("SubSQL"."JSONData"->''entities'') AS "Key"
																								) AS "InnerSubSQL"
																							) AS "InnerSubSQL"
																						WHERE
																							"InnerSubSQL"."Key" = ''businessDocumentVersion_RefID''
																						LIMIT 1
																						)
																					ELSE
																						NULL
																				END AS "SignKeyPositionBusinessDocumentVersionRefID",
																				------------------------------
																				"SubSQL"."JSONData",
																				------------------------------
																				"SubSQL"."OrderSequence"
																			FROM
																				(
																				SELECT
																					"SubSQL"."SignNull",
																					"SubSQL"."SignInsertMode",
																					CASE
																						WHEN (SUM ("SubSQL"."SignExistBusinessDocumentVersionRefID") OVER () > 0) THEN
																							TRUE
																						ELSE
																							FALSE
																					END::boolean AS "SignExistBusinessDocumentVersionRefID",
																					------------------------------
																					"SubSQL"."JSONData",
																					------------------------------
																					"SubSQL"."OrderSequence"
																				FROM
																					(
																					SELECT
																						CASE
																							WHEN ("SubSQL"."JSONData"::varchar = ''null'') THEN
																								TRUE
																							ELSE
																								FALSE
																						END AS "SignNull",
																						CASE
																							WHEN (("SubSQL"."JSONData"->>''recordID'')::bigint IS NULL) THEN
																								TRUE
																							ELSE
																								FALSE
																						END AS "SignInsertMode",
																						CASE
																							WHEN ((SELECT ("SubSQL"."JSONData"->''entities'')::jsonb ? ''businessDocumentVersion_RefID'') IS TRUE) THEN
																								1
																							ELSE
																								0
																						END AS "SignExistBusinessDocumentVersionRefID",
																						------------------------------
																						"SubSQL"."JSONData",
																						------------------------------
																						ROW_NUMBER () OVER () AS "OrderSequence"
																					FROM
																						(
																						SELECT
																							JSON_ARRAY_ELEMENTS (
																								"SubSQL"."JSONData"
																								) AS "JSONData"
																						FROM
																							(
																							SELECT
																								''' || REPLACE (varJSONData::varchar, '''', '''''') || '''::json AS "JSONData"
																							) AS "SubSQL"
																						) AS "SubSQL"
																					) AS "SubSQL"
																				) AS "SubSQL"
																			) AS "SubSQL"
																		) AS "SubSQL"
																	LIMIT 1	
																	) AS "SubSQL"
																) AS "SubSQL"
															) AS "SubSQL"
														) AS "SubSQL"
													) AS "SubSQL"
												) AS "SubSQL"
											-----[ MAIN DATA ]-----(  END  )-----
											) AS "SubSQL"
										) AS "SubSQL"
									) AS "SubSQL"
								) AS "SubSQL"
							LIMIT 1
							) AS "SubSQL"
						';
					--RAISE NOTICE '%', varSQL;
					EXECUTE
						varSQL
					INTO
						varSQL,
						varJSONData_BusDoc;
					--RAISE NOTICE '%', varSQL;
					--RAISE NOTICE '%', varJSONData_BusDoc;

					IF (varSQL IS NOT NULL) THEN
						EXECUTE
							varSQL
						INTO
							varArraySysRPK;
						--RAISE NOTICE '%', varArraySysRPK;
					END IF;

				---> Reinitilizing : varArraySysPID, varArraySysSID
					varSQL := '
						SELECT
							"SubSQL"."Sys_PIDArray",
							"SubSQL"."Sys_SIDArray"
						FROM
							(
							SELECT
								CASE
									WHEN ("SubSQL"."OrderSequence" = 1) THEN
										(
										''{'' ||
										STRING_AGG (
											COALESCE ((''"'' || REPLACE (REPLACE ("SubSQL"."Sys_PID"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''), ''NULL''),
											'', ''
											) OVER () ||
										''}''
										)
									ELSE
										NULL
								END::bigint[] AS "Sys_PIDArray",
								CASE
									WHEN ("SubSQL"."OrderSequence" = 1) THEN
										(
										''{'' ||
										STRING_AGG (
											COALESCE ((''"'' || REPLACE (REPLACE ("SubSQL"."Sys_SID"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''), ''NULL''),
											'', ''
											) OVER () ||
										''}''
										)
									ELSE
										NULL
								END::bigint[] AS "Sys_SIDArray"
							FROM
								(
								SELECT
									"VirtTblData"."Sys_PID",
									"VirtTblData"."Sys_SID",
									"SubSQL"."Sys_RPK",
									------------------------------
									ROW_NUMBER () OVER (
										ORDER BY
											"SubSQL"."OrderSequence" ASC
										) AS "OrderSequence"
								FROM
									(
									SELECT
										"Sys_RPK",
										------------------------------
										ROW_NUMBER () OVER () AS "OrderSequence"
									FROM
										UNNEST (''' || COALESCE (varArraySysRPK::varchar, '{null}') || '''::bigint[]) AS "Sys_RPK"
									) AS "SubSQL"
										LEFT JOIN
											"' || varSchema || '"."' || varTable || '" AS "VirtTblData"
												ON
													"SubSQL"."Sys_RPK" = "VirtTblData"."Sys_RPK"
								) AS "SubSQL"
							LIMIT 1
							) AS "SubSQL"
						';
					--RAISE NOTICE 'varSQL %', varSQL;
					EXECUTE
						varSQL
					INTO
						varArraySysPID,
						varArraySysSID;
					--RAISE NOTICE 'varArraySysPID %', varArraySysPID;
					--RAISE NOTICE 'varArraySysSID %', varArraySysSID;

				---> Update Detail Based On Additional Data
					varSQL := '
						SELECT
							"SubSQL"."SQLSyntax"
						FROM
							(
							SELECT
								CASE
									WHEN ("SubSQL"."FilterSequence" = 1) THEN
										STRING_AGG (
											"SubSQL"."SQLSyntax",
											''
											'') OVER (
												)
									ELSE
										NULL
								END AS "SQLSyntax",
								------------------------------
								"SubSQL"."OrderSequence",
								ROW_NUMBER () OVER (
									ORDER BY
										"SubSQL"."OrderSequenceOverAll" ASC
									) AS "OrderSequenceOverAll"
							FROM
								(
								SELECT
									"SubSQL"."SysLoginSession_RefID",
									"SubSQL"."RecordID",
									------------------------------
									"SubSQL"."SQLSyntax",
									------------------------------
									ROW_NUMBER () OVER (
										ORDER BY
											"SubSQL"."OrderSequenceOverAll" ASC
										) AS "FilterSequence",
									"SubSQL"."OrderSequence",
									"SubSQL"."OrderSequenceExpansion",
									ROW_NUMBER () OVER (
										ORDER BY
											"SubSQL"."OrderSequenceOverAll" ASC
										) AS "OrderSequenceOverAll"
								FROM
									(
									SELECT
										"SubSQL"."SysLoginSession_RefID",
										"SubSQL"."RecordID",
										------------------------------
										''
										SELECT
											'' || (''"'' || REPLACE ("SubSQL"."FunctionName", ''.'', ''"."'') || ''"'') || ''(
												''''{}'''',
												'''''' || REPLACE ("SubSQL"."JSONData"::varchar, '''''''', '''''''''''') || ''''''::json,
												JSON_BUILD_OBJECT (
													''''sysLoginSession_RefID'''', '' || "SubSQL"."SysLoginSession_RefID" || ''::bigint,
													''''SQLSyntaxCriteria'''', '''''' || REPLACE ("SubSQL"."SQLSyntax_Delete"::varchar, '''''''', '''''''''''') || ''''''::varchar
													)
												);
										''::varchar AS "SQLSyntax",
										------------------------------
										"SubSQL"."OrderSequence",
										"SubSQL"."OrderSequenceExpansion",
										ROW_NUMBER () OVER (
											ORDER BY
												"SubSQL"."OrderSequenceOverAll" ASC
											) AS "OrderSequenceOverAll"
									FROM
										(
										SELECT
											"SubSQL"."SignExistAdditionalData",
											"SubSQL"."SignExistBusinessDocumentVersionRefID",
											------------------------------
											"SubSQL"."SysLoginSession_RefID",
											"SubSQL"."RecordID",
											------------------------------
											"SubSQL"."FunctionName",
											------------------------------
											"SubSQL"."SQLSyntax_Delete",
											------------------------------
											(
											CASE
												WHEN (("SubSQL"."SignExistAdditionalData" IS TRUE) AND ("SubSQL"."FunctionName" IS NOT NULL) AND ("SubSQL"."JSONData" IS NULL)) THEN
													''[]''::json
												ELSE
													"SubSQL"."JSONData"
											END
											) AS "JSONData",
											------------------------------
											"SubSQL"."FilterSequence",
											"SubSQL"."OrderSequence",
											"SubSQL"."OrderSequenceExpansion",
											ROW_NUMBER () OVER (
												ORDER BY
													"SubSQL"."OrderSequenceOverAll"
												) AS "OrderSequenceOverAll"
										FROM
											(
											SELECT
												"SubSQL"."SignExistAdditionalData",
												"SubSQL"."SignExistBusinessDocumentVersionRefID",
												------------------------------
												"SubSQL"."SysLoginSession_RefID",
												"SubSQL"."RecordID",
												------------------------------
												CASE
													WHEN ("SubSQL"."FilterSequence" = 1) THEN
														"SubSQL"."FunctionName"
													ELSE
														NULL
												END::varchar AS "FunctionName",
												------------------------------
												CASE
													WHEN ("SubSQL"."FilterSequence" = 1) THEN
														(
														''('' ||
														STRING_AGG (
															"SubSQL"."SQLSyntax_Delete",
															''
															OR 
															''
															) OVER (
																PARTITION BY
																	"SubSQL"."FunctionName"
																) ||
														'')''
														)
													ELSE
														NULL
												END::varchar AS "SQLSyntax_Delete",
												------------------------------
												CASE
													WHEN ("SubSQL"."FilterSequence" = 1) THEN
														(
														''['' ||
														STRING_AGG (
															"SubSQL"."JSONDataVarChar"::varchar,
															'',''
															) OVER (
																PARTITION BY
																	"SubSQL"."FunctionName"
																) ||
														'']''
														)
													ELSE
														NULL
												END::json AS "JSONData",
												------------------------------
												"SubSQL"."FilterSequence",
												"SubSQL"."OrderSequence",
												"SubSQL"."OrderSequenceExpansion",
												"SubSQL"."OrderSequenceOverAll"
											FROM
												(
												SELECT
													"SubSQL"."SignExistAdditionalData",
													"SubSQL"."SignExistBusinessDocumentVersionRefID",
													------------------------------
													"SubSQL"."SysLoginSession_RefID",
													"SubSQL"."RecordID",
													------------------------------
													"SubSQL"."FunctionName",
													------------------------------
													"SubSQL"."SQLSyntax_Delete",
													------------------------------
													"SubSQL"."JSONDataVarChar",
													------------------------------
													"SubSQL"."FilterSequence",
													"SubSQL"."OrderSequence",
													"SubSQL"."OrderSequenceExpansion",
													ROW_NUMBER () OVER (
														ORDER BY
															"SubSQL"."OrderSequenceOverAll" ASC
														) AS "OrderSequenceOverAll"
												FROM
													(
													SELECT
														"SubSQL"."SignExistAdditionalData",
														"SubSQL"."SignExistBusinessDocumentVersionRefID",
														------------------------------
														"SubSQL"."SysLoginSession_RefID",
														"SubSQL"."RecordID",
														------------------------------
														"SubSQL"."FunctionName",
														------------------------------
														"SubSQL"."SQLSyntax_Delete",
														------------------------------
														"SubSQL"."JSONDataVarChar",
														------------------------------
														ROW_NUMBER () OVER (
															PARTITION BY
																"SubSQL"."FunctionName"
															ORDER BY
																"SubSQL"."OrderSequence" ASC,
																"SubSQL"."OrderSequenceExpansion" ASC,
																"SubSQL"."OrderSequenceOverAll" ASC
															) AS "FilterSequence",
														"SubSQL"."OrderSequence",
														"SubSQL"."OrderSequenceExpansion",
														ROW_NUMBER () OVER (
															ORDER BY
																"SubSQL"."OrderSequence" ASC,
																"SubSQL"."OrderSequenceExpansion" ASC,
																"SubSQL"."OrderSequenceOverAll" ASC
															) AS "OrderSequenceOverAll"
													FROM
														(
														SELECT
															"SubSQL"."SignExistAdditionalData",
															"SubSQL"."SignExistBusinessDocumentVersionRefID",
															------------------------------
															"SubSQL"."SysLoginSession_RefID",
															"SubSQL"."RecordID",
															------------------------------
															"SubSQL"."FunctionName",
															------------------------------
															/*
															CASE
																WHEN (("SubSQL2"."RecordPID" IS NULL) AND ("SubSQL2"."RecordSID" IS NULL)) THEN
																	NULL
																ELSE*/
																	(
																		''
																		(
																		"Sys_Data_Delete_DateTimeTZ" IS NULL
																		AND
																			(
																				("'' || "SubSQL"."DataLinkerName" || ''" = '' || COALESCE ("SubSQL"."DataLinkerName_RefPID", 0::bigint) || ''::bigint)
																				OR
																				("'' || "SubSQL"."DataLinkerName" || ''" = '' || COALESCE ("SubSQL"."DataLinkerName_RefSID", 0::bigint) || ''::bigint)
																			)
																		AND
																			(
																			"Sys_PID" NOT IN (
																				SELECT
																					UNNEST('' || '''''''' || "SubSQL"."ExistingDetailRecordIDArray"::varchar || '''''''' || ''::bigint[])
																				)
																			AND
																			"Sys_SID" NOT IN (
																				SELECT
																					UNNEST('' || '''''''' || "SubSQL"."ExistingDetailRecordIDArray"::varchar || '''''''' || ''::bigint[])
																				)
																			)
																		)
																		''
																	)::varchar AS "SQLSyntax_Delete",
															--END::varchar AS "SQLSyntax_Delete",
															------------------------------
															(
															CASE
																WHEN ("SubSQL"."JSONDataVarChar"::varchar = ''null'') THEN
																	"SubSQL"."JSONDataVarChar"
																ELSE
																	REPLACE (
																		REPLACE (
																			"SubSQL"."JSONDataVarChar"::varchar,
																			''"<<ZhtTagDataLinker>>"''::varchar,
																			COALESCE (
																				"SubSQL"."DataLinkerName_RefPID"::varchar,
																				"SubSQL"."DataLinkerName_RefSID"::varchar
																				)
																			)::varchar,
																		''"<<ZhtTagLoginSessionRefID>>"''::varchar,
																		COALESCE (
																			"SubSQL"."SysLoginSession_RefID"::varchar,
																			''6000000000001''::varchar
																			)
																		)
															END
															) AS "JSONDataVarChar",
															------------------------------
															"SubSQL"."OrderSequence",
															"SubSQL"."OrderSequenceExpansion",
															"SubSQL"."OrderSequenceOverAll"
														FROM
															(
															SELECT
																"SubSQL"."SignExistAdditionalData",
																"SubSQL"."SignExistBusinessDocumentVersionRefID",
																------------------------------
																"SubSQL"."SysLoginSession_RefID",
																"SubSQL"."MainRecordID" AS "RecordID",
																------------------------------
																"SubSQL"."FunctionName",
																"SubSQL"."DataLinkerName",
																------------------------------
																"SubSQL"."DataLinkerName_RefPID",
																"SubSQL"."DataLinkerName_RefSID",
																------------------------------
																"SubSQL"."ExistingDetailRecordIDArray",
																------------------------------
																CASE
																	WHEN ("SubSQL"."JSONDataVarChar" != '''') THEN
																		"SubSQL"."JSONDataVarChar"
																	ELSE
																		NULL
																END AS "JSONDataVarChar",
																------------------------------
																"SubSQL"."OrderSequence",
																"SubSQL"."OrderSequenceExpansion",
																ROW_NUMBER () OVER (
																	ORDER BY
																		"SubSQL"."OrderSequenceOverAll"
																	) AS "OrderSequenceOverAll"
															FROM
																(
																SELECT
																	"SubSQL"."SignExistAdditionalData",
																	"SubSQL"."SignExistBusinessDocumentVersionRefID",
																	------------------------------
																	"SubSQL"."SysLoginSession_RefID",
																	"SubSQL"."MainRecordID",
																	------------------------------
																	"SubSQL"."FunctionName",
																	"SubSQL"."DataLinkerName",
																	------------------------------
																	"SubSQL"."DataLinkerName_RefPID",
																	"SubSQL"."DataLinkerName_RefSID",
																	------------------------------
																	CASE
																		WHEN ("SubSQL"."OrderSequenceExpansion2" = 1) THEN
																			(
																			''{'' ||
																			COALESCE (
																				STRING_AGG (
																					(''"'' || REPLACE (REPLACE ("SubSQL"."DetailRecordID"::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''),
																					'', ''
																					) OVER (
																						PARTITION BY
																							"SubSQL"."OrderSequence",
																							"SubSQL"."OrderSequenceExpansion",
																							"SubSQL"."FunctionName"
																						),
																				''''
																				) ||
																			''}''
																			)
																		ELSE
																			NULL
																	END::bigint[] AS "ExistingDetailRecordIDArray",
																	------------------------------
																	CASE
																		WHEN ("SubSQL"."OrderSequenceExpansion2" = 1) THEN
																			(
																			COALESCE (
																				STRING_AGG (
																					COALESCE (
																						"SubSQL"."JSONData"::varchar,
																						''null''::varchar
																						),
																					'', ''
																					) OVER (
																						PARTITION BY
																							"SubSQL"."OrderSequence",
																							"SubSQL"."OrderSequenceExpansion",
																							"SubSQL"."FunctionName"
																						),
																				''''
																				)
																			)
																		ELSE
																			NULL
																	END::varchar AS "JSONDataVarChar",
																	------------------------------
																	"SubSQL"."OrderSequence",
																	"SubSQL"."OrderSequenceExpansion",
																	"SubSQL"."OrderSequenceExpansion2",
																	"SubSQL"."OrderSequenceOverAll"
																FROM
																	(
																	-----[ MAIN DATA ]-----( START )-----
																	SELECT
																		"SubSQL"."SignExistAdditionalData",
																		"SubSQL"."SignExistBusinessDocumentVersionRefID",
																		------------------------------
																		"SubSQL"."SysLoginSession_RefID",
																		"SubSQL"."MainRecordID",
																		------------------------------
																		"SubSQL"."FunctionName",
																		"SubSQL"."DataLinkerName",
																		------------------------------
																		"SubSQL"."DataLinkerName_RefPID",
																		"SubSQL"."DataLinkerName_RefSID",
																		------------------------------
																		("JSONData"->>''recordID'')::bigint AS "DetailRecordID",
																		------------------------------
																		"SubSQL"."JSONData",
																		------------------------------
																		"SubSQL"."OrderSequence",
																		"SubSQL"."OrderSequenceExpansion",
																		"SubSQL"."OrderSequenceExpansion2",
																		"SubSQL"."OrderSequenceOverAll"
																	FROM
																		(
																		SELECT
																			"SubSQL"."SignExistAdditionalData",
																			"SubSQL"."SignExistBusinessDocumentVersionRefID",
																			------------------------------
																			"SubSQL"."SysLoginSession_RefID",
																			"SubSQL"."MainRecordID",
																			------------------------------
																			"SubSQL"."FunctionName",
																			"SubSQL"."DataLinkerName",
																			------------------------------
																			"SubSQL"."DataLinkerName_RefPID",
																			"SubSQL"."DataLinkerName_RefSID",
																			------------------------------
																			("JSONData"->>''recordID'')::bigint AS "DetailRecordID",
																			------------------------------
																			"SubSQL"."JSONData",
																			------------------------------
																			"SubSQL"."OrderSequence",
																			"SubSQL"."OrderSequenceExpansion",
																			"SubSQL"."OrderSequenceExpansion2",
																			"SubSQL"."OrderSequenceOverAll"
																		FROM
																			(
																			SELECT
																				"SubSQL"."SignExistAdditionalData",
																				"SubSQL"."SignExistBusinessDocumentVersionRefID",
																				------------------------------
																				"SubSQL"."SysLoginSession_RefID",
																				"SubSQL"."MainRecordID",
																				------------------------------
																				"SubSQL"."FunctionName",
																				"SubSQL"."DataLinkerName",
																				------------------------------
																				"SubSQL"."DataLinkerName_RefPID",
																				"SubSQL"."DataLinkerName_RefSID",
																				------------------------------
																				CASE
																					WHEN ("SubSQL"."Entities" IS NOT NULL) THEN
																						JSON_BUILD_OBJECT (
																							''recordID'', "SubSQL"."RecordID",
																							''entities'', "SubSQL"."Entities"
																							)
																					ELSE
																						NULL::json
																				END AS "JSONData",
																				------------------------------
																				"SubSQL"."OrderSequence",
																				"SubSQL"."OrderSequenceExpansion",
																				"SubSQL"."OrderSequenceExpansion2",
																				"SubSQL"."OrderSequenceOverAll"
																			FROM
																				(
																				SELECT
																					"SubSQL"."SignExistAdditionalData",
																					"SubSQL"."SignExistBusinessDocumentVersionRefID",
																					------------------------------
																					"SubSQL"."SysLoginSession_RefID",
																					"SubSQL"."MainRecordID",
																					------------------------------
																					"SubSQL"."FunctionName",
																					"SubSQL"."DataLinkerName",
																					------------------------------
																					"SubSQL"."DataLinkerName_RefPID",
																					"SubSQL"."DataLinkerName_RefSID",
																					------------------------------
																					"SubSQL"."RecordID",
																					(
																					SELECT
																						CASE
																							WHEN ("InnerSubSQL"."OrderSequence" = 1) THEN
																								(
																								''{'' ||
																								STRING_AGG (
																									(''"'' || "InnerSubSQL"."Key" || ''" : '' || (CASE WHEN (UPPER("InnerSubSQL"."Key") = UPPER(''sysLoginSession_RefID'')) THEN ''"<<ZhtTagLoginSessionRefID>>"'' WHEN (UPPER("InnerSubSQL"."Key") = UPPER("SubSQL"."DataLinkerName")) THEN ''"<<ZhtTagDataLinker>>"'' ELSE "InnerSubSQL"."Value" END)::varchar),
																									'', ''
																									) OVER () ||
																								 ''}''
																								 )::json
																							ELSE
																								NULL
																						END
																					FROM
																						(
																						SELECT
																							"InnerSubSQL"."key" AS "Key",
																							"InnerSubSQL"."value" AS "Value",
																							------------------------------
																							ROW_NUMBER () OVER () AS "OrderSequence"
																						FROM
																							JSON_EACH ("SubSQL"."Entities") AS "InnerSubSQL"
																						) AS "InnerSubSQL"
																					LIMIT 1
																					) AS "Entities",
																					------------------------------
																					"SubSQL"."OrderSequence",
																					"SubSQL"."OrderSequenceExpansion",
																					"SubSQL"."OrderSequenceExpansion2",
																					"SubSQL"."OrderSequenceOverAll"
																				FROM
																					(
																					SELECT
																						"SubSQL"."SignExistAdditionalData",
																						"SubSQL"."SignExistBusinessDocumentVersionRefID",
																						------------------------------
																						"SubSQL"."SysLoginSession_RefID",
																						"SubSQL"."MainRecordID",
																						------------------------------
																						"SubSQL"."FunctionName",
																						"SubSQL"."DataLinkerName",
																						------------------------------
																						"SubSQL"."DataLinkerName_RefPID",
																						"SubSQL"."DataLinkerName_RefSID",
																						------------------------------
																						"SubSQL"."JSONData",
																						"SubSQL"."JSONData"->''recordID'' AS "RecordID",
																						"SubSQL"."JSONData"->''entities'' AS "Entities",
																						------------------------------
																						"SubSQL"."OrderSequence",
																						"SubSQL"."OrderSequenceExpansion",
																						ROW_NUMBER () OVER (
																							PARTITION BY
																								"SubSQL"."OrderSequence",
																								"SubSQL"."OrderSequenceExpansion",
																								"SubSQL"."FunctionName"
																							ORDER BY
																								"SubSQL"."OrderSequenceOverAll" ASC
																							) AS "OrderSequenceExpansion2",
																						ROW_NUMBER () OVER (
																							ORDER BY
																								"SubSQL"."OrderSequenceOverAll" ASC
																							) AS "OrderSequenceOverAll"
																					FROM
																						(
																						SELECT
																							"SubSQL"."SignExistAdditionalData",
																							"SubSQL"."SignExistBusinessDocumentVersionRefID",
																							------------------------------
																							"SubSQL"."SysLoginSession_RefID",
																							"SubSQL"."MainRecordID",
																							------------------------------
																							"SubSQL"."FunctionName",
																							(
																							CASE
																								WHEN (LENGTH ("SubSQL"."DataLinkerName") < 2) THEN
																									UPPER (SUBSTR ("SubSQL"."DataLinkerName", 1, 1))
																								ELSE
																									CASE
																										WHEN (SUBSTR ("SubSQL"."DataLinkerName", 2, 1) = UPPER (SUBSTR ("SubSQL"."DataLinkerName", 2, 1))) THEN
																											SUBSTR ("SubSQL"."DataLinkerName", 1, 1)
																										ELSE
																											UPPER (SUBSTR ("SubSQL"."DataLinkerName", 1, 1))
																									END
																							END ||
																							SUBSTR ("SubSQL"."DataLinkerName", 2, LENGTH ("SubSQL"."DataLinkerName") - 1)
																							) AS "DataLinkerName",
																							------------------------------
																							"SubSQL"."DataLinkerName_RefPID",
																							"SubSQL"."DataLinkerName_RefSID",
																							------------------------------
																							JSON_ARRAY_ELEMENTS (
																								COALESCE (
																									CASE
																										WHEN (JSON_ARRAY_LENGTH ("SubSQL"."JSONData") = 0) THEN
																											''[null]''::json
																										ELSE
																											"SubSQL"."JSONData"
																									END,
																									''[null]''::json
																									)
																								) AS "JSONData",
																							------------------------------
																							"SubSQL"."OrderSequence",
																							"SubSQL"."OrderSequenceExpansion",
																							ROW_NUMBER () OVER (
																								ORDER BY
																									"SubSQL"."OrderSequenceOverAll" ASC
																								) AS "OrderSequenceOverAll"
																						FROM
																							(
																							SELECT
																								"SubSQL"."SignExistAdditionalData",
																								"SubSQL"."SignExistBusinessDocumentVersionRefID",
																								------------------------------
																								"SubSQL"."SysLoginSession_RefID",
																								"SubSQL"."MainRecordID",
																								------------------------------
																								"SubSQL"."FunctionName",
																								"SubSQL"."DataLinkerName",
																								------------------------------
																								"SubSQL"."DataLinkerName_RefPID",
																								"SubSQL"."DataLinkerName_RefSID",
																								------------------------------
																								(
																								CASE
																									WHEN ((JSON_ARRAY_LENGTH("SubSQL"."JSONData") = 0) AND ("SubSQL"."SignExistAdditionalData" IS TRUE)) THEN
																										NULL::json
																									ELSE
																										"SubSQL"."JSONData"
																								END
																								) AS "JSONData",
																								------------------------------
																								"SubSQL"."OrderSequence",
																								"SubSQL"."OrderSequenceExpansion",
																								"SubSQL"."OrderSequenceOverAll"
																							FROM
																								(
																								SELECT
																									"SubSQL"."SignExistAdditionalData",
																									"SubSQL"."SignExistBusinessDocumentVersionRefID",
																									------------------------------
																									"SubSQL"."SysLoginSession_RefID",
																									"SubSQL"."MainRecordID",
																									------------------------------
																									("SubSQL"."JSONData"->>''functionName'')::varchar AS "FunctionName",
																									("SubSQL"."JSONData"->>''dataLinkerName'')::varchar AS "DataLinkerName",
																									------------------------------
																									"SubSQL"."DataLinkerName_RefPID",
																									"SubSQL"."DataLinkerName_RefSID",
																									------------------------------
																									("SubSQL"."JSONData"->''data'')::json AS "JSONData",
																									------------------------------
																									"SubSQL"."OrderSequence",
																									ROW_NUMBER () OVER (
																										PARTITION BY
																											"SubSQL"."OrderSequence",
																											("SubSQL"."JSONData"->>''functionName'')::varchar
																										ORDER BY
																											"SubSQL"."OrderSequenceOverAll" ASC
																										) AS "OrderSequenceExpansion",
																									ROW_NUMBER () OVER (
																										ORDER BY
																											"SubSQL"."OrderSequenceOverAll" ASC
																										) AS "OrderSequenceOverAll"
																								FROM
																									(
																									SELECT
																										"SubSQL"."SignExistAdditionalData",
																										"SubSQL"."SignExistBusinessDocumentVersionRefID",
																										------------------------------
																										"SubSQL"."DataLinkerName_RefPID",
																										"SubSQL"."DataLinkerName_RefSID",
																										------------------------------
																										"SubSQL"."SysLoginSession_RefID",
																										"SubSQL"."MainRecordID",
																										------------------------------
																										"SubSQL"."JSONData",
																										------------------------------
																										"SubSQL"."OrderSequence",
																										ROW_NUMBER () OVER (
																											ORDER BY
																												"SubSQL"."OrderSequence" ASC
																											) AS "OrderSequenceOverAll"
																									FROM
																										(
																										SELECT
																											"SubSQL"."SignExistAdditionalData",
																											"SubSQL"."SignExistBusinessDocumentVersionRefID",
																											------------------------------
																											"SubSQL"."DataLinkerName_RefPID",
																											"SubSQL"."DataLinkerName_RefSID",
																											------------------------------
																											"SubSQL"."SysLoginSession_RefID",
																											"SubSQL"."MainRecordID",
																											------------------------------
																											JSON_ARRAY_ELEMENTS ("SubSQL"."JSONData") AS "JSONData",
																											------------------------------
																											"SubSQL"."OrderSequence"
																										FROM
																											(
																											SELECT
																												"SubSQL"."SignExistAdditionalData",
																												"SubSQL"."SignExistBusinessDocumentVersionRefID",
																												------------------------------
																												"SubSQL"."DataLinkerName_RefPID",
																												"SubSQL"."DataLinkerName_RefSID",
																												------------------------------
																												("SubSQL"."JSONData"->''entities''->>''sysLoginSession_RefID'')::bigint AS "SysLoginSession_RefID",
																												("SubSQL"."JSONData"->>''recordID'')::bigint AS "MainRecordID",
																												------------------------------
																												COALESCE (
																													("SubSQL"."JSONData"->''entities''->''additionalData''),
																													''[null]''::json
																													) AS "JSONData",
																												------------------------------
																												ROW_NUMBER () OVER (
																													ORDER BY
																														"SubSQL"."OrderSequence" ASC
																													) AS "OrderSequence"
																											FROM
																												(
																												SELECT
																													(SELECT ("SubSQL"."JSONData"->''entities'')::jsonb ? ''additionalData'') AS "SignExistAdditionalData",
																													(SELECT ("SubSQL"."JSONData"->''entities'')::jsonb ? ''businessDocumentVersion_RefID'') AS "SignExistBusinessDocumentVersionRefID",
																													------------------------------
																													"SubSQL2"."RecordPID" AS "DataLinkerName_RefPID",
																													"SubSQL2"."RecordSID" AS "DataLinkerName_RefSID",
																													------------------------------
																													"SubSQL"."JSONData",
																													------------------------------
																													"SubSQL"."OrderSequence"
																												FROM
																													(
																													SELECT
																														"SubSQL"."JSONData",
																														------------------------------
																														ROW_NUMBER () OVER () AS "OrderSequence"
																													FROM
																														(
																														SELECT
																															JSON_ARRAY_ELEMENTS (
																																"SubSQL"."JSONData"
																																) AS "JSONData"
																														FROM
																															(
																															SELECT
																																' ||
																																(
																																SELECT
																																	('''' || REPLACE (varJSONData::varchar, '''', '''''') || '''')::varchar
																																)::varchar ||
																																'::json AS "JSONData"
																															) AS "SubSQL"
																														) AS "SubSQL"
																													) AS "SubSQL"
																														LEFT JOIN
																															(
																															SELECT
																																"SubSQL"."RecordPID",
																																"SubSQL"."RecordSID",
																																------------------------------
																																ROW_NUMBER () OVER () AS "OrderSequence"
																															FROM
																																(
																																SELECT
																																	UNNEST (''' || varArraySysPID::varchar || '''::bigint[]) AS "RecordPID",
																																	UNNEST (''' || varArraySysSID::varchar || '''::bigint[]) AS "RecordSID"
																																) AS "SubSQL"
																															) AS "SubSQL2"
																																ON
																																	"SubSQL"."OrderSequence" = "SubSQL2"."OrderSequence"
																												) AS "SubSQL"
																											) AS "SubSQL"
																										) AS "SubSQL"
																									) AS "SubSQL"
																								) AS "SubSQL"
																							) AS "SubSQL"
																						) AS "SubSQL"
																					) AS "SubSQL"
																				) AS "SubSQL"
																			) AS "SubSQL"
																		) AS "SubSQL"
																	-----[ MAIN DATA ]-----( START )-----
																	) AS "SubSQL"
																) AS "SubSQL"
															WHERE
																"SubSQL"."OrderSequenceExpansion2" = 1
															) AS "SubSQL"
														) AS "SubSQL"
													) AS "SubSQL"
												) AS "SubSQL"
											) AS "SubSQL"
										) AS "SubSQL"
									WHERE
										"SubSQL"."FilterSequence" = 1
									) AS "SubSQL"
								) AS "SubSQL"
							LIMIT 1
							) AS "SubSQL"
						';

					--RAISE NOTICE '%', varSQL;
					EXECUTE varSQL INTO varSQL;
					--RAISE NOTICE 'varSQL : %', varSQL;
					IF (varSQL IS NOT NULL) THEN
						EXECUTE varSQL;
					END IF;

				---> Initializing : varReturn
					IF (varArraySysPID::varchar = '{NULL}') THEN
						varArraySysPID := '{}'::bigint[];
					END IF;
				
					varReturn :=
						JSON_BUILD_OBJECT (
							'status', 'Success',
							'executionTime', (CLOCK_TIMESTAMP() - varSignExecutionTime),
							'impactedRecords',
								JSON_BUILD_OBJECT (
									'dataCount', CARDINALITY (varArraySysPID),
									'PIDList', varArraySysPID
									),
							'additionalData',
								(
								CASE
									WHEN (varJSONData_BusDoc IS NOT NULL) THEN
										JSON_BUILD_OBJECT (
											'businessDocument', varJSONData_BusDoc
											)
									ELSE
										NULL								
								END
								)
							);
					--RAISE NOTICE '%', varReturn;

			-----[ MAIN DATA PROCESSING ]---------------------------------------------(  END  )-----

			-----[ AFTERWARDS ADDITIONAL DATA PROCESSING ]----------------------------( START )-----
			-----[ AFTERWARDS ADDITIONAL DATA PROCESSING ]----------------------------(  END  )-----

		ELSE
			varReturn :=
				JSON_BUILD_OBJECT (
					'status', 'Success',
					'executionTime', (CLOCK_TIMESTAMP() - varSignExecutionTime),
					'impactedRecords',
						JSON_BUILD_OBJECT (
							'dataCount', 0,
							'PIDList', NULL
							),
					'additionalData', NULL
					);
		END IF;

	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----
		RETURN
			varReturn;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		EXCEPTION
			WHEN OTHERS THEN
				RETURN
					JSON_BUILD_OBJECT (
						'status', 'Failed',
						'executionTime', (CLOCK_TIMESTAMP() - varSignExecutionTime),
						'impactedRecords',
							JSON_BUILD_OBJECT (
								'dataCount', NULL,
								'PIDList', NULL
								),
						'additionalData', NULL
						);

END;
$_$;


ALTER FUNCTION "SchSystem"."FuncSys_General_SetBulkData"(json, json, json) OWNER TO "SysAdmin";

--
-- TOC entry 311 (class 1255 OID 4967701)
-- Name: FuncSys_General_SetSequence(character varying, character varying, bigint); Type: FUNCTION; Schema: SchSystem; Owner: SysEngine
--

CREATE FUNCTION "SchSystem"."FuncSys_General_SetSequence"(character varying, character varying, bigint) RETURNS void
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama               : "SchSysConfig"."FuncSys_General_SetSequence"
▪ Versi              : 1.00.0001
▪ Tanggal            : 2021-07-27
▪ Input              : varSchemaName (varchar)
                       varTableName (varchar)
▪ Output             : void
▪ Keterkaitan Fungsi : -
▪ Deskripsi          : Fungsi ini digunakan untuk menginisialisasi ulang sequence yang terkait 
					   dengan Skema (varSchemaName) dan Table (varTableName) tertentu kembali
                       keangka tertentu (varSequenceNumber)
▪ Copyright          : Zheta © 2018 - 2021
----------------------------------------------------------------------------------------------------*/

DECLARE
   varSchemaName		ALIAS FOR $1;
   varTableName			ALIAS FOR $2;
   varSequenceNumber	ALIAS FOR $3;
   varSQL				varchar;
   varSequenceName		varchar;

BEGIN
	IF ((LENGTH(varTableName) >= 13) AND (SUBSTR(varTableName, 1, 13) = 'TblRotateLog_'))  THEN
		varSequenceName :=  varTableName || '_Sys_RPK_seq';
	ELSE
		varSQL :='
			SELECT
				SUBSTRING("SubSQL"."SequenceField", (10 + LENGTH(''' || varSchemaName || ''') + 4), (LENGTH("SubSQL"."SequenceField") - LENGTH(''' || varSchemaName || ''') - 13 - 13))
			FROM
				(
				SELECT 
					column_default AS "SequenceField"
				FROM
					information_schema.columns 
				WHERE 
					table_schema LIKE ''' || varSchemaName || '''
					AND
					table_name LIKE ''' || varTableName || '''
					AND
					column_default LIKE ''nextval(%''
					AND
					column_default LIKE ''%::regclass)''
				) AS "SubSQL"
			';
		EXECUTE varSQL INTO varSequenceName;
	END IF;

   ---> Set Sequence
	varSQL :='
		ALTER SEQUENCE 
			"' || varSchemaName || '"."' || varSequenceName || '"
		RESTART WITH ' || varSequenceNumber;
	EXECUTE varSQL;
END;
$_$;


ALTER FUNCTION "SchSystem"."FuncSys_General_SetSequence"(character varying, character varying, bigint) OWNER TO "SysEngine";

--
-- TOC entry 296 (class 1255 OID 4967702)
-- Name: FuncSys_General_StrSQLBuilder_FilterAndSort(json, json, json, json); Type: FUNCTION; Schema: SchSystem; Owner: SysAdmin
--

CREATE FUNCTION "SchSystem"."FuncSys_General_StrSQLBuilder_FilterAndSort"(json, json, json DEFAULT NULL::json, json DEFAULT NULL::json) RETURNS json
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchSystem"."FuncSys_General_StrSQLBuilder_FilterAndSort"
▪ Versi               :	1.02.0002
▪ Tanggal
     ► Pemutakhiran   :	2026-07-24
     ► Pembuatan      :	2025-10-22
▪ Input               :	• varJSONFilter (json - Mandatory)
						• varJSONSort (json - Mandatory)
						------------------------------
						• varJSONCoreFields (json - Optional)
						• varJSONAllFields (json - Optional)
						------------------------------
						------------------------------
▪ Output              :	varReturn (record)
▪ Keterkaitan Fungsi  : -
▪ Deskripsi           :	• Mendapatkan String SQL untuk Filtering dan Sorting.
						• Secara global string Query yang terlibat dalam proses akan digenerate
						  pada 'filterString' dan 'sortString' varReturn.
						• varJSONCoreFields didefinisikan untuk menentukan Field-Field Utama yang
						  berada dalam Query Utama (Core) pada MAIN PROCESS DATA. Bila didefiniskan
						  maka 'filterString_CoreFields' dan 'sortString_CoreFields' pada varReturn
						  akan didefiniskan. Dan secara otomatis akan mengurangi definisi yang
						  terbentuk pada 'filterString_NonCoreFields' dan 'sortString_NonCoreFields'.
						• Bila varJSONCoreFields tidak didefinisikan, maka 'filterString_CoreFields'
						  dan 'sortString_CoreFields' pada varReturn akan bernilai NULL. Sehingga
						  'filterString_NonCoreFields' dan 'sortString_NonCoreFields' pada varReturn
						  akan bernilai sama dengan 'filterString' dan 'sortString'.
					  	• varJSONAllFields didefinisikan untuk menjaga agar nama-nama field yang
						  terlibat dalam proses Filtering dan Sorting tetap konsisten. Bila ada
						  Klausa yang melenceng dari data varJSONAllFields maka akan diabaikan dan
						  dibuang dari proses.
						• Secara sederhana bisa diilustrasikan sebagai berikut :
							- 'filterString' = 'filterString_CoreFields' + 'filterString_NonCoreFields'
							- 'sortString' = 'sortString_CoreFields' + 'sortString_NonCoreFields'
▪ Copyright           :	Zheta © 2025 - 2026

----[ SQL Example(s) ]------------------------------------------------------------------------------

▪ ---> Without CoreField
	SELECT 
		"SchSystem"."FuncSys_General_StrSQLBuilder_FilterAndSort"(
			JSON_BUILD_ARRAY (
				JSON_BUILD_ARRAY ('Name', 'varchar', 'ILIKE', 'Wisnu')
				--JSON_BUILD_ARRAY ('Name', 'varchar', '=', 'Wisnu')
				--JSON_BUILD_ARRAY ('OrderSequence', 'bigint', '=', '1')
				--JSON_BUILD_ARRAY ('OrderSequence', 'bigint', 'IS', 'NULL')
				--JSON_BUILD_ARRAY ('FetchDateTimeTZ', 'timestamptz', '=', '2025-01-01')
				),
			JSON_BUILD_ARRAY (
				JSON_BUILD_ARRAY ('Name', 'ASC')
				)
			------------------------------
			------------------------------
			);

▪ ---> With CoreField
	SELECT 
		"SchSystem"."FuncSys_General_StrSQLBuilder_FilterAndSort"(
			JSON_BUILD_ARRAY (
				JSON_BUILD_ARRAY ('Name', 'varchar', 'ILIKE', 'Wisnu')
				--JSON_BUILD_ARRAY ('Name', 'varchar', '=', 'Wisnu')
				--JSON_BUILD_ARRAY ('OrderSequence', 'bigint', '=', '1')
				--JSON_BUILD_ARRAY ('OrderSequence', 'bigint', 'IS', 'NULL')
				--JSON_BUILD_ARRAY ('FetchDateTimeTZ', 'timestamptz', '=', '2025-01-01')
				),
			JSON_BUILD_ARRAY (
				JSON_BUILD_ARRAY ('Name', 'ASC')
				),
			------------------------------
			JSON_BUILD_ARRAY (
				'Name'
				)
			------------------------------
			);

▪ ---> With CoreField and AllField
	SELECT
		"SchSystem"."FuncSys_General_StrSQLBuilder_FilterAndSort"(
			JSON_BUILD_ARRAY (
				JSON_BUILD_ARRAY ('Name', 'varchar', 'ILIKE', 'Wisnu')
				--JSON_BUILD_ARRAY ('Name', 'varchar', '=', 'Wisnu')
				--JSON_BUILD_ARRAY ('OrderSequence', 'bigint', '=', '1')
				--JSON_BUILD_ARRAY ('OrderSequence', 'bigint', 'IS', 'NULL')
				--JSON_BUILD_ARRAY ('FetchDateTimeTZ', 'timestamptz', '=', '2025-01-01')
				),
			JSON_BUILD_ARRAY (
				JSON_BUILD_ARRAY ('Name', 'ASC')
				),
			------------------------------
			JSON_BUILD_ARRAY (
				'Name'
				),
			JSON_BUILD_ARRAY (
				'Name'
				)
			------------------------------
			);

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varJSONFilter											ALIAS FOR $1;
			varJSONSort												ALIAS FOR $2;
			------------------------------

		---{ Optional }-------------------
			varJSONCoreFields										ALIAS FOR $3;
			varJSONAllFields										ALIAS FOR $4;

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----
			varReturn												json;

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

			varStr_Filter											varchar;
			varStr_Sort												varchar;

			varStr_Filter_CoreFields								varchar;
			varStr_Sort_CoreFields									varchar;

			varStr_Filter_NonCoreFields								varchar;
			varStr_Sort_NonCoreFields								varchar;

			varJSON_Filter											json;
			varJSON_Sort											json;

			varJSON_Filter_CoreFields								json;
			varJSON_Sort_CoreFields									json;

			varJSON_Filter_NonCoreFields							json;
			varJSON_Sort_NonCoreFields								json;


		---{ Additional }-----------------

BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------( START )-----
			IF (varSignEligibleToProcess IS FALSE) THEN
				varSignEligibleToProcess := TRUE;
			END IF;
		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------(  END  )-----

		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------( START )-----
			IF (varSignEligibleToProcess IS TRUE) THEN
				---> Reinitializing : varJSONCoreFields
					varJSONCoreFields :=
						COALESCE (
							varJSONCoreFields,
							'[]'::json
							);
			END IF;
		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------(  END  )-----

	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			-----[ MAIN DATA PROCESSING ]---------------------------------------------( START )-----
				---> Initializing : varStr_Filter, varJSON_Filter, varStr_Filter_CoreFields, varJSON_Filter_CoreFields, varStr_Filter_NonCoreFields, varJSON_Filter_NonCoreFields
					IF ((varJSONFilter::json IS NOT NULL) AND (varJSONFilter::varchar != '[]')) THEN
						IF (JSON_ARRAY_LENGTH (varJSONFilter::json) > 0) THEN
							---> Initializing : varStr_Filter
								varStr_Filter :=
									(
									SELECT
										(
										'WHERE ' ||
										STRING_AGG (
											CASE
												WHEN (
														(
														varJSONAllFields IS NULL
														)
													OR
														(
														varJSONAllFields IS NOT NULL
														AND
														(varJSONAllFields::json::jsonb @> ('"' || ("SubSQL"."JSONData"->>0)::varchar || '"')::jsonb IS TRUE)
														)
													) THEN
														(
															(
															'"' ||
															("SubSQL"."JSONData"->>0)::varchar ||
															'"' ||
															(
															CASE
																WHEN (("SubSQL"."JSONData"->>2)::varchar ILIKE '%LIKE') THEN
																	'::varchar '
																ELSE
																	('::' || ("SubSQL"."JSONData"->>1)::varchar || ' ')
															END
															)
															)
															||
															(
																("SubSQL"."JSONData"->>2)::varchar ||
																' '
															) 
															||											
															(
															CASE
																WHEN (("SubSQL"."JSONData"->>2)::varchar ILIKE '%LIKE') THEN
																	'''%'
																WHEN (("SubSQL"."JSONData"->>2)::varchar ILIKE '@>') THEN
																	''''
																WHEN (
																	(("SubSQL"."JSONData"->>1)::varchar ILIKE '%CHAR%') OR
																	(("SubSQL"."JSONData"->>1)::varchar ILIKE '%TIMESTAMP%') OR
																	(("SubSQL"."JSONData"->>1)::varchar ILIKE '%DATE%')
																	) THEN
																	''''
																ELSE
																	''
															END
															) 
															||
																									
															("SubSQL"."JSONData"->>3)::varchar ||
															
															(
															CASE
																WHEN (("SubSQL"."JSONData"->>2)::varchar ILIKE '%LIKE') THEN
																	'%''::varchar'
																WHEN (("SubSQL"."JSONData"->>2)::varchar ILIKE '@>') THEN
																	'''::' || ("SubSQL"."JSONData"->>1)::varchar
																WHEN (
																	(("SubSQL"."JSONData"->>1)::varchar ILIKE '%CHAR%') OR
																	(("SubSQL"."JSONData"->>1)::varchar ILIKE '%TIMESTAMP%') OR
																	(("SubSQL"."JSONData"->>1)::varchar ILIKE '%DATE%')
																	) THEN
																	'''::' || ("SubSQL"."JSONData"->>1)::varchar
																ELSE
																	''
															END
															)
														)
												ELSE
													NULL
											END,
											' AND '
											) OVER ()
										)
									FROM
										(
										SELECT
											JSON_ARRAY_ELEMENTS (
												varJSONFilter::json
												) AS "JSONData"
										) AS "SubSQL"
									LIMIT 1
									);
								--RAISE NOTICE 'varStr_Filter : %', varStr_Filter;

							---> Initializing :  varJSON_Filter
								varJSON_Filter :=
									(
									SELECT
										'['
										||
										STRING_AGG (
											CASE
												WHEN (
														(
														varJSONAllFields IS NULL
														)
													OR
														(
														varJSONAllFields IS NOT NULL
														AND
														(varJSONAllFields::json::jsonb @> ('"' || ("SubSQL"."JSONData"->>0)::varchar || '"')::jsonb IS TRUE)
														)
													) THEN
														"SubSQL"."JSONData"::varchar
												ELSE
													NULL
											END,
											', '
											) OVER ()
										||
										']'
									FROM
										(
										SELECT
											JSON_ARRAY_ELEMENTS (
												varJSONFilter::json
												) AS "JSONData"
										) AS "SubSQL"
									LIMIT 1
									)::json;
								--RAISE NOTICE '%', varJSON_Filter;

							---> Initializing : varStr_Filter_CoreFields
								varStr_Filter_CoreFields :=
									(
									SELECT
										(
										'WHERE ' ||
										STRING_AGG (
											CASE
												WHEN (
													(varJSONCoreFields::json::jsonb @> ('"' || ("SubSQL"."JSONData"->>0)::varchar || '"')::jsonb IS TRUE)
													--AND
													--	(
													--		(
													--		varJSONAllFields IS NULL
													--		)
													--	OR
													--		(
													--		varJSONAllFields IS NOT NULL
													--		AND
													--		(varJSONAllFields::json::jsonb @> ('"' || ("SubSQL"."JSONData"->>0)::varchar || '"')::jsonb IS TRUE)
													--		)
													--	)
													) THEN
														(
															(
															'"' ||
															("SubSQL"."JSONData"->>0)::varchar ||
															'"' ||
															(
															CASE
																WHEN (("SubSQL"."JSONData"->>2)::varchar ILIKE '%LIKE') THEN
																	'::varchar '
																ELSE
																	('::' || ("SubSQL"."JSONData"->>1)::varchar || ' ')
															END
															)
															)
															||
															(
																("SubSQL"."JSONData"->>2)::varchar ||
																' '
															) 
															||											
															(
															CASE
																WHEN (("SubSQL"."JSONData"->>2)::varchar ILIKE '%LIKE') THEN
																	'''%'
																WHEN (("SubSQL"."JSONData"->>2)::varchar ILIKE '@>') THEN
																	''''
																WHEN (
																	(("SubSQL"."JSONData"->>1)::varchar ILIKE '%CHAR%') OR
																	(("SubSQL"."JSONData"->>1)::varchar ILIKE '%TIMESTAMP%') OR
																	(("SubSQL"."JSONData"->>1)::varchar ILIKE '%DATE%')
																	) THEN
																	''''
																ELSE
																	''
															END
															) 
															||
																									
															("SubSQL"."JSONData"->>3)::varchar ||
															
															(
															CASE
																WHEN (("SubSQL"."JSONData"->>2)::varchar ILIKE '%LIKE') THEN
																	'%''::varchar'
																WHEN (("SubSQL"."JSONData"->>2)::varchar ILIKE '@>') THEN
																	'''::' || ("SubSQL"."JSONData"->>1)::varchar
																WHEN (
																	(("SubSQL"."JSONData"->>1)::varchar ILIKE '%CHAR%') OR
																	(("SubSQL"."JSONData"->>1)::varchar ILIKE '%TIMESTAMP%') OR
																	(("SubSQL"."JSONData"->>1)::varchar ILIKE '%DATE%')
																	) THEN
																	'''::' || ("SubSQL"."JSONData"->>1)::varchar
																ELSE
																	''
															END
															)
														)
												ELSE
													NULL
											END,
											' AND '
											) OVER ()
										)
									FROM
										(
										SELECT
											JSON_ARRAY_ELEMENTS (
												varJSONFilter::json
												) AS "JSONData"
										) AS "SubSQL"
									LIMIT 1
									);
								--RAISE NOTICE 'varStr_Filter_CoreFields : %', varStr_Filter_CoreFields;

							---> Initializing :  varJSON_Filter_CoreFields
								varJSON_Filter_CoreFields :=
									(
									SELECT
										'['
										||
										STRING_AGG (
											CASE
												WHEN (
													(varJSONCoreFields::json::jsonb @> ('"' || ("SubSQL"."JSONData"->>0)::varchar || '"')::jsonb IS TRUE)
													) THEN
														"SubSQL"."JSONData"::varchar
												ELSE
													NULL
											END,
											', '
											) OVER ()
										||
										']'
									FROM
										(
										SELECT
											JSON_ARRAY_ELEMENTS (
												varJSONFilter::json
												) AS "JSONData"
										) AS "SubSQL"
									LIMIT 1
									)::json;
								--RAISE NOTICE '%', varJSON_Filter_CoreFields;

							---> Initializing : varStr_Filter_NonCoreFields
								varStr_Filter_NonCoreFields :=
									(
									SELECT
										(
										'WHERE ' ||
										STRING_AGG (
											CASE
												WHEN (
													(varJSONCoreFields::json::jsonb @> ('"' || ("SubSQL"."JSONData"->>0)::varchar || '"')::jsonb IS FALSE)
													AND
														(
															(
															varJSONAllFields IS NULL
															)
														OR
															(
															varJSONAllFields IS NOT NULL
															AND
															(varJSONAllFields::json::jsonb @> ('"' || ("SubSQL"."JSONData"->>0)::varchar || '"')::jsonb IS TRUE)
															)
														)
													) THEN
														(
															(
															'"' ||
															("SubSQL"."JSONData"->>0)::varchar ||
															'"' ||
															(
															CASE
																WHEN (("SubSQL"."JSONData"->>2)::varchar ILIKE '%LIKE') THEN
																	'::varchar '
																ELSE
																	('::' || ("SubSQL"."JSONData"->>1)::varchar || ' ')
															END
															)
															)
															||
															(
																("SubSQL"."JSONData"->>2)::varchar ||
																' '
															) 
															||											
															(
															CASE
																WHEN (("SubSQL"."JSONData"->>2)::varchar ILIKE '%LIKE') THEN
																	'''%'
																WHEN (("SubSQL"."JSONData"->>2)::varchar ILIKE '@>') THEN
																	''''
																WHEN (
																	(("SubSQL"."JSONData"->>1)::varchar ILIKE '%CHAR%') OR
																	(("SubSQL"."JSONData"->>1)::varchar ILIKE '%TIMESTAMP%') OR
																	(("SubSQL"."JSONData"->>1)::varchar ILIKE '%DATE%')
																	) THEN
																	''''
																ELSE
																	''
															END
															) 
															||
																									
															("SubSQL"."JSONData"->>3)::varchar ||
															
															(
															CASE
																WHEN (("SubSQL"."JSONData"->>2)::varchar ILIKE '%LIKE') THEN
																	'%''::varchar'
																WHEN (("SubSQL"."JSONData"->>2)::varchar ILIKE '@>') THEN
																	'''::' || ("SubSQL"."JSONData"->>1)::varchar
																WHEN (
																	(("SubSQL"."JSONData"->>1)::varchar ILIKE '%CHAR%') OR
																	(("SubSQL"."JSONData"->>1)::varchar ILIKE '%TIMESTAMP%') OR
																	(("SubSQL"."JSONData"->>1)::varchar ILIKE '%DATE%')
																	) THEN
																	'''::' || ("SubSQL"."JSONData"->>1)::varchar
																ELSE
																	''
															END
															)
														)
												ELSE
													NULL
											END,
											' AND '
											) OVER ()
										)
									FROM
										(
										SELECT
											JSON_ARRAY_ELEMENTS (
												varJSONFilter::json
												) AS "JSONData"
										) AS "SubSQL"
									LIMIT 1
									);
								--RAISE NOTICE 'varStr_Filter_NonCoreFields : %', varStr_Filter_NonCoreFields;

							---> Initializing :  varJSON_Filter_NonCoreFields
								varJSON_Filter_NonCoreFields :=
									(
									SELECT
										'['
										||
										STRING_AGG (
											CASE
												WHEN (
													(varJSONCoreFields::json::jsonb @> ('"' || ("SubSQL"."JSONData"->>0)::varchar || '"')::jsonb IS FALSE)
													AND
														(
															(
															varJSONAllFields IS NULL
															)
														OR
															(
															varJSONAllFields IS NOT NULL
															AND
															(varJSONAllFields::json::jsonb @> ('"' || ("SubSQL"."JSONData"->>0)::varchar || '"')::jsonb IS TRUE)
															)
														)
													) THEN
														"SubSQL"."JSONData"::varchar
												ELSE
													NULL
											END,
											', '
											) OVER ()
										||
										']'
									FROM
										(
										SELECT
											JSON_ARRAY_ELEMENTS (
												varJSONFilter::json
												) AS "JSONData"
										) AS "SubSQL"
									LIMIT 1
									)::json;
								--RAISE NOTICE '%', varJSON_Filter_NonCoreFields;
						END IF;
					END IF;

				---> Initializing : varStr_Sort, varJSON_Sort, varStr_Sort_CoreFields, varJSON_Sort_CoreFields, varStr_Sort_NonCoreFields, varJSON_Sort_NonCoreFields
					IF ((varJSONSort::json IS NOT NULL) AND (varJSONSort::varchar != '[]')) THEN
						IF (JSON_ARRAY_LENGTH (varJSONSort::json) > 0) THEN
							---> Initializing : varStr_Sort
								varStr_Sort :=
									(
									SELECT
										(
										'ORDER BY ' ||
										STRING_AGG (
											CASE
												WHEN (
														(
														varJSONAllFields IS NULL
														)
													OR
														(
														varJSONAllFields IS NOT NULL
														AND
														(varJSONAllFields::json::jsonb @> ('"' || ("SubSQL"."JSONData"->>0)::varchar || '"')::jsonb IS TRUE)
														)
													) THEN
														(
														'"' ||
														("SubSQL"."JSONData"->>0)::varchar ||
														'" ' ||
														("SubSQL"."JSONData"->>1)::varchar
														)
												ELSE
													NULL
											END,
											', '
											) OVER ()
										)
									FROM
										(
										SELECT
											JSON_ARRAY_ELEMENTS (
												varJSONSort::json
												) AS "JSONData"
										) AS "SubSQL"
									LIMIT 1
									);
								--RAISE NOTICE 'varStr_Sort : %', varStr_Sort;

							---> Initializing :  varJSON_Sort
								varJSON_Sort :=
									(
									SELECT
										'['
										||
										STRING_AGG (
											CASE
												WHEN (
														(
														varJSONAllFields IS NULL
														)
													OR
														(
														varJSONAllFields IS NOT NULL
														AND
														(varJSONAllFields::json::jsonb @> ('"' || ("SubSQL"."JSONData"->>0)::varchar || '"')::jsonb IS TRUE)
														)
													) THEN
														"SubSQL"."JSONData"::varchar
												ELSE
													NULL
											END,
											', '
											) OVER ()
										||
										']'
									FROM
										(
										SELECT
											JSON_ARRAY_ELEMENTS (
												varJSONSort::json
												) AS "JSONData"
										) AS "SubSQL"
									LIMIT 1
									)::json;
								--RAISE NOTICE '%', varJSON_Sort;

							---> Initializing : varStr_Sort_CoreFields
								varStr_Sort_CoreFields :=
									(
									SELECT
										(
										'ORDER BY ' ||
										STRING_AGG (
											CASE
												WHEN (
													(varJSONCoreFields::json::jsonb @> ('"' || ("SubSQL"."JSONData"->>0)::varchar || '"')::jsonb IS TRUE)
													--AND
													--	(
													--		(
													--		varJSONAllFields IS NULL
													--		)
													--	OR
													--		(
													--		varJSONAllFields IS NOT NULL
													--		AND
													--		(varJSONAllFields::json::jsonb @> ('"' || ("SubSQL"."JSONData"->>0)::varchar || '"')::jsonb IS TRUE)
													--		)
													--	)
													) THEN
														(
														'"' ||
														("SubSQL"."JSONData"->>0)::varchar ||
														'" ' ||
														("SubSQL"."JSONData"->>1)::varchar
														)
												ELSE
													NULL
											END,
											', '
											) OVER ()
										)
									FROM
										(
										SELECT
											JSON_ARRAY_ELEMENTS (
												varJSONSort::json
												) AS "JSONData"
										) AS "SubSQL"
									LIMIT 1
									);
								--RAISE NOTICE 'varStr_Sort_CoreFields : %', varStr_Sort_CoreFields;

							---> Initializing :  varJSON_Sort_CoreFields
								varJSON_Sort_CoreFields :=
									(
									SELECT
										'['
										||
										STRING_AGG (
											CASE
												WHEN (
													(varJSONCoreFields::json::jsonb @> ('"' || ("SubSQL"."JSONData"->>0)::varchar || '"')::jsonb IS TRUE)
													) THEN
														"SubSQL"."JSONData"::varchar
												ELSE
													NULL
											END,
											', '
											) OVER ()
										||
										']'
									FROM
										(
										SELECT
											JSON_ARRAY_ELEMENTS (
												varJSONSort::json
												) AS "JSONData"
										) AS "SubSQL"
									LIMIT 1
									)::json;
								--RAISE NOTICE '%', varJSON_Sort_CoreFields;

							---> Initializing : varStr_Sort_NonCoreFields
								varStr_Sort_NonCoreFields :=
									(
									SELECT
										(
										'ORDER BY ' ||
										STRING_AGG (
											CASE
												WHEN (
													(varJSONCoreFields::json::jsonb @> ('"' || ("SubSQL"."JSONData"->>0)::varchar || '"')::jsonb IS FALSE)
													AND
														(
															(
															varJSONAllFields IS NULL
															)
														OR
															(
															varJSONAllFields IS NOT NULL
															AND
															(varJSONAllFields::json::jsonb @> ('"' || ("SubSQL"."JSONData"->>0)::varchar || '"')::jsonb IS TRUE)
															)
														)
													) THEN
														(
														'"' ||
														("SubSQL"."JSONData"->>0)::varchar ||
														'" ' ||
														("SubSQL"."JSONData"->>1)::varchar
														)
												ELSE
													NULL
											END,
											', '
											) OVER ()
										)
									FROM
										(
										SELECT
											JSON_ARRAY_ELEMENTS (
												varJSONSort::json
												) AS "JSONData"
										) AS "SubSQL"
									LIMIT 1
									);
								--RAISE NOTICE 'varStr_Sort_NonCoreFields : %', varStr_Sort_NonCoreFields;

							---> Initializing :  varJSON_Sort_NonCoreFields
								varJSON_Sort_NonCoreFields :=
									(
									SELECT
										'['
										||
										STRING_AGG (
											CASE
												WHEN (
													(varJSONCoreFields::json::jsonb @> ('"' || ("SubSQL"."JSONData"->>0)::varchar || '"')::jsonb IS FALSE)
													AND
														(
															(
															varJSONAllFields IS NULL
															)
														OR
															(
															varJSONAllFields IS NOT NULL
															AND
															(varJSONAllFields::json::jsonb @> ('"' || ("SubSQL"."JSONData"->>0)::varchar || '"')::jsonb IS TRUE)
															)
														)
													) THEN
														"SubSQL"."JSONData"::varchar
												ELSE
													NULL
											END,
											', '
											) OVER ()
										||
										']'
									FROM
										(
										SELECT
											JSON_ARRAY_ELEMENTS (
												varJSONSort::json
												) AS "JSONData"
										) AS "SubSQL"
									LIMIT 1
									)::json;
								--RAISE NOTICE '%', varJSON_Sort_NonCoreFields;
						END IF;
					END IF;

				---> Initializing : varReturn
					varReturn :=
						JSON_BUILD_OBJECT (
							'filterJSON', varJSON_Filter,
							'filterString', varStr_Filter,
							------------------------------
							'sortJSON', varJSON_Sort,
							'sortString', varStr_Sort,
							------------------------------
							'filterJSON_CoreFields', varJSON_Filter_CoreFields,
							'filterString_CoreFields', varStr_Filter_CoreFields,
							------------------------------
							'sortJSON_CoreFields', varJSON_Sort_CoreFields,
							'sortString_CoreFields', varStr_Sort_CoreFields,
							------------------------------
							'filterJSON_NonCoreFields', varJSON_Filter_NonCoreFields,
							'filterString_NonCoreFields', varStr_Filter_NonCoreFields,
							------------------------------
							'sortJSON_NonCoreFields', varJSON_Sort_NonCoreFields,
							'sortString_NonCoreFields', varStr_Sort_NonCoreFields
							);

			-----[ MAIN DATA PROCESSING ]---------------------------------------------(  END  )-----
		END IF;

	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			---> Send Data Output
				RETURN
					varReturn;
		END IF;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		EXCEPTION
			WHEN OTHERS THEN
				NULL;

END;
$_$;


ALTER FUNCTION "SchSystem"."FuncSys_General_StrSQLBuilder_FilterAndSort"(json, json, json, json) OWNER TO "SysAdmin";

--
-- TOC entry 233 (class 1255 OID 4967705)
-- Name: FuncSys_General_StrSQLFlattenToSingleRecord(json, character varying); Type: FUNCTION; Schema: SchSystem; Owner: SysAdmin
--

CREATE FUNCTION "SchSystem"."FuncSys_General_StrSQLFlattenToSingleRecord"(json, character varying) RETURNS character varying
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchSystem"."FuncSys_General_StrSQLFlattenToSingleRecord"
▪ Versi               :	1.00.0001
▪ Tanggal
     ► Pemutakhiran   :	2026-09-11
     ► Pembuatan      :	2026-09-11
▪ Input               :	• varJSONStructure (json - Mandatory)
						• varSQL (varchar - Mandatory)
						------------------------------
						------------------------------
▪ Output              :	varReturn (varchar)
▪ Keterkaitan Fungsi  : -
▪ Deskripsi           :	• Melakukan Flattening output Recordset dari String SQL kedalam record
					 	  tunggal yang hanya terdiri dari beberapa field Array.
					   	• Apabila ditemukan Type Data yang berbentuk Array maka akan dicasting
						  sebagai varchar
▪ Copyright           :	Zheta © 2026

----[ SQL Example(s) ]------------------------------------------------------------------------------

▪ --->
	SELECT
		"SchSystem"."FuncSys_General_StrSQLFlattenToSingleRecord"(
			(
			JSON_BUILD_OBJECT (
				'sortFieldName', 'SubSQL.OrderSequence',
				'structures',
					JSON_BUILD_ARRAY (
						JSON_BUILD_OBJECT (
							'name', 'x',
							'dataType', 'bigint'
							),
						JSON_BUILD_OBJECT (
							'name', 'y',
							'dataType', 'numeric(20,2)'
							)
						)
				)
			),
			'
			SELECT
				"SubSQL"."x",
				"SubSQL"."y",
				"SubSQL"."OrderSequence"
			FROM
				(
				SELECT
					1 AS "x",
					200.02 AS "y",
					1 AS "OrderSequence"
				UNION ALL
				SELECT
					2 AS "x",
					400.01 AS "y",
					2 AS "OrderSequence"
				) AS "SubSQL"
			'
			);

▪ --->
	SELECT
		"SchSystem"."FuncSys_General_StrSQLFlattenToSingleRecord"(
			(
			JSON_BUILD_OBJECT (
				'sortFieldName', 'SubSQL.OrderSequence',
				'structures',
					JSON_BUILD_ARRAY (
						JSON_BUILD_OBJECT (
							'name', 'SubSQL.x',
							'dataType', 'bigint'
							),
						JSON_BUILD_OBJECT (
							'name', 'SubSQL.y',
							'dataType', 'numeric(20,2)'
							)
						)
				)
			),
			'
			SELECT
				"SubSQL"."x",
				"SubSQL"."y",
				"SubSQL"."OrderSequence"
			FROM
				(
				SELECT
					1 AS "x",
					200.02 AS "y",
					1 AS "OrderSequence"
				UNION ALL
				SELECT
					2 AS "x",
					400.01 AS "y",
					2 AS "OrderSequence"
				) AS "SubSQL"
			'
			);

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varJSONStructure										ALIAS FOR $1;
			varSQL													ALIAS FOR $2;
			------------------------------

		---{ Optional }-------------------

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----
			varReturn												varchar;

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

		---{ Additional }-----------------

BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------( START )-----
			IF (varSignEligibleToProcess IS FALSE) THEN
				varSignEligibleToProcess := TRUE;
			END IF;
		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------(  END  )-----

		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------( START )-----
			IF (varSignEligibleToProcess IS TRUE) THEN
			END IF;
		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------(  END  )-----

	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			-----[ MAIN DATA PROCESSING ]---------------------------------------------( START )-----
			varReturn := (
				SELECT
					CASE
						WHEN ("SubSQL"."OrderSequence" = 1) THEN
							'
							SELECT
								*
							FROM
								(
								SELECT
									'
									||
									STRING_AGG (
										"SubSQL"."StrSQL",
										', '
										) OVER ()
									||
									'
								FROM
									(
									' || varSQL || '
									) AS "SubSQL"
								LIMIT 1
								) AS "SubSQL"
							'
						ELSE
							NULL
					END
				FROM
					(
					SELECT
						(
						'
						CASE
							WHEN (' || "SubSQL"."OrderSequence" || ' = 1) THEN
								(
								''{'' ||
								STRING_AGG (
									COALESCE (
										(''"'' || REPLACE (REPLACE (' || "SubSQL"."InputFieldName" || '::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''),
										''NULL''
										),
									'',''
									) OVER () ||
								''}''
								)
							ELSE
								NULL
						END::' || "SubSQL"."OutputFieldArrayType" || ' AS ' || "SubSQL"."OutputFieldName" || '
						'
						)::varchar AS "StrSQL",
						ROW_NUMBER () OVER () AS "OrderSequence"
					FROM
						(
						SELECT
							"SubSQL"."OrderSequence",
							"SubSQL"."InputFieldName",
							"SubSQL"."OutputFieldName",
							"SubSQL"."OutputFieldArrayType",
							(
							'
							CASE
								WHEN (' || "SubSQL"."OrderSequence" || ' = 1) THEN
									(
									''{'' ||
									STRING_AGG (
										COALESCE (
											(''"'' || REPLACE (REPLACE (' || "SubSQL"."InputFieldName" || '::varchar, ''\'', ''\\''), ''"'', ''\"'') || ''"''),
											''NULL''
											),
										'',''
										) OVER () ||
									''}''
									)
								ELSE
									NULL
							END::' || "SubSQL"."OutputFieldArrayType" || ' AS ' || "SubSQL"."OutputFieldName" || '
							'
							) AS "StrSQL"
						FROM
							(
							SELECT
								"SubSQL"."OrderSequence",
								('"' || REPLACE (("SubSQL"."JSONData"->>'name'), '.', '"."') || '"') AS "InputFieldName",		
								CASE
									---> Without SubSQL
									WHEN (CARDINALITY((('{"' || REPLACE (("SubSQL"."JSONData"->>'name'), '.', '", "') || '"}')::varchar[])) = 1) THEN
										('"' || REPLACE (("SubSQL"."JSONData"->>'name'), '.', '"."') || 'Array"')
									---> With SubSQL
									ELSE
										('"' || (('{"' || REPLACE (("SubSQL"."JSONData"->>'name'), '.', '", "') || '"}')::varchar[])[2] || 'Array"')
								END AS "OutputFieldName",
								CASE
									WHEN (STRPOS (("SubSQL"."JSONData"->>'dataType'), '[') > 0) THEN
										--(('{"' || REPLACE (("SubSQL"."JSONData"->>'dataType'), '[', '", "') || '"}')::varchar[])[1]
										'varchar[]'
									ELSE
										(("SubSQL"."JSONData"->>'dataType') || '[]')
								END AS "OutputFieldArrayType"
							FROM
								(
								SELECT
									('"' || REPLACE (("SubSQL"."JSONData"->>'sortFieldName'), '.', '"."') || '"')::varchar AS "OrderSequence",
									JSON_ARRAY_ELEMENTS ("SubSQL"."JSONData"->'structures') AS "JSONData"
								FROM
									(
									SELECT
										varJSONStructure AS "JSONData"
									) AS "SubSQL"
								) AS "SubSQL"
							) AS "SubSQL"
						) AS "SubSQL"
					) AS "SubSQL"
				LIMIT 1
				);
			-----[ MAIN DATA PROCESSING ]---------------------------------------------(  END  )-----
		END IF;

	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----
		RETURN
			varReturn;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		--EXCEPTION
		--	WHEN OTHERS THEN
		--		NULL;

END;
$_$;


ALTER FUNCTION "SchSystem"."FuncSys_General_StrSQLFlattenToSingleRecord"(json, character varying) OWNER TO "SysAdmin";

--
-- TOC entry 292 (class 1255 OID 4967708)
-- Name: FuncSys_GetInformation_SessionID(bigint, character varying); Type: FUNCTION; Schema: SchSystem; Owner: SysAdmin
--

CREATE FUNCTION "SchSystem"."FuncSys_GetInformation_SessionID"(bigint, character varying DEFAULT NULL::character varying) RETURNS json
    LANGUAGE plpgsql
    AS $_$
/*----------------------------------------------------------------------------------------------------
▪ Nama                :	"SchSystem"."FuncSys_GetInformation_SessionID"
▪ Versi               :	1.00.0000
▪ Tanggal
     ► Pemutakhiran   :	2026-07-03
     ► Pembuatan      :	2026-07-03
▪ Input               :	• varID (bigint - Mandatory)
						------------------------------
						• varSQLFunctionInitiator (bigint - Optional)
▪ Output              :	varReturn (json)
▪ Keterkaitan Fungsi  :	-
▪ Deskripsi           :	• Mendapatkan Informasi dari Session IS
▪ Copyright           :	Zheta © 2026

----[ Related Database Object(s) ]------------------------------------------------------------------

▪ Tabel               :	• [BE] "SchSysConfig"."TblLog_UserLoginSession"
						• [BE] "SchSysConfig"."TblDBObject_Table"

▪ Fungsi              :	• [BE] "SchSystem"."FuncSys_General_GetEnvironmentParameter"(varchar)
	 					• [BE] "SchSystem"."FuncSys_General_StrSQLExecution"(varchar)

----[ SQL Example(s) ]------------------------------------------------------------------------------

▪ --->
	SELECT
		"SchSystem"."FuncSys_GetInformation_SessionID"(
			6000000001000::bigint
			------------------------------
			);

	SELECT
		"SchSystem"."FuncSys_GetInformation_SessionID"(
			10006000000001000::bigint
			------------------------------
			);

▪ --->
	SELECT
		"SchSystem"."FuncSys_GetInformation_SessionID"(
			10006000000001000::bigint,
			------------------------------
			'Schema.FunctionName'
			);

----------------------------------------------------------------------------------------------------*/

DECLARE
	----[ ⦿ ]--[ Input Variable(s) ]-------------------------------------------------------[ ⦿ ]----
		---{ Mandatory }------------------
			varID													ALIAS FOR $1;
			------------------------------

		---{ Optional }-------------------
			varSQLFunctionInitiator									ALIAS FOR $2;

		---{ Additional }-----------------

	----[ ⦿ ]--[ Output Variable(s) ]-----------------------------------------------------[ ⦿ ]----
			varReturn												json;

	----[ ⦿ ]--[ Intermediate Variable(s) ]-----------------------------------------------[ ⦿ ]----
		---{ Default }--------------------
			varSystemNoticeTag										varchar;
			varSignEligibleToProcess								boolean;

			varSQL													varchar;

BEGIN
	----[ ⦿ ]--[ Data Initializing ]------------------------------------------------------[ ⦿ ]----
		--varSystemNoticeTag := "SchSysAsset"."Func_GetSystemNoticeTag"();
		varSignEligibleToProcess := FALSE;

		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------( START )-----
			IF (varSignEligibleToProcess IS FALSE) THEN
				varSignEligibleToProcess := TRUE;
			END IF;
		-----[ ELIGIBLE PROCESS DETERMINATION ]---------------------------------------(  END  )-----

		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------( START )-----
			IF (varSignEligibleToProcess IS TRUE) THEN
			END IF;
		-----[ VARIABLES INITIALIZATION FOR ELIGIBLE PROCESS ]------------------------(  END  )-----

	----[ ⦿ ]--[ Data Processing ]--------------------------------------------------------[ ⦿ ]----
		IF (varSignEligibleToProcess IS TRUE) THEN
			-----[ MAIN DATA PROCESSING ]---------------------------------------------( START )-----
				---> Initializing : varReturn
					varReturn := (
						SELECT
							"SubSQL"."JSONData"
						FROM
							DBLINK (
								(SELECT "SchSystem"."FuncSys_General_GetEnvironmentParameter"('DBLink.ConnectionString.BackEnd.SysConfig')),
								'
								SELECT
									JSON_BUILD_OBJECT (
										''identifier'',
											JSON_BUILD_OBJECT (
												''APIWebToken'', "APIWebToken",
												''SQLFunctionInitiator'', ' || COALESCE (('''' || varSQLFunctionInitiator::varchar || ''''), 'NULL'::varchar) || '::varchar
											),
										''identities'',
											JSON_BUILD_OBJECT (
												''user_RefID'', "User_RefID",
												''userRole_RefID'', "UserRole_RefID"
												),
										''session'',
											JSON_BUILD_OBJECT (
												''startDateTimeTZ'', "SessionStartDateTimeTZ",
												''finishDateTimeTZ'', "SessionFinishDateTimeTZ",
												''autoStartDateTimeTZ'', "SessionAutoStartDateTimeTZ",
												''autoFinishDateTimeTZ'', "SessionAutoFinishDateTimeTZ"
												)
										) AS "JSONData"
								FROM
									"SchSysConfig"."TblLog_UserLoginSession"
								WHERE
									"Sys_PID" = ' || COALESCE (varID::varchar, 'NULL'::varchar) || '::bigint
									OR
									"Sys_SID" = ' || COALESCE (varID::varchar, 'NULL'::varchar) || '::bigint
								'
								) AS "SubSQL" ("JSONData" json)
						);
			END IF;

	----[ ⦿ ]--[ Data Return ]------------------------------------------------------------[ ⦿ ]----
		---> Send Data Output
			RETURN
				varReturn;

	----[ ⦿ ]--[ Exception Handling ]-----------------------------------------------------[ ⦿ ]----
		EXCEPTION
			WHEN OTHERS THEN
				RETURN NULL;

END;
$_$;


ALTER FUNCTION "SchSystem"."FuncSys_GetInformation_SessionID"(bigint, character varying) OWNER TO "SysAdmin";

--
-- TOC entry 230 (class 1259 OID 4967709)
-- Name: TblCombinedBudgetSectionDetailAbsorption_Sys_RPK_seq; Type: SEQUENCE; Schema: SchBudgeting; Owner: SysEngine
--

CREATE SEQUENCE "SchBudgeting"."TblCombinedBudgetSectionDetailAbsorption_Sys_RPK_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "SchBudgeting"."TblCombinedBudgetSectionDetailAbsorption_Sys_RPK_seq" OWNER TO "SysEngine";

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 231 (class 1259 OID 4967710)
-- Name: TblCombinedBudgetSectionDetailAbsorption; Type: TABLE; Schema: SchBudgeting; Owner: SysAdmin
--

CREATE TABLE "SchBudgeting"."TblCombinedBudgetSectionDetailAbsorption" (
    "Sys_PID" bigint,
    "Sys_SID" bigint,
    "Sys_RPK" bigint DEFAULT nextval('"SchBudgeting"."TblCombinedBudgetSectionDetailAbsorption_Sys_RPK_seq"'::regclass) NOT NULL,
    "Sys_Data_Annotation" character varying(1024),
    "Sys_Data_Entry_LoginSession_RefID" bigint,
    "Sys_Data_Entry_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Edit_LoginSession_RefID" bigint,
    "Sys_Data_Edit_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Delete_LoginSession_RefID" bigint,
    "Sys_Data_Delete_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Hidden_LoginSession_RefID" bigint,
    "Sys_Data_Hidden_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Authentication_LoginSession_RefID" bigint,
    "Sys_Data_Authentication_DateTimeTZ" timestamp with time zone,
    "Sys_Data_Validity_StartDateTimeTZ" timestamp with time zone,
    "Sys_Data_Validity_FinishDateTimeTZ" timestamp with time zone,
    "Sys_Partition_RemovableRecord_Key_RefID" bigint,
    "Sys_Branch_RefID" bigint,
    "Sys_BaseCurrency_RefID" bigint,
    "Sys_DataIntegrityShadow" character varying(32),
    "CombinedBudgetSectionDetail_RefID" bigint,
    "QuantityAbsorption" numeric(20,2),
    "PriceBaseCurrencyAbsorptionValue" numeric(20,2),
    "AbsorptionDetail" json
);


ALTER TABLE "SchBudgeting"."TblCombinedBudgetSectionDetailAbsorption" OWNER TO "SysAdmin";

--
-- TOC entry 3415 (class 1259 OID 4967726)
-- Name: idx0247_000001; Type: INDEX; Schema: SchBudgeting; Owner: SysAdmin
--

CREATE INDEX idx0247_000001 ON "SchBudgeting"."TblCombinedBudgetSectionDetailAbsorption" USING btree ("Sys_PID");


--
-- TOC entry 3416 (class 1259 OID 4967727)
-- Name: idx0247_000002; Type: INDEX; Schema: SchBudgeting; Owner: SysAdmin
--

CREATE INDEX idx0247_000002 ON "SchBudgeting"."TblCombinedBudgetSectionDetailAbsorption" USING btree ("Sys_SID");


--
-- TOC entry 3417 (class 1259 OID 4967728)
-- Name: idx0247_000003; Type: INDEX; Schema: SchBudgeting; Owner: SysAdmin
--

CREATE INDEX idx0247_000003 ON "SchBudgeting"."TblCombinedBudgetSectionDetailAbsorption" USING btree ("Sys_RPK");


--
-- TOC entry 3418 (class 1259 OID 4967729)
-- Name: idx0247_000004; Type: INDEX; Schema: SchBudgeting; Owner: SysAdmin
--

CREATE INDEX idx0247_000004 ON "SchBudgeting"."TblCombinedBudgetSectionDetailAbsorption" USING btree ("Sys_Data_Delete_DateTimeTZ");


--
-- TOC entry 3419 (class 1259 OID 4967730)
-- Name: idx0247_000005; Type: INDEX; Schema: SchBudgeting; Owner: SysAdmin
--

CREATE INDEX idx0247_000005 ON "SchBudgeting"."TblCombinedBudgetSectionDetailAbsorption" USING btree ("Sys_Data_Hidden_DateTimeTZ");


--
-- TOC entry 3420 (class 1259 OID 4967731)
-- Name: idx0247_000006; Type: INDEX; Schema: SchBudgeting; Owner: SysAdmin
--

CREATE INDEX idx0247_000006 ON "SchBudgeting"."TblCombinedBudgetSectionDetailAbsorption" USING btree ("CombinedBudgetSectionDetail_RefID");


--
-- TOC entry 3575 (class 0 OID 0)
-- Dependencies: 10
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


-- Completed on 2026-09-18 19:10:43 WIB

--
-- PostgreSQL database dump complete
--

\unrestrict VrDx2aNMJgoaqrNYR7o1zfKCagq2KXldf3y3nnDfsRweO48g0ddR9yzlMOLjQGP

