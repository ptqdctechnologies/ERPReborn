<script>
    $(document).ready(function() {
        $('.TableProduct').DataTable();
    });
</script>