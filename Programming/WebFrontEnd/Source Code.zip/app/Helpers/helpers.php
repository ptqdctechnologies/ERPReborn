<?php

namespace App\Helpers;

class helpers
{

    // 4B586A
    public function GoToDocumentBGColor()
    {
        return "background-color:red;";
    }
    public function SidebarBGColor()
    {
        return "background-color:yellow;";
    }
}
