<div class="card-body table-responsive p-0">
    <table class="table table-head-fixed text-nowrap table-striped tableArfDetail">
        <thead>
            <tr>
                <th>Action</th>
                <th>Applied</th>
                <th>Trano</th>
                <th>Product Id</th>
                <th>Name Material</th>
                <th>UOM</th>
                <th>Unit Price</th>
                <th>Qty</th>
                <th>Total</th>
                <th>Currency</th>
                <th>Descirption</th>
            </tr>
        </thead>
        <tbody>
            
        </tbody>
    </table>
</div>