<div class="card-body table-responsive p-0" style="height: 250px;">
    <table class="table table-head-fixed text-nowrap table-striped" id="arfTableDisableEnable">
        <thead>
            <tr>
                <th></th>
                <th></th>
                <th>Project</th>
                <th>Site</th>
                <th>Work ID</th>
                <th>Product Id</th>
                <th>Product Name</th>
                <th>Qty</th>
                <th>Uom</th>
                <th>Progress</th>
            </tr>
        </thead>
        <tbody>

        </tbody>
    </table>
</div>