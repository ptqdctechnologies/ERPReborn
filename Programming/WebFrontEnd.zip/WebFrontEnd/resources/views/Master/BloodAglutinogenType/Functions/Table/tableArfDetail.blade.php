<div class="card-body table-responsive p-0">
    <table id="table1" class="table table-head-fixed text-nowrap table-striped" id="arfTableDisableEnable">
        <thead>
            <tr>
                <th>No Trans</th>
                <th>Product Id</th>
                <th>Name Material</th>
                <th>Unit</th>
                <th>Unit Price</th>
                <th>Qty</th>
                <th>Total Price</th>
                <th>Currency</th>
                <th>Descirption</th>
                <th>Available</th>
            </tr>
        </thead>
        <tbody id="tableArfListCart"></tbody>
    </table>
</div>