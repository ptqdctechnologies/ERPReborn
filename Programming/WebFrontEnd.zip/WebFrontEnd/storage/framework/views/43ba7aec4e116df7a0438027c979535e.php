<?php $__env->startSection('main'); ?>
<?php echo $__env->make('Partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('getFunction.getSite', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Documents.Functions.PopUp.SearchCheckDocument', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('toastr', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="content-wrapper">
  <section class="content">
    <div class="container-fluid">
      <div class="row mb-1" style="background-color:#4B586A;">
        <div class="col-sm-6">
          <label style="font-size:15px;position:relative;top:7px;color:white;">Check Document on Process</label>
        </div>
      </div>
      
      <?php echo $__env->make('Documents.Functions.Menu.MenuCheckDocument', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <?php if($var == 1): ?>
      <div class="card" style="position:relative;bottom:10px;">
        <div class="tab-content p-3" id="nav-tabContent">

          <div class="row">
            <div class="card ViewWorkflow" style="background-color:#e9ecef;border:1px solid #ced4da;margin-left:10px;">
              <a class="btn btn-default btn-sm">
                View Workflow History
              </a>
            </div>

            <div class="card ViewDocument" style="background-color:#e9ecef;border:1px solid #ced4da;margin-left:10px;">
              <a class="btn btn-default btn-sm">
                View Document Transaction
              </a>
            </div>
          </div>

          <div class="row">
            <?php echo $__env->make('Documents.Transactions.DocumentWorkflow', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php if($businessDocumentTitle == "Advance Form"): ?>
            <?php echo $__env->make('Documents.Transactions.DocumentAdvance', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php elseif($businessDocumentTitle == "Person Business Trip Form"): ?>
            <?php echo $__env->make('Documents.Transactions.DocumentBussinesTripRequest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php elseif($businessDocumentTitle == "Purchase Requisition Form"): ?>
            <?php echo $__env->make('Documents.Transactions.DocumentPurchaseRequisition', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php elseif($businessDocumentTitle == "Purchase Order Form"): ?>
            <?php echo $__env->make('Documents.Transactions.DocumentPurchaseRequisition', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php endif; ?>

          </div>
        </div>
      </div>
      <?php endif; ?>
    </div>
  </section>
</div>
<?php echo $__env->make('Partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Documents.Functions.Footer.FooterCheckDocument', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/WebFrontEnd/resources/views/Documents/Transactions/index.blade.php ENDPATH**/ ?>