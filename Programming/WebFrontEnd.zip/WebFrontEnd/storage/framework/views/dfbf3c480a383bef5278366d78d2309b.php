<script>
    var msg = "<?php echo e(Session::get('NotFound')); ?>";
    var exist = "<?php echo e(Session::has('NotFound')); ?>";
    if(exist){
		toastr.options =
		{
			"closeButton": true,
			"debug": false,
			"newestOnTop": false,
			"progressBar": true,
			"positionClass": "toast-top-right",
			"preventDuplicates": false,
			"onclick": null,
			"showDuration": "300",
			"hideDuration": "1000",
			"timeOut": "3000",
			"extendedTimeOut": "1000",
			"showEasing": "swing",
			"hideEasing": "linear",
			"showMethod": "fadeIn",
			"hideMethod": "fadeOut"
		}
  		toastr.error("<?php echo e(session('NotFound')); ?>");
    }
</script>

<!-- toastr.success("<?php echo e(session('message')); ?>");
toastr.error("<?php echo e(session('error')); ?>");
toastr.warning("<?php echo e(session('warning')); ?>");
toastr.info("<?php echo e(session('info')); ?>"); -->
<?php /**PATH /var/www/html/WebFrontEnd/resources/views/toastr.blade.php ENDPATH**/ ?>