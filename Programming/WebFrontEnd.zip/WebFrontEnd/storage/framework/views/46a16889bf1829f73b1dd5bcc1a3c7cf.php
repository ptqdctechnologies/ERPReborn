<?php $__env->startSection('main'); ?>
<?php echo $__env->make('Partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
  #chartdiv {
    width: 100%;
    height: 500px;
  }
</style>
<div class="content-wrapper">
  <section class="content">
    <div class="container-fluid">

      <div class="row mb-1" style="background-color:#4B586A;">
        <div class="col-sm-6" style="height:30px;">
          <label style="font-size:15px;position:relative;top:7px;color:white;">Project Dashboard</label>
        </div>
      </div>
    </div>
  </section>
</div>
<?php echo $__env->make('Partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/WebFrontEnd/resources/views/Dashboard/index.blade.php ENDPATH**/ ?>